# AFRICA TALENT FOOTBALL - PROJET MOBILE ANDROID OFFICIEL

Bienvenue dans la configuration mobile Android native officielle de **Africa Talent Football**.

- **Application ID** : `com.africatalentfootball.app`
- **Nom officiel** : Africa Talent Football
- **Nom court** : Africa Talent Football
- **Description** : International Football Talent Network
- **Direction & Fondateur** : TRAORÉ SEYDOU, Directeur Fondateur – Agent Scout
- **Email** : mariosemario6@gmail.com
- **WhatsApp Direct** : +2250544420162
- **Application Live** : https://africa-talent-football.ai.studio/
- **Version** : 1.0.0 (versionCode: 1)
- **SDK Configuration** : compileSdk 36, targetSdk 36, minSdk 24
- **Toolchain** : Android Gradle Plugin 8.7.3, Gradle 8.10.2, Kotlin 2.0.21, Java 17

---

## 📱 Architecture & Fonctionnalités Incluses

1. **Expérience 100% Native Android** :
   - Écran de démarrage officiel (Android 12+ Splash Screen API) avec logo ATF
   - WebView sécurisée avec accélération matérielle et gestion de mémoire cache
   - Prise en charge du bouton Retour physique / gestuel Android
   - Barre de navigation mobile tactile ergonomique (`AndroidBottomBar`)
   - Gestion des orientations Portrait et Paysage (idéal pour visionner les vidéos de match 90 min)
   - Support d'upload de fichiers (CV, passeports sportifs, vidéos, rapports de détection)
   - Redirection automatique intelligente vers les applications natives (WhatsApp pour le desk Mario Traoré, Appels téléphoniques, Emails)
   - Mode Hors-Ligne automatique avec écran élégant et bouton Réessayer
   - Gestuel Pull-To-Refresh pour recharger instantanément les données en direct

2. **Multilingue Intégral** :
   - Les 10 langues mondiales (Français, English, Español, Português, Italiano, Deutsch, العربية RTL, 中文, Русский, Türkçe) fonctionnent à 100% sur mobile.

---

## 🛠️ Comment Tester l'Application sur Android

### Option A : Test Immédiat via l'application Web PWA (Sans installer Android Studio)
1. Ouvrez l'URL de votre application sur le navigateur Chrome de votre téléphone Android.
2. Appuyez sur le bouton **« Installer Maintenant »** dans le bandeau ou dans le menu.
3. L'application s'installe directement sur l'écran d'accueil de votre téléphone avec l'icône officielle ATF et fonctionne en plein écran comme une application du Play Store.

### Option B : Compilation du Fichier APK / AAB avec Android Studio
1. Ouvrez **Android Studio**.
2. Cliquez sur **Open** et sélectionnez le dossier `android` de ce projet.
3. Android Studio synchronise automatiquement Gradle.
4. Pour tester immédiatement :
   - Branchez votre smartphone Android en mode débogage USB (ou lancez un émulateur).
   - Cliquez sur le bouton vert **Run ▶** (app).
5. Pour générer le fichier APK de test :
   - Menu **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
   - Le fichier `app-debug.apk` est généré dans `android/app/build/outputs/apk/debug/`.
   - Transférez-le sur votre téléphone et installez-le en un clic.

---

## 📦 Génération du Fichier Release pour Google Play (AAB)

Google Play exige désormais le format **Android App Bundle (.aab)** :
1. Dans Android Studio, allez dans :
   **Build** > **Generate Signed Bundle / APK...**
2. Sélectionnez **Android App Bundle**.
3. Choisissez le fichier keystore situé dans `android/keystore/release.keystore` (ou généré via `android/keystore/generate-keystore.sh`).
4. Choisissez la variante **release**.
5. Cliquez sur **Create**.
6. Le fichier `app-release.aab` est généré, prêt à être déposé sur la Google Play Console !

---

## 📋 Étapes Restantes avant la Publication sur Google Play

1. **Créer un compte Développeur Google Play** (25$ frais uniques à vie sur https://play.google.com/console).
2. **Créer une nouvelle application** :
   - Nom : `AFRICA TALENT FOOTBALL`
   - Langue par défaut : Français (avec prise en charge des 10 langues)
   - Catégorie : Sports
3. **Fiche Play Store** :
   - Titre court : `Africa Talent Football`
   - Description courte : `International Football Talent Network`
   - Description complète : Présentation officielle de la plateforme et de la direction technique de Seydou Mario Traoré.
   - Captures d'écran de l'application (téléphone, tablette 7 pouces, tablette 10 pouces).
4. **Politique de Confidentialité & Déclaration des contenus** :
   - Lien vers la politique de confidentialité (déjà présente dans l'application : section Mentions Légales & RGPD).
   - Questionnaire d'évaluation du contenu (PEGI 3).
5. **Uploader le fichier .aab** dans la piste de Test Interne ou Production.
6. **Lancer le test interne** avec vos propres adresses email avant la validation finale par Google.
