# Proguard rules for Africa Talent Football Android App
-keepattributes *Annotation*
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.africatalentfootball.app.** { *; }
-dontwarn okio.**
-dontwarn javax.annotation.**
