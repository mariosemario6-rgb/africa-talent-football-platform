#!/bin/bash
# Script de génération du Keystore Release officiel pour Google Play
# Application : AFRICA TALENT FOOTBALL
# Package : com.africatalentfootball.app

set -e

KEYSTORE_NAME="release.keystore"
ALIAS="africatalentfootball"
VALIDITY_DAYS=10000

echo "=== Génération du Keystore de Signature Android Production ==="
echo "Application : AFRICA TALENT FOOTBALL"
echo "Alias : $ALIAS"

keytool -genkeypair -v \
  -keystore "$KEYSTORE_NAME" \
  -alias "$ALIAS" \
  -keyalg RSA \
  -keysize 2048 \
  -validity $VALIDITY_DAYS \
  -dname "CN=Seydou Mario TRAORE, O=Africa Talent Football, L=Abidjan, ST=Lagunes, C=CI"

echo ""
echo "Keystore généré avec succès dans : $(pwd)/$KEYSTORE_NAME"
echo "Empreinte SHA-256 pour Google Play Console :"
keytool -list -v -keystore "$KEYSTORE_NAME" -alias "$ALIAS" | grep "SHA256:"
