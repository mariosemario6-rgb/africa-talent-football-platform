# ⚽ AFRICA TALENT FOOTBALL — Plateforme Internationale & Mobile

> **Plateforme Professionnelle de Détection, Recrutement et Valorisation du Football Africain**  
> Direction & Supervision Technique : **Seydou Mario TRAORÉ** (Agent Scout – Directeur Fondateur)  
> Siège & Réseau : Abidjan (Côte d'Ivoire) · Liège · Lens · Europe & Monde

---

## 📋 Table des Matières

1. [Vue d'Ensemble & Architecture](#-vue-densemble--architecture)
2. [Fonctionnalités Principales](#-fonctionnalités-principales)
3. [Structure Complète du Projet](#-structure-complète-du-projet)
4. [Prérequis & Installation Locale](#-prérequis--installation-locale)
5. [Commandes Disponibles](#-commandes-disponibles)
6. [Déploiement Web en Ligne (Vercel, Netlify, Firebase)](#-déploiement-web-en-ligne)
7. [Projet Mobile Android & Compilation APK Automatisée](#-projet-mobile-android)
8. [Guide de Transfert vers GitHub (PC & Smartphone Android)](#-guide-de-transfert-vers-github)
9. [Sécurité & Variables d'Environnement](#-sécurité--variables-denvironnement)

---

## 🏗️ 1. Vue d'Ensemble & Architecture

La plateforme **Africa Talent Football** est une solution complète combinant :

* **Web App SPA (Single Page Application)** ultra-rapide construite avec **React 19**, **TypeScript** et **Vite**.
* **Design & UI Professionnel** propulsé par **Tailwind CSS v4**, avec thématique sombre haute performance, typographie sportive et animations fluides (`motion`, `lucide-react`).
* **Visualisations & Data Scouting** avec **D3.js** (Radar physique 6 axes, graphiques de statistiques GPS, vitesse max, précision de passe).
* **Moteur d'Évaluation Marchande** algorithmique certifié pour les transferts et la cotation des jeunes talents.
* **Système Multilingue Intégral 10 Langues** (Français, Anglais, Espagnol, Portugais, Italien, Allemand, Arabe RTL, Chinois, Russe, Turc) couvrant 100 % de l'application (619 clés traduites sans aucun texte codé en dur).
* **Progressive Web App (PWA)** avec Service Worker, manifeste (`manifest.webmanifest`), icônes haute résolution et installation 1-clic sur mobile.
* **Projet Android Natif (`./android`)** autonome (package `com.africatalentfootball.app`), prêt pour Android Studio et le Google Play Store.
* **Pipeline CI/CD GitHub Actions (`.github/workflows/build-apk.yml`)** pour compiler et télécharger les APKs (Debug & Release) automatiquement à chaque push sans installer Android Studio.

---

## 🌟 2. Fonctionnalités Principales

* **Base de Données Talents & Filtres Avancés** : Recherche par poste, pied fort, pays, tranche d'âge, statut contractuel, vitesse GPS et valeur marchande.
* **Fiches Joueurs Certifiées & Vidéos 90 min** : Archivage de séquences complètes de matches et rapports physiques certifiés.
* **Réseau Professionnel & Fil d'Actualités B2B (Feed)** : Échanges entre clubs européens, académies africaines, agents FIFA et recruteurs.
* **Messagerie Directe Sécurisée & Tiroir QuickChat** : Discussions en temps réel entre clubs, scouts et le desk de direction.
* **Centre d'Intelligence Partenaires (Realtime Partner Hub)** : Appels d'offres mercatos, cautions bancaires FIFA Article 19 et bourses d'études.
* **Espace Direction Fondateur & Profil Administrateur** : Présentation institutionnelle de Seydou Mario TRAORÉ, formulaire de sollicitation WhatsApp officiel et gestion de photo de profil avec recadrage dynamique.
* **Calculateur de Valorisation Marchande (Market Valuation)** : Algorithme intégrant âge, vitesse de pointe, ratio buts/passes, statut international et potentiel de revente.
* **Générateur de QR Code Téléphone** : Partage instantané du lien officiel sur smartphones via scan caméra.

---

## 📁 3. Structure Complète du Projet

```text
africa-talent-football/
├── .github/
│   └── workflows/
│       └── build-apk.yml              # CI/CD GitHub Actions : compilation automatique APK
├── android/                           # Projet Android Natif complet (Gradle wrapper, manifests)
│   ├── app/
│   │   ├── build.gradle               # Configuration Gradle de l'application mobile
│   │   ├── proguard-rules.pro
│   │   └── src/main/
│   │       ├── AndroidManifest.xml    # Permissions réseau, icônes, intent filters
│   │       ├── java/com/africatalentfootball/app/
│   │       │   └── MainActivity.kt    # WebView native optimisée, PWA bridge, offline cache
│   │       └── res/                   # Drawables, layouts, valeurs XML (strings.xml)
│   ├── keystore/
│   │   └── generate-keystore.sh       # Script de création sécurisée de clé de signature
│   ├── build.gradle
│   ├── settings.gradle
│   ├── gradle-wrapper.properties
│   └── README.md                      # Documentation dédiée Android
├── public/                            # Fichiers statiques servis à la racine
│   ├── favicon.ico
│   ├── icon.svg
│   ├── apple-touch-icon.png
│   ├── pwa-192x192.png
│   ├── pwa-512x512.png
│   ├── manifest.webmanifest          # Configuration Progressive Web App
│   ├── sw.js                         # Service Worker PWA (mise en cache hors-ligne)
│   ├── robots.txt
│   ├── sitemap.xml
│   └── founder_africa_talent.jpg      # Photo officielle du fondateur
├── src/                               # Code source TypeScript / React
│   ├── assets/images/                 # Photos joueurs, héros, stades
│   ├── components/
│   │   ├── common/                    # Modales, Navbar, Tiroir, QR Code, Partage
│   │   ├── stats/                     # Graphiques D3.js radar et barres
│   │   ├── talent/                    # Cartes talents, fiches détaillées
│   │   └── tactical/                  # Tableaux tactiques
│   ├── context/                       # Gestion globale d'état (Auth, Langues, Joueurs, Réseau, Paiement)
│   │   ├── AuthContext.tsx
│   │   ├── LanguageContext.tsx        # Moteur 10 langues avec détection et RTL
│   │   ├── NetworkContext.tsx
│   │   ├── PaymentContext.tsx
│   │   ├── PlayerContext.tsx
│   │   └── PushNotificationContext.tsx
│   ├── data/                          # Données certifiées (clubs, joueurs, partenaires, calendrier)
│   ├── hooks/                         # Hooks réutilisables (usePWAInstall, etc.)
│   ├── pages/                         # Pages de l'application
│   │   ├── Home.tsx                   # Accueil officiel
│   │   ├── Founder.tsx                # Page officielle Seydou Mario TRAORÉ
│   │   ├── Auth/                      # Connexion, Inscription, Mon Profil
│   │   ├── Dashboards/                # Tableaux de bord recruteurs / clubs
│   │   ├── Download/                  # Centre de téléchargement Stores & APK
│   │   ├── Matches/                   # Calendriers et scores
│   │   ├── Network/                   # Fil réseau, annuaire et messagerie
│   │   ├── Pricing/                   # Abonnements & services VIP
│   │   └── Search/                    # Moteur de recherche avancé
│   ├── translations/                  # Dictionnaires complets des 10 langues
│   ├── types/                         # Types TypeScript (RegisteredPlayer, User, etc.)
│   ├── utils/                         # Calculateurs, cryptographie, compression image
│   ├── App.tsx                        # Composant racine et routage
│   ├── main.tsx                       # Point d'entrée React 19
│   └── index.css                      # Configuration Tailwind CSS v4
├── .env.example                       # Exemple de configuration des variables d'environnement
├── .gitignore                         # Exclusions de sécurité (secrets, keystores, build)
├── firebase-blueprint.json            # Schéma Firestore pour persistance cloud
├── firestore.rules                    # Règles de sécurité Firestore
├── index.html                         # Point d'entrée HTML avec métadonnées SEO
├── package.json                       # Dépendances et scripts npm
├── tsconfig.json                      # Configuration du compilateur TypeScript
└── vite.config.ts                     # Configuration du bundler Vite et plugin PWA
```

---

## 💻 4. Prérequis & Installation Locale

### Prérequis
* **Node.js** version 18 ou supérieure (recommandé : Node.js 20 LTS ou 22 LTS).
* Gestionnaire de paquets : **npm**, **pnpm**, **yarn** ou **bun**.

### Installation pas à pas

1. **Cloner ou décompresser le projet** dans le dossier de votre choix :
   ```bash
   cd africa-talent-football
   ```

2. **Installer toutes les dépendances** :
   ```bash
   npm install
   ```

3. **Créer le fichier d'environnement local** :
   ```bash
   cp .env.example .env
   ```

4. **Lancer le serveur de développement local** :
   ```bash
   npm run dev
   ```
   L'application s'ouvre sur `http://localhost:3000`.

---

## ⚡ 5. Commandes Disponibles

| Commande | Action |
| :--- | :--- |
| `npm run dev` | Démarre le serveur local de développement Vite sur le port 3000 |
| `npm run build` | Compile l'application TypeScript et génère les fichiers optimisés dans `dist/` |
| `npm run preview` | Prévisualise localement le build de production généré dans `dist/` |
| `npm run lint` | Exécute la vérification TypeScript stricte (`tsc --noEmit`) |
| `npm run clean` | Nettoie les dossiers de compilation |
| `npm run android:status` | Affiche l'état de configuration du projet Android natif |

---

## 🚀 6. Déploiement Web en Ligne

Le projet est conçu pour être déployé en 1 clic sur les principaux hébergeurs mondiaux grâce à son bundle statique optimisé :

### Option 1 : Vercel (Recommandé, Gratuit, Déploiement en 60 secondes)
1. Créez un compte sur [vercel.com](https://vercel.com) avec votre compte GitHub.
2. Cliquez sur **« Add New Project »** et importez votre dépôt GitHub `africa-talent-football`.
3. Vercel détecte automatiquement **Vite** :
   * **Framework Preset** : `Vite`
   * **Build Command** : `npm run build`
   * **Output Directory** : `dist`
4. Cliquez sur **« Deploy »**. Votre plateforme est immédiatement en ligne avec HTTPS et CDN mondial.

### Option 2 : Netlify
1. Connectez-vous sur [netlify.com](https://netlify.com).
2. Cliquez sur **« Import from Git »** > GitHub.
3. Paramètres de compilation :
   * Build command : `npm run build`
   * Publish directory : `dist`
4. Cliquez sur **« Deploy Site »**.

### Option 3 : GitHub Pages
Grâce aux scripts de build standard, vous pouvez également déployer le dossier `dist/` sur la branche `gh-pages` ou via GitHub Actions.

---

## 📱 7. Projet Mobile Android & Compilation Automatisée

Le dossier `android/` contient un projet complet développé sous Android Gradle Plugin.

### Option A : Compilation Automatique via GitHub Actions (Sans rien installer !)
Dès que vous poussez le projet sur GitHub :
1. Allez dans l'onglet **« Actions »** de votre dépôt GitHub.
2. Le workflow **« Build Android APK »** s'exécute automatiquement.
3. Une fois terminé (environ 2-3 minutes), descendez dans la section **Artifacts** et téléchargez :
   * `app-debug-apk` : Fichier APK directement installable sur n'importe quel smartphone Android.
   * `app-release-apk` : Version de production signée prête pour distribution.

### Option B : Compilation Locale avec Android Studio
1. Ouvrez **Android Studio**.
2. Choisissez **« Open »** et sélectionnez le dossier `android/` du projet.
3. Laissez Gradle synchroniser les dépendances.
4. Menu **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.

---

## 📤 8. Guide de Transfert vers GitHub (PC & Smartphone Android)

### Méthode 1 — Depuis un Ordinateur (Terminal Git)

```bash
# 1. Initialiser Git si ce n'est pas déjà fait
git init -b main

# 2. Configurer vos identifiants
git config user.name "Seydou Mario TRAORÉ"
git config user.email "mariosemario6@gmail.com"

# 3. Ajouter tous les fichiers
git add .

# 4. Créer le commit officiel
git commit -m "feat: initial commit Africa Talent Football complete platform"

# 5. Lier votre dépôt GitHub distant
git remote add origin https://github.com/VOTRE_COMPTE/africa-talent-football.git

# 6. Pousser vers GitHub
git push -u origin main
```

### Méthode 2 — Depuis un Smartphone Android (Sans Ordinateur !)

Vous pouvez administrer et pousser votre projet directement depuis votre téléphone Android :

1. **Via le site web GitHub (Google Chrome mobile)** :
   * Ouvrez [github.com](https://github.com) sur Chrome Mobile et activez **« Version pour ordinateur »**.
   * Créez un nouveau dépôt vide nommé `africa-talent-football`.
   * Téléchargez l'archive complète du projet (disponible via le lien d'export).
   * Décompressez-la avec l'application « Fichiers » ou « RAR » / « ZArchiver ».
   * Dans GitHub, cliquez sur **« Uploading an existing file »**, glissez les dossiers et validez le commit.

2. **Via l'application Termux sur Android** :
   * Installez l'application **Termux** (disponible sur F-Droid).
   * Exécutez :
     ```bash
     pkg update && pkg install git nodejs
     cd /sdcard/Download/africa-talent-football
     git init -b main
     git add .
     git commit -m "Africa Talent Football complete release"
     git remote add origin https://github.com/VOTRE_COMPTE/africa-talent-football.git
     git push -u origin main
     ```

---

## 🔐 9. Sécurité & Variables d'Environnement

* Le fichier `.gitignore` protège de manière stricte vos clés privées :
  * Les fichiers `.env`, `.env.local` ne sont jamais envoyés sur Git.
  * Les keystores de signature Android (`*.keystore`, `*.jks`, `*.key`) sont strictement exclus.
* Pour les clés d'API (ex. Google Gemini API), renseignez-les dans le fichier local `.env` ou dans les secrets de votre hébergeur (Vercel Secrets, Netlify Environment Variables, GitHub Actions Secrets).

---

*Plateforme officielle Africa Talent Football — Tous droits réservés.*
