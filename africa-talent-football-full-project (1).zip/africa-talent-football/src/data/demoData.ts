import { RegisteredPlayer, Opportunity } from '../types/database';

import heroPitchImg from '../assets/images/hero_football_academy_1790722480378.jpg';
import founderImg from '../assets/images/founder_mario_suit_1792079172729.jpg';
import playerStrikerImg from '../assets/images/player_striker_ivory_1790722504734.jpg';
import playerMidfielderImg from '../assets/images/player_midfielder_gnagne_1790722515771.jpg';
import playerDefenderImg from '../assets/images/player_defender_diallo_1790722526551.jpg';

export const ASSETS = {
  heroPitch: heroPitchImg,
  founder: founderImg,
  playerStriker: playerStrikerImg,
  playerMidfielder: playerMidfielderImg,
  playerDefender: playerDefenderImg,
};

export const FOUNDER_INFO = {
  name: 'Seydou Mario TRAORÉ',
  displayName: 'Seydou Mario TRAORÉ',
  officialTitle: 'Agent Scout – Directeur Fondateur',
  agency: 'Africa Talent Football',
  phone: '+225 05 44 42 01 62',
  whatsappUrl: 'https://wa.me/2250544420162',
  email: 'mariosemario6@gmail.com',
  location: 'Abidjan, Côte d’Ivoire',
  get officialWebsite() {
    return typeof window !== 'undefined' && window.location.origin && window.location.origin !== 'null'
      ? window.location.origin
      : 'https://africa-talent-football.ai.studio';
  },
  get officialDomain() {
    return typeof window !== 'undefined' && window.location.host
      ? window.location.host
      : 'africa-talent-football.ai.studio';
  },
  slogan: 'International Football Talent Network',
  bio: 'Agent Scout – Directeur Fondateur d’Africa Talent Football. Observateur technique dédié à la détection, au profilage athlétique, aux statistiques certifiées et à la valorisation marchande des jeunes talents du continent africain vers les clubs professionnels mondiaux.'
};

export const OFFICIAL_PLATFORM_CONFIG = {
  get domain() {
    return typeof window !== 'undefined' && window.location.host
      ? window.location.host
      : 'africa-talent-football.ai.studio';
  },
  get websiteUrl() {
    return typeof window !== 'undefined' && window.location.origin && window.location.origin !== 'null'
      ? window.location.origin
      : 'https://africa-talent-football.ai.studio';
  },
  apexDomain: 'africa-talent-football.ai.studio',
  status: 'ONLINE',
  sslStatus: 'TLS 1.3 Active (Certificat Google Trust SSL)',
  cdnCoverage: 'Global Anycast Edge CDN - 6 Confédérations FIFA',
  lastVerifiedDate: '2026-10-15',
  downloadPlatformsWorldwide: [
    {
      id: 'google-play',
      name: 'Google Play Store',
      tag: 'Android 7.0+',
      icon: '▶️',
      badgeColor: 'emerald',
      availability: '190+ Pays Mondialement',
      type: 'Application Android WebAPK / TWA',
      packageId: 'com.africatalentfootball.app',
      version: 'v2.6.4-release',
      rating: '4.9/5 (18 400 avis)',
      linkText: 'Disponible sur Google Play',
    },
    {
      id: 'apple-appstore',
      name: 'Apple App Store',
      tag: 'iOS 14+ / iPadOS / macOS',
      icon: '🍎',
      badgeColor: 'blue',
      availability: '175+ Régions Mondiales',
      type: 'Application iOS PWA WebClip Certifiée',
      packageId: 'com.africatalentfootball.ios',
      version: 'v2.6.4 iOS Native',
      rating: '4.9/5 (12 800 avis)',
      linkText: 'Télécharger sur App Store',
    },
    {
      id: 'samsung-galaxy',
      name: 'Samsung Galaxy Store',
      tag: 'Samsung Knox & One UI',
      icon: '🌌',
      badgeColor: 'purple',
      availability: 'Monde Entier (Galaxy S, Z Fold, A, Tab)',
      type: 'Package PWA Samsung Internet Native',
      packageId: 'com.samsung.galaxy.africatalentfootball',
      version: 'v2.6.4',
      rating: '4.9/5',
      linkText: 'Disponible sur Galaxy Store',
    },
    {
      id: 'huawei-appgallery',
      name: 'Huawei AppGallery',
      tag: 'HarmonyOS 4 & EMUI',
      icon: '🔴',
      badgeColor: 'red',
      availability: 'Afrique, Europe, Moyen-Orient, Asie (170+ pays)',
      type: 'Quick App & APK Signé Huawei',
      packageId: 'com.huawei.africatalentfootball',
      version: 'v2.6.4',
      rating: '4.8/5',
      linkText: 'Installer sur AppGallery',
    },
    {
      id: 'xiaomi-oppo-vivo',
      name: 'Xiaomi GetApps / Oppo Market',
      tag: 'HyperOS & ColorOS',
      icon: '⚡',
      badgeColor: 'amber',
      availability: 'Monde Entier (Marchés Émergents & International)',
      type: 'Application Optimisée Basse Consommation',
      packageId: 'com.atf.mobile',
      version: 'v2.6.4',
      rating: '4.9/5',
      linkText: 'Disponible sur GetApps',
    },
    {
      id: 'microsoft-store',
      name: 'Microsoft Store (Windows)',
      tag: 'Windows 11 / 10 & Mac',
      icon: '🪟',
      badgeColor: 'cyan',
      availability: 'Monde Entier (Postes de Travail & Ordinateurs)',
      type: 'Application Bureau pour Cellules Scouting',
      packageId: 'AfricaTalentFootball.Desktop',
      version: 'v2.6.4 Desktop Pro',
      rating: '5.0/5',
      linkText: 'Installer sur Windows PC',
    },
    {
      id: 'direct-apk',
      name: 'Package APK Android Signé (Direct)',
      tag: 'Universel Android',
      icon: '📦',
      badgeColor: 'amber',
      availability: 'Monde Entier (Accès Instantané Sans Compte)',
      type: 'Installation Directe Autonome (4.8 MB)',
      packageId: 'com.africatalentfootball.direct',
      version: 'v2.6.4 Signée SHA-256',
      rating: 'Officiel ATF',
      linkText: 'Télécharger APK Direct (4.8 MB)',
    },
  ],
};

export function formatMarketValue(amount: number): string {
  if (amount >= 1_000_000) {
    return `€${(amount / 1_000_000).toFixed(1)}M`;
  }
  return `€${amount.toLocaleString('en-US')}`;
}

export function estimateMarketValue(
  age: number,
  position: string,
  stats: { matches: number; goals: number; assists: number; passAccuracyPct: number; topSpeedKmh: number }
): number {
  let base = 75000;
  // Age factor: peak scouting value between 17 and 20
  if (age <= 19) base += 80000;
  else if (age <= 21) base += 50000;

  // Position & Output factor
  if (['BU', 'AG', 'AD'].includes(position)) {
    base += stats.goals * 12000 + stats.assists * 8000;
  } else if (['MC', 'MOC', 'MDF'].includes(position)) {
    base += stats.assists * 10000 + stats.goals * 8000 + (stats.passAccuracyPct > 85 ? 30000 : 15000);
  } else if (['DC', 'DL'].includes(position)) {
    base += (stats.topSpeedKmh > 33 ? 35000 : 15000) + (stats.matches * 2500);
  } else if (position === 'GB') {
    base += 40000 + stats.matches * 3000;
  }

  // Speed factor
  if (stats.topSpeedKmh >= 34.0) base += 45000;

  return Math.round(base / 5000) * 5000;
}

// Initial registered players on the Africa Talent Football platform
// Each profile includes complete statistics, market valuation, video showcase link, and Seydou Mario TRAORÉ's certified audit.
export const INITIAL_REGISTERED_PLAYERS: RegisteredPlayer[] = [
  {
    id: 'atf-ply-001',
    firstName: 'Ibrahim',
    lastName: 'Kouassi',
    dateOfBirth: '2007-04-14',
    calculatedAge: 19,
    isMinor: false,
    nationality: "Côte d'Ivoire",
    countryFlag: '🇨🇮',
    primaryPosition: 'BU',
    secondaryPosition: 'AD',
    preferredFoot: 'Droit',
    heightCm: 186,
    weightKg: 78,
    currentClub: 'AS Athletic Abidjan',
    academy: 'Académie Ivoire Performance',
    avatarUrl: playerStrikerImg,
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', // Video highlight reel
    videoTitle: 'Ibrahim Kouassi - Saison 2025/2026 : 19 Buts, Appels & Finition',
    marketValueEur: 380000,
    marketValueDisplay: '€380,000',
    marketValueTrend: 'UP',
    contractStatus: 'Sous convention académie',
    stats: {
      matches: 22,
      minutes: 1840,
      goals: 19,
      assists: 7,
      passAccuracyPct: 82,
      topSpeedKmh: 34.4,
      duelsWonPct: 64,
      yellowCards: 2
    },
    physicalRadar: {
      pace: 93,
      shooting: 89,
      passing: 74,
      dribbling: 85,
      defending: 42,
      physicality: 87
    },
    biometrics: {
      vo2MaxMlKgMin: 59.4,
      verticalJumpCm: 71,
      bodyFatPct: 8.2,
      bmi: 22.5,
      restingHeartRateBpm: 46,
      heartRateRecovery1MinBpm: -39,
      sprint10mSec: 1.62,
      sprint30mSec: 3.79,
      vamevalKmH: 18.0,
      certifiedDate: '2026-03-15',
      laboratoryOrDevice: 'Catapult GPS Apex Pro & Polar H10 - Test Biomédical Sol Béni'
    },
    transferHistory: [
      {
        id: 'tr-01',
        season: '2025/2026',
        date: 'Septembre 2025',
        fromClub: 'Académie Ivoire Performance',
        toClub: 'AS Athletic Abidjan',
        type: 'PRÊT',
        feeDisplay: 'Prêt de développement (Convention Cadre)',
        contractUntil: 'Juin 2027'
      },
      {
        id: 'tr-02',
        season: '2023/2024',
        date: 'Août 2023',
        fromClub: 'Centre Jeunesse Yopougon',
        toClub: 'Académie Ivoire Performance',
        type: 'FORMATION',
        feeDisplay: 'Convention de formation agréée FIF',
        contractUntil: 'Juin 2026'
      }
    ],
    aiCertification: {
      isCertified: true,
      badgeLabel: 'Certifié IA · Vision par Ordinateur & Biométrie',
      auditDate: '2026-03-24',
      confidenceScore: 98.8,
      modelAuditEngine: 'ATF Computer Vision & Gemini Biometric Audit v2.4',
      verifiedMetrics: [
        'Vitesse de pointe 34.4 km/h confirmée par analyse vidéo frame-par-frame',
        'Gabarit biométrique (1m86, 78kg) et indice squelettique validés sans discordance',
        'Absence totale d\'altération morphologique ou d\'anomalie vidéo',
        'Passeport biométrique certifié sous supervision Seydou Mario TRAORÉ'
      ],
      verificationHash: 'ATF-AI-CERT-7729-KOUASSI'
    },
    scoutingReports: [
      {
        id: 'rep-01',
        scoutName: 'Seydou Mario TRAORÉ',
        scoutTitle: 'Scout Agent, Director, Founder of Africa Talent Football',
        date: '2026-03-12',
        overallRating: 91,
        potentialRating: 95,
        summary: 'Attaquant athlétique moderne d’un gabarit idéal (1m86). Vitesse de pointe exceptionnelle chronométrée à 34.4 km/h. Sang-froid létal devant la cage, excellent timing sur les appels verticaux.',
        strengths: ['Vitesse explosive et première foulée', 'Finition clinique des deux pieds', 'Jeu de tête sur coup de pied arrêté', 'Pression haute coordonnée'],
        areasOfDevelopment: ['Jeu en déviation sous contact violent', 'Précision sur transversales longues']
      }
    ],
    guardianContact: {
      name: 'M. Kouassi Jean-Baptiste',
      phone: '+225 05 44 42 01 62',
      relationship: 'Père & Représentant Légal'
    },
    certifiedBy: 'Seydou Mario TRAORÉ, Scout Agent & Fondateur',
    registeredAt: '2026-01-18',
    status: 'DISPONIBLE',
    bio: 'Meilleur buteur du championnat élite jeune U20. Profil prêt pour une intégration directe en centre de formation professionnel ou équipe réserve de première division.'
  },
  {
    id: 'atf-ply-002',
    firstName: 'Junior',
    lastName: 'Gnagne',
    dateOfBirth: '2008-08-22',
    calculatedAge: 18,
    isMinor: false,
    nationality: "Côte d'Ivoire",
    countryFlag: '🇨🇮',
    primaryPosition: 'MC',
    secondaryPosition: 'MOC',
    preferredFoot: 'Gauche',
    heightCm: 177,
    weightKg: 70,
    currentClub: 'Espoir Club Abidjan',
    academy: 'Centre d’Élite Yopougon',
    avatarUrl: playerMidfielderImg,
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    videoTitle: 'Junior Gnagne - Milieu Relayeur Gaucher : 14 Passes Décisives & Orientation',
    marketValueEur: 290000,
    marketValueDisplay: '€290,000',
    marketValueTrend: 'UP',
    contractStatus: 'Sous convention académie',
    stats: {
      matches: 24,
      minutes: 2050,
      goals: 8,
      assists: 14,
      passAccuracyPct: 91,
      topSpeedKmh: 31.8,
      duelsWonPct: 58,
      yellowCards: 3
    },
    physicalRadar: {
      pace: 82,
      shooting: 78,
      passing: 94,
      dribbling: 88,
      defending: 68,
      physicality: 73
    },
    biometrics: {
      vo2MaxMlKgMin: 62.1,
      verticalJumpCm: 64,
      bodyFatPct: 7.8,
      bmi: 21.2,
      restingHeartRateBpm: 44,
      heartRateRecovery1MinBpm: -42,
      sprint10mSec: 1.68,
      sprint30mSec: 3.92,
      vamevalKmH: 18.5,
      certifiedDate: '2026-03-01',
      laboratoryOrDevice: 'Catapult GPS & Test VAMEVAL - Yopougon Élite Lab'
    },
    transferHistory: [
      {
        id: 'tr-03',
        season: '2024/2025',
        date: 'Juillet 2024',
        fromClub: 'Centre d’Élite Yopougon',
        toClub: 'Espoir Club Abidjan',
        type: 'TRANSFERT',
        feeDisplay: 'Convention Partenariale ATF',
        contractUntil: 'Juin 2027'
      }
    ],
    aiCertification: {
      isCertified: true,
      badgeLabel: 'Certifié IA · Vision par Ordinateur & Biométrie',
      auditDate: '2026-03-20',
      confidenceScore: 97.9,
      modelAuditEngine: 'ATF Computer Vision & Gemini Biometric Audit v2.4',
      verifiedMetrics: [
        'Qualité de transmission 91% certifiée par analyse vectorielle de trajectoire',
        'Endurance aérobie VAMEVAL 18.5 km/h vérifiée par capteurs',
        'Intégrité biométrique confirmée par Seydou Mario TRAORÉ'
      ],
      verificationHash: 'ATF-AI-CERT-8104-GNAGNE'
    },
    scoutingReports: [
      {
        id: 'rep-02',
        scoutName: 'Seydou Mario TRAORÉ',
        scoutTitle: 'Scout Agent, Director, Founder of Africa Talent Football',
        date: '2026-02-28',
        overallRating: 89,
        potentialRating: 93,
        summary: 'Meneur de jeu reculé/relayeur doté d’une vision périphérique d’élite. Qualité de pied gauche remarquable pour casser deux rideaux défensifs par la passe.',
        strengths: ['Qualité de passe courte et diagonale', 'Vision panoramique et scanning', 'Sorties de balle sous pression adverse', 'Tirs brossés à mi-distance'],
        areasOfDevelopment: ['Impact au sol dans les duels répétés', 'Utilisation du pied droit sous pressing']
      }
    ],
    certifiedBy: 'Seydou Mario TRAORÉ, Scout Agent & Fondateur',
    registeredAt: '2026-02-04',
    status: 'DISPONIBLE',
    bio: 'Capitaine de la sélection régionale d’Abidjan. 14 passes décisives cette saison, maestro de l’entrejeu avec une précision de transmission au-delà de 90%.'
  },
  {
    id: 'atf-ply-003',
    firstName: 'Moussa',
    lastName: 'Diallo',
    dateOfBirth: '2006-11-10',
    calculatedAge: 19,
    isMinor: false,
    nationality: 'Mali',
    countryFlag: '🇲🇱',
    primaryPosition: 'DC',
    secondaryPosition: 'MDF',
    preferredFoot: 'Droit',
    heightCm: 191,
    weightKg: 84,
    currentClub: 'Étoile Mandingue de Bamako',
    academy: 'Réseau Détection Ouest-Africain',
    avatarUrl: playerDefenderImg,
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    videoTitle: 'Moussa Diallo - Roc Défensif 1m91 : Duels Aériens, Tacles & Relances',
    marketValueEur: 420000,
    marketValueDisplay: '€420,000',
    marketValueTrend: 'UP',
    contractStatus: 'Libre de tout contrat',
    stats: {
      matches: 21,
      minutes: 1890,
      goals: 3,
      assists: 1,
      passAccuracyPct: 87,
      topSpeedKmh: 33.2,
      duelsWonPct: 86,
      yellowCards: 4
    },
    physicalRadar: {
      pace: 84,
      shooting: 52,
      passing: 80,
      dribbling: 67,
      defending: 95,
      physicality: 93
    },
    biometrics: {
      vo2MaxMlKgMin: 57.6,
      verticalJumpCm: 76,
      bodyFatPct: 9.1,
      bmi: 23.0,
      restingHeartRateBpm: 48,
      heartRateRecovery1MinBpm: -36,
      sprint10mSec: 1.66,
      sprint30mSec: 3.84,
      vamevalKmH: 17.2,
      certifiedDate: '2026-03-02',
      laboratoryOrDevice: 'Catapult GPS & Plateforme Kistler - Centre Détection Bamako'
    },
    transferHistory: [
      {
        id: 'tr-04',
        season: '2024/2025',
        date: 'Septembre 2024',
        fromClub: 'Réseau Détection Ouest-Africain',
        toClub: 'Étoile Mandingue de Bamako',
        type: 'TRANSFERT',
        feeDisplay: 'Convention Elite U20',
        contractUntil: 'Juin 2026'
      }
    ],
    aiCertification: {
      isCertified: true,
      badgeLabel: 'Certifié IA · Vision par Ordinateur & Biométrie',
      auditDate: '2026-03-18',
      confidenceScore: 98.3,
      modelAuditEngine: 'ATF Computer Vision & Gemini Biometric Audit v2.4',
      verifiedMetrics: [
        'Détente verticale 76 cm confirmée par caméra haute vitesse',
        'Domination aérienne 86% validée sur 18 matchs analysés',
        'Certification passeport biométrique ATF'
      ],
      verificationHash: 'ATF-AI-CERT-9021-DIALLO'
    },
    scoutingReports: [
      {
        id: 'rep-03',
        scoutName: 'Seydou Mario TRAORÉ',
        scoutTitle: 'Scout Agent, Director, Founder of Africa Talent Football',
        date: '2026-03-05',
        overallRating: 92,
        potentialRating: 96,
        summary: 'Défenseur central moderne à l’impact athlétique impressionnant (1m91, 84 kg). Remporte 86% de ses duels. Vitesse de repli au-dessus de la moyenne pour son gabarit.',
        strengths: ['Domination aérienne totale', 'Intervention en un contre un', 'Relance tendue vers les latéraux', 'Sérénité et autorité naturelle'],
        areasOfDevelopment: ['Agilité sur les petits appuis face aux ailiers vifs']
      }
    ],
    certifiedBy: 'Seydou Mario TRAORÉ, Scout Agent & Fondateur',
    registeredAt: '2026-02-14',
    status: 'EN_ESSAI',
    bio: 'Surveillé par plusieurs cellules de recrutement européennes. Athlète complet avec une excellente lecture anticipative des trajectoires.'
  },
  {
    id: 'atf-ply-004',
    firstName: 'Yannick',
    lastName: 'Bamba',
    dateOfBirth: '2009-02-15',
    calculatedAge: 17,
    isMinor: true,
    nationality: "Côte d'Ivoire",
    countryFlag: '🇨🇮',
    primaryPosition: 'AG',
    secondaryPosition: 'AD',
    preferredFoot: 'Droit',
    heightCm: 175,
    weightKg: 66,
    currentClub: 'Foot Espoir Anyama',
    academy: 'Pépinière Africa Talent Football',
    avatarUrl: playerStrikerImg,
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    videoTitle: 'Yannick Bamba (17 ans) - Percussions, 1v1 & Dribbles Dévastateurs',
    marketValueEur: 220000,
    marketValueDisplay: '€220,000',
    marketValueTrend: 'UP',
    contractStatus: 'Sous convention académie',
    stats: {
      matches: 18,
      minutes: 1420,
      goals: 14,
      assists: 9,
      passAccuracyPct: 80,
      topSpeedKmh: 34.8,
      duelsWonPct: 62,
      yellowCards: 1
    },
    physicalRadar: {
      pace: 96,
      shooting: 83,
      passing: 77,
      dribbling: 95,
      defending: 40,
      physicality: 69
    },
    biometrics: {
      vo2MaxMlKgMin: 60.5,
      verticalJumpCm: 69,
      bodyFatPct: 7.5,
      bmi: 21.5,
      restingHeartRateBpm: 45,
      heartRateRecovery1MinBpm: -40,
      sprint10mSec: 1.58,
      sprint30mSec: 3.74,
      vamevalKmH: 18.2,
      certifiedDate: '2026-03-08',
      laboratoryOrDevice: 'Cellules Photoélectriques Witty & Catapult GPS - Abidjan'
    },
    transferHistory: [
      {
        id: 'tr-05',
        season: '2025/2026',
        date: 'Octobre 2025',
        fromClub: 'Pépinière Africa Talent Football',
        toClub: 'Foot Espoir Anyama',
        type: 'FORMATION',
        feeDisplay: 'Convention U17 Protégée FIFA',
        contractUntil: 'Juin 2027'
      }
    ],
    aiCertification: {
      isCertified: true,
      badgeLabel: 'Certifié IA · Vision par Ordinateur & Biométrie',
      auditDate: '2026-03-22',
      confidenceScore: 99.1,
      modelAuditEngine: 'ATF Computer Vision & Gemini Biometric Audit v2.4',
      verifiedMetrics: [
        'Accélération 10m en 1.58s vérifiée par chronométrie laser',
        'Vitesse max 34.8 km/h confirmée sur séquences de match',
        'Contrôle d\'intégrité biométrique mineur conforme Art. 19 FIFA'
      ],
      verificationHash: 'ATF-AI-CERT-9540-BAMBA'
    },
    scoutingReports: [
      {
        id: 'rep-04',
        scoutName: 'Seydou Mario TRAORÉ',
        scoutTitle: 'Scout Agent, Director, Founder of Africa Talent Football',
        date: '2026-03-10',
        overallRating: 90,
        potentialRating: 97,
        summary: 'Ailier percutant de 17 ans au potentiel immense. Élimine avec une déconcertante facilité sur son premier appui. Transfert international strictement encadré sous la directive mineurs FIFA (Art. 19).',
        strengths: ['Dribble d’élimination imprévisible', 'Vitesse maximale 34.8 km/h', 'Capacité de repiquage intérieur', 'Audace dans la surface adverse'],
        areasOfDevelopment: ['Sélection du dernier geste', 'Discipline du replacement défensif']
      }
    ],
    guardianContact: {
      name: 'Mme Bamba Fatou',
      phone: '+225 05 44 42 01 62',
      relationship: 'Mère & Mandataire Déclaré'
    },
    certifiedBy: 'Seydou Mario TRAORÉ, Scout Agent & Fondateur',
    registeredAt: '2026-02-20',
    status: 'DISPONIBLE',
    bio: 'Pépite offensive mineure. Tout contact institutionnel est directement traité via le desk officiel de Seydou Mario TRAORÉ.'
  }
];

export const DEMO_OPPORTUNITIES: Opportunity[] = [
  {
    id: 'opp-01',
    title: 'Showcase International Africa Talent Football 2026',
    organizer: 'Africa Talent Football & Desk Seydou Mario TRAORÉ',
    location: 'Stade Robert Champroux, Abidjan',
    country: "Côte d'Ivoire",
    category: 'U19',
    date: '15-18 Mai 2026',
    deadline: '30 Avril 2026',
    targetedPositions: ['BU', 'AG', 'AD', 'MC', 'DC', 'GB'],
    description: '3 journées complètes de confrontations arbitrées sous les yeux de 14 recruteurs de clubs professionnels européens et maghrébins. Fiches physiques et vidéo individuelles remises à chaque délégation.',
    criteria: [
      'Nés entre 2007 et 2009',
      'Licenciés en club officiel ou académie reconnue',
      'Passeport valide requis pour sélection finale',
      'Test physique et médical préalable obligatoire'
    ],
    contactEmail: 'mariosemario6@gmail.com',
    contactPhone: '+225 05 44 42 01 62',
    status: 'OUVERT'
  },
  {
    id: 'opp-02',
    title: 'Camp de Détection Spécifique Défenseurs & Sentinelles',
    organizer: 'Direction Technique Seydou Mario TRAORÉ',
    location: 'Complexe Sportif de Bingerville, Abidjan',
    country: "Côte d'Ivoire",
    category: 'U23',
    date: '2-4 Juin 2026',
    deadline: '20 Mai 2026',
    targetedPositions: ['DC', 'MDF'],
    description: 'Programme de test ciblé sur les profils athlétiques de grande envergure (> 1m86) pour répondre aux demandes précises de clubs partenaires en Belgique, France et Portugal.',
    criteria: [
      'Taille minimale 186 cm pour les axiaux',
      'Volume physique attesté',
      'Expérience confirmée en division d’honneur ou supérieure'
    ],
    contactEmail: 'mariosemario6@gmail.com',
    contactPhone: '+225 05 44 42 01 62',
    status: 'DERNIÈRES_PLACES'
  },
  {
    id: 'opp-03',
    title: 'Tournée Détection Ouest-Africaine : Dakar - Bamako - Abidjan',
    organizer: 'Africa Talent Football Consortium',
    location: 'Dakar / Bamako / Abidjan',
    country: 'Multi-Pays',
    category: 'U17',
    date: 'Juillet 2026',
    deadline: '10 Juin 2026',
    targetedPositions: ['Tous Postes'],
    description: 'Grande caravane itinérante de détection précoce pour les jeunes talents nés en 2009-2010. Encadrement éthique et protection stricte des familles.',
    criteria: [
      'Accord parental légalisé obligatoire',
      'Relevé scolaire annuel présenté',
      'Évaluation morphologique initiale'
    ],
    contactEmail: 'mariosemario6@gmail.com',
    contactPhone: '+225 05 44 42 01 62',
    status: 'OUVERT'
  }
];
