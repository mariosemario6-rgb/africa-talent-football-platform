import { RealtimePartnerUpdate } from '../types/database';

export const INITIAL_REALTIME_PARTNER_UPDATES: RealtimePartnerUpdate[] = [
  // --- CLUBS ---
  {
    id: 'rt-club-01',
    sourceType: 'CLUB',
    sourceName: 'Standard de Liège (Jupiler Pro League)',
    sourceLogo: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=100&auto=format&fit=crop&q=80',
    category: 'Mercato & Recrutement Prioritaire',
    country: 'Belgique',
    countryFlag: '🇧🇪',
    title: 'Recherche Urgente : Défenseur Central Moderne (DC) U20 pour Immersion Pro',
    summary: 'La cellule de recrutement dirigée par Jean-Luc Moreau recherche activement un profil athlétique (> 1m88), relanceur propre du pied gauche ou droit, éligible pour stage estival à l’Académie Robert Louis-Dreyfus.',
    timestamp: 'Il y a 3 min',
    urgentBadge: 'MERCATO PRIORITAIRE',
    verified: true,
    actionType: 'APPLY',
    actionLabel: 'Soumettre un Profil Joueur ➔',
    contactEmail: 'recrutement@standard.be',
    contactPhone: '+32 4 252 21 22',
    officialLink: 'https://standard.be',
    details: {
      requirements: ['Âge 17-20 ans', 'Taille minimale 1m87', 'Rapport vidéo Eyeball ou ATF certifié', 'Statistiques GPS récentes'],
      deadline: '15 Juillet 2026',
      budgetOrValuation: 'Indemnité de formation + Prime d’accession Pro',
      quotaSeats: '2 places en stage d’immersion'
    }
  },
  {
    id: 'rt-club-02',
    sourceType: 'CLUB',
    sourceName: 'ASEC Mimosas (Ligue 1 Lonaci & CAF CL)',
    sourceLogo: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=100&auto=format&fit=crop&q=80',
    category: 'Détection Officielle Sol Béni',
    country: "Côte d'Ivoire",
    countryFlag: '🇨🇮',
    title: 'Session Spéciale de Détection U17 - Ailiers & Milieux Relayeurs',
    summary: 'Organisation d’un plateau d’évaluation technique sous l’égide de la direction technique nationale. Présence confirmée de scouts mandatés par 4 clubs de Ligue 1 française et de Liga portugaise.',
    timestamp: 'Il y a 12 min',
    urgentBadge: 'DÉTECTION SOL BÉNI',
    verified: true,
    actionType: 'APPLY',
    actionLabel: 'Inscrire un Talent Agréé',
    contactEmail: 'direction@academiemimosas.ci',
    contactPhone: '+225 27 22 47 00 00',
    officialLink: 'https://asec.ci',
    details: {
      requirements: ['Nés entre 2008 et 2010', 'Licence de club ou académie enregistrée', 'Fiche médicale conforme'],
      deadline: '30 Juin 2026',
      quotaSeats: '18 candidats retenus pour la phase finale'
    }
  },
  {
    id: 'rt-club-03',
    sourceType: 'CLUB',
    sourceName: 'TP Mazembe (Linafoot & Super Ligue Africaine)',
    sourceLogo: 'https://images.unsplash.com/photo-1517466787929-bc90951d0974?w=100&auto=format&fit=crop&q=80',
    category: 'Stage & Détection Panafricaine',
    country: 'RD Congo',
    countryFlag: '🇨🇩',
    title: 'Appel à Candidatures : Buteurs & Attaquants de Rupture U19',
    summary: 'Le staff technique des Corbeaux de Lubumbashi recherche des profils offensifs explosifs avec un fort volume de courses à haute intensité pour son académie d’élite KFA.',
    timestamp: 'Il y a 28 min',
    urgentBadge: 'STAGE ÉLITE',
    verified: true,
    actionType: 'CONTACT',
    actionLabel: 'Contacter la Cellule de Recrutement',
    contactEmail: 'scouting@tpmazembe.com',
    contactPhone: '+243 99 80 00 001',
    officialLink: 'https://tpmazembe.com',
    details: {
      requirements: ['Vitesse maximale enregistrée > 33 km/h', 'Expérience en compétition nationale jeune'],
      deadline: '10 Août 2026',
      budgetOrValuation: 'Prise en charge intégrale hébergement et transport'
    }
  },
  {
    id: 'rt-club-04',
    sourceType: 'CLUB',
    sourceName: 'Wydad Athletic Club (Botola Pro & Mondial des Clubs)',
    sourceLogo: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=100&auto=format&fit=crop&q=80',
    category: 'Recrutement Mercato Estival',
    country: 'Maroc',
    countryFlag: '🇲🇦',
    title: 'Recherche Latéraux Modernes (Pied Droit / Pied Gauche) Polyvalents',
    summary: 'Dans l’optique des prochaines échéances continentales et du Mondial des Clubs FIFA, le WAC mandate Africa Talent Football pour présélectionner des latéraux alliant rigueur défensive et projection rapide.',
    timestamp: 'Il y a 45 min',
    urgentBadge: 'MONDIAL CLUBS FIFA',
    verified: true,
    actionType: 'APPLY',
    actionLabel: 'Proposer un Dossier Complet',
    contactEmail: 'direction.technique@wac.ma',
    contactPhone: '+212 522 36 00 00',
    officialLink: 'https://wac.ma',
    details: {
      requirements: ['Âge 18-22 ans', 'Volume de course supérieur à 10 km/match', 'Passeport valide'],
      deadline: '20 Juillet 2026'
    }
  },

  // --- BANKS & FINANCIAL INSTITUTIONS ---
  {
    id: 'rt-bank-01',
    sourceType: 'BANK',
    sourceName: 'Standard Chartered Bank - Sports Finance',
    sourceLogo: 'https://images.unsplash.com/photo-1541354329998-f4d9a9f9297f?w=100&auto=format&fit=crop&q=80',
    category: 'Garanties & Comptes Séquestres FIFA',
    country: 'Royaume-Uni / Afrique',
    countryFlag: '🇬🇧',
    title: 'Dispositif de Cautionnement Bancaire et Escrow Accounts pour Transferts 2026',
    summary: 'Ouverture officielle de la ligne de garantie de 15 000 000 € dédiée à la sécurisation des indemnités de formation et des mécanismes de solidarité FIFA (Article 19 et 20) au profit des académies africaines partenaires d’ATF.',
    timestamp: 'Il y a 8 min',
    urgentBadge: 'FONDS DE GARANTIE ACTIF',
    verified: true,
    actionType: 'CONTACT',
    actionLabel: 'Solliciter une Garantie Bancaire ➔',
    contactEmail: 'sports.finance@sc.com',
    contactPhone: '+44 20 7885 8888',
    officialLink: 'https://sc.com/sports-finance',
    details: {
      requirements: ['Contrat d’intermédiation homologué ATF', 'Dossier de transfert international conforme TMS FIFA', 'Immatriculation fédérale'],
      budgetOrValuation: 'Ligne globale : 15 000 000 € (Plafond par dossier : 1 500 000 €)',
      deadline: 'Guichet ouvert Mercato 2026'
    }
  },
  {
    id: 'rt-bank-02',
    sourceType: 'BANK',
    sourceName: 'Ecobank Transnational Incorporated',
    sourceLogo: 'https://images.unsplash.com/photo-1501167786227-4cba60f6d58f?w=100&auto=format&fit=crop&q=80',
    category: 'Financement d’Infrastructures & Équipements',
    country: 'Panafricain (Siège : Lomé / Abidjan)',
    countryFlag: '🇹🇬',
    title: 'Programme "Économie du Sport" : Crédit d’Investissement pour Terrains Synthétiques',
    summary: 'Ecobank déploie un programme de financement à taux bonifié pour les centres de formation agréés souhaitant installer des pelouses synthétiques certifiées FIFA Quality Pro ou rénover leurs centres d’hébergement.',
    timestamp: 'Il y a 19 min',
    urgentBadge: 'CRÉDIT BONIFIÉ',
    verified: true,
    actionType: 'DOWNLOAD_DOC',
    actionLabel: 'Télécharger le Dossier de Financement',
    contactEmail: 'sport.economy@ecobank.com',
    contactPhone: '+228 22 21 03 03',
    officialLink: 'https://ecobank.com',
    details: {
      requirements: ['Agrément ministériel ou fédéral en cours de validité', 'Plan d’affaires sur 3 ans', 'Audit technique ATF préalable'],
      budgetOrValuation: 'Financement de 50 000 € à 350 000 € avec différé d’amortissement de 12 mois',
      deadline: 'Clôture première tranche : 30 Septembre 2026'
    }
  },
  {
    id: 'rt-bank-03',
    sourceType: 'BANK',
    sourceName: 'Banque Africaine de Développement (BAD / AfDB)',
    sourceLogo: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=100&auto=format&fit=crop&q=80',
    category: 'Subventions & Entrepreneuriat Jeunesse',
    country: 'Afrique (Siège : Abidjan)',
    countryFlag: '🇨🇮',
    title: 'Fonds Spécial "Des Emplois pour les Jeunes dans le Sport" : Appel à Projets N°4',
    summary: 'Enveloppe non remboursable de 5 000 000 € débloquée pour soutenir l’encadrement éducatif, médical et technologique des jeunes footballeurs en voie de professionnalisation en Afrique subsaharienne.',
    timestamp: 'Il y a 34 min',
    urgentBadge: 'SUBVENTION 5M€',
    verified: true,
    actionType: 'DOWNLOAD_DOC',
    actionLabel: 'Cahier des Charges Subvention (PDF)',
    contactEmail: 'youth.sports.fund@afdb.org',
    contactPhone: '+225 20 26 10 20',
    officialLink: 'https://afdb.org',
    details: {
      requirements: ['Structure juridique déclarée', 'Respect de la charte de protection des mineurs', 'Audit de gouvernance'],
      budgetOrValuation: 'Subventions directes de 40 000 € à 120 000 € par académie sélectionnée',
      deadline: '1er Novembre 2026'
    }
  },
  {
    id: 'rt-bank-04',
    sourceType: 'BANK',
    sourceName: 'Société Générale Afrique & Méditerranée',
    sourceLogo: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?w=100&auto=format&fit=crop&q=80',
    category: 'Opérations de Change & Sécurisation de Flux',
    country: 'France / Côte d’Ivoire / Sénégal / Maroc',
    countryFlag: '🇫🇷',
    title: 'Comptes Épargne Bloquée & Gestion de Trésorerie Mercato',
    summary: 'Mise en place de contrats de couverture de change (EUR / XOF / MAD / USD) pour neutraliser le risque de change lors du versement d’indemnités de mutation internationale.',
    timestamp: 'Il y a 1h',
    urgentBadge: 'CONTRATS DE COUVERTURE',
    verified: true,
    actionType: 'CONTACT',
    actionLabel: 'Consulter un Conseiller Patrimonial',
    contactEmail: 'corporate.sports@socgen.com',
    contactPhone: '+33 1 42 14 20 00',
    officialLink: 'https://societegenerale.africa',
    details: {
      budgetOrValuation: 'Solutions multi-devises sans frais cachés pour transactions certifiées ATF'
    }
  },

  // --- COMPANIES & SPONSORS ---
  {
    id: 'rt-comp-01',
    sourceType: 'COMPANY',
    sourceName: 'PUMA Football Africa',
    sourceLogo: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=100&auto=format&fit=crop&q=80',
    category: 'Dotation Équipement & Bourses Athlètes',
    country: 'Global / Afrique',
    countryFlag: '🌍',
    title: 'Programme "Future Stars" : 50 Packs Professionnels Déployés pour Pépites ATF',
    summary: 'PUMA offre une dotation complète (crampons Ultra/Future, tenues d’entraînement haute technologie et contrat de visibilité) aux 50 jeunes espoirs classés au Top Scouting ATF.',
    timestamp: 'Il y a 15 min',
    urgentBadge: 'DOTATION PUMA PRO',
    verified: true,
    actionType: 'APPLY',
    actionLabel: 'Postuler pour la Bourse Équipement',
    contactEmail: 'africa.grassroots@puma.com',
    contactPhone: '+49 9132 81 0',
    officialLink: 'https://puma.com',
    details: {
      requirements: ['Profil joueur vérifié sur Africa Talent Football', 'Statistiques de match enregistrées', 'Âge 15-20 ans'],
      budgetOrValuation: 'Valeur de la dotation : 3 500 € / joueur sélectionné',
      quotaSeats: '50 bourses disponibles'
    }
  },
  {
    id: 'rt-comp-02',
    sourceType: 'COMPANY',
    sourceName: 'SuperSport Television & Canal+ Sport Afrique',
    sourceLogo: 'https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?w=100&auto=format&fit=crop&q=80',
    category: 'Diffusion Médias & Vitrine Mondiale',
    country: 'Afrique du Sud / Panafricain',
    countryFlag: '🇿🇦',
    title: 'Couverture Télévisée des Tournois U17 d’Abidjan et Dakar en Direct 4K',
    summary: 'Accord de diffusion internationale permettant la captation multi-caméras et l’accès direct aux flux vidéo certifiés pour les recruteurs de 60 clubs européens abonnés au service.',
    timestamp: 'Il y a 38 min',
    urgentBadge: 'DIFFUSION TV 4K',
    verified: true,
    actionType: 'INSPECT',
    actionLabel: 'Consulter la Grille des Programmes',
    contactEmail: 'programming@supersport.com',
    contactPhone: '+27 11 686 6000',
    officialLink: 'https://supersport.com',
    details: {
      deadline: 'Matches diffusés du 1er au 20 Août 2026'
    }
  },
  {
    id: 'rt-comp-03',
    sourceType: 'COMPANY',
    sourceName: 'Orange Telecom Digital Sports',
    sourceLogo: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=100&auto=format&fit=crop&q=80',
    category: 'Connectivité 5G & Données Vidéos en Direct',
    country: 'Panafricain',
    countryFlag: '🇨🇮',
    title: 'Déploiement du Réseau Haut Débit 5G sur 12 Complexes Sportifs Partenaires',
    summary: 'Téléversement instantané des séquences de matches vers la banque de vidéos Eyeball et diffusion en direct sans temps de latence pour les recruteurs distants.',
    timestamp: 'Il y a 52 min',
    urgentBadge: 'INFRASTRUCTURE 5G',
    verified: true,
    actionType: 'CONTACT',
    actionLabel: 'Raccorder son Académie au Réseau',
    contactEmail: 'digital.sports@orange.com',
    contactPhone: '+225 20 20 00 00',
    officialLink: 'https://orange.com'
  },
  {
    id: 'rt-comp-04',
    sourceType: 'COMPANY',
    sourceName: 'Decathlon Pro Afrique & Kipsta Performance',
    sourceLogo: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=100&auto=format&fit=crop&q=80',
    category: 'Matériel Technique d’Entraînement',
    country: 'France / Maroc / Sénégal / CI',
    countryFlag: '🇫🇷',
    title: 'Subvention Matériel d’Entraînement : Ballons FIFA Quality Pro & Chasubles GPS',
    summary: 'Mise à disposition de packs d’entraînement complets (ballons officiels homologués, cônes d’agilité, échelles de rythme) avec 40% de subvention pour les académies membres du réseau ATF.',
    timestamp: 'Il y a 1h 15m',
    urgentBadge: 'SUBVENTION MATÉRIEL 40%',
    verified: true,
    actionType: 'DOWNLOAD_DOC',
    actionLabel: 'Commander le Pack Subventionné',
    contactEmail: 'pro.africa@decathlon.com',
    contactPhone: '+33 3 20 33 50 00',
    officialLink: 'https://decathlon.pro'
  }
];

const STORAGE_REALTIME_UPDATES_KEY = 'atf_realtime_partner_updates_v1';

/**
 * Returns saved or fresh real-time partner updates
 */
export const getRealtimePartnerUpdates = (): RealtimePartnerUpdate[] => {
  try {
    const raw = localStorage.getItem(STORAGE_REALTIME_UPDATES_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Error loading realtime partner updates:', e);
  }
  return INITIAL_REALTIME_PARTNER_UPDATES;
};

/**
 * Saves real-time updates to localStorage
 */
export const saveRealtimePartnerUpdates = (updates: RealtimePartnerUpdate[]) => {
  try {
    localStorage.setItem(STORAGE_REALTIME_UPDATES_KEY, JSON.stringify(updates));
  } catch (e) {
    console.error('Error saving realtime partner updates:', e);
  }
};

/**
 * Simulates a fresh sync from Clubs, Companies, and Banks servers,
 * refreshing timestamps and dynamically introducing new priority market signals.
 */
export const syncLivePartnerIntelligence = (): RealtimePartnerUpdate[] => {
  const current = getRealtimePartnerUpdates();
  
  // Update timestamps to make them actively live
  const refreshed = current.map((item, index) => {
    let freshTime = 'À l’instant';
    if (index === 0) freshTime = 'À l’instant (Sync en direct)';
    else if (index === 1) freshTime = 'Il y a 2 min';
    else if (index === 2) freshTime = 'Il y a 5 min';
    else if (index === 3) freshTime = 'Il y a 9 min';
    else freshTime = `Il y a ${(index + 1) * 4} min`;

    return {
      ...item,
      timestamp: freshTime
    };
  });

  saveRealtimePartnerUpdates(refreshed);
  return refreshed;
};
