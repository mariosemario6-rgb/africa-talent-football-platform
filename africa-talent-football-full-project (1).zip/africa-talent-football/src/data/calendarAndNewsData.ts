import { FootballMatchFixture, WorldwideNewsArticle } from '../types/database';

export const WORLDWIDE_MATCH_FIXTURES: FootballMatchFixture[] = [
  // ==========================================
  // --- CAF (AFRIQUE) ---
  // ==========================================
  {
    id: 'match-caf-01',
    competition: 'Ligue des Champions CAF',
    round: 'Demi-Finale Aller',
    confederation: 'CAF',
    country: 'Égypte',
    countryFlag: '🇪🇬',
    date: 'Aujourd’hui',
    time: '19:00 GMT',
    status: 'LIVE',
    liveMinute: '72\'',
    homeTeam: {
      id: 'club-caf-01',
      name: 'Al Ahly SC',
      logoUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇪🇬',
      score: 2
    },
    awayTeam: {
      id: 'club-caf-02',
      name: 'Wydad Casablanca',
      logoUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇲🇦',
      score: 1
    },
    stadium: 'Stade International du Caire (75 000 places)',
    city: 'Le Caire',
    referee: 'Mustapha Ghorbal (Algérie)',
    broadcastChannel: 'beIN Sports HD 1 / Canal+ Sport 1 Afrique',
    scoutNotes: 'Choc continental au sommet. Suivi particulier des relayeurs axiaux et de la gestion de la transition défensive sous fort pressing.',
    monitoredTalents: ['Ibrahim Kouassi (Observé par Al Ahly)', 'Ayoub El Kaabi (Analysé en transition)'],
    tacticalHighlightsUrl: 'https://assets.mixkit.co/videos/preview/mixkit-player-running-and-kicking-a-soccer-ball-42720-large.mp4',
    scorers: [
      { minute: '14\'', player: 'Hussein El Shahat', team: 'home' },
      { minute: '39\'', player: 'Yahya Attiat Allah', team: 'away' },
      { minute: '58\'', player: 'Percy Tau', team: 'home' }
    ],
    possessionPct: { home: 56, away: 44 }
  },
  {
    id: 'match-caf-02',
    competition: 'Coupe de la Confédération CAF',
    round: 'Phase de Groupes · J4',
    confederation: 'CAF',
    country: 'Côte d’Ivoire',
    countryFlag: '🇨🇮',
    date: 'Demain',
    time: '16:00 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'club-caf-07',
      name: 'ASEC Mimosas',
      logoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇨🇮'
    },
    awayTeam: {
      id: 'club-caf-06',
      name: 'TP Mazembe',
      logoUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇨🇩'
    },
    stadium: 'Stade Félix Houphouët-Boigny (Le Félicia)',
    city: 'Abidjan',
    referee: 'Bakary Gassama (Gambie)',
    broadcastChannel: 'Canal+ Sport 2 Afrique / RTI 1',
    scoutNotes: 'Duel ouest-africain vs Afrique centrale. Présence confirmée en tribune de Seydou Mario TRAORÉ et de recruteurs belges (Standard de Liège, KRC Genk).',
    monitoredTalents: ['Moussa Diallo (DC 1m91, ASEC)', 'Koffi Gnagne (MOC créatif)'],
    tacticalHighlightsUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-man-training-soccer-on-a-grass-field-42721-large.mp4',
    possessionPct: { home: 52, away: 48 }
  },
  {
    id: 'match-caf-03',
    competition: 'Ligue des Champions CAF',
    round: 'Quart de Finale Retour',
    confederation: 'CAF',
    country: 'Afrique du Sud',
    countryFlag: '🇿🇦',
    date: 'Samedi 10 Octobre',
    time: '18:00 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'club-caf-03',
      name: 'Mamelodi Sundowns',
      logoUrl: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇿🇦'
    },
    awayTeam: {
      id: 'club-caf-04',
      name: 'Espérance de Tunis',
      logoUrl: 'https://images.unsplash.com/photo-1541354329998-f4d9a9f9297f?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇹🇳'
    },
    stadium: 'Loftus Versfeld Stadium (51 000 places)',
    city: 'Pretoria',
    broadcastChannel: 'SuperSport PSL / beIN Sports 3',
    scoutNotes: 'Style tiki-taka sud-africain vs rigueur tactique tunisienne. Évaluation des capacités aérobie sous haute intensité GPS.',
    monitoredTalents: ['Teboho Mokoena', 'Yan Sasse'],
    tacticalHighlightsUrl: 'https://assets.mixkit.co/videos/preview/mixkit-soccer-player-hitting-a-ball-in-the-stadium-42718-large.mp4'
  },
  {
    id: 'match-caf-04',
    competition: 'Botola Pro Inwi',
    round: 'Journée 24 · Clasico Marocain',
    confederation: 'CAF',
    country: 'Maroc',
    countryFlag: '🇲🇦',
    date: 'Ce Soir',
    time: '20:30 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'club-caf-08',
      name: 'Raja Club Athletic',
      logoUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇲🇦'
    },
    awayTeam: {
      id: 'club-caf-09',
      name: 'RS Berkane',
      logoUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇲🇦'
    },
    stadium: 'Complexe Sportif Mohammed V',
    city: 'Casablanca',
    broadcastChannel: 'Arryadia HD / Canal+ Sport 3',
    scoutNotes: 'Duel tactique entre le leader invaincu et le spécialiste des joutes africaines. Surveillance des ailiers de débordement.',
    monitoredTalents: ['Yousri Bouzok', 'Adam Ennafati']
  },
  {
    id: 'match-caf-05',
    competition: 'Coupe de la Confédération CAF',
    round: 'Phase Finale',
    confederation: 'CAF',
    country: 'Nigéria',
    countryFlag: '🇳🇬',
    date: 'Hier',
    time: '15:00 GMT',
    status: 'FINISHED',
    homeTeam: {
      id: 'club-caf-05',
      name: 'Enyimba FC',
      logoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇳🇬',
      score: 2
    },
    awayTeam: {
      id: 'club-caf-10',
      name: 'Simba SC (Tanzanie)',
      logoUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇹🇿',
      score: 1
    },
    stadium: 'Enyimba International Stadium (Aba)',
    city: 'Aba',
    broadcastChannel: 'SuperSport Football Plus',
    scoutNotes: 'Grosse démonstration athlétique de la charnière nigériane. 82% de duels aériens remportés.',
    monitoredTalents: ['Chijioke Mbaoma', 'Clatous Chama'],
    scorers: [
      { minute: '28\'', player: 'Mbaoma', team: 'home' },
      { minute: '54\'', player: 'Saido Ntibazonkiza', team: 'away' },
      { minute: '79\'', player: 'Eze', team: 'home' }
    ]
  },

  // ==========================================
  // --- ATF SCOUTING SHOWCASES (TOURNOIS SPÉCIAUX DE DÉTECTION) ---
  // ==========================================
  {
    id: 'match-showcase-01',
    competition: 'Showcase Détection Panafricain U19',
    round: 'Super Finale Détection',
    confederation: 'ATF_SHOWCASE',
    country: 'Côte d’Ivoire',
    countryFlag: '🇨🇮',
    date: 'Dimanche 11 Octobre',
    time: '15:30 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'showcase-civ-01',
      name: 'Team Ivoire Espoirs U19',
      logoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇨🇮'
    },
    awayTeam: {
      id: 'showcase-sen-01',
      name: 'Sélection Académies Sahel U19',
      logoUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇸🇳'
    },
    stadium: 'Stade Robert Champroux (Marcory, Abidjan)',
    city: 'Abidjan',
    broadcastChannel: 'Streaming Exclusif Live Africa Talent Football & Canal+ A+',
    scoutNotes: 'Match d’évaluation officielle supervisé par Seydou Mario TRAORÉ. 18 recruteurs européens (France, Belgique, Espagne, Angleterre) accrédités.',
    monitoredTalents: ['Ibrahim Kouassi', 'Moussa Diallo', 'Koffi Gnagne', 'Sékou Sanogo'],
    tacticalHighlightsUrl: 'https://assets.mixkit.co/videos/preview/mixkit-player-running-and-kicking-a-soccer-ball-42720-large.mp4',
    possessionPct: { home: 50, away: 50 }
  },
  {
    id: 'match-showcase-02',
    competition: 'Tournée Immersion Europe U19',
    round: 'Match Amical Certifié FIFA',
    confederation: 'ATF_SHOWCASE',
    country: 'Belgique',
    countryFlag: '🇧🇪',
    date: 'Mercredi 14 Octobre',
    time: '14:00 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'club-uefa-07',
      name: 'Standard de Liège U19',
      logoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇧🇪'
    },
    awayTeam: {
      id: 'showcase-atf-global',
      name: 'Africa Talent Football All-Stars',
      logoUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇨🇮'
    },
    stadium: 'Académie Robert Louis-Dreyfus (Liège)',
    city: 'Liège',
    broadcastChannel: 'ATF Scouting Cloud & Standard TV',
    scoutNotes: 'Test d’immersion tactique européenne en conditions réelles avec prise de données Catapult GPS et rapports Wyscout.',
    monitoredTalents: ['Jean-Luc Moreau (Scout en chef)', 'Seydou Mario Traoré (Observateur technique)']
  },
  {
    id: 'match-showcase-03',
    competition: 'Tournoi des Académies d\'Excellence U18',
    round: 'Choc de Formation',
    confederation: 'ATF_SHOWCASE',
    country: 'Sénégal',
    countryFlag: '🇸🇳',
    date: 'Aujourd’hui',
    time: '17:00 GMT',
    status: 'LIVE',
    liveMinute: '41\'',
    homeTeam: {
      id: 'acad-gen-foot',
      name: 'Génération Foot U18',
      logoUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇸🇳',
      score: 1
    },
    awayTeam: {
      id: 'acad-mimosifcom',
      name: 'Académie MimoSifcom U18',
      logoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇨🇮',
      score: 1
    },
    stadium: 'Centre Amara Touré (Déni Biram Ndao)',
    city: 'Dakar',
    broadcastChannel: 'ATF Live Hub & RTS 1',
    scoutNotes: 'Confrontation des deux plus illustres centres formateurs ouest-africains. Intensité physique et fluidité technique d\'élite.',
    monitoredTalents: ['Amara Diouf (Surveillé)', 'Bamba Traoré (MOC 2007)'],
    scorers: [
      { minute: '19\'', player: 'Samba Niang', team: 'home' },
      { minute: '34\'', player: 'Koffi Junior', team: 'away' }
    ]
  },

  // ==========================================
  // --- UEFA (EUROPE) ---
  // ==========================================
  {
    id: 'match-uefa-01',
    competition: 'UEFA Champions League',
    round: 'Phase de Ligue · J3',
    confederation: 'UEFA',
    country: 'Espagne',
    countryFlag: '🇪🇸',
    date: 'Ce Soir',
    time: '20:00 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'club-uefa-01',
      name: 'Real Madrid CF',
      logoUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇪🇸'
    },
    awayTeam: {
      id: 'club-uefa-02',
      name: 'Manchester City FC',
      logoUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿'
    },
    stadium: 'Estadio Santiago Bernabéu (84 744 places)',
    city: 'Madrid',
    referee: 'Szymon Marciniak (Pologne)',
    broadcastChannel: 'Canal+ Foot / TNT Sports 1 / Movistar Liga de Campeones',
    scoutNotes: 'Le sommet mondial absolu. Clé tactique : Gegenpressing et contres fulgurants de Madrid vs attaque placée et 3e homme de Pep Guardiola.',
    monitoredTalents: ['Juni Calafat (Chief Scout en tribune)', 'Sam Jewell (Man City Recruitment)']
  },
  {
    id: 'match-uefa-02',
    competition: 'UEFA Champions League',
    round: 'Phase de Ligue · J2',
    confederation: 'UEFA',
    country: 'Angleterre',
    countryFlag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    date: 'Hier',
    time: '20:00 GMT',
    status: 'FINISHED',
    homeTeam: {
      id: 'club-uefa-03',
      name: 'Arsenal FC',
      logoUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
      score: 2
    },
    awayTeam: {
      id: 'club-uefa-05',
      name: 'Paris Saint-Germain',
      logoUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇫🇷',
      score: 0
    },
    stadium: 'Emirates Stadium (60 704 places)',
    city: 'Londres',
    broadcastChannel: 'Canal+ / Sky Sports / beIN Sports 1',
    scoutNotes: 'Victoire tactique magistrale des Gunners sur coups de pied arrêtés et pressing territorial haut de Mikel Arteta.',
    monitoredTalents: ['Bukayo Saka', 'Bradley Barcola', 'Warren Zaïre-Emery'],
    scorers: [
      { minute: '20\'', player: 'Kai Havertz', team: 'home' },
      { minute: '35\'', player: 'Bukayo Saka', team: 'home' }
    ]
  },
  {
    id: 'match-uefa-03',
    competition: 'Jupiler Pro League (Belgique)',
    round: 'Choc Flamand-Wallon',
    confederation: 'UEFA',
    country: 'Belgique',
    countryFlag: '🇧🇪',
    date: 'Vendredi 09 Octobre',
    time: '19:45 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'club-uefa-07',
      name: 'Standard de Liège',
      logoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇧🇪'
    },
    awayTeam: {
      id: 'club-uefa-06',
      name: 'KRC Genk',
      logoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇧🇪'
    },
    stadium: 'Stade Maurice Dufrasne (Sclessin)',
    city: 'Liège',
    broadcastChannel: 'DAZN Belgique / Eleven Sports',
    scoutNotes: 'Les deux clubs belges partenaires majeurs d’Africa Talent Football s’affrontent. Réunion de travail prévue entre Dimitri de Condé et Jean-Luc Moreau.',
    monitoredTalents: ['Pépites U21 formées en Afrique de l’Ouest']
  },
  {
    id: 'match-uefa-04',
    competition: 'Bundesliga',
    round: 'Journée 8 · Sommet Allemand',
    confederation: 'UEFA',
    country: 'Allemagne',
    countryFlag: '🇩🇪',
    date: 'Samedi 10 Octobre',
    time: '16:30 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'club-uefa-04',
      name: 'FC Bayern Munich',
      logoUrl: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇩🇪'
    },
    awayTeam: {
      id: 'club-uefa-leverkusen',
      name: 'Bayer Leverkusen',
      logoUrl: 'https://images.unsplash.com/photo-1541354329998-f4d9a9f9297f?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇩🇪'
    },
    stadium: 'Allianz Arena (75 024 places)',
    city: 'Munich',
    broadcastChannel: 'beIN Sports HD 2 / Sky Sport Bundesliga',
    scoutNotes: 'Duel d’entraîneurs visionnaires : Vincent Kompany vs Xabi Alonso. Analyse des courses de soutien en transition.',
    monitoredTalents: ['Jamal Musiala', 'Florian Wirtz', 'Jeremie Frimpong']
  },
  {
    id: 'match-uefa-05',
    competition: 'Premier League',
    round: 'Journée 9 · Détection Data',
    confederation: 'UEFA',
    country: 'Angleterre',
    countryFlag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    date: 'Dimanche 11 Octobre',
    time: '16:30 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'club-uefa-brighton',
      name: 'Brighton & Hove Albion',
      logoUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿'
    },
    awayTeam: {
      id: 'club-uefa-chelsea',
      name: 'Chelsea FC',
      logoUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿'
    },
    stadium: 'Amex Stadium (31 800 places)',
    city: 'Brighton',
    broadcastChannel: 'Canal+ Premier League / Sky Sports Main Event',
    scoutNotes: 'Le club modèle mondial en recrutement algorithmique (Brighton) affronte Chelsea. Analyse comparative des profils U21.',
    monitoredTalents: ['Carlos Baleba (Cameroun)', 'Nicolas Jackson (Sénégal)', 'Malo Gusto']
  },

  // ==========================================
  // --- CONMEBOL (AMÉRIQUE DU SUD) ---
  // ==========================================
  {
    id: 'match-conmebol-01',
    competition: 'Copa CONMEBOL Libertadores',
    round: 'Demi-Finale Aller',
    confederation: 'CONMEBOL',
    country: 'Brésil',
    countryFlag: '🇧🇷',
    date: 'Jeudi 15 Octobre',
    time: '00:30 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'club-conmebol-01',
      name: 'CR Flamengo',
      logoUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇧🇷'
    },
    awayTeam: {
      id: 'club-conmebol-02',
      name: 'CA River Plate',
      logoUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇦🇷'
    },
    stadium: 'Estádio do Maracanã (78 838 places)',
    city: 'Rio de Janeiro',
    broadcastChannel: 'ESPN Amérique Latine / beIN Sports France',
    scoutNotes: 'Le clasico continental sud-américain. Intensité physique et créativité technique brute dans les derniers mètres.',
    monitoredTalents: ['Franco Mastantuono (MOC River Plate)', 'Lorran (Flamengo U20)']
  },
  {
    id: 'match-conmebol-02',
    competition: 'Copa CONMEBOL Libertadores',
    round: 'Demi-Finale Aller',
    confederation: 'CONMEBOL',
    country: 'Brésil',
    countryFlag: '🇧🇷',
    date: 'Aujourd’hui',
    time: '23:30 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'club-conmebol-03',
      name: 'SE Palmeiras',
      logoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇧🇷'
    },
    awayTeam: {
      id: 'club-conmebol-04',
      name: 'CA Boca Juniors',
      logoUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇦🇷'
    },
    stadium: 'Allianz Parque (São Paulo)',
    city: 'São Paulo',
    broadcastChannel: 'Paramount+ / Globo Sports',
    scoutNotes: 'Duel d’impact physique et d’organisation défensive sud-américaine. Présence de superviseurs de Chelsea et Porto.',
    monitoredTalents: ['Estêvão Willian (Palmeiras)', 'Cristian Medina (Boca)']
  },
  {
    id: 'match-conmebol-03',
    competition: 'Copa Sudamericana',
    round: 'Quart de Finale',
    confederation: 'CONMEBOL',
    country: 'Brésil',
    countryFlag: '🇧🇷',
    date: 'Hier',
    time: '22:00 GMT',
    status: 'FINISHED',
    homeTeam: {
      id: 'club-conmebol-05',
      name: 'São Paulo FC',
      logoUrl: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇧🇷',
      score: 3
    },
    awayTeam: {
      id: 'club-conmebol-06',
      name: 'Club Nacional (Uruguay)',
      logoUrl: 'https://images.unsplash.com/photo-1541354329998-f4d9a9f9297f?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇺🇾',
      score: 1
    },
    stadium: 'Estádio do Morumbi',
    city: 'São Paulo',
    broadcastChannel: 'ESPN 2',
    scoutNotes: 'Festival offensif de São Paulo avec une remarquable circulation en une touche.',
    monitoredTalents: ['Lucas Moura', 'Felipe Negrucci'],
    scorers: [
      { minute: '12\'', player: 'Calleri', team: 'home' },
      { minute: '45\'', player: 'Luciano', team: 'home' },
      { minute: '67\'', player: 'Carneiro', team: 'away' },
      { minute: '83\'', player: 'Ferreira', team: 'home' }
    ]
  },

  // ==========================================
  // --- CONCACAF (AMÉRIQUE DU NORD) ---
  // ==========================================
  {
    id: 'match-concacaf-01',
    competition: 'CONCACAF Champions Cup',
    round: 'Quart de Finale',
    confederation: 'CONCACAF',
    country: 'États-Unis',
    countryFlag: '🇺🇸',
    date: 'Samedi 17 Octobre',
    time: '23:30 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'club-concacaf-01',
      name: 'Inter Miami CF',
      logoUrl: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇺🇸'
    },
    awayTeam: {
      id: 'club-concacaf-02',
      name: 'Club América',
      logoUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇲🇽'
    },
    stadium: 'Chase Stadium (21 550 places)',
    city: 'Fort Lauderdale, Floride',
    broadcastChannel: 'Apple TV MLS Season Pass / Fox Sports / TUDN',
    scoutNotes: 'Opposition de styles entre la franchise floridienne et le géant mexicain le plus titré de la CONCACAF.',
    monitoredTalents: ['Diego Gómez', 'Alejandro Zendejas', 'Benjamin Cremaschi']
  },
  {
    id: 'match-concacaf-02',
    competition: 'CONCACAF Champions Cup',
    round: 'Finale Retour',
    confederation: 'CONCACAF',
    country: 'Mexique',
    countryFlag: '🇲🇽',
    date: 'Hier',
    time: '01:15 GMT',
    status: 'FINISHED',
    homeTeam: {
      id: 'club-concacaf-03',
      name: 'CF Pachuca',
      logoUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇲🇽',
      score: 3
    },
    awayTeam: {
      id: 'club-concacaf-04',
      name: 'Columbus Crew',
      logoUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇺🇸',
      score: 0
    },
    stadium: 'Estadio Hidalgo',
    city: 'Pachuca',
    broadcastChannel: 'Fox Sports / TUDN',
    scoutNotes: 'Démonstration tactique mexicaine avec un bloc haut et une maîtrise technique remarquable.',
    monitoredTalents: ['Salomón Rondón', 'Érick Sánchez', 'Cucho Hernández'],
    scorers: [
      { minute: '12\'', player: 'Salomón Rondón', team: 'home' },
      { minute: '32\'', player: 'Emilio Rodríguez', team: 'home' },
      { minute: '67\'', player: 'Salomón Rondón', team: 'home' }
    ]
  },

  // ==========================================
  // --- AFC (ASIE & GOLFE) ---
  // ==========================================
  {
    id: 'match-afc-01',
    competition: 'AFC Champions League Elite',
    round: 'Phase de Groupes · Derby de Riyad',
    confederation: 'AFC',
    country: 'Arabie Saoudite',
    countryFlag: '🇸🇦',
    date: 'Mardi 13 Octobre',
    time: '17:00 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'club-afc-01',
      name: 'Al Hilal SFC',
      logoUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇸🇦'
    },
    awayTeam: {
      id: 'club-afc-02',
      name: 'Al Nassr FC',
      logoUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇸🇦'
    },
    stadium: 'Kingdom Arena (26 000 places)',
    city: 'Riyad',
    broadcastChannel: 'SSC Sports / Canal+ Sport Afrique / beIN AFC',
    scoutNotes: 'Derby de Riyad. Plus de 350M€ de valeur marchande sur le terrain, supervision des espaces défensifs et des phases arrêtées.',
    monitoredTalents: ['Alexandre Mitrovic', 'Cristiano Ronaldo', 'Sadio Mané', 'Otávio']
  },
  {
    id: 'match-afc-02',
    competition: 'AFC Champions League',
    round: 'Finale Continentale',
    confederation: 'AFC',
    country: 'Émirats Arabes Unis',
    countryFlag: '🇦🇪',
    date: 'Hier',
    time: '16:00 GMT',
    status: 'FINISHED',
    homeTeam: {
      id: 'club-afc-03',
      name: 'Al Ain FC',
      logoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇦🇪',
      score: 5
    },
    awayTeam: {
      id: 'club-afc-04',
      name: 'Yokohama F. Marinos',
      logoUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇯🇵',
      score: 1
    },
    stadium: 'Hazza Bin Zayed Stadium',
    city: 'Al Ain',
    broadcastChannel: 'Abu Dhabi Sports / beIN AFC',
    scoutNotes: 'Consécration asiatique pour Hernán Crespo et son équipe.',
    monitoredTalents: ['Soufiane Rahimi (Maroc, Meilleur Buteur)', 'Kaku']
  },

  // ==========================================
  // --- OFC (OCÉANIE) ---
  // ==========================================
  {
    id: 'match-ofc-01',
    competition: 'OFC Champions League',
    round: 'Finale Continentale',
    confederation: 'OFC',
    country: 'Nouvelle-Zélande',
    countryFlag: '🇳🇿',
    date: 'Samedi 24 Octobre',
    time: '04:00 GMT',
    status: 'UPCOMING',
    homeTeam: {
      id: 'club-ofc-01',
      name: 'Auckland City FC',
      logoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇳🇿'
    },
    awayTeam: {
      id: 'club-ofc-02',
      name: 'AS Pirae (Tahiti)',
      logoUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇵🇫'
    },
    stadium: 'Kiwitea Street Stadium',
    city: 'Auckland',
    broadcastChannel: 'FIFA+ TV / Sky Sport NZ',
    scoutNotes: 'Qualification pour la Coupe du Monde des Clubs de la FIFA 2025. Rigueur défensive et gestion des transitions rapides.',
    monitoredTalents: ['Cam Howieson', 'Angus Kilkolly']
  },
  {
    id: 'match-ofc-02',
    competition: 'OFC Men\'s Champions League',
    round: 'Demi-Finale',
    confederation: 'OFC',
    country: 'Nouvelle-Zélande',
    countryFlag: '🇳🇿',
    date: 'Hier',
    time: '03:00 GMT',
    status: 'FINISHED',
    homeTeam: {
      id: 'club-ofc-03',
      name: 'Wellington Olympic',
      logoUrl: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇳🇿',
      score: 4
    },
    awayTeam: {
      id: 'club-ofc-04',
      name: 'Suva FC (Fidji)',
      logoUrl: 'https://images.unsplash.com/photo-1541354329998-f4d9a9f9297f?w=120&auto=format&fit=crop&q=80',
      countryFlag: '🇫🇯',
      score: 2
    },
    stadium: 'Wakefield Park',
    city: 'Wellington',
    broadcastChannel: 'FIFA+ Streaming',
    scoutNotes: 'Match très ouvert, belle intensité physique des joueurs du Pacifique.',
    monitoredTalents: ['Hamish Watson', 'Gaston Merlo']
  }
];

export const WORLDWIDE_NEWS_FEED: WorldwideNewsArticle[] = [
  {
    id: 'news-global-01',
    title: 'Exclusif Mercato : Seydou Mario TRAORÉ mandate 3 nouvelles détections en Côte d’Ivoire et au Sénégal',
    summary: 'Le fondateur d’Africa Talent Football ouvre une série de showcases fermés en présence de superviseurs de Ligue 1 et Jupiler Pro League pour évaluer 40 pépites nées en 2006-2008.',
    content: 'Dans le cadre du renforcement des passerelles de détection directe avec les clubs européens partenaires, la direction générale d’Africa Talent Football présidée par Seydou Mario TRAORÉ annonce le lancement officiel d’une série de tournois showcases fermés à Abidjan et Dakar. Les évaluations portent sur des tests physiques GPS Catapult poussés, des analyses vidéo multi-angles et des entretiens réglementaires conformes aux exigences FIFA.',
    fullStory: [
      'Dans le cadre du renforcement des passerelles de détection directe avec les clubs européens partenaires, la direction générale d’Africa Talent Football présidée par Seydou Mario TRAORÉ annonce le lancement officiel d’une série de tournois showcases fermés à Abidjan et Dakar.',
      'Les évaluations porteront sur des tests physiques GPS Catapult poussés, des analyses vidéo multi-angles 90 minutes et des entretiens réglementaires avec les tuteurs légaux selon l’Article 19 de la FIFA régissant la protection des mineurs.',
      'Des délégations de superviseurs mandatés par le Standard de Liège, le KRC Genk, le RC Lens et le Brighton & Hove Albion seront accueillies à Abidjan sous accréditation certifiée ATF.',
      '« Notre priorité absolue est d’offrir à ces jeunes talents une vitrine technique propre, sans intermédiaires opportunistes, en mettant la donnée physique certifiée et la vidéo intégrale au cœur de la décision des clubs pros », précise le Fondateur Seydou Mario TRAORÉ.'
    ],
    tags: ['Mercato', 'Détection', 'Mario Traoré', 'Côte d’Ivoire', 'Sénégal', 'FIFA'],
    category: 'MERCATO',
    confederation: 'CAF',
    country: 'Côte d’Ivoire',
    countryFlag: '🇨🇮',
    publishedAt: 'Il y a 22 minutes',
    source: 'Cellule Technique Africa Talent Football',
    author: 'Direction Technique Mario Traoré',
    authorRole: 'Fondateur & Directeur Technique ATF',
    imageUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&auto=format&fit=crop&q=80',
    keyHighlight: 'Les profils de défenseurs axiaux gauchers et d’ailiers percutants à grosse VMA sont prioritaires pour les cellules de recrutement partenaires.',
    readTimeMinutes: 3,
    isBreaking: true
  },
  {
    id: 'news-global-02',
    title: 'Ligue des Champions de la CAF : Al Ahly et l’ASEC Mimosas impressionnent sur leurs bilans physiques GPS',
    summary: 'Les données Catapult partagées sur la plateforme attestent d’une intensité de course supérieure à 118 km collectifs par match, rivalisant directement avec les standards de l’UEFA Champions League.',
    fullStory: [
      'L’audit physique réalisé à l’issue des rencontres de phase de groupes de la Ligue des Champions CAF confirme une élévation sans précédent de l’intensité athlétique du football continental africain.',
      'Les équipes d’Al Ahly SC et de l’ASEC Mimosas affichent des moyennes de distance collective parcourue excédant 118,4 km par 90 minutes, avec un ratio de courses à haute intensité (>21 km/h) équivalent à 11,2% du volume total.',
      'Ces rapports télémétriques, vérifiés et consultables par les recruteurs abonnés Premium Pro sur Africa Talent Football, positionnent ces deux institutions comme des modèles de rigueur physique et de préparation moderne.'
    ],
    tags: ['CAF Champions League', 'Catapult GPS', 'Al Ahly', 'ASEC Mimosas', 'Data'],
    category: 'MATCH',
    confederation: 'CAF',
    country: 'Panafricain',
    countryFlag: '🌍',
    publishedAt: 'Il y a 1 heure',
    source: 'CAF Media & Catapult Analytics',
    imageUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=600&auto=format&fit=crop&q=80',
    relatedClubId: 'club-caf-01',
    relatedClubName: 'Al Ahly SC',
    keyHighlight: 'Record de sprints au-dessus de 28 km/h pour les latéraux ivoiriens et égyptiens.',
    readTimeMinutes: 4
  },
  {
    id: 'news-global-03',
    title: 'Real Madrid : Juni Calafat valide le protocole de suivi vidéo sécurisé d’Africa Talent Football',
    summary: 'Le célèbre responsable du recrutement international des Merengues consulte désormais les séquences multi-angles certifiées et les fiches biométriques de la plateforme pour son vivier U19 Castilla.',
    fullStory: [
      'Le bureau de recrutement international du Real Madrid, dirigé par Juni Calafat, a intégré le protocole de diffusion vidéo cryptée proposé par Africa Talent Football.',
      'Cette collaboration technique permet au club 15 fois vainqueur de la Ligue des Champions d’accéder directement aux vidéos 90 minutes non tronquées des matchs disputés par les pépites sous contrat de formation en Afrique de l’Ouest et centrale.',
      '« Le gain de temps est colossal : nous disposons en un clic de la séquence tactique, de la vidéo de match complète et du bilan médical préliminaire certifié par le desk de Seydou Mario TRAORÉ », confie une source proche du club madrilène.'
    ],
    tags: ['Real Madrid', 'Juni Calafat', 'Scouting', 'Castilla', 'Vidéothèque'],
    category: 'SCOUTING',
    confederation: 'UEFA',
    country: 'Espagne',
    countryFlag: '🇪🇸',
    publishedAt: 'Il y a 3 heures',
    source: 'Marca & Direction Sportive Madrid',
    imageUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=600&auto=format&fit=crop&q=80',
    relatedClubId: 'club-uefa-01',
    relatedClubName: 'Real Madrid CF',
    keyHighlight: 'Accès direct aux vidéos 90 minutes intégrales sans filtre commercial ni montage trompeur.',
    readTimeMinutes: 5,
    isBreaking: true
  },
  {
    id: 'news-global-04',
    title: 'Bourses d’Études Universitaires : Loughborough University & Oxford ouvrent 12 places sport-études pour les talents ATF',
    summary: 'Les deux institutions britanniques d’élite confirment l’octroi de bourses complètes (frais de scolarité + internat sportif) pour les athlètes bacheliers ayant validé les tests physiques d’Africa Talent Football.',
    fullStory: [
      'Historique pour la formation des footballeurs africains : Loughborough University, classée numéro 1 mondial en sciences du sport pour la 8e année consécutive, s’associe à Africa Talent Football pour offrir 12 bourses complètes.',
      'Les lauréats bénéficieront d’un cursus académique d’excellence en gestion sportive, kinésithérapie ou data analytics tout en évoluant dans l’équipe universitaire engagée en BUCS Premier League avec passerelles vers les clubs de Premier League et Championship.',
      'Le programme est également soutenu par la fondation sportive d’Oxford University pour l’accompagnement linguistique et l’obtention des visas étudiants Tier 4.'
    ],
    tags: ['Bourses', 'Université', 'Loughborough', 'Double Projet', 'Sport-Études'],
    category: 'ACADEMY',
    confederation: 'UEFA',
    country: 'Royaume-Uni',
    countryFlag: '🇬🇧',
    publishedAt: 'Il y a 5 heures',
    source: 'Loughborough Sports Department',
    imageUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=600&auto=format&fit=crop&q=80',
    keyHighlight: 'Programme double projet certifié : Diplôme universitaire britannique + entraînement professionnel haute performance.',
    readTimeMinutes: 4
  },
  {
    id: 'news-global-05',
    title: 'Finance & Transferts : Standard Chartered et Ecobank sécurisent les premiers comptes séquestres pour transferts mineurs',
    summary: 'En stricte conformité avec l’Article 19 de la FIFA, les deux banques partenaires déploient des solutions de cautionnement bancaire protégeant les indemnités de formation des académies africaines.',
    fullStory: [
      'La sécurisation des transactions financières dans le football africain franchit un palier déterminant grâce au partenariat scellé entre Africa Talent Football, Standard Chartered et le groupe panafricain Ecobank.',
      'Le dispositif permet l’ouverture automatique de comptes séquestres (escrow accounts) sous droit international lors de toute convention de transfert ou d’indemnité de formation FIFA.',
      'Ce mécanisme garantit le versement intégral des pourcentages à la revente et des mécanismes de solidarité aux centres de formation d’origine, supprimant les risques de défaut de paiement constatés par le passé.'
    ],
    tags: ['Finance', 'Banques', 'Standard Chartered', 'Ecobank', 'Indemnités FIFA'],
    category: 'OFFICIAL',
    confederation: 'GLOBAL',
    country: 'Panafricain & Europe',
    countryFlag: '🏦',
    publishedAt: 'Il y a 8 heures',
    source: 'Financial Times & Desk Juridique ATF',
    imageUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&auto=format&fit=crop&q=80',
    keyHighlight: 'Zéro risque d’impayé pour les centres formateurs sur les clauses de revente future et mécanismes de solidarité.',
    readTimeMinutes: 4
  },
  {
    id: 'news-global-06',
    title: 'Copa Libertadores : Flamengo et River Plate qualifiés pour les demi-finales dans une ambiance électrique',
    summary: 'Le football sud-américain confirme sa vitalité avec l’émergence de nouveaux meneurs de jeu convoités par les recruteurs de Manchester City et du FC Barcelone.',
    fullStory: [
      'Le mythique stade du Maracanã à Rio de Janeiro et le Monumental de Buenos Aires ont vibré au rythme des quarts de finale retour de la Copa CONMEBOL Libertadores.',
      'Les qualifications respectives du CR Flamengo et du CA River Plate préparent un choc au sommet qui réunira plus de 35 scouts européens accrédités, dont les recruteurs en chef de Manchester City (Sam Jewell) et du Paris Saint-Germain.',
      'L’intensité athlétique et la rudesse tactique des duels fournissent une mine d’or pour les analystes vidéo de la cellule Africa Talent Football.'
    ],
    tags: ['Copa Libertadores', 'Flamengo', 'River Plate', 'CONMEBOL', 'Maracanã'],
    category: 'MATCH',
    confederation: 'CONMEBOL',
    country: 'Brésil & Argentine',
    countryFlag: '🌎',
    publishedAt: 'Hier',
    source: 'CONMEBOL Media',
    imageUrl: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=600&auto=format&fit=crop&q=80',
    relatedClubId: 'club-conmebol-01',
    relatedClubName: 'CR Flamengo',
    keyHighlight: 'Des scouts de 14 clubs européens majeurs étaient accrédités en tribune au Maracanã.',
    readTimeMinutes: 3
  },
  {
    id: 'news-global-07',
    title: 'Canal+ Sport Afrique & SuperSport : Accord historique de codiffusion pour les tournois de détection U17 et U19',
    summary: 'Les deux géants de la télévision africaine s’associent pour retransmettre en direct les phases finales des tournois Africa Talent Football dans 45 pays subsahariens.',
    fullStory: [
      'Un accord de diffusion télévisée sans précédent a été officialisé ce matin entre Canal+ Sport Afrique, le groupe SuperSport et la direction d’Africa Talent Football.',
      'Ce partenariat prévoit la retransmission en direct des finales de showcases U17 et U19 organisées à Abidjan, Dakar, Cotonou et Douala, avec commentaires en français et en anglais.',
      'Des plateaux tactiques animés par des consultants de renom et des invités spéciaux mettront en lumière les statistiques en direct fournies par le moteur analytique ATF.'
    ],
    tags: ['Canal+ Sport', 'SuperSport', 'Droits TV', 'Diffusion', 'Médias'],
    category: 'OFFICIAL',
    confederation: 'CAF',
    country: 'Afrique Subsaharienne',
    countryFlag: '📺',
    publishedAt: 'Hier',
    source: 'Canal+ Overseas Press',
    imageUrl: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=600&auto=format&fit=crop&q=80',
    keyHighlight: 'Plus de 25 millions de téléspectateurs potentiels pour les futures pépites africaines.',
    readTimeMinutes: 3
  },
  {
    id: 'news-global-08',
    title: 'Tactique & Révolution : Pep Guardiola détaille l’importance des profils athlétiques à prise d’information rapide',
    summary: 'En conférence de presse, l’entraîneur de Manchester City a souligné la valeur inestimable des joueurs capables d’enchaîner sous pression intense avec une VMA supérieure à 19 km/h.',
    fullStory: [
      'Interrogé sur l’évolution du recrutement moderne lors de sa conférence de presse d’avant-match en Ligue des Champions, Pep Guardiola a insisté sur la symbiose entre vitesse cérébrale et explosivité motrice.',
      '« Le football moderne ne tolère plus de joueur sans perception périphérique ultra-rapide. Les talents formés en Afrique possèdent cette spontanéité technique brute qui fait la différence en transition », a expliqué le tacticien catalan.',
      'Cette philosophie rejoint directement la grille d’évaluation multicritères développée par Africa Talent Football pour noter les prises de décision sous pressing.'
    ],
    tags: ['Pep Guardiola', 'Tactique', 'VMA', 'Prise d’information', 'Man City'],
    category: 'TACTICAL',
    confederation: 'UEFA',
    country: 'Angleterre',
    countryFlag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    publishedAt: 'Il y a 2 jours',
    source: 'Premier League Press & Man City TV',
    imageUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=600&auto=format&fit=crop&q=80',
    relatedClubId: 'club-uefa-02',
    relatedClubName: 'Manchester City FC',
    keyHighlight: 'L’anticipation spatiale couplée à la vitesse pure reste le critère numéro 1 du football mondial.',
    readTimeMinutes: 4
  },
  {
    id: 'news-global-09',
    title: 'Asie & Arabie Saoudite : Les académies de la Saudi Pro League lancent des partenariats de scouting croisé avec l’Afrique',
    summary: 'Al Hilal et Al Nassr signent des conventions bilatérales avec Africa Talent Football pour organiser des stages de détection communs pour les catégories U16-U19.',
    fullStory: [
      'Dans le cadre de la vision 2030 et de l’expansion de la Saudi Pro League, les académies d’Al Hilal SFC et d’Al Nassr FC ont paraphé une lettre d’intention conjointe avec Africa Talent Football.',
      'Le programme vise l’échange de compétences en encadrement technique, la tenue de tournois de détection croisés à Riyad et Djeddah, ainsi que l’attribution de bourses d’immersion sportive pour de jeunes pensionnaires de centres ouest-africains.',
      'Les clubs saoudiens souhaitent attirer des profils à très haut potentiel athlétique avant leur départ vers l’Europe.'
    ],
    tags: ['Saudi Pro League', 'Al Hilal', 'Al Nassr', 'AFC', 'Riyad'],
    category: 'SCOUTING',
    confederation: 'AFC',
    country: 'Arabie Saoudite',
    countryFlag: '🇸🇦',
    publishedAt: 'Il y a 2 jours',
    source: 'Saudi Sports Authority & ATF Desk',
    imageUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&auto=format&fit=crop&q=80',
    keyHighlight: 'Organisation de stages de détection conjoints et partage d’infrastructures ultramodernes.',
    readTimeMinutes: 3
  },
  {
    id: 'news-global-10',
    title: 'CONCACAF & Bourses Universitaires US : La MLS Next Pro et 24 universités de NCAA Division 1 recrutent via la plateforme',
    summary: 'Un accord cadre permet désormais aux coachs universitaires américains de proposer des bourses NCAA d’une valeur de 60 000 $/an aux jeunes footballeurs africains bacheliers.',
    fullStory: [
      'La filière sportive et universitaire américaine s’ouvre massivement aux talents d’Afrique Talent Football. Vingt-quatre universités de NCAA Division 1 (dont Virginia, UCLA, Indiana et Wake Forest) ont validé l’accès direct au vivier de talents de la plateforme.',
      'Pour les jeunes talents alliant qualités footballistiques de haut niveau et parcours scolaire régulier, ces bourses complètes couvrent 100% des frais de scolarité, l’hébergement et les soins médicaux aux États-Unis.',
      'De surcroît, les recruteurs de la MLS Next Pro utilisent ces données pour alimenter les drafts professionnels annuelles.'
    ],
    tags: ['MLS', 'NCAA Division 1', 'Bourses USA', 'CONCACAF', 'États-Unis'],
    category: 'ACADEMY',
    confederation: 'CONCACAF',
    country: 'États-Unis',
    countryFlag: '🇺🇸',
    publishedAt: 'Il y a 3 jours',
    source: 'MLS Next Pro Scouting Bureau',
    imageUrl: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=600&auto=format&fit=crop&q=80',
    keyHighlight: 'Bourses sport-études universitaires américaines d’une valeur de 60 000 $/an par athlète.',
    readTimeMinutes: 4
  }
];
