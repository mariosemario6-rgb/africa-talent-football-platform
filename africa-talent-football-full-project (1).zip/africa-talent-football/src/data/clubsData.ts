import { FootballClub } from '../types/database';
import { CAF_CLUBS } from './clubs/cafClubs';
import { UEFA_CLUBS } from './clubs/uefaClubs';
import { CONMEBOL_CLUBS } from './clubs/conmebolClubs';
import { CONCACAF_CLUBS } from './clubs/concacafClubs';
import { AFC_CLUBS } from './clubs/afcClubs';
import { OFC_CLUBS } from './clubs/ofcClubs';

export const COMPREHENSIVE_WORLD_CLUBS: FootballClub[] = [
  ...CAF_CLUBS,
  ...UEFA_CLUBS,
  ...CONMEBOL_CLUBS,
  ...CONCACAF_CLUBS,
  ...AFC_CLUBS,
  ...OFC_CLUBS,
];

export {
  CAF_CLUBS,
  UEFA_CLUBS,
  CONMEBOL_CLUBS,
  CONCACAF_CLUBS,
  AFC_CLUBS,
  OFC_CLUBS,
};
