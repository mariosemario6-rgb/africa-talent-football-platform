import {
  FootballClub,
  FootballProfessional,
  FootballCompany,
  Conversation,
  ChatMessage,
  FeedPost
} from '../types/database';
import { INITIAL_REGISTERED_PLAYERS, FOUNDER_INFO } from './demoData';
import { COMPREHENSIVE_WORLD_CLUBS } from './clubsData';
export { INITIAL_MERCATO_ALERTS } from './mercatoData';

export const GLOBAL_CLUBS: FootballClub[] = COMPREHENSIVE_WORLD_CLUBS;

export const GLOBAL_PROFESSIONALS: FootballProfessional[] = [
  {
    id: 'pro-01',
    name: 'Seydou Mario TRAORÉ',
    title: 'Scout Agent, Director, Founder of Africa Talent Football',
    role: 'SCOUT_AGENT',
    clubOrOrg: 'Africa Talent Football Platform',
    country: "Côte d'Ivoire",
    countryFlag: '🇨🇮',
    avatarUrl: FOUNDER_INFO.name ? '/src/assets/images/founder_mario_suit_1792079172729.jpg' : '',
    verified: true,
    email: 'mariosemario6@gmail.com',
    phone: '+225 05 44 42 01 62',
    connectionsCount: 3450,
    connectionStatus: 'CONNECTED',
    bio: 'Superviseur technique et scout agent international. Détection scientifique, vidéos certifiées et pont direct avec les clubs européens et mondiaux.'
  },
  {
    id: 'pro-02',
    name: 'Dimitri de Condé',
    title: 'Directeur Sportif / Head of Football',
    role: 'SPORTING_DIRECTOR',
    clubOrOrg: 'KRC Genk (Belgique)',
    country: 'Belgique',
    countryFlag: '🇧🇪',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    verified: true,
    email: 'd.deconde@krcgenk.be',
    phone: '+32 89 84 96 00',
    connectionsCount: 2800,
    connectionStatus: 'CONNECTED',
    bio: 'Directeur sportif réputé pour son flair sur les talents émergents africains et leur valorisation sur le marché européen.'
  },
  {
    id: 'pro-03',
    name: 'Jean-Luc Moreau',
    title: 'Responsable Cellule Recrutement Afrique & Europe de l’Est',
    role: 'CHIEF_SCOUT',
    clubOrOrg: 'Standard de Liège',
    country: 'Belgique',
    countryFlag: '🇧🇪',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    verified: true,
    email: 'recrutement@standard.be',
    phone: '+32 4 252 21 22',
    connectionsCount: 1940,
    connectionStatus: 'CONNECTED',
    bio: 'Observateur terrain permanent en Afrique de l’Ouest. Partenaire régulier du desk Seydou Mario TRAORÉ.'
  },
  {
    id: 'pro-04',
    name: 'Will Still',
    title: 'Entraîneur Principal Professionnel',
    role: 'HEAD_COACH',
    clubOrOrg: 'Racing Club de Lens (Ligue 1)',
    country: 'France',
    countryFlag: '🇫🇷',
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
    verified: true,
    email: 'staff.technique@rclens.fr',
    phone: '+33 3 21 13 22 22',
    connectionsCount: 4600,
    connectionStatus: 'CONNECT',
    bio: 'Coach moderne de Ligue 1 adepte d’intensité, de pressing haut et de développement de talents dynamiques.'
  },
  {
    id: 'pro-05',
    name: 'Pierre Locht',
    title: 'Président Directeur Général',
    role: 'PRESIDENT',
    clubOrOrg: 'Standard de Liège',
    country: 'Belgique',
    countryFlag: '🇧🇪',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80',
    verified: true,
    email: 'direction@standard.be',
    phone: '+32 4 252 21 22',
    connectionsCount: 1520,
    connectionStatus: 'CONNECT',
    bio: 'Dirigeant exécutif supervisant la politique sportive et les partenariats d’académies internationales du club.'
  },
  {
    id: 'pro-06',
    name: 'David Weir',
    title: 'Directeur Technique & Recrutement',
    role: 'SPORTING_DIRECTOR',
    clubOrOrg: 'Brighton & Hove Albion FC',
    country: 'Angleterre',
    countryFlag: '🇬🇧',
    avatarUrl: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=120&auto=format&fit=crop&q=80',
    verified: true,
    email: 'technical@bhafc.co.uk',
    phone: '+44 1273 878288',
    connectionsCount: 3890,
    connectionStatus: 'CONNECT',
    bio: 'Directeur technique du club modèle en matière d’acquisition analytique et d’intégration de talents mondiaux.'
  },
  {
    id: 'pro-07',
    name: 'Julien Chevalier',
    title: 'Entraîneur Principal Professionnel',
    role: 'HEAD_COACH',
    clubOrOrg: 'ASEC Mimosas',
    country: "Côte d'Ivoire",
    countryFlag: '🇨🇮',
    avatarUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&auto=format&fit=crop&q=80',
    verified: true,
    email: 'coach@asec.ci',
    phone: '+225 27 22 44 20 00',
    connectionsCount: 2750,
    connectionStatus: 'CONNECTED',
    bio: 'Formateur et entraîneur français d’élite en Afrique de l’Ouest, champion de Côte d’Ivoire et demi-finaliste CAF.'
  },
  {
    id: 'pro-08',
    name: 'Me Laurent Delvaux',
    title: 'Avocat Mandataire Sportif Spécialiste FIFA',
    role: 'LAWYER',
    clubOrOrg: 'Sport & Law Partners (Genève / Paris)',
    country: 'Suisse',
    countryFlag: '🇨🇭',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    verified: true,
    email: 'ldelvaux@sportlaw-partners.ch',
    phone: '+41 22 718 20 00',
    connectionsCount: 1180,
    connectionStatus: 'CONNECTED',
    bio: 'Expert réglementaire transferts internationaux, contrats aspirants et conformité stricte Article 19 FIFA.'
  }
];

export const GLOBAL_COMPANIES: FootballCompany[] = [
  // --- MAJOR MULTINATIONAL COMPANIES & SPONSORS ---
  {
    id: 'comp-01',
    name: 'Nike Football Global',
    category: 'Grandes Entreprises & Sponsors Mondiaux',
    entityType: 'CORPORATE',
    country: 'États-Unis / Monde',
    countryFlag: '🇺🇸',
    logoUrl: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Marcus Vance',
    contactRole: 'Global Director of Grassroots & Emerging Talents',
    verified: true,
    followersCount: 145000,
    website: 'https://nike.com/football',
    description: 'Leader mondial de l’équipement sportif, propulseur des plus grandes icônes du football mondial et partenaire d’académies d’élite.',
    partnershipOpportunities: [
      'Dotation d’équipements et ballons de match officiels',
      'Contrats athlètes espoirs pour les pépites certifiées U17/U19',
      'Accès prioritaire aux Nike Premier Cup et tournois mondiaux'
    ],
    programDetails: {
      sponsorshipPackages: ['Contrat Équipement Élite', 'Bourse Athlète Nike NextGen', 'Showcase Mondial Oregon']
    }
  },
  {
    id: 'comp-02',
    name: 'TotalEnergies African Football',
    category: 'Grandes Entreprises & Sponsors Mondiaux',
    entityType: 'CORPORATE',
    country: 'France / Afrique',
    countryFlag: '🇫🇷',
    logoUrl: 'https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Amadou Cissé',
    contactRole: 'Directeur des Partenariats Sportifs & Jeunesse CAF',
    verified: true,
    followersCount: 110000,
    website: 'https://totalenergies.com',
    description: 'Partenaire titre historique du football africain et de la CAF, finançant les compétitions continentales et le développement de la jeunesse.',
    partnershipOpportunities: [
      'Subvention des tournois de détection panafricains',
      'Programme d’insertion professionnelle des jeunes athlètes',
      'Visibilité de marque sur les événements Africa Talent Football'
    ],
    programDetails: {
      sponsorshipPackages: ['Fonds Jeunesse TotalEnergies', 'Bourse d’Excellence RSE', 'Support Infrastructures Académies']
    }
  },
  {
    id: 'comp-03',
    name: 'Orange Télécom Sports Afrique',
    category: 'Grandes Entreprises & Sponsors Mondiaux',
    entityType: 'CORPORATE',
    country: 'France / Côte d’Ivoire / Sénégal',
    countryFlag: '🇨🇮',
    logoUrl: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Fatou Diop',
    contactRole: 'Responsable Sponsoring Sportif & Écosystème Digital',
    verified: true,
    followersCount: 88000,
    website: 'https://orange.com',
    description: 'Opérateur télécom majeur en Afrique de l’Ouest, soutenant la digitalisation des centres de formation et la connectivité des talents.',
    partnershipOpportunities: [
      'Diffusion des flux vidéo de détection via plateformes mobiles Orange',
      'Équipement numérique des académies partenaires',
      'Bourses Orange Football Digital pour les jeunes scouts'
    ],
    programDetails: {
      sponsorshipPackages: ['Pass Digital Académie', 'Tournoi Orange e-Football & Terrain', 'Partenariat Data Haut Débit']
    }
  },
  {
    id: 'comp-04',
    name: 'MTN Group Youth Football',
    category: 'Grandes Entreprises & Sponsors Mondiaux',
    entityType: 'CORPORATE',
    country: 'Afrique du Sud / Panafricain',
    countryFlag: '🇿🇦',
    logoUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Kgomotso Ndlovu',
    contactRole: 'Executive Head of Youth & Sports Sponsorship',
    verified: true,
    followersCount: 97000,
    website: 'https://mtn.com',
    description: 'Le plus grand réseau télécom panafricain, engagé dans l’émancipation par le sport et la valorisation des compétences footballistiques.',
    partnershipOpportunities: [
      'Parrainage des détections régionales dans 17 pays africains',
      'Financement de bourses pour les prodiges non signés',
      'Campagnes de visibilité panafricaine'
    ]
  },
  {
    id: 'comp-05',
    name: 'Fly Emirates Sports Sponsorship',
    category: 'Grandes Entreprises & Sponsors Mondiaux',
    entityType: 'CORPORATE',
    country: 'Émirats Arabes Unis / Monde',
    countryFlag: '🇦🇪',
    logoUrl: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Tariq Al-Mansoor',
    contactRole: 'Senior Vice President Sports & Cultural Sponsorship',
    verified: true,
    followersCount: 160000,
    website: 'https://emirates.com',
    description: 'Partenaire aérien mondial des géants du football (Real Madrid, Arsenal, AC Milan), facilitant les déplacements internationaux de délégations.',
    partnershipOpportunities: [
      'Accords de transport aérien pour les stages d’immersion en Europe et au Moyen-Orient',
      'Passerelles directes avec les clubs sous pavillon Emirates',
      'Accueil privilégié lors des tournées internationales'
    ]
  },

  // --- MAJOR BANKS & FINANCIAL INSTITUTIONS ---
  {
    id: 'bank-01',
    name: 'Standard Chartered Bank - Sports Finance',
    category: 'Banque & Financement Sportif',
    entityType: 'BANK',
    country: 'Royaume-Uni / Afrique',
    countryFlag: '🇬🇧',
    logoUrl: 'https://images.unsplash.com/photo-1541354329998-f4d9a9f9297f?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Sir Alistair Campbell',
    contactRole: 'Managing Director, Global Sports Finance & Wealth',
    verified: true,
    followersCount: 78000,
    website: 'https://sc.com/sports-finance',
    description: 'Banque internationale de premier rang, partenaire majeur du Liverpool FC et spécialiste de la structuration financière des transferts et de la gestion de patrimoine des joueurs.',
    partnershipOpportunities: [
      'Lignes de cautionnement bancaire pour transferts internationaux FIFA',
      'Comptes séquestres (escrow accounts) sécurisés pour indemnités de formation',
      'Gestion privée et accompagnement patrimonial des joueurs néo-professionnels'
    ],
    programDetails: {
      financingTypes: ['Cautionnement Transfert FIFA', 'Compte Séquestre Sécurisé', 'Crédit d’Investissement Académie'],
      scholarshipFundEur: '2 500 000 € / an'
    }
  },
  {
    id: 'bank-02',
    name: 'Ecobank Transnational Incorporated',
    category: 'Banque & Financement Sportif',
    entityType: 'BANK',
    country: 'Panafricain (Siège : Lomé / Abidjan)',
    countryFlag: '🇹🇬',
    logoUrl: 'https://images.unsplash.com/photo-1501167786227-4cba60f6d58f?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Kouassi Jean-Baptiste',
    contactRole: 'Directeur Général Pôle Économie du Sport & Académies',
    verified: true,
    followersCount: 65000,
    website: 'https://ecobank.com',
    description: 'La banque panafricaine de référence présente dans 35 pays d’Afrique, offrant des solutions bancaires sur mesure pour clubs, académies et transferts de joueurs.',
    partnershipOpportunities: [
      'Comptes dédiés de gestion des primes et indemnités de transfert',
      'Financement d’infrastructures (terrains synthétiques, internats sportifs)',
      'Assurance santé et rapatriement international pour joueurs en essai'
    ],
    programDetails: {
      financingTypes: ['Facilité de Caisse Mercato', 'Crédit Équipement Centre de Formation', 'Microcrédit Familles Athlètes'],
      scholarshipFundEur: '1 200 000 € / an'
    }
  },
  {
    id: 'bank-03',
    name: 'Banque Africaine de Développement (BAD / AfDB)',
    category: 'Banque & Financement Sportif',
    entityType: 'BANK',
    country: 'Afrique (Siège : Abidjan)',
    countryFlag: '🇨🇮',
    logoUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Dr. Amina Traoré-Keïta',
    contactRole: 'Coordinatrice Fonds Spécial Jeunesse & Entrepreneuriat Sportif',
    verified: true,
    followersCount: 92000,
    website: 'https://afdb.org',
    description: 'Institution financière multilatérale de développement finançant les programmes structurants pour l’employabilité des jeunes et les infrastructures sportives de pointe.',
    partnershipOpportunities: [
      'Subventions non remboursables pour centres de formation agréés',
      'Appui technique et audit de conformité éthique et financière',
      'Intégration au programme "Des emplois pour les jeunes en Afrique"'
    ],
    programDetails: {
      financingTypes: ['Subvention d’Infrastructures Sportives', 'Fonds d’Appui Formation Continue'],
      scholarshipFundEur: '5 000 000 € / an'
    }
  },
  {
    id: 'bank-04',
    name: 'Société Générale Afrique & Méditerranée',
    category: 'Banque & Financement Sportif',
    entityType: 'BANK',
    country: 'France / Côte d’Ivoire / Sénégal / Maroc',
    countryFlag: '🇫🇷',
    logoUrl: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Bertrand Lefebvre',
    contactRole: 'Responsable Financement Grands Projets & Sports Afrique',
    verified: true,
    followersCount: 51000,
    website: 'https://societegenerale.africa',
    description: 'Banque partenaire historique du sport africain, garantissant les opérations de change, garanties bancaires à première demande et sécurisation de flux.',
    partnershipOpportunities: [
      'Émission de garanties bancaires pour clubs européens acheteurs',
      'Assurance juridique et protection contractuelle des mineurs',
      'Comptes d’épargne bloquée pour jeunes espoirs'
    ]
  },
  {
    id: 'bank-05',
    name: 'Attijariwafa Bank Sports & Development',
    category: 'Banque & Financement Sportif',
    entityType: 'BANK',
    country: 'Maroc / Afrique de l’Ouest',
    countryFlag: '🇲🇦',
    logoUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Mehdi Benkaddour',
    contactRole: 'Directeur Partenariats Sportifs & Écoles de Football',
    verified: true,
    followersCount: 47000,
    website: 'https://attijariwafabank.com',
    description: 'Groupe bancaire et financier leader au Maghreb et en zone UEMOA, partenaire d’académies d’élite et sponsor de tournois de détection U17.',
    partnershipOpportunities: [
      'Financement de tournois d’immersion Maroc-Afrique subsaharienne',
      'Solutions de paiement multi-devises pour agents et clubs',
      'Accompagnement de projets de complexes sportifs modernes'
    ]
  },

  // --- WORLD-RENOWNED UNIVERSITIES & SPORTS SCIENCE INSTITUTES ---
  {
    id: 'univ-01',
    name: 'Loughborough University - School of Sport',
    category: 'Université & Bourses Sport-Études',
    entityType: 'UNIVERSITY',
    country: 'Royaume-Uni',
    countryFlag: '🇬🇧',
    logoUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Prof. David Sanderson',
    contactRole: 'Dean of International Sports Science & Elite Athlete Recruitment',
    verified: true,
    followersCount: 85000,
    website: 'https://lboro.ac.uk/sport',
    description: 'Classée N°1 Mondiale en sciences du sport (QS World Ranking), pionnière dans l’analyse de performance biomécanique, l’évaluation physique et les cursus sport-études universitaires.',
    partnershipOpportunities: [
      'Bourses d’études complètes (Full Sports Scholarship) pour jeunes joueurs africains bacheliers',
      'Audit physique et biométrique de haute précision pour profils certifiés ATF',
      'Cursus double projet : Diplôme universitaire + entraînement en équipe universitaire d’élite'
    ],
    programDetails: {
      scholarshipFundEur: '1 800 000 £ / an',
      academicPrograms: [
        'BSc Sport Science & Football Performance',
        'MSc Football Analytics & Scouting',
        'Elite Athlete Development Track'
      ]
    }
  },
  {
    id: 'univ-02',
    name: 'Oxford University - Sports Analytics Lab',
    category: 'Université & Bourses Sport-Études',
    entityType: 'UNIVERSITY',
    country: 'Royaume-Uni',
    countryFlag: '🇬🇧',
    logoUrl: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Dr. Eleanor Wright',
    contactRole: 'Head of Sports Analytics & International Fellowships',
    verified: true,
    followersCount: 120000,
    website: 'https://ox.ac.uk',
    description: 'Une des universités les plus renommées de la planète, abritant un département d’analyse de données sportives et des passerelles d’excellence pour talents et analystes mondiaux.',
    partnershipOpportunities: [
      'Bourses de recherche et fellowship en data science appliquée au football',
      'Modélisation prédictive de détection des talents d’Afrique subsaharienne',
      'Conférences et masterclasses pour directeurs de centres de formation'
    ],
    programDetails: {
      scholarshipFundEur: '2 000 000 £ / an',
      academicPrograms: ['Postgraduate Fellowship Football Data', 'Sports Management Executive Program']
    }
  },
  {
    id: 'univ-03',
    name: 'University of Cape Town (UCT) - Sports Science Institute',
    category: 'Université & Bourses Sport-Études',
    entityType: 'UNIVERSITY',
    country: 'Afrique du Sud',
    countryFlag: '🇿🇦',
    logoUrl: 'https://images.unsplash.com/photo-1498243691581-b145c3f54a5a?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Prof. Thabo Moloi',
    contactRole: 'Director, Sports Science Institute of South Africa (SSISA)',
    verified: true,
    followersCount: 59000,
    website: 'https://ssisa.com',
    description: 'L’institution universitaire de pointe en Afrique en physiologie de l’effort, tests VO2max et préparation athlétique pour footballeurs de haut niveau.',
    partnershipOpportunities: [
      'Bourses sport-études panafricaines UCT pour joueurs bilingues',
      'Stages de préparation physique intensive en altitude pour joueurs présélectionnés',
      'Certification des tests physiques des tournois Africa Talent Football'
    ],
    programDetails: {
      scholarshipFundEur: '850 000 $ / an',
      academicPrograms: ['BSc Exercise Science', 'High Performance Football Academy']
    }
  },
  {
    id: 'univ-04',
    name: 'Université Cheikh Anta Diop (UCAD) - INSEPS Dakar',
    category: 'Université & Bourses Sport-Études',
    entityType: 'UNIVERSITY',
    country: 'Sénégal',
    countryFlag: '🇸🇳',
    logoUrl: 'https://images.unsplash.com/photo-1562774053-701939374585?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Dr. Babacar Ndiaye',
    contactRole: 'Directeur des Études & Coopération Internationale',
    verified: true,
    followersCount: 42000,
    website: 'https://ucad.sn/inseps',
    description: 'Institut National Supérieur de l’Éducation Populaire et du Sport de Dakar, référence d’Afrique francophone pour la formation des entraîneurs, préparateurs physiques et managers sportifs.',
    partnershipOpportunities: [
      'Formation diplômante CAF/FIFA pour formateurs d’académies ivoiriennes et sénégalaises',
      'Programme d’accueil et reconversion sportive pour anciens footballeurs',
      'Suivi scientifique de croissance et maturation osseuse des U15/U17'
    ],
    programDetails: {
      scholarshipFundEur: '400 000 € / an',
      academicPrograms: ['Licence & Master Management du Sport', 'Diplôme d’Entraîneur Fédéral d’Élite']
    }
  },
  {
    id: 'univ-05',
    name: 'Sorbonne Université & INSEP Paris',
    category: 'Université & Bourses Sport-Études',
    entityType: 'UNIVERSITY',
    country: 'France',
    countryFlag: '🇫🇷',
    logoUrl: 'https://images.unsplash.com/photo-1592280771190-3e2e4d571952?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Dr. Claire Delorme',
    contactRole: 'Responsable Pôle Sport de Haut Niveau & Passerelles Francophonie',
    verified: true,
    followersCount: 73000,
    website: 'https://insep.fr',
    description: 'Le temple de la performance sportive française associé à la prestigieuse Sorbonne, accueillant l’élite mondiale pour des cursus d’excellence sportive et académique.',
    partnershipOpportunities: [
      'Bourses d’immersion sport-études pour les profils majeurs bacheliers détectés par ATF',
      'Bilans de performance biomécanique dans les laboratoires de l’INSEP au Bois de Vincennes',
      'Programme de mentorat avec d’anciens internationaux tricolores et africains'
    ],
    programDetails: {
      scholarshipFundEur: '950 000 € / an',
      academicPrograms: ['DU Droit & Économie du Sport Professionnel', 'Master Optimisation de la Performance']
    }
  },

  // --- DATA, TECH & MEDIA PARTNERS ---
  {
    id: 'comp-tech-01',
    name: 'Wyscout / Hudl Football',
    category: 'Data & Video Analytics',
    entityType: 'TECH',
    country: 'Italie / Mondial',
    countryFlag: '🇮🇹',
    logoUrl: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Matteo Rinaldi',
    contactRole: 'Global Scouting Relations Director',
    verified: true,
    followersCount: 65000,
    website: 'https://wyscout.com',
    description: 'La plus grande plateforme mondiale de séquençage vidéo, données de match et scouting pour clubs professionnels.',
    partnershipOpportunities: [
      'Indexation officielle des profils certifiés Africa Talent Football',
      'Accès direct aux fiches pour les clubs partenaires'
    ]
  },
  {
    id: 'comp-tech-02',
    name: 'Catapult Sports Football',
    category: 'Data & Video Analytics',
    entityType: 'TECH',
    country: 'Royaume-Uni / Monde',
    countryFlag: '🇬🇧',
    logoUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Marc Henderson',
    contactRole: 'Head of Elite Academy Partnerships',
    verified: true,
    followersCount: 22000,
    website: 'https://catapultsports.com',
    description: 'Leader mondial des gilets GPS et capteurs biométriques équipant les académies pour mesurer la VMA et vitesse de pointe.',
    partnershipOpportunities: [
      'Équipement GPS des tournois Africa Talent Football',
      'Rapports biométriques certifiés partagés aux clubs'
    ]
  },
  // --- TELEVISION & BROADCASTING GIANTS ---
  {
    id: 'tv-01',
    name: 'Canal+ Sport Afrique & A+',
    category: 'Chaîne Télévision & Médias Mondiaux',
    entityType: 'TELEVISION',
    country: 'France / Côte d’Ivoire / Sénégal',
    countryFlag: '🇨🇮',
    logoUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Koffi Mensah',
    contactRole: 'Directeur des Acquisitions & Émissions Découverte',
    verified: true,
    followersCount: 195000,
    website: 'https://canalplus-afrique.com',
    description: 'Premier diffuseur du football d’élite en Afrique subsaharienne (Ligue 1, Champions League, CAN), produisant des reportages d’immersion sur les futures pépites africaines.',
    partnershipOpportunities: [
      'Diffusion des résumés vidéo des tournois Africa Talent Football sur Canal+ Sport',
      'Couverture télévisuelle en direct des showcases U19',
      'Production de capsules documentaires exclusives "Génération Talents"'
    ],
    programDetails: {
      sponsorshipPackages: ['Pack Diffusion Télévisée Exclusive', 'Partenariat Écran Géant & Droits d’Images']
    }
  },
  {
    id: 'tv-02',
    name: 'beIN Sports Global',
    category: 'Chaîne Télévision & Médias Mondiaux',
    entityType: 'TELEVISION',
    country: 'Qatar / France / MENA',
    countryFlag: '🇶🇦',
    logoUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Youssef El-Hadj',
    contactRole: 'Head of Global Football Scouting Programming',
    verified: true,
    followersCount: 280000,
    website: 'https://beinsports.com',
    description: 'Réseau mondial de télévision sportive diffusant dans plus de 40 pays, partenaire majeur des grandes compétitions FIFA, UEFA et CAF.',
    partnershipOpportunities: [
      'Visibilité internationale des talents auprès des directeurs sportifs du Golfe et d’Europe',
      'Diffusion multi-plateforme beIN Connect des phases finales de détection',
      'Interviews exclusives de Seydou Mario Traoré et des scouts partenaires'
    ]
  },
  {
    id: 'tv-03',
    name: 'SuperSport Africa (MultiChoice)',
    category: 'Chaîne Télévision & Médias Mondiaux',
    entityType: 'TELEVISION',
    country: 'Afrique du Sud / Nigéria / Ghana / Kenya',
    countryFlag: '🇿🇦',
    logoUrl: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Babatunde Adeleke',
    contactRole: 'Senior Commissioning Editor - African Grassroots Football',
    verified: true,
    followersCount: 165000,
    website: 'https://supersport.com',
    description: 'Le géant de la télévision sportive en Afrique anglophone et australe, diffuseur officiel de la Premier League et pionnier du scouting télévisuel.',
    partnershipOpportunities: [
      'Retransmission pan-africaine en anglais des tests de détection',
      'Partenariat médias pour les académies du Nigéria, Ghana et Afrique du Sud',
      'Intégration des profils vidéos certifiés dans les émissions d’analyse tactique'
    ]
  },
  {
    id: 'tv-04',
    name: 'New World TV',
    category: 'Chaîne Télévision & Médias Mondiaux',
    entityType: 'TELEVISION',
    country: 'Togo / Panafricain / France',
    countryFlag: '🇹🇬',
    logoUrl: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Éric Tano',
    contactRole: 'Directeur Général Pôle Sports & Événements',
    verified: true,
    followersCount: 75000,
    website: 'https://newworldtv.com',
    description: 'Groupe audiovisuel panafricain détenteur des droits exclusifs FIFA & CAF en Afrique francophone, engagé dans la promotion du football à la base.',
    partnershipOpportunities: [
      'Partenariat de retransmission télévisée en direct par satellite et TNT',
      'Sponsoring des émissions spéciales de recrutement',
      'Accès prioritaire aux images de match officielles'
    ]
  },

  // --- TELECOM & COMMUNICATION LEADERS ---
  {
    id: 'telecom-01',
    name: 'Vodacom / Vodafone Africa Football',
    category: 'Opérateur Télécom & Communication',
    entityType: 'TELECOM',
    country: 'RDC / Afrique du Sud / Tanzanie',
    countryFlag: '🇨🇩',
    logoUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Mukendi Ilunga',
    contactRole: 'Directeur Sponsoring Digital & Connectivité des Jeunes',
    verified: true,
    followersCount: 130000,
    website: 'https://vodacom.com',
    description: 'Leader des télécommunications mobiles et de l’Internet haut débit en RDC et Afrique australe, sponsor historique de la Ligue 1 Vodacom.',
    partnershipOpportunities: [
      'Fourniture de connectivité 5G et tablettes de scouting pour les académies',
      'Plateforme de vote populaire et bourses data pour les supporters',
      'Financement d’infrastructures de transmission vidéo en direct depuis les stades'
    ],
    programDetails: {
      sponsorshipPackages: ['Pack Connectivité Fibre Stade', 'Dotation Écrans Numériques & Analyse']
    }
  },
  {
    id: 'telecom-02',
    name: 'Moov Africa (Groupe Maroc Telecom)',
    category: 'Opérateur Télécom & Communication',
    entityType: 'TELECOM',
    country: 'Côte d’Ivoire / Bénin / Gabon / Burkina Faso',
    countryFlag: '🇨🇮',
    logoUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Sékou Sanogo',
    contactRole: 'Responsable Communication Commerciale & Partenariats Sportifs',
    verified: true,
    followersCount: 94000,
    website: 'https://moov-africa.ci',
    description: 'Opérateur de premier plan en Afrique de l’Ouest et centrale, soutenant activement les initiatives sportives de proximité et la jeunesse.',
    partnershipOpportunities: [
      'Parrainage officiel des tournois de quartier et détections régionales',
      'Solutions de paiement mobile Moov Money pour les inscriptions et conventions',
      'Campagnes SMS et visibilité sur 11 pays africains'
    ]
  },

  // --- FOOD, BEVERAGE & SPORTS NUTRITION GIANTS ---
  {
    id: 'food-01',
    name: 'Nestlé Milo Grassroots Football',
    category: 'Agroalimentaire, Boissons & Nutrition',
    entityType: 'FOOD',
    country: 'Suisse / Panafricain (Siège régional : Abidjan)',
    countryFlag: '🇨🇭',
    logoUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Christian Kaboré',
    contactRole: 'Brand Manager Milo Sports & Nutrition Jeunesse',
    verified: true,
    followersCount: 185000,
    website: 'https://milo.com',
    description: 'Partenaire mondial historique du sport scolaire et des tournois de football jeunesse U13-U17, incarnant l’énergie, l’effort et la nutrition saine.',
    partnershipOpportunities: [
      'Dotation en petits-déjeuners fortifiés et boissons énergétiques pour les académies',
      'Parrainage du Trophée Milo des Meilleurs Buteurs U17',
      'Ateliers de sensibilisation à l’équilibre nutritionnel des futurs athlètes pro'
    ],
    programDetails: {
      sponsorshipPackages: ['Dotation Alimentaire Annuelle Académie', 'Trophée Nutrition & Performance Milo']
    }
  },
  {
    id: 'food-02',
    name: 'Danone Nations Cup Football',
    category: 'Agroalimentaire, Boissons & Nutrition',
    entityType: 'FOOD',
    country: 'France / Maroc / Monde',
    countryFlag: '🇫🇷',
    logoUrl: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Marie-Laure Dupont',
    contactRole: 'Global Director - Youth Football & Health Through Food',
    verified: true,
    followersCount: 140000,
    website: 'https://danonenationscup.com',
    description: 'La plus grande compétition internationale de football pour les jeunes de 10 à 15 ans, parrainée par les plus grandes légendes du football mondial.',
    partnershipOpportunities: [
      'Passerelle officielle de repérage des talents lors des finales Danone Nations Cup',
      'Fourniture de produits laitiers et nutrition sportive aux centres d’entraînement',
      'Bourses d’excellence pour les enfants défavorisés à fort potentiel athlétique'
    ]
  },
  {
    id: 'food-03',
    name: 'Coca-Cola Youth Football Cup (Copa Coca-Cola)',
    category: 'Agroalimentaire, Boissons & Nutrition',
    entityType: 'FOOD',
    country: 'États-Unis / Afrique',
    countryFlag: '🇺🇸',
    logoUrl: 'https://images.unsplash.com/photo-1554866585-cd94860890b7?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'David Osei',
    contactRole: 'VP Marketing & Football Sponsorship Africa',
    verified: true,
    followersCount: 310000,
    website: 'https://coca-cola.com',
    description: 'Partenaire historique de la Coupe du Monde FIFA et initiateur de la Copa Coca-Cola réunissant plus de 1 million de jeunes joueurs chaque année.',
    partnershipOpportunities: [
      'Hydratation officielle lors de tous les matchs et tournois Africa Talent Football',
      'Camp d’entraînement international pour les 5 meilleurs talents détectés de l’année',
      'Visibilité de premier plan sur l’ensemble des événements ATF'
    ],
    programDetails: {
      sponsorshipPackages: ['Hydratation Totale Showcase', 'Camp Mondial d’Entraînement']
    }
  },
  {
    id: 'food-04',
    name: 'Gatorade Sports Science Institute (PepsiCo)',
    category: 'Agroalimentaire, Boissons & Nutrition',
    entityType: 'FOOD',
    country: 'États-Unis / Europe / Monde',
    countryFlag: '🇺🇸',
    logoUrl: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Dr. James Martinez',
    contactRole: 'Head of Elite Football Hydration & Recovery Science',
    verified: true,
    followersCount: 115000,
    website: 'https://gssiweb.org',
    description: 'Le laboratoire de référence scientifique de la boisson sportive n°1 des clubs de Ligue des Champions, mesurant le taux de sudation et la récupération électrolytique.',
    partnershipOpportunities: [
      'Tests de sudation et bilans d’hydratation personnalisés pour les pépites ATF',
      'Fourniture de bidons et poudres électrolytes de récupération physique',
      'Rapports d’endurance physiologique intégrés aux dossiers scouts de Seydou Mario Traoré'
    ]
  },
  {
    id: 'food-05',
    name: 'Red Bull Athlete Performance Academy',
    category: 'Agroalimentaire, Boissons & Nutrition',
    entityType: 'FOOD',
    country: 'Autriche / Allemagne / Brésil',
    countryFlag: '🇦🇹',
    logoUrl: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=120&auto=format&fit=crop&q=80',
    contactPerson: 'Helmut Weber',
    contactRole: 'Global Head of Football Scouting (Leipzig / Salzburg / Bragantino)',
    verified: true,
    followersCount: 220000,
    website: 'https://redbull.com/football',
    description: 'Le réseau de football le plus dynamique du monde (RB Leipzig, RB Salzbourg, New York Red Bulls), modèle absolu de détection précoce, pressing haut et explosivité.',
    partnershipOpportunities: [
      'Passerelle d’essais directs dans les centres de formation Red Bull en Europe et au Brésil',
      'Stages intensifs au Red Bull Athlete Performance Center (APC) à Thalgau',
      'Contrats athlètes Red Bull pour les phénomènes U17 d’Afrique de l’Ouest'
    ],
    programDetails: {
      sponsorshipPackages: ['Essai Supervisé RB Leipzig / Salzburg', 'Stage Performance APC Autriche']
    }
  }
];

export const INITIAL_CONVERSATIONS: Conversation[] = [
  {
    id: 'conv-01',
    participantId: 'pro-03',
    participantName: 'Jean-Luc Moreau',
    participantTitle: 'Scout Afrique & Europe · Standard de Liège',
    participantAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    participantOrg: 'Standard de Liège',
    participantRole: 'CHIEF_SCOUT',
    lastMessage: 'Bonjour Seydou, nous avons visionné la vidéo d’Ibrahim Kouassi. Peux-tu nous envoyer les 90 minutes complètes de son dernier match ?',
    lastMessageTime: '14:22',
    unreadCount: 1,
    online: true
  },
  {
    id: 'conv-02',
    participantId: 'pro-02',
    participantName: 'Dimitri de Condé',
    participantTitle: 'Directeur Sportif · KRC Genk',
    participantAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    participantOrg: 'KRC Genk',
    participantRole: 'SPORTING_DIRECTOR',
    lastMessage: 'Le profil de Moussa Diallo (1m91) correspond exactement à nos critères axiaux. Quel est son statut contractuel exact ?',
    lastMessageTime: 'Hier',
    unreadCount: 0,
    online: false
  },
  {
    id: 'conv-03',
    participantId: 'comp-01',
    participantName: 'Marc Henderson (Catapult)',
    participantTitle: 'Head of Elite Academy Partnerships',
    participantAvatar: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=120&auto=format&fit=crop&q=80',
    participantOrg: 'Catapult Sports Football',
    participantRole: 'EXECUTIVE',
    lastMessage: 'Nous validons la mise à disposition de 25 capteurs GPS pour votre Showcase d’Abidjan en Mai 2026.',
    lastMessageTime: '26 Sept',
    unreadCount: 0,
    online: true
  }
];

export const INITIAL_MESSAGES: Record<string, ChatMessage[]> = {
  'conv-01': [
    {
      id: 'msg-01',
      conversationId: 'conv-01',
      senderId: 'pro-03',
      senderName: 'Jean-Luc Moreau',
      senderAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
      senderRole: 'Scout Standard de Liège',
      text: 'Bonjour Seydou Mario, j’espère que tu vas bien. Notre cellule de recrutement a analysé la fiche d’Ibrahim Kouassi (buteur, 19 buts cette saison, cote €380k).',
      timestamp: '14:15',
      isMine: false
    },
    {
      id: 'msg-02',
      conversationId: 'conv-01',
      senderId: 'user-scout-01',
      senderName: 'Seydou Mario TRAORÉ',
      senderAvatar: '/src/assets/images/founder_mario_suit_1792079172729.jpg',
      senderRole: 'Scout Agent & Directeur ATF',
      text: 'Bonjour Jean-Luc. Ibrahim est dans une forme athlétique impressionnante. Vitesse de pointe mesurée à 34.4 km/h au dernier match et excellente finition des deux pieds.',
      timestamp: '14:18',
      isMine: true
    },
    {
      id: 'conv-msg-03',
      conversationId: 'conv-01',
      senderId: 'pro-03',
      senderName: 'Jean-Luc Moreau',
      senderAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
      senderRole: 'Scout Standard de Liège',
      text: 'Bonjour Seydou, nous avons visionné la vidéo d’Ibrahim Kouassi. Peux-tu nous envoyer les 90 minutes complètes de son dernier match ?',
      timestamp: '14:22',
      isMine: false,
      attachment: {
        type: 'VIDEO',
        title: 'Ibrahim Kouassi - Match Complet vs AS Tanda (90 min)',
        subtitle: 'Format brut HD avec tracking GPS'
      }
    }
  ],
  'conv-02': [
    {
      id: 'msg-04',
      conversationId: 'conv-02',
      senderId: 'pro-02',
      senderName: 'Dimitri de Condé',
      senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
      senderRole: 'Directeur Sportif KRC Genk',
      text: 'Le profil de Moussa Diallo (1m91) correspond exactement à nos critères axiaux. Quel est son statut contractuel exact ?',
      timestamp: 'Hier 18:30',
      isMine: false
    },
    {
      id: 'msg-05',
      conversationId: 'conv-02',
      senderId: 'user-scout-01',
      senderName: 'Seydou Mario TRAORÉ',
      senderAvatar: '/src/assets/images/founder_mario_suit_1792079172729.jpg',
      senderRole: 'Scout Agent & Directeur ATF',
      text: 'Bonsoir Dimitri. Moussa a 19 ans, passeport valide, libre de tout engagement professionnel et disponible pour un essai officiel dès le mois de mai.',
      timestamp: 'Hier 19:10',
      isMine: true
    }
  ],
  'conv-03': [
    {
      id: 'msg-06',
      conversationId: 'conv-03',
      senderId: 'comp-01',
      senderName: 'Marc Henderson',
      senderAvatar: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=120&auto=format&fit=crop&q=80',
      senderRole: 'Catapult Sports',
      text: 'Nous validons la mise à disposition de 25 capteurs GPS pour votre Showcase d’Abidjan en Mai 2026.',
      timestamp: '26 Sept 10:00',
      isMine: false
    }
  ]
};

export const INITIAL_FEED_POSTS: FeedPost[] = [
  {
    id: 'post-01',
    authorName: 'Seydou Mario TRAORÉ',
    authorTitle: 'Scout Agent, Director, Founder of Africa Talent Football',
    authorAvatar: '/src/assets/images/founder_mario_suit_1792079172729.jpg',
    authorOrg: 'Africa Talent Football Platform',
    authorRole: 'SCOUT_AGENT',
    isVerified: true,
    timeAgo: 'Il y a 3 heures',
    content: '🚨 NOUVEL AUDIT VIDÉO DISPONIBLE SUR LA PLATEFORME !\n\nNous venons de finaliser l’indexation complète des performances de Junior Gnagne (18 ans, Milieu relayeur gaucher, Académie Ivoire Performance). Visionnez sa vidéo de scouting avec ses 14 passes décisives et son orientation corporelle sous pressing.\n\nCote marchande estimée : €290,000. Disponible pour consultation par les cellules de recrutement affiliées.',
    tags: ['#ScoutingAfrique', '#EyeballVideo', '#AfricaTalentFootball', '#TransferMarket', '#ProScouting'],
    likesCount: 148,
    commentsCount: 24,
    sharesCount: 18,
    isLiked: false,
    playerAttachment: INITIAL_REGISTERED_PLAYERS[1],
    videoPreviewUrl: 'https://www.youtube.com',
    comments: [
      {
        id: 'c-01',
        author: 'Jean-Luc Moreau',
        authorTitle: 'Scout Standard de Liège',
        text: 'Superbe touché de balle. Nous suivons ce joueur avec attention depuis son match à Yamoussoukro.',
        time: 'Il y a 2h'
      },
      {
        id: 'c-02',
        author: 'Dimitri de Condé',
        authorTitle: 'Directeur Sportif KRC Genk',
        text: 'La qualité de relance sous pression est de niveau pro européen. Dossier transmis à notre cellule.',
        time: 'Il y a 1h'
      }
    ]
  },
  {
    id: 'post-02',
    authorName: 'Jean-Luc Moreau',
    authorTitle: 'Responsable Recrutement Afrique · Standard de Liège',
    authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    authorOrg: 'Standard de Liège',
    authorRole: 'CHIEF_SCOUT',
    isVerified: true,
    timeAgo: 'Il y a 6 heures',
    content: '📢 APPEL D’OFFRE SCOUTING OFFICIEL STANDARD DE LIÈGE :\n\nPour notre équipe réserve (SL16 FC) et notre groupe Pro, nous recherchons activement :\n1. Un défenseur central axial droit (Gabarit > 1m88, vitesse de pointe > 33 km/h)\n2. Un numéro 9 athlétique né entre 2006 et 2008 avec passeport valide.\n\nToutes les académies partenaires d’Africa Talent Football peuvent soumettre leurs fiches avec vidéos directement via la messagerie de Seydou Mario TRAORÉ.',
    tags: ['#RecrutementPro', '#StandardDeLiege', '#MercatoJeunes', '#B2BFootball'],
    likesCount: 215,
    commentsCount: 42,
    sharesCount: 35,
    isLiked: true,
    comments: [
      {
        id: 'c-03',
        author: 'Seydou Mario TRAORÉ',
        authorTitle: 'Scout Agent, Director ATF',
        text: 'Message reçu Jean-Luc. Moussa Diallo (1m91, 19 ans) et Ibrahim Kouassi (1m86, 19 buts) correspondent à 100% à cette fiche de poste.',
        time: 'Il y a 4h'
      }
    ]
  },
  {
    id: 'post-03',
    authorName: 'Marc Henderson',
    authorTitle: 'Head of Elite Academy Partnerships · Catapult Sports',
    authorAvatar: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=120&auto=format&fit=crop&q=80',
    authorOrg: 'Catapult Sports Football',
    authorRole: 'EXECUTIVE',
    isVerified: true,
    timeAgo: 'Hier',
    content: 'Fier d’annoncer notre partenariat technologique officiel avec la plateforme Africa Talent Football dirigée par Seydou Mario TRAORÉ. Les futurs tournois de détection en Côte d’Ivoire et au Sénégal seront équipés de nos trackers GPS FIFA-Approved pour fournir aux recruteurs européens des données physiques infalsifiables.',
    tags: ['#SportsTech', '#DataFootball', '#CatapultGPS', '#AfricaTalentFootball'],
    likesCount: 312,
    commentsCount: 19,
    sharesCount: 52,
    isLiked: false,
    comments: []
  }
];
