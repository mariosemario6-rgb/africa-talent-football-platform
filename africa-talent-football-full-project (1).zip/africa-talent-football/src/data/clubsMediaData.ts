import { ClubNewsItem, ClubVideoItem, FootballClub } from '../types/database';

// Specific media datasets for major world clubs
export const SPECIALIZED_CLUB_VIDEOS: Record<string, ClubVideoItem[]> = {
  // Real Madrid CF
  'club-uefa-01': [
    {
      id: 'vid-rm-01',
      title: 'Séance Tactique Madrid : Sortie de balle sous Gegenpressing & Transition Rapide',
      type: 'TRAINING',
      duration: '14:20',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-man-training-soccer-on-a-grass-field-42721-large.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=500&auto=format&fit=crop&q=80',
      description: 'Entraînement complet à Valdebebas sous la direction du staff de Carlo Ancelotti : conservation en infériorité et projections verticales.',
      views: '124 500',
      date: 'Hier',
      tacticalKey: 'Schéma 4-3-3 asymétrique'
    },
    {
      id: 'vid-rm-02',
      title: 'Match Highlights : Real Madrid vs Borussia Dortmund (UCL) - Analyse des Espaces',
      type: 'MATCH',
      duration: '18:45',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-player-running-and-kicking-a-soccer-ball-42720-large.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=500&auto=format&fit=crop&q=80',
      description: 'Résumé officiel avec caméra tactique aérienne isolant les mouvements sans ballon et les passes clés dans le dos des axiaux.',
      views: '389 000',
      date: 'Il y a 3 jours',
      tacticalKey: 'Bloc Médian & Contres Foudroyants'
    },
    {
      id: 'vid-rm-03',
      title: 'La Fábrica U19 : Détection & Drills de Finition devant le but',
      type: 'ACADEMY',
      duration: '09:15',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-soccer-player-hitting-a-ball-in-the-stadium-42718-large.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=500&auto=format&fit=crop&q=80',
      description: 'Exercices d’explosivité et timing de reprise de volée pour les attaquants et ailiers du centre de formation de Madrid.',
      views: '67 800',
      date: 'Il y a 5 jours',
      tacticalKey: 'Attaque de surface'
    }
  ],
  // Manchester City FC
  'club-uefa-02': [
    {
      id: 'vid-mc-01',
      title: 'Pep Guardiola Masterclass : Entraînement au Rondo 10v4 & 3e Homme',
      type: 'TRAINING',
      duration: '16:50',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-man-training-soccer-on-a-grass-field-42721-large.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=500&auto=format&fit=crop&q=80',
      description: 'Séance à l’Etihad Campus City Football Academy axée sur le dédoublement intérieur et la fixation du milieu adverse.',
      views: '245 000',
      date: 'Hier',
      tacticalKey: 'Possession 3-2-4-1'
    },
    {
      id: 'vid-mc-02',
      title: 'Tactical Cam : Manchester City vs Arsenal - Pressing Ultra-Haut',
      type: 'MATCH',
      duration: '22:10',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-player-running-and-kicking-a-soccer-ball-42720-large.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=500&auto=format&fit=crop&q=80',
      description: 'Analyse vidéo exhaustive des 15 premières secondes à la perte du ballon et du contre-pressing des relayeurs.',
      views: '512 000',
      date: 'Il y a 4 jours',
      tacticalKey: 'Gegenpressing 5 secondes'
    }
  ],
  // Al Ahly SC (Egypte / CAF)
  'club-caf-01': [
    {
      id: 'vid-ahly-01',
      title: 'Al Ahly SC Match Complet : Finale Ligue des Champions CAF - Temps Forts & Analyse',
      type: 'MATCH',
      duration: '15:30',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-player-running-and-kicking-a-soccer-ball-42720-large.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=500&auto=format&fit=crop&q=80',
      description: 'Victoire tactique des Diables Rouges du Caire devant 75 000 spectateurs avec gestion du rythme et transitions assassines.',
      views: '680 000',
      date: 'Il y a 2 jours',
      tacticalKey: 'Contrôle continental CAF'
    },
    {
      id: 'vid-ahly-02',
      title: 'Séance Entraînement Mokhtar El-Tetsh : Préparation Physique & Vitesse Maximale Aérobie',
      type: 'TRAINING',
      duration: '11:40',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-man-training-soccer-on-a-grass-field-42721-large.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=500&auto=format&fit=crop&q=80',
      description: 'Travail spécifique de pliométrie et enchaînement courses à haute intensité suivi de frappes au but.',
      views: '95 000',
      date: 'Il y a 5 jours',
      tacticalKey: 'Intensité physique d’élite'
    }
  ],
  // ASEC Mimosas (Côte d'Ivoire)
  'club-caf-07': [
    {
      id: 'vid-asec-01',
      title: 'Académie MimoSifcom Sol Béni : Séance Détection U17 - Test Technique & Vitesse',
      type: 'ACADEMY',
      duration: '13:50',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-soccer-player-hitting-a-ball-in-the-stadium-42718-large.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=500&auto=format&fit=crop&q=80',
      description: 'Immersion à Sol Béni (Abidjan) : les pépites ivoiriennes formées au contrôle orienté, jeu en une touche et vivacité d’appui.',
      views: '112 000',
      date: 'Hier',
      tacticalKey: 'ADN Technique Mimosas'
    },
    {
      id: 'vid-asec-02',
      title: 'Coupe de la Confédération CAF : ASEC Mimosas - Résumé Match & Buts Décisifs',
      type: 'MATCH',
      duration: '10:25',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-player-running-and-kicking-a-soccer-ball-42720-large.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=500&auto=format&fit=crop&q=80',
      description: 'Démonstration collective au Stade Félix Houphouët-Boigny, pressing synchronisé et débordements sur les ailes.',
      views: '84 000',
      date: 'Il y a 3 jours',
      tacticalKey: 'Jeu court et percussion'
    }
  ]
};

export const SPECIALIZED_CLUB_NEWS: Record<string, ClubNewsItem[]> = {
  // Real Madrid CF
  'club-uefa-01': [
    {
      id: 'news-rm-01',
      title: 'Scouting Mondial : Juni Calafat mandate une mission prioritaire en Afrique de l’Ouest',
      date: 'Aujourd’hui à 11:30',
      summary: 'La cellule de recrutement du Real Madrid intensifie sa veille sur les profils U17/U19 en Côte d’Ivoire, Sénégal et Mali pour son équipe Castilla.',
      category: 'MERCATO',
      source: 'Marca & Direction Sportive Real Madrid',
      keyHighlight: 'Profils axiaux athlétiques et ailiers percutants ciblés'
    },
    {
      id: 'news-rm-02',
      title: 'Point Médical & Préparation Champions League : Retour au groupe complet à Valdebebas',
      date: 'Hier à 17:45',
      summary: 'Séance tactique intense à huis clos. Carlo Ancelotti a testé deux variantes offensives pour contrer les blocs bas compacts.',
      category: 'OFFICIEL',
      source: 'Real Madrid TV',
      keyHighlight: 'Travail spécifique sur les coups de pied arrêtés'
    }
  ],
  // Manchester City FC
  'club-uefa-02': [
    {
      id: 'news-mc-01',
      title: 'City Football Group : Protocole de détection signé pour intégration d’académies partenaires',
      date: 'Aujourd’hui à 09:15',
      summary: 'Manchester City et le réseau CFG ouvrent 4 bourses de développement pour les meilleurs talents formés en Afrique subsaharienne.',
      category: 'FORMATION',
      source: 'CFG Global Football Operations',
      keyHighlight: 'Parcours d’immersion entre Lommel SK, Girona et Manchester'
    },
    {
      id: 'news-mc-02',
      title: 'Rapport Tactique Premier League : 72% de possession moyenne et record d’entrées dans le dernier tiers',
      date: 'Il y a 2 jours',
      summary: 'Les analystes vidéo de City confirment une efficacité maximale sur les transitions rapides post-récupération haute.',
      category: 'MATCH',
      source: 'Opta & Man City Analytics',
      keyHighlight: 'PPDA (Pressing intensity) le plus élevé d’Europe'
    }
  ],
  // Al Ahly SC
  'club-caf-01': [
    {
      id: 'news-ahly-01',
      title: 'Ligue des Champions de la CAF : Al Ahly valide sa qualification pour les demi-finales',
      date: 'Hier à 22:00',
      summary: 'Grâce à un bloc défensif hermétique et une finition clinique, le club cairote poursuit sa quête d’une 12e couronne africaine record.',
      category: 'MATCH',
      source: 'CAF Online & Al Ahly Media Centre',
      keyHighlight: 'Zéro but encaissé sur les 4 derniers matchs continentaux'
    },
    {
      id: 'news-ahly-02',
      title: 'Mercato Estival : Recherche active d’un avant-centre U23 francophone',
      date: 'Il y a 3 jours',
      summary: 'La direction sportive d’Al Ahly consulte le desk de Seydou Mario Traoré pour identifier les buteurs prolifiques d’Afrique de l’Ouest.',
      category: 'MERCATO',
      source: 'Al Ahram Sports',
      keyHighlight: 'Budget transfert disponible supérieur à 2.5M€'
    }
  ]
};

// Universal generator ensuring EVERY football club in the world has rich videos and live news
export function getClubVideos(club: FootballClub): ClubVideoItem[] {
  if (club.videos && club.videos.length > 0) {
    return club.videos;
  }
  if (SPECIALIZED_CLUB_VIDEOS[club.id]) {
    return SPECIALIZED_CLUB_VIDEOS[club.id];
  }

  // Generate realistic, rich match & training videos for any club worldwide
  const clubName = club.name;
  const league = club.league || 'Championnat';
  const formation = club.tacticalSystem || '4-3-3';
  const style = club.playingStyle || 'Intensité & Pressing';

  return [
    {
      id: `vid-${club.id}-match`,
      title: `Résumé Officiel : ${clubName} en ${league} - Temps Forts, Buts & Caméra Tactique`,
      type: 'MATCH',
      duration: '14:40',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-player-running-and-kicking-a-soccer-ball-42720-large.mp4',
      thumbnailUrl: club.logoUrl || 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=500&auto=format&fit=crop&q=80',
      description: `Séquences exclusives de match officiel démontrant l'organisation collective en ${formation}, les circuits de relance axiale et la gestion des temps forts.`,
      views: `${Math.floor(25 + (club.followersCount || 1000) / 1000)}k`,
      date: 'Il y a 2 jours',
      tacticalKey: style
    },
    {
      id: `vid-${club.id}-training`,
      title: `Séance d'Entraînement Officielle : Drills Tactiques & Pression Collective`,
      type: 'TRAINING',
      duration: '12:15',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-man-training-soccer-on-a-grass-field-42721-large.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=500&auto=format&fit=crop&q=80',
      description: `Immersion au centre d'entraînement de ${clubName} : conservation de balle en espace réduit, duels 1v1 sous haute intensité et travail athlétique GPS Catapult.`,
      views: `${Math.floor(12 + (club.followersCount || 1000) / 2500)}k`,
      date: 'Hier',
      tacticalKey: 'Préparation Physique & Gammes de Passes'
    },
    {
      id: `vid-${club.id}-academy`,
      title: `Centre de Formation & U19 : Détection des Futurs Espoirs de ${clubName}`,
      type: 'ACADEMY',
      duration: '08:50',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-soccer-player-hitting-a-ball-in-the-stadium-42718-large.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=500&auto=format&fit=crop&q=80',
      description: `Mise en situation des jeunes talents de l'académie, exercices de vivacité, vitesse de prise d'information avant la passe et coordination offensive.`,
      views: `${Math.floor(8 + (club.followersCount || 1000) / 5000)}k`,
      date: 'Il y a 4 jours',
      tacticalKey: 'Développement & Passerelles Pro'
    }
  ];
}

export function getClubNews(club: FootballClub): ClubNewsItem[] {
  if (club.news && club.news.length > 0) {
    return club.news;
  }
  if (SPECIALIZED_CLUB_NEWS[club.id]) {
    return SPECIALIZED_CLUB_NEWS[club.id];
  }

  const clubName = club.name;
  const country = club.country || 'Monde';
  const director = club.sportingDirector || club.headOfRecruitment || 'La Direction Technique';
  const needs = club.openNeeds && club.openNeeds.length > 0 ? club.openNeeds[0] : 'profils U19 prometteurs';

  return [
    {
      id: `news-${club.id}-01`,
      title: `Mercato & Recrutement : ${clubName} intensifie ses recherches pour "${needs}"`,
      date: 'Aujourd’hui',
      summary: `${director} a validé la consultation des profils certifiés Africa Talent Football pour renforcer l'effectif lors de la prochaine fenêtre de transferts.`,
      category: 'MERCATO',
      source: `Cellule Recrutement · ${clubName}`,
      keyHighlight: `Supervision directe avec Seydou Mario Traoré · Priorité aux joueurs de ${club.country}`
    },
    {
      id: `news-${club.id}-02`,
      title: `Bilan Tactique & Préparation : ${clubName} peaufine son système en ${club.tacticalSystem || '4-3-3'}`,
      date: 'Il y a 2 jours',
      summary: `Le staff technique de ${clubName} a dispensé une session vidéo d'analyse des blocs adverses. L'accent est mis sur la vitesse de projection et la compacité défensive.`,
      category: 'OFFICIEL',
      source: `Communication Officielle ${clubName}`,
      keyHighlight: `Objectif podium et qualification en compétition continentale (${club.confederation || 'FIFA'})`
    },
    {
      id: `news-${club.id}-03`,
      title: `Académie & Détection : Journées Portes Ouvertes et Tournois de Visionnage`,
      date: 'Il y a 4 jours',
      summary: `Les recruteurs de ${clubName} seront présents sur les prochains showcases internationaux pour évaluer les espoirs U17/U19 en conditions réelles de match.`,
      category: 'FORMATION',
      source: `Académie & Centre de Performance ${country}`,
      keyHighlight: 'Conventions de partenariats et conventions clubs tremplins'
    }
  ];
}
