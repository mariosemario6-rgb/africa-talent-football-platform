export type UserRole = 
  | 'PLAYER' 
  | 'SCOUT' 
  | 'CLUB' 
  | 'ACADEMY'
  | 'FIFA_AGENT'
  | 'HEAD_COACH'
  | 'SPORTING_DIRECTOR'
  | 'PRESIDENT'
  | 'RECRUITMENT_MANAGER'
  | 'ADMIN';

export type SubscriptionTier = 'FREE' | 'PLAYER_PRO' | 'SCOUT_PRO' | 'CLUB_ELITE' | 'ENTERPRISE';
export type BillingInterval = 'MONTHLY' | 'ANNUAL';
export type CurrencyCode = 'EUR' | 'USD' | 'GBP' | 'XOF';
export type PaymentMethodType = 'CARD' | 'MOBILE_MONEY' | 'PAYPAL' | 'BANK_TRANSFER';

export interface UserSubscription {
  tier: SubscriptionTier;
  interval: BillingInterval;
  status: 'ACTIVE' | 'PAST_DUE' | 'CANCELLED';
  startDate: string;
  expiresAt: string;
  pricePaid: number;
  currency: CurrencyCode;
  paymentMethod: {
    type: PaymentMethodType;
    details: string; // e.g. "Visa terminant par 4242" or "Orange Money (+225 07...)"
  };
  invoiceId: string;
}

export interface User {
  id: string;
  email: string;
  passwordHash?: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  country: string;
  phone?: string;
  avatarUrl?: string;
  coverUrl?: string;
  bio?: string;
  clubName?: string;
  academyName?: string;
  scoutOrg?: string;
  fifaLicenseNumber?: string;
  coachingBadge?: string;
  leagueOrDivision?: string;
  territoryCovered?: string;
  organization?: string;
  officialWebsite?: string;
  primaryPosition?: string;
  dateOfBirth?: string;
  preferredFoot?: string;
  verified: boolean;
  registeredAt: string;
  lastLoginAt?: string;
  subscription?: UserSubscription;
}

export interface PlayerStats {
  matches: number;
  minutes: number;
  goals: number;
  assists: number;
  cleanSheets?: number;
  passAccuracyPct: number;
  topSpeedKmh: number;
  duelsWonPct?: number;
  yellowCards?: number;
}

export interface ScoutingReport {
  id: string;
  scoutName: string;
  scoutTitle: string;
  date: string;
  overallRating: number;
  potentialRating: number;
  summary: string;
  strengths: string[];
  areasOfDevelopment: string[];
}

export interface PhysicalRadar {
  pace: number;
  shooting: number;
  passing: number;
  dribbling: number;
  defending: number;
  physicality: number;
}

export interface GuardianContact {
  name: string;
  phone: string;
  relationship: string;
}

export interface BiometricAnalysis {
  vo2MaxMlKgMin: number;
  verticalJumpCm: number;
  bodyFatPct: number;
  bmi: number;
  restingHeartRateBpm: number;
  heartRateRecovery1MinBpm: number;
  sprint10mSec: number;
  sprint30mSec: number;
  vamevalKmH: number;
  certifiedDate?: string;
  laboratoryOrDevice?: string;
}

export interface TransferRecord {
  id: string;
  season: string;
  date: string;
  fromClub: string;
  toClub: string;
  type: 'FORMATION' | 'TRANSFERT' | 'PRÊT' | 'SIGNATURE_LIBRE' | 'PROMOTION_ÉLITE';
  feeEur?: number;
  feeDisplay: string;
  contractUntil?: string;
}

export interface AICertificationBadge {
  isCertified: boolean;
  badgeLabel: string;
  auditDate: string;
  confidenceScore: number;
  modelAuditEngine: string;
  verifiedMetrics: string[];
  verificationHash?: string;
}

export interface RegisteredPlayer {
  id: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  calculatedAge: number;
  isMinor: boolean;
  nationality: string;
  countryFlag: string;
  primaryPosition: 'BU' | 'AG' | 'AD' | 'MOC' | 'MC' | 'MDF' | 'DC' | 'DL' | 'GB';
  secondaryPosition?: string;
  preferredFoot: 'Droit' | 'Gauche' | 'Ambidextre';
  heightCm: number;
  weightKg: number;
  currentClub: string;
  academy: string;
  avatarUrl: string;
  videoUrl: string;
  videoTitle?: string;
  marketValueEur: number;
  marketValueDisplay: string;
  marketValueTrend: 'UP' | 'STABLE';
  contractStatus: 'Sous convention académie' | 'Libre de tout contrat' | 'Contrat aspirant';
  stats: PlayerStats;
  scoutingReports: ScoutingReport[];
  physicalRadar: PhysicalRadar;
  biometrics?: BiometricAnalysis;
  transferHistory?: TransferRecord[];
  aiCertification?: AICertificationBadge;
  guardianContact?: GuardianContact;
  certifiedBy: string;
  registeredAt: string;
  status: 'DISPONIBLE' | 'EN_ESSAI' | 'SOUS_OPTION';
  bio: string;
}

export interface Opportunity {
  id: string;
  title: string;
  organizer: string;
  location: string;
  country: string;
  category: 'U17' | 'U19' | 'U23' | 'PRO';
  date: string;
  deadline: string;
  targetedPositions: string[];
  description: string;
  criteria: string[];
  contactEmail: string;
  contactPhone: string;
  status: 'OUVERT' | 'DERNIÈRES_PLACES' | 'CLÔTURÉ';
}

export type ConfederationCode = 'CAF' | 'UEFA' | 'CONMEBOL' | 'CONCACAF' | 'AFC' | 'OFC';

export interface FootballMatchFixture {
  id: string;
  competition: string;
  round?: string;
  confederation: ConfederationCode | 'ATF_SHOWCASE';
  country: string;
  countryFlag: string;
  date: string;
  time: string;
  status: 'UPCOMING' | 'LIVE' | 'FINISHED' | 'POSTPONED';
  liveMinute?: string;
  homeTeam: {
    id?: string;
    name: string;
    logoUrl: string;
    countryFlag: string;
    score?: number;
  };
  awayTeam: {
    id?: string;
    name: string;
    logoUrl: string;
    countryFlag: string;
    score?: number;
  };
  stadium: string;
  city: string;
  referee?: string;
  broadcastChannel?: string;
  scoutNotes?: string;
  monitoredTalents?: string[];
  tacticalHighlightsUrl?: string;
  scorers?: Array<{ minute: string; player: string; team: 'home' | 'away' }>;
  possessionPct?: { home: number; away: number };
}

export interface WorldwideNewsArticle {
  id: string;
  title: string;
  summary: string;
  content?: string;
  fullStory?: string[];
  tags?: string[];
  category: 'MERCATO' | 'MATCH' | 'ACADEMY' | 'OFFICIAL' | 'TACTICAL' | 'SCOUTING';
  confederation: ConfederationCode | 'GLOBAL';
  country?: string;
  countryFlag?: string;
  publishedAt: string;
  source: string;
  author?: string;
  authorRole?: string;
  imageUrl: string;
  relatedClubId?: string;
  relatedClubName?: string;
  keyHighlight?: string;
  readTimeMinutes?: number;
  isBreaking?: boolean;
}

export type TacticalFormation = '4-3-3' | '4-2-3-1' | '3-5-2' | '3-4-3' | '4-4-2';
export type TacticalPlayingStyle = 
  | 'Gegenpressing & Bloc Haut' 
  | 'Attaque Placée & Possession' 
  | 'Transition Rapide & Contre' 
  | 'Bloc Médian & Défense Compacte';

export interface TacticalMetrics {
  pressingIntensity: number; // 0-100
  possessionIndex: number; // 0-100
  transitionSpeed: number; // 0-100
  defensiveLineHeight: number; // 0-100
}

export interface ClubNewsItem {
  id: string;
  title: string;
  date: string;
  summary: string;
  category: 'OFFICIEL' | 'MERCATO' | 'FORMATION' | 'MATCH' | 'PRESS_CONFERENCE';
  source: string;
  url?: string;
  keyHighlight?: string;
}

export interface ClubVideoItem {
  id: string;
  title: string;
  type: 'MATCH' | 'TRAINING' | 'TACTICAL' | 'ACADEMY' | 'HIGHLIGHTS';
  duration: string;
  videoUrl: string;
  thumbnailUrl: string;
  description: string;
  views?: string;
  date?: string;
  tacticalKey?: string;
}

// B2B FOOTBALL LINKEDIN & EYEBALL EXTENSIONS
export interface FootballClub {
  id: string;
  name: string;
  country: string;
  countryFlag: string;
  city: string;
  league: string;
  division: string;
  logoUrl: string;
  president: string;
  sportingDirector: string;
  headCoach: string;
  headOfRecruitment: string;
  verified: boolean;
  followersCount: number;
  openNeeds: string[];
  website: string;
  stadium: string;
  description: string;
  confederation?: ConfederationCode;
  budgetRange?: 'ÉLITE (+15M€)' | 'MOYEN (2M€ - 15M€)' | 'TREMPLIN (< 2M€)' | 'CONVENTION ACADÉMIE';
  targetAge?: 'U17' | 'U19' | 'U21' | 'SENIOR';
  transferType?: 'ACHAT DIRECT' | 'PRÊT AVEC OPTION' | 'CONVENTION PARTENARIAT' | 'ESSAI SUPERVISÉ';
  partnerStatus?: 'PARTENAIRE_OFFICIEL' | 'AFFILIÉ_ATF' | 'CLUB_PROSPECTEUR';
  trophiesCount?: number;
  famousAlumni?: string[];
  tacticalSystem?: TacticalFormation;
  playingStyle?: TacticalPlayingStyle;
  tacticalMetrics?: TacticalMetrics;
  tacticalPhilosophy?: string;
  news?: ClubNewsItem[];
  videos?: ClubVideoItem[];
}

export type MercatoAlertType = 
  | 'OFFICIAL_TRANSFER' 
  | 'TRIAL_OFFER' 
  | 'SCOUTING_INQUIRY' 
  | 'URGENT_NEED' 
  | 'CONTRACT_EXTENSION';

export interface MercatoAlert {
  id: string;
  type: MercatoAlertType;
  title: string;
  clubName: string;
  clubLogo?: string;
  clubCountry: string;
  clubCountryFlag: string;
  confederation: ConfederationCode;
  playerTarget?: string;
  positionTarget?: string;
  amountDisplay?: string;
  timestamp: string;
  summary: string;
  details: string;
  verifiedByDesk: boolean;
  urgent?: boolean;
}

export interface PushNotificationSettings {
  enabled: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  mercatoAlerts: boolean;
  newPlayersDetected: boolean;
  clubMessages: boolean;
  scoutingShowcases: boolean;
}

export type ProfessionalRole = 
  | 'PRESIDENT' 
  | 'SPORTING_DIRECTOR' 
  | 'HEAD_COACH' 
  | 'CHIEF_SCOUT' 
  | 'SCOUT_AGENT' 
  | 'EXECUTIVE'
  | 'LAWYER';

export interface FootballProfessional {
  id: string;
  name: string;
  title: string;
  role: ProfessionalRole;
  clubOrOrg: string;
  country: string;
  countryFlag: string;
  avatarUrl: string;
  verified: boolean;
  email: string;
  phone: string;
  connectionsCount: number;
  connectionStatus: 'CONNECTED' | 'PENDING' | 'CONNECT';
  bio: string;
}

export interface FootballCompany {
  id: string;
  name: string;
  category: 
    | 'Équipementier & Marque' 
    | 'Data & Video Analytics' 
    | 'Droit du Sport & Fiscalité' 
    | 'Nutrition & Performance' 
    | 'Organisation de Stages' 
    | 'Médias & Diffusion'
    | 'Chaîne Télévision & Médias Mondiaux'
    | 'Opérateur Télécom & Communication'
    | 'Agroalimentaire, Boissons & Nutrition'
    | 'Banque & Financement Sportif'
    | 'Université & Bourses Sport-Études'
    | 'Grandes Entreprises & Sponsors Mondiaux';
  country: string;
  countryFlag: string;
  logoUrl: string;
  contactPerson: string;
  contactRole: string;
  verified: boolean;
  followersCount: number;
  website: string;
  description: string;
  partnershipOpportunities: string[];
  entityType?: 'BANK' | 'UNIVERSITY' | 'CORPORATE' | 'TECH' | 'MEDIA' | 'TELEVISION' | 'TELECOM' | 'FOOD' | 'LEGAL';
  programDetails?: {
    scholarshipFundEur?: string;
    financingTypes?: string[];
    academicPrograms?: string[];
    sponsorshipPackages?: string[];
  };
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  senderRole: string;
  text: string;
  timestamp: string;
  isMine: boolean;
  attachment?: {
    type: 'PLAYER_DOSSIER' | 'VIDEO' | 'TRIAL_INVITE';
    title: string;
    subtitle?: string;
    targetId?: string;
  };
}

export interface Conversation {
  id: string;
  participantId: string;
  participantName: string;
  participantTitle: string;
  participantAvatar: string;
  participantOrg: string;
  participantRole: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  online: boolean;
}

export interface FeedPost {
  id: string;
  authorId?: string;
  authorName: string;
  authorTitle: string;
  authorAvatar: string;
  authorOrg: string;
  authorRole: ProfessionalRole;
  isVerified: boolean;
  isPremiumAuthor?: boolean;
  category?: 'GENERAL' | 'TALENT' | 'MERCATO' | 'TRIAL' | 'TACTICAL' | 'OFFICIAL';
  timeAgo: string;
  content: string;
  tags: string[];
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  isLiked: boolean;
  playerAttachment?: RegisteredPlayer;
  videoPreviewUrl?: string;
  mediaUrl?: string;
  comments: Array<{
    id: string;
    author: string;
    authorTitle: string;
    text: string;
    time: string;
  }>;
}

export interface RealtimePartnerUpdate {
  id: string;
  sourceType: 'CLUB' | 'COMPANY' | 'BANK';
  sourceName: string;
  sourceLogo?: string;
  category: string;
  country: string;
  countryFlag: string;
  title: string;
  summary: string;
  timestamp: string;
  urgentBadge?: string;
  verified: boolean;
  actionType: 'APPLY' | 'CONTACT' | 'DOWNLOAD_DOC' | 'INSPECT';
  actionLabel: string;
  contactEmail?: string;
  contactPhone?: string;
  officialLink?: string;
  details?: {
    requirements?: string[];
    deadline?: string;
    budgetOrValuation?: string;
    downloadUrl?: string;
    quotaSeats?: string;
  };
}
