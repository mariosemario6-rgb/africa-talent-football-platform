/**
 * Secure Password Hashing & Verification using standard Web Crypto API (SHA-256 with salt)
 */
export async function hashPassword(password: string): Promise<string> {
  const enc = new TextEncoder();
  // Fixed application salt to prevent rainbow table attacks
  const salt = 'ATF_SECURE_AUTH_SALT_2026_';
  const data = enc.encode(salt + password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function verifyPassword(password: string, expectedHash: string): Promise<boolean> {
  const calculatedHash = await hashPassword(password);
  return calculatedHash === expectedHash;
}
