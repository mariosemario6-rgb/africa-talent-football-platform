/**
 * Utility to optimize image URLs on the fly for mobile speed & low data consumption.
 * Adds responsive parameters to Unsplash URLs and provides graceful fallbacks.
 * Drastically improves First Contentful Paint (FCP) and saves mobile bandwidth in Africa.
 */

export type ImagePreset = 'avatar' | 'thumbnail' | 'card' | 'cover' | 'hero';

const PRESET_CONFIG: Record<ImagePreset, { width: number; quality: number }> = {
  avatar: { width: 128, quality: 75 },
  thumbnail: { width: 200, quality: 70 },
  card: { width: 440, quality: 70 },
  cover: { width: 880, quality: 75 },
  hero: { width: 1200, quality: 80 }
};

export const getOptimizedImageUrl = (
  url?: string,
  presetOrWidth: ImagePreset | number = 'card',
  customQuality?: number
): string => {
  if (!url || typeof url !== 'string') {
    return 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=400&auto=format&fit=crop&q=70';
  }

  // If local asset or data URL, return as-is
  if (url.startsWith('/src/') || url.startsWith('data:') || url.startsWith('blob:')) {
    return url;
  }

  let width = 440;
  let quality = 70;

  if (typeof presetOrWidth === 'string' && PRESET_CONFIG[presetOrWidth]) {
    width = PRESET_CONFIG[presetOrWidth].width;
    quality = customQuality ?? PRESET_CONFIG[presetOrWidth].quality;
  } else if (typeof presetOrWidth === 'number') {
    width = presetOrWidth;
    quality = customQuality ?? 70;
  }

  // If Unsplash URL, ensure optimal width, WebP format, and compression quality
  if (url.includes('images.unsplash.com')) {
    try {
      const baseUrl = url.split('?')[0];
      return `${baseUrl}?w=${width}&auto=format&fit=crop&q=${quality}`;
    } catch {
      return url;
    }
  }

  return url;
};

/**
 * Standard performance attributes for img elements below the fold
 */
export const lazyImageProps = {
  loading: 'lazy' as const,
  decoding: 'async' as const
};
