// Africa Talent Football - Market Valuation & Statistics Engine
// Algorithme certifié de cotation marchande et d'analyse statistique sportive
// Conforme aux directives FIFA RSTJ et standards de scouting international

export interface ValuationInput {
  age: number;
  primaryPosition: 'BU' | 'AG' | 'AD' | 'MOC' | 'MC' | 'MDF' | 'DC' | 'DLG' | 'DLD' | 'GB';
  secondaryPositions?: string[];
  preferredFoot: 'DROIT' | 'GAUCHE' | 'LES_DEUX';
  heightCm: number;
  weightKg?: number;
  topSpeedKmh: number;
  divisionLevel: 'PRO_D1' | 'PRO_D2' | 'ACADEMY_ELITE' | 'AMATEUR_U20' | 'REGIONAL';
  nationalTeamLevel: 'SENIOR_A' | 'U23_OLYMPIC' | 'U20' | 'U17' | 'NONE';
  contractStatus: 'UNDER_CONTRACT' | 'EXPIRING_SOON' | 'FREE_AGENT' | 'TRAINING_AGREEMENT';
  contractMonthsRemaining?: number;
  isMinor: boolean;
  hasParentalConsent?: boolean;
  videoCertified: boolean;
  stats: {
    matches: number;
    minutes: number;
    goals: number;
    assists: number;
    passAccuracyPct: number;
    aerialDuelsWonPct?: number;
    interceptionsPerMatch?: number;
    cleanSheets?: number;
    yellowCards: number;
    redCards: number;
  };
}

export interface ValuationBreakdown {
  baseValue: number;
  ageMultiplier: number;
  positionScore: number;
  athleticScore: number;
  competitionScore: number;
  internationalBonus: number;
  contractFactor: number;
  videoAuditBonus: number;
  disciplinaryPenalty: number;
}

export interface ValuationResult {
  estimatedValueEur: number;
  estimatedValueDisplay: string;
  valueRange: {
    minEur: number;
    maxEur: number;
    minDisplay: string;
    maxDisplay: string;
  };
  trend: 'UP' | 'STABLE' | 'RAPID_GROWTH';
  confidenceScore: number; // 0 to 100%
  breakdown: ValuationBreakdown;
  comparableProfile: string;
  advisoryCategory: 'HIGH_PRIORITY_PROSPECT' | 'DEVELOPING_TALENT' | 'SOLID_FIRST_TEAM' | 'IMMEDIATE_TRANSFER_READY';
  keyStrengths: string[];
  developmentAxes: string[];
}

export function calculateMarketValuation(input: ValuationInput): ValuationResult {
  const {
    age,
    primaryPosition,
    preferredFoot,
    heightCm,
    topSpeedKmh,
    divisionLevel,
    nationalTeamLevel,
    contractStatus,
    videoCertified,
    stats
  } = input;

  // 1. Base value according to competition division
  let baseValue = 50000;
  switch (divisionLevel) {
    case 'PRO_D1':
      baseValue = 180000;
      break;
    case 'PRO_D2':
      baseValue = 110000;
      break;
    case 'ACADEMY_ELITE':
      baseValue = 85000;
      break;
    case 'AMATEUR_U20':
      baseValue = 45000;
      break;
    case 'REGIONAL':
      baseValue = 30000;
      break;
  }

  // 2. Age Factor (Young prospect premium in modern scouting)
  let ageMultiplier = 1.0;
  if (age <= 18) ageMultiplier = 1.45;
  else if (age <= 20) ageMultiplier = 1.35;
  else if (age <= 22) ageMultiplier = 1.20;
  else if (age <= 25) ageMultiplier = 1.05;
  else if (age <= 28) ageMultiplier = 0.95;
  else ageMultiplier = 0.75;

  // 3. Position and Specific Performance Output
  let positionScore = 0;
  const isAttacker = ['BU', 'AG', 'AD'].includes(primaryPosition);
  const isMidfielder = ['MOC', 'MC', 'MDF'].includes(primaryPosition);
  const isDefender = ['DC', 'DLG', 'DLD'].includes(primaryPosition);
  const isGoalkeeper = primaryPosition === 'GB';

  if (isAttacker) {
    positionScore = (stats.goals * 14000) + (stats.assists * 9500);
    // Goals per minute ratio bonus
    if (stats.minutes > 500 && (stats.goals / (stats.minutes / 90)) >= 0.5) {
      positionScore += 35000;
    }
  } else if (isMidfielder) {
    positionScore = (stats.assists * 12000) + (stats.goals * 9000);
    if (stats.passAccuracyPct >= 86) positionScore += 28000;
    if (stats.passAccuracyPct >= 90) positionScore += 20000;
    if ((stats.interceptionsPerMatch || 0) >= 3.0) positionScore += 18000;
  } else if (isDefender) {
    positionScore = (stats.matches * 3000) + ((stats.aerialDuelsWonPct || 65) >= 70 ? 25000 : 10000);
    if (stats.cleanSheets && stats.cleanSheets >= 4) positionScore += stats.cleanSheets * 5000;
    if (heightCm >= 188) positionScore += 20000; // Physical presence bonus for CB
  } else if (isGoalkeeper) {
    positionScore = (stats.matches * 3500) + ((stats.cleanSheets || 0) * 8000);
    if (heightCm >= 190) positionScore += 25000;
  }

  // 4. Athletic & Physical Biometrics
  let athleticScore = 0;
  // Speed benchmark (modern transition play)
  if (topSpeedKmh >= 35.0) athleticScore += 50000;
  else if (topSpeedKmh >= 33.5) athleticScore += 30000;
  else if (topSpeedKmh >= 32.0) athleticScore += 15000;

  // Foot rarity bonus (Left-footed or ambidextrous players are rare and valued)
  if (preferredFoot === 'GAUCHE' || preferredFoot === 'LES_DEUX') {
    athleticScore += 20000;
  }

  // 5. Competition & International Exposure
  let internationalBonus = 0;
  switch (nationalTeamLevel) {
    case 'SENIOR_A':
      internationalBonus = 120000;
      break;
    case 'U23_OLYMPIC':
      internationalBonus = 75000;
      break;
    case 'U20':
      internationalBonus = 50000;
      break;
    case 'U17':
      internationalBonus = 35000;
      break;
    case 'NONE':
      internationalBonus = 0;
      break;
  }

  // 6. Contractual Status Factor
  let contractFactor = 1.0;
  switch (contractStatus) {
    case 'UNDER_CONTRACT':
      contractFactor = 1.15; // Requires transfer compensation
      break;
    case 'EXPIRING_SOON':
      contractFactor = 0.90; // Player can negotiate pre-contract
      break;
    case 'FREE_AGENT':
      contractFactor = 0.85; // Immediate signing without club fee
      break;
    case 'TRAINING_AGREEMENT':
      contractFactor = 1.05; // Standard FIFA training compensation applies
      break;
  }

  // 7. Video & Scouting Audit Certification by ATF
  const videoAuditBonus = videoCertified ? 25000 : 0;

  // 8. Disciplinary Penalty
  const disciplinaryPenalty = (stats.redCards * 15000) + (stats.yellowCards > 5 ? (stats.yellowCards - 5) * 3000 : 0);

  // Raw Calculation
  const subTotal = (baseValue + positionScore + athleticScore + internationalBonus + videoAuditBonus - disciplinaryPenalty);
  let finalCalculated = Math.max(25000, Math.round((subTotal * ageMultiplier * contractFactor) / 5000) * 5000);

  // Confidence Score Calculation based on data completeness
  let confidence = 50;
  if (stats.minutes > 600) confidence += 20;
  if (stats.matches >= 8) confidence += 10;
  if (videoCertified) confidence += 15;
  if (nationalTeamLevel !== 'NONE') confidence += 5;
  confidence = Math.min(98, confidence);

  // Value Range
  const spreadPct = (100 - confidence) / 100 * 0.35 + 0.15; // 15% to 32% spread
  const minEur = Math.max(15000, Math.round((finalCalculated * (1 - spreadPct)) / 5000) * 5000);
  const maxEur = Math.round((finalCalculated * (1 + spreadPct)) / 5000) * 5000;

  // Market Trend
  let trend: 'UP' | 'STABLE' | 'RAPID_GROWTH' = 'STABLE';
  if (age <= 20 && (stats.goals >= 5 || stats.assists >= 4 || topSpeedKmh >= 34.0)) {
    trend = 'RAPID_GROWTH';
  } else if (age <= 23 || nationalTeamLevel !== 'NONE') {
    trend = 'UP';
  }

  // Advisory category
  let advisoryCategory: ValuationResult['advisoryCategory'] = 'DEVELOPING_TALENT';
  if (finalCalculated >= 350000) advisoryCategory = 'IMMEDIATE_TRANSFER_READY';
  else if (age <= 19 && (topSpeedKmh >= 33.5 || stats.goals >= 4)) advisoryCategory = 'HIGH_PRIORITY_PROSPECT';
  else if (divisionLevel === 'PRO_D1' || divisionLevel === 'PRO_D2') advisoryCategory = 'SOLID_FIRST_TEAM';

  // Benchmark profile
  let comparableProfile = 'Profil standard académie régionale africaine';
  if (isAttacker) {
    if (finalCalculated >= 350000) comparableProfile = 'Attaquant U20 en ligue pro africaine prêt pour l’Europe (Standard Ligue 2 / Pro League belge / Super Lig)';
    else comparableProfile = 'Jeune ailier/attaquant explosif avec potentiel de transition rapide';
  } else if (isMidfielder) {
    if (finalCalculated >= 300000) comparableProfile = 'Milieu organisateur moderne à fort volume athlétique et précision technique';
    else comparableProfile = 'Milieu box-to-box polyvalent en développement';
  } else if (isDefender) {
    if (finalCalculated >= 250000) comparableProfile = 'Défenseur athlétique moderne avec vitesse de couverture et relance propre';
    else comparableProfile = 'Défenseur central rigoureux profil Ligue 1 / CAF Champions League';
  } else if (isGoalkeeper) {
    comparableProfile = 'Gardien de but moderne avec grande envergure et réflexes sur la ligne';
  }

  // Strengths & Axes
  const keyStrengths: string[] = [];
  if (topSpeedKmh >= 33.5) keyStrengths.push(`Vitesse de pointe exceptionnelle (${topSpeedKmh} km/h)`);
  if (stats.passAccuracyPct >= 84) keyStrengths.push(`Précision de passe certifiée (${stats.passAccuracyPct}%)`);
  if (stats.goals >= 5) keyStrengths.push(`Efficacité offensive (${stats.goals} buts marqués)`);
  if (stats.assists >= 4) keyStrengths.push(`Vision de jeu et vista (${stats.assists} passes décisives)`);
  if (preferredFoot === 'GAUCHE') keyStrengths.push('Pied gauche naturel recherché au niveau professionnel');
  if (preferredFoot === 'LES_DEUX') keyStrengths.push('Ambidextrie rare et précieuse');
  if (nationalTeamLevel !== 'NONE') keyStrengths.push(`Expérience internationale (${nationalTeamLevel})`);
  if (videoCertified) keyStrengths.push('Audit vidéo 90 min certifié par la direction technique ATF');

  const developmentAxes: string[] = [];
  if (stats.minutes < 600) developmentAxes.push('Augmenter le temps de jeu effectif sur 90 minutes complètes');
  if (stats.yellowCards >= 4) developmentAxes.push('Canaliser l’agressivité et la discipline tactique');
  if (!videoCertified) developmentAxes.push('Faire certifier les vidéos complètes de match sur caméra grand angle');
  if (stats.passAccuracyPct < 80) developmentAxes.push('Perfectionner la régularité technique sous pressing');

  return {
    estimatedValueEur: finalCalculated,
    estimatedValueDisplay: formatValuationCurrency(finalCalculated),
    valueRange: {
      minEur,
      maxEur,
      minDisplay: formatValuationCurrency(minEur),
      maxDisplay: formatValuationCurrency(maxEur)
    },
    trend,
    confidenceScore: confidence,
    breakdown: {
      baseValue,
      ageMultiplier,
      positionScore,
      athleticScore,
      competitionScore: baseValue,
      internationalBonus,
      contractFactor,
      videoAuditBonus,
      disciplinaryPenalty
    },
    comparableProfile,
    advisoryCategory,
    keyStrengths,
    developmentAxes
  };
}

export function formatValuationCurrency(amount: number): string {
  if (amount >= 1000000) {
    return `€${(amount / 1000000).toFixed(2)}M`;
  }
  return `€${amount.toLocaleString('en-US')}`;
}
