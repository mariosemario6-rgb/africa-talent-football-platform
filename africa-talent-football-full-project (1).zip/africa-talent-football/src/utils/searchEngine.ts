/**
 * Expert Search Engine utilities for Africa Talent Football
 * Provides diacritic-agnostic token search, position synonym expansion, and field ranking.
 */

export function normalizeSearch(str: string): string {
  if (!str) return '';
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

// Synonyms map for football positions & roles
const POSITION_SYNONYMS: Record<string, string[]> = {
  attaquant: ['bu', 'ag', 'ad', 'avant-centre', 'buteur', 'ailier', 'striker', 'forward'],
  buteur: ['bu', 'avant-centre', 'attaquant', 'striker'],
  ailier: ['ag', 'ad', 'winger', 'ailier gauche', 'ailier droit'],
  milieu: ['mc', 'moc', 'mdf', 'milieu central', 'relayeur', 'recule', 'meneur', 'sentinelle', 'midfielder'],
  sentinelle: ['mdf', 'recule', 'milieu defensif', 'sentinel'],
  defenseur: ['dc', 'dl', 'defenseur central', 'lateral', 'defender', 'arriere'],
  lateral: ['dl', 'lateral gauche', 'lateral droit', 'piston'],
  gardien: ['gb', 'gk', 'gardien de but', 'goalkeeper', 'portier'],
  coach: ['entraineur', 'head coach', 'manager', 'technicien'],
  entraineur: ['coach', 'head coach', 'manager', 'technicien'],
  president: ['dirigeant', 'proprietaire', 'chairman', 'pdg'],
  directeur: ['directeur sportif', 'sporting director', 'head of football', 'chief scout', 'recrutement'],
  scout: ['recruteur', 'detecteur', 'scouting', 'agent', 'cellule'],
  agent: ['scout agent', 'mandataire', 'intermediaire'],
};

/**
 * Checks if all tokens in query match anywhere in target text,
 * with position synonym expansions and accent insensitivity.
 */
export function matchesQuery(targetText: string, query: string): boolean {
  if (!query || !query.trim()) return true;

  const normalizedTarget = normalizeSearch(targetText);
  const normalizedQuery = normalizeSearch(query);

  const queryTokens = normalizedQuery.split(/\s+/).filter(Boolean);
  if (queryTokens.length === 0) return true;

  return queryTokens.every((token) => {
    // Direct token substring check
    if (normalizedTarget.includes(token)) return true;

    // Check if token matches a synonym that appears in target
    const synonyms = POSITION_SYNONYMS[token];
    if (synonyms && synonyms.some((syn) => normalizedTarget.includes(syn))) {
      return true;
    }

    // Check reverse: if target has synonym that matches token
    for (const [key, synList] of Object.entries(POSITION_SYNONYMS)) {
      if (synList.includes(token) && (normalizedTarget.includes(key) || synList.some(s => normalizedTarget.includes(s)))) {
        return true;
      }
    }

    return false;
  });
}
