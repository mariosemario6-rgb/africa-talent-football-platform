/**
 * Utility for client-side image compression, conversion to lightweight Base64 Data URLs,
 * and curated preset avatars and cover photos for football profiles.
 */

export interface PresetImage {
  id: string;
  name: string;
  url: string;
  category?: string;
}

export const PRESET_AVATARS: PresetImage[] = [
  {
    id: 'avatar-scout',
    name: 'Scout Agréé / Recruteur',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=240&auto=format&fit=crop&q=80',
    category: 'Scout'
  },
  {
    id: 'avatar-coach',
    name: 'Coach & Stratège',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=240&auto=format&fit=crop&q=80',
    category: 'Staff'
  },
  {
    id: 'avatar-player-striker',
    name: 'Jeune Prodige / Joueur',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=240&auto=format&fit=crop&q=80',
    category: 'Joueur'
  },
  {
    id: 'avatar-agent',
    name: 'Agent Officiel FIFA',
    url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=240&auto=format&fit=crop&q=80',
    category: 'Agent'
  },
  {
    id: 'avatar-director',
    name: 'Directeur Sportif / Club',
    url: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=240&auto=format&fit=crop&q=80',
    category: 'Club'
  },
  {
    id: 'avatar-academy',
    name: 'Directeur Académie',
    url: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=240&auto=format&fit=crop&q=80',
    category: 'Académie'
  }
];

export const PRESET_COVERS: PresetImage[] = [
  {
    id: 'cover-ebimpe',
    name: 'Stade Olympique Alassane Ouattara (Ebimpé)',
    url: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=1200&auto=format&fit=crop&q=80',
    category: 'Stade'
  },
  {
    id: 'cover-champions',
    name: 'Arène Sous Projecteurs (Match de Gala)',
    url: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=1200&auto=format&fit=crop&q=80',
    category: 'Match'
  },
  {
    id: 'cover-pitch-sunset',
    name: 'Pelouse d’Entraînement au Couchant',
    url: 'https://images.unsplash.com/photo-1431324155629-1a6deb1dec8d?w=1200&auto=format&fit=crop&q=80',
    category: 'Terrain'
  },
  {
    id: 'cover-tactics',
    name: 'Tableau Tactique & Performance Pro',
    url: 'https://images.unsplash.com/photo-1518091043644-c1d4457512c6?w=1200&auto=format&fit=crop&q=80',
    category: 'Tactique'
  },
  {
    id: 'cover-crowd',
    name: 'Ferveur des Supporters & Ambiance CAN',
    url: 'https://images.unsplash.com/photo-1489944440615-453fc2b6a9a9?w=1200&auto=format&fit=crop&q=80',
    category: 'Supporters'
  }
];

/**
 * Compresses an image file client-side using an HTML5 Canvas, ensuring the generated
 * base64 string easily fits in local storage without performance degradation.
 */
export const compressImageFile = (
  file: File,
  maxWidth: number = 800,
  maxHeight: number = 800,
  quality: number = 0.85
): Promise<string> => {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('Le fichier sélectionné doit être une image (JPG, PNG, WEBP).'));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Impossible de lire le fichier.'));
    reader.onload = (e) => {
      const img = new Image();
      img.onerror = () => reject(new Error('Image corrompue ou format non supporté.'));
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          // Fallback to original data URL if canvas 2d context fails
          resolve(reader.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);

        // Always output JPEG or WEBP to keep storage minimal
        const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(compressedDataUrl);
      };

      img.src = e.target?.result as string;
    };

    reader.readAsDataURL(file);
  });
};
