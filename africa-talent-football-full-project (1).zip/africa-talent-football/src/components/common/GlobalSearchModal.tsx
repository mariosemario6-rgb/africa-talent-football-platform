import React, { useState, useMemo, useEffect, useRef } from 'react';
import { usePlayers } from '../../context/PlayerContext';
import { useNetwork } from '../../context/NetworkContext';
import { RegisteredPlayer, FootballClub, FootballProfessional, FootballCompany } from '../../types/database';
import { formatMarketValue } from '../../data/demoData';
import { matchesQuery } from '../../utils/searchEngine';
import { useLanguage } from '../../context/LanguageContext';

interface GlobalSearchModalProps {
  onNavigate: (view: string, payload?: any) => void;
  isOpen: boolean;
  onClose: () => void;
}

type SearchCategory = 'ALL' | 'CLUBS' | 'PRESIDENTS' | 'DIRECTORS' | 'COACHES' | 'PLAYERS' | 'COMPANIES';

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({ isOpen, onClose, onNavigate }) => {
  const { t, formatNumber } = useLanguage();
  const { players, openVideoModal } = usePlayers();
  const { clubs, professionals, companies, createDirectConversation } = useNetwork();
  
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<SearchCategory>('ALL');
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input when opened
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
      setCategory('ALL');
    }
  }, [isOpen]);

  // Handle ESC key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Search results with expert matchesQuery
  const matchedPlayers = useMemo(() => {
    if (!query.trim()) return players.slice(0, 4);
    return players.filter((p) => {
      const text = `${p.firstName} ${p.lastName} ${p.primaryPosition} ${p.secondaryPosition || ''} ${p.academy} ${p.currentClub || ''} ${p.nationality} ${p.preferredFoot} ${p.bio}`;
      return matchesQuery(text, query);
    });
  }, [players, query]);

  const matchedClubs = useMemo(() => {
    if (!query.trim()) return clubs.slice(0, 4);
    return clubs.filter((c) => {
      const text = `${c.name} ${c.league} ${c.division} ${c.country} ${c.city} ${c.president} ${c.sportingDirector} ${c.headCoach} ${c.headOfRecruitment || ''} ${c.openNeeds.join(' ')} ${c.description}`;
      return matchesQuery(text, query);
    });
  }, [clubs, query]);

  const matchedPresidents = useMemo(() => {
    const list = professionals.filter(p => p.role === 'PRESIDENT');
    if (!query.trim()) return list;
    return list.filter((p) => {
      const text = `${p.name} ${p.title} ${p.clubOrOrg} ${p.country} ${p.bio}`;
      return matchesQuery(text, query);
    });
  }, [professionals, query]);

  const matchedDirectors = useMemo(() => {
    const list = professionals.filter(p => p.role === 'SPORTING_DIRECTOR' || p.role === 'CHIEF_SCOUT' || p.role === 'SCOUT_AGENT');
    if (!query.trim()) return list;
    return list.filter((p) => {
      const text = `${p.name} ${p.title} ${p.clubOrOrg} ${p.country} ${p.bio}`;
      return matchesQuery(text, query);
    });
  }, [professionals, query]);

  const matchedCoaches = useMemo(() => {
    const list = professionals.filter(p => p.role === 'HEAD_COACH');
    if (!query.trim()) return list;
    return list.filter((p) => {
      const text = `${p.name} ${p.title} ${p.clubOrOrg} ${p.country} ${p.bio}`;
      return matchesQuery(text, query);
    });
  }, [professionals, query]);

  const matchedCompanies = useMemo(() => {
    if (!query.trim()) return companies.slice(0, 3);
    return companies.filter((c) => {
      const text = `${c.name} ${c.category} ${c.country} ${c.contactPerson} ${c.description} ${c.partnershipOpportunities.join(' ')}`;
      return matchesQuery(text, query);
    });
  }, [companies, query]);

  const totalResultsCount =
    (category === 'ALL' || category === 'PLAYERS' ? matchedPlayers.length : 0) +
    (category === 'ALL' || category === 'CLUBS' ? matchedClubs.length : 0) +
    (category === 'ALL' || category === 'PRESIDENTS' ? matchedPresidents.length : 0) +
    (category === 'ALL' || category === 'DIRECTORS' ? matchedDirectors.length : 0) +
    (category === 'ALL' || category === 'COACHES' ? matchedCoaches.length : 0) +
    (category === 'ALL' || category === 'COMPANIES' ? matchedCompanies.length : 0);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-3 sm:p-6 sm:pt-14 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="bg-[#090E1B] border border-amber-500/40 rounded-3xl max-w-4xl w-full flex flex-col max-h-[88vh] shadow-2xl overflow-hidden">
        
        {/* TOP SEARCH INPUT BAR */}
        <div className="p-4 sm:p-5 border-b border-white/10 bg-[#050810]/80">
          <div className="flex items-center gap-3">
            <span className="text-xl text-amber-400">🔍</span>
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Rechercher un club mondial, président, directeur sportif, coach, talent ou sponsor..."
              className="flex-1 bg-transparent text-white text-sm sm:text-base font-medium placeholder:text-gray-500 focus:outline-none"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="text-gray-400 hover:text-white p-1 text-xs rounded-full hover:bg-white/10"
                title="Effacer"
              >
                ✕
              </button>
            )}
            <div className="hidden sm:flex items-center gap-1.5 px-2 py-0.5 rounded bg-white/5 border border-white/10 text-[10px] text-gray-400 font-mono">
              <span>ESC pour quitter</span>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 text-sm ml-1"
            >
              ✕
            </button>
          </div>

          {/* CATEGORY FILTER TABS */}
          <div className="flex items-center gap-1.5 overflow-x-auto pt-4 pb-1 text-xs">
            {[
              { id: 'ALL', label: `Tout (${totalResultsCount})` },
              { id: 'CLUBS', label: `Clubs (${matchedClubs.length})` },
              { id: 'PRESIDENTS', label: `Présidents (${matchedPresidents.length})` },
              { id: 'DIRECTORS', label: `Directeurs Sportifs (${matchedDirectors.length})` },
              { id: 'COACHES', label: `Entraîneurs (${matchedCoaches.length})` },
              { id: 'PLAYERS', label: `Talents & Vidéos (${matchedPlayers.length})` },
              { id: 'COMPANIES', label: `Entreprises (${matchedCompanies.length})` },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setCategory(tab.id as SearchCategory)}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors cursor-pointer text-xs ${
                  category === tab.id
                    ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20 font-black'
                    : 'bg-white/5 text-gray-400 hover:text-white hover:bg-white/10'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Quick Suggestions Chips when query is empty */}
          {!query && (
            <div className="flex items-center gap-2 pt-3 text-[11px] text-gray-400 overflow-x-auto">
              <span className="text-amber-400/80 font-mono uppercase text-[10px] shrink-0">Suggestions :</span>
              {[
                'Standard de Liège',
                'ASEC Mimosas',
                'Brighton',
                'Directeurs Sportifs',
                'RC Lens',
                'Attaquants U19',
                'Wyscout',
                'Seydou Mario TRAORÉ',
              ].map((suggestion) => (
                <button
                  key={suggestion}
                  onClick={() => setQuery(suggestion)}
                  className="px-2.5 py-0.5 rounded-full bg-white/5 hover:bg-amber-500/20 hover:text-amber-300 border border-white/5 hover:border-amber-500/30 whitespace-nowrap transition-colors cursor-pointer"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* RESULTS SCROLLABLE CONTAINER */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {totalResultsCount === 0 && (
            <div className="text-center py-16 space-y-3">
              <span className="text-4xl">🔎</span>
              <h3 className="text-base font-bold text-white">Aucun résultat trouvé pour « {query} »</h3>
              <p className="text-xs text-gray-400 max-w-sm mx-auto">
                Essayez d'ajuster votre recherche avec un nom de club mondial, un pays (ex: Belgique, France, Côte d'Ivoire) ou un poste (BU, DC, MC).
              </p>
            </div>
          )}

          {/* 1. CLUBS SECTION */}
          {(category === 'ALL' || category === 'CLUBS') && matchedClubs.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-mono font-bold text-amber-400 uppercase tracking-wider">
                <span>🏟️ Clubs Mondiaux & Européens ({matchedClubs.length})</span>
                <button
                  onClick={() => {
                    onClose();
                    onNavigate('directory');
                  }}
                  className="text-gray-400 hover:text-amber-400 normal-case font-sans"
                >
                  Voir dans l'annuaire →
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {matchedClubs.map((club: FootballClub) => (
                  <div
                    key={club.id}
                    className="p-4 rounded-2xl bg-[#050810] border border-white/5 hover:border-amber-500/40 transition-all flex flex-col justify-between space-y-3 group"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{club.countryFlag}</span>
                          <h4 className="font-black text-white text-sm group-hover:text-amber-400 transition-colors">
                            {club.name}
                          </h4>
                        </div>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-gray-300">
                          {club.division}
                        </span>
                      </div>
                      <p className="text-[11px] text-gray-400 mt-1 line-clamp-2">
                        {club.description}
                      </p>
                      
                      <div className="mt-2.5 pt-2 border-t border-white/5 text-[11px] space-y-1">
                        <div className="text-gray-300">
                          <span className="text-gray-500">Président :</span> <strong>{club.president}</strong>
                        </div>
                        <div className="text-gray-300">
                          <span className="text-gray-500">Directeur Sportif :</span> <strong>{club.sportingDirector}</strong>
                        </div>
                        <div className="text-gray-300">
                          <span className="text-gray-500">Coach :</span> <strong>{club.headCoach}</strong>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                      <button
                        onClick={() => {
                          onClose();
                          onNavigate('directory');
                        }}
                        className="flex-1 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white font-bold text-xs transition-colors"
                      >
                        Consulter Profil Club
                      </button>
                      <button
                        onClick={() => {
                          onClose();
                          createDirectConversation({
                            id: club.id,
                            name: club.sportingDirector || club.president,
                            title: `Cellule Recrutement · ${club.name}`,
                            avatar: club.logoUrl,
                            org: club.name,
                            role: 'CLUB'
                          });
                          onNavigate('messages');
                        }}
                        className="py-1.5 px-3 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 font-bold text-xs transition-colors"
                      >
                        💬 Contacter
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 2. PLAYERS & TALENTS SECTION */}
          {(category === 'ALL' || category === 'PLAYERS') && matchedPlayers.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider">
                <span>⚽ Talents Détectés & Fiches Techniques ({matchedPlayers.length})</span>
                <button
                  onClick={() => {
                    onClose();
                    onNavigate('players');
                  }}
                  className="text-gray-400 hover:text-emerald-400 normal-case font-sans"
                >
                  Voir toute la vidéothèque →
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {matchedPlayers.map((player: RegisteredPlayer) => (
                  <div
                    key={player.id}
                    className="p-4 rounded-2xl bg-[#050810] border border-white/5 hover:border-emerald-500/40 transition-all flex items-center justify-between gap-4 group"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={player.avatarUrl}
                        alt={player.firstName}
                        className="w-14 h-14 rounded-xl object-cover border border-white/10"
                      />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs">{player.countryFlag}</span>
                          <h4 className="font-black text-white text-sm group-hover:text-emerald-400 transition-colors">
                            {player.firstName} {player.lastName}
                          </h4>
                          <span className="text-[10px] font-mono font-black px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300">
                            {player.primaryPosition}
                          </span>
                        </div>
                        <p className="text-[11px] text-gray-400">
                          {player.calculatedAge} ans · {player.heightCm} cm · {player.preferredFoot}
                        </p>
                        <p className="text-[11px] text-emerald-400 font-mono font-bold mt-0.5">
                          Valeur : {formatMarketValue(player.marketValueEur)}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col gap-1.5 shrink-0">
                      <button
                        onClick={() => {
                          onClose();
                          onNavigate('player-detail', player);
                        }}
                        className="py-1.5 px-3 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors"
                      >
                        Fiche
                      </button>
                      {player.videoUrl && (
                        <button
                          onClick={() => {
                            openVideoModal(player);
                          }}
                          className="py-1 px-3 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold transition-colors flex items-center gap-1"
                        >
                          <span>▶ Vidéo</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 3. PRESIDENTS, DIRECTORS & COACHES SECTION */}
          {(category === 'ALL' || category === 'PRESIDENTS' || category === 'DIRECTORS' || category === 'COACHES') && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-mono font-bold text-blue-400 uppercase tracking-wider">
                <span>👔 Dirigeants, Présidents & Entraîneurs</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {[
                  ...(category === 'ALL' || category === 'PRESIDENTS' ? matchedPresidents : []),
                  ...(category === 'ALL' || category === 'DIRECTORS' ? matchedDirectors : []),
                  ...(category === 'ALL' || category === 'COACHES' ? matchedCoaches : []),
                ].map((pro: FootballProfessional) => (
                  <div
                    key={pro.id}
                    className="p-4 rounded-2xl bg-[#050810] border border-white/5 hover:border-blue-500/40 transition-all flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={pro.avatarUrl}
                        alt={pro.name}
                        className="w-12 h-12 rounded-full object-cover border border-white/10"
                      />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs">{pro.countryFlag}</span>
                          <h4 className="font-bold text-white text-sm">
                            {pro.name}
                          </h4>
                          {pro.verified && <span className="text-blue-400 text-xs" title="Vérifié">☑</span>}
                        </div>
                        <p className="text-[11px] text-gray-300 leading-tight">
                          {pro.title}
                        </p>
                        <p className="text-[10px] text-gray-500 font-mono mt-0.5">
                          {pro.clubOrOrg}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        onClose();
                        createDirectConversation({
                          id: pro.id,
                          name: pro.name,
                          title: pro.title,
                          avatar: pro.avatarUrl,
                          org: pro.clubOrOrg,
                          role: pro.role
                        });
                        onNavigate('messages');
                      }}
                      className="py-1.5 px-3 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/30 font-bold text-xs transition-colors shrink-0"
                    >
                      Message
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 4. COMPANIES & SPONSORS SECTION */}
          {(category === 'ALL' || category === 'COMPANIES') && matchedCompanies.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-mono font-bold text-purple-400 uppercase tracking-wider">
                <span>🏢 Entreprises, Équipementiers & Partenaires ({matchedCompanies.length})</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {matchedCompanies.map((comp: FootballCompany) => (
                  <div
                    key={comp.id}
                    className="p-4 rounded-2xl bg-[#050810] border border-white/5 hover:border-purple-500/40 transition-all flex flex-col justify-between space-y-3"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-white text-sm">{comp.name}</h4>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">
                          {comp.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-gray-400 mt-1">
                        {comp.description}
                      </p>
                      <div className="mt-2 text-[10px] text-gray-500 font-mono">
                        Contact : {comp.contactPerson} ({comp.contactRole})
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        onClose();
                        createDirectConversation({
                          id: comp.id,
                          name: comp.contactPerson,
                          title: `${comp.contactRole} · ${comp.name}`,
                          avatar: comp.logoUrl,
                          org: comp.name,
                          role: 'COMPANY'
                        });
                        onNavigate('messages');
                      }}
                      className="py-1.5 px-3 rounded-lg bg-white/5 hover:bg-white/10 text-white font-bold text-xs transition-colors text-center"
                    >
                      Contacter Partenariat
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* MODAL FOOTER */}
        <div className="p-3 sm:p-4 border-t border-white/10 bg-[#050810] flex items-center justify-between text-[11px] text-gray-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Moteur d'indexation mondiale en direct · Africa Talent Football</span>
          </div>
          <button
            onClick={() => {
              onClose();
              onNavigate('directory');
            }}
            className="text-amber-400 hover:underline font-bold"
          >
            Accéder à l'Annuaire Complet →
          </button>
        </div>
      </div>
    </div>
  );
};
