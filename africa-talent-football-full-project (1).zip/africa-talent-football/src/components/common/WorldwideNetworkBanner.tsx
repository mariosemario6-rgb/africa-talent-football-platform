import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { FOUNDER_INFO } from '../../data/demoData';

export const WorldwideNetworkBanner: React.FC = () => {
  const { t } = useLanguage();

  const regions = [
    {
      name: "Afrique de l'Ouest (UFOA)",
      flag: '🌍',
      countries: "Côte d'Ivoire (Siège ATF), Sénégal, Mali, Ghana, Nigéria, Burkina Faso, Guinée",
      badge: 'Hub Principal Détection',
      color: 'border-amber-500/40 bg-amber-500/10 text-amber-300',
    },
    {
      name: 'Afrique du Nord (UNAF)',
      flag: '🌐',
      countries: 'Maroc, Égypte, Tunisie, Algérie',
      badge: 'Partenariats Clubs Botola & Égypte',
      color: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300',
    },
    {
      name: 'Afrique Centrale & Australe (UNIFFAC / COSAFA)',
      flag: '⚡',
      countries: 'RD Congo, Cameroun, Gabon, Afrique du Sud',
      badge: 'Viviers Physiques & Académies',
      color: 'border-blue-500/40 bg-blue-500/10 text-blue-300',
    },
    {
      name: 'Europe & Corridors Internationaux (UEFA & Monde)',
      flag: '🏆',
      countries: 'Belgique, France, Angleterre, Espagne, Portugal, Suisse, Pays du Golfe, MLS',
      badge: 'Cellules Recrutement & Pro Clubs',
      color: 'border-purple-500/40 bg-purple-500/10 text-purple-300',
    },
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-gradient-to-r from-[#060B18] via-[#091226] to-[#060B18] rounded-3xl p-6 sm:p-10 border border-amber-500/40 shadow-2xl relative overflow-hidden space-y-8">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* HEADER */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 relative z-10 border-b border-white/10 pb-6">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold uppercase tracking-wider">
                Réseau Panafricain & Mondial 24/7/365
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Disponible Partout en Afrique & dans le Monde</span>
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {t('global.coverageTitle', 'Disponibilité & Corridor de Détection Afrique & Monde')}
            </h2>

            <p className="text-xs sm:text-sm text-gray-300 max-w-3xl leading-relaxed">
              {t(
                'global.coverageSubtitle',
                'Plateforme en ligne 24/7/365 avec CDN haute performance et synchronisation PWA optimisée pour tous les réseaux mobiles africains (2G/3G/4G/5G).'
              )}
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-black/60 border border-amber-500/30 text-xs font-mono shrink-0 space-y-1">
            <span className="text-gray-400 block text-[10px] uppercase font-bold">Direction Technique</span>
            <span className="text-amber-400 font-bold block">{FOUNDER_INFO.name}</span>
            <span className="text-gray-300 block">{FOUNDER_INFO.officialTitle}</span>
            <span className="text-emerald-400 font-bold block">{FOUNDER_INFO.phone}</span>
          </div>
        </div>

        {/* 4 REGIONAL CORRIDORS */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 relative z-10">
          {regions.map((region, i) => (
            <div
              key={i}
              className="p-4 rounded-2xl bg-[#050A15] border border-white/10 hover:border-amber-500/40 transition-all flex flex-col justify-between space-y-3"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-2xl">{region.flag}</span>
                  <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold border ${region.color}`}>
                    {region.badge}
                  </span>
                </div>

                <h3 className="font-bold text-white text-sm">
                  {region.name}
                </h3>

                <p className="text-[11px] text-gray-400 leading-relaxed font-mono">
                  {region.countries}
                </p>
              </div>

              <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[10px] font-mono text-gray-500">
                <span>Statut : En Ligne</span>
                <span className="text-emerald-400 font-bold">● Actif</span>
              </div>
            </div>
          ))}
        </div>

        {/* AFRICAN CELLULAR & LOW-BANDWIDTH GUARANTEE */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-center text-xs font-mono relative z-10">
          <div className="p-3 rounded-xl bg-[#050A15] border border-white/5 space-y-1">
            <span className="text-amber-400 font-bold block text-sm">⚡ PWA Faible Débit</span>
            <span className="text-gray-400 text-[10px]">Optimisé 2G/3G/4G/5G sans perte de données</span>
          </div>

          <div className="p-3 rounded-xl bg-[#050A15] border border-white/5 space-y-1">
            <span className="text-emerald-400 font-bold block text-sm">💳 Mobile Money</span>
            <span className="text-gray-400 text-[10px]">Wave, Orange Money, MTN MoMo, Moov</span>
          </div>

          <div className="p-3 rounded-xl bg-[#050A15] border border-white/5 space-y-1">
            <span className="text-blue-400 font-bold block text-sm">🌍 Multi-Devises</span>
            <span className="text-gray-400 text-[10px]">Franc CFA (XOF), EUR (€), USD ($), GBP (£)</span>
          </div>

          <div className="p-3 rounded-xl bg-[#050A15] border border-white/5 space-y-1">
            <span className="text-purple-400 font-bold block text-sm">🗣️ 10 Langues</span>
            <span className="text-gray-400 text-[10px]">Français, Anglais, Espagnol, Arabe, etc.</span>
          </div>
        </div>
      </div>
    </section>
  );
};
