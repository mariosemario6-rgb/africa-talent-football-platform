import React, { useState } from 'react';
import { FootballCompany } from '../../types/database';
import { FOUNDER_INFO } from '../../data/demoData';
import { useLanguage } from '../../context/LanguageContext';

interface InstitutionalConnectionModalProps {
  company: FootballCompany | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (message: string) => void;
}

export const InstitutionalConnectionModal: React.FC<InstitutionalConnectionModalProps> = ({
  company,
  isOpen,
  onClose,
  onSuccess
}) => {
  const { t } = useLanguage();
  const [applicantName, setApplicantName] = useState('');
  const [applicantRole, setApplicantRole] = useState('DIRECTEUR_ACADEMIE');
  const [organization, setOrganization] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [targetProgram, setTargetProgram] = useState('');
  const [budgetOrGuarantee, setBudgetOrGuarantee] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen || !company) return null;

  const isBank = company.entityType === 'BANK' || company.category === 'Banque & Financement Sportif';
  const isUniv = company.entityType === 'UNIVERSITY' || company.category === 'Université & Bourses Sport-Études';
  const isTV = company.entityType === 'TELEVISION' || company.category === 'Chaîne Télévision & Médias Mondiaux';
  const isTelecom = company.entityType === 'TELECOM' || company.category === 'Opérateur Télécom & Communication';
  const isFood = company.entityType === 'FOOD' || company.category === 'Agroalimentaire, Boissons & Nutrition';
  const isCorporate = company.entityType === 'CORPORATE' || company.category === 'Grandes Entreprises & Sponsors Mondiaux';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      if (onSuccess) {
        onSuccess(t('instModal.successMsg'));
      }
    }, 1500);
  };

  const handleDirectWhatsApp = () => {
    const topic = isBank 
      ? `Cautionnement / Financement Bancaire (${company.name})`
      : isUniv
      ? `Candidature Bourse Sport-Études (${company.name})`
      : isTV
      ? `Droits TV / Retransmission & Couverture Médiatique (${company.name})`
      : isTelecom
      ? `Connectivité Télécom & Partenariat Digital (${company.name})`
      : isFood
      ? `Dotation Nutritionnelle, Boissons & Sponsoring (${company.name})`
      : `Partenariat & Sponsoring (${company.name})`;

    const text = `Bonjour Seydou Mario TRAORÉ,\nJe souhaite établir une mise en relation officielle avec l'institution "${company.name}" (${company.country}) sur Africa Talent Football.\n\n- Objet : ${topic}\n- Organisation / Académie : ${organization || 'Non spécifié'}\n- Contact : ${applicantName || 'Responsable'}\n\nMerci de m'indiquer la démarche et les pièces justificatives requises.`;

    window.open(`${FOUNDER_INFO.whatsappUrl}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto text-left">
      <div className="bg-[#070D1B] border-2 border-amber-500/50 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative my-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-gray-400 hover:text-white p-2 text-xl font-bold rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          aria-label={t('modal.close')}
        >
          ✕
        </button>

        {/* Header */}
        <div className="flex items-start gap-4">
          <img
            src={company.logoUrl}
            alt={company.name}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-amber-500/40 shadow-lg shrink-0"
          />
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${
                isBank
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                  : isUniv
                  ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              }`}>
                {company.category}
              </span>
              <span className="text-emerald-400 text-xs font-bold">{t('instModal.verifiedInstitution')}</span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black text-white">{company.name}</h2>
            <p className="text-xs text-gray-300 font-mono">
              {company.countryFlag} {t('instModal.headquarters')} : {company.country} · {t('instModal.contact')} : {company.contactPerson} ({company.contactRole})
            </p>
          </div>
        </div>

        {/* Modal content state */}
        {submitted ? (
          <div className="py-8 text-center space-y-4 bg-[#050914] rounded-2xl border border-emerald-500/40 p-6 animate-in zoom-in duration-300">
            <span className="text-5xl block animate-bounce">✅</span>
            <h3 className="text-xl font-black text-white">{t('instModal.successTitle')}</h3>
            <p className="text-xs text-gray-300 max-w-md mx-auto leading-relaxed">
              {t('instModal.successMsg')}
            </p>
            <div className="p-3 bg-[#0A1224] rounded-xl border border-white/10 text-[11px] font-mono text-gray-300 max-w-md mx-auto">
              {t('instModal.trackingNumber')} : ATF-984210 · {t('instModal.processingTime')}
            </div>
            <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={handleDirectWhatsApp}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black font-black text-xs uppercase tracking-wider transition-all"
              >
                {t('instModal.whatsappDesk')}
              </button>
              <button
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase transition-colors"
              >
                {t('instModal.close')}
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="p-3.5 rounded-xl bg-[#050914] border border-white/10 text-xs text-gray-300 space-y-1">
              <span className="text-amber-400 font-bold font-mono text-[10px] uppercase block">
                {company.name} · {company.category}
              </span>
              <p className="text-[11px] leading-relaxed">
                {company.description}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="space-y-1">
                <label className="text-gray-300 font-mono text-[11px] font-bold block">
                  {t('instModal.fullName')}
                </label>
                <input
                  type="text"
                  required
                  placeholder="Seydou Traoré"
                  value={applicantName}
                  onChange={(e) => setApplicantName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/10 text-white placeholder-gray-500 focus:border-amber-500 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-gray-300 font-mono text-[11px] font-bold block">
                  {t('instModal.yourRole')}
                </label>
                <select
                  value={applicantRole}
                  onChange={(e) => setApplicantRole(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/10 text-white focus:border-amber-500 outline-none"
                >
                  <option value="DIRECTEUR_ACADEMIE">Directeur Académie / Centre</option>
                  <option value="PRESIDENT_CLUB">Président de Club</option>
                  <option value="AGENT_JOUEUR">Agent / Représentant de Joueur</option>
                  <option value="JOUEUR_CANDIDAT">Joueur / Candidat Sport-Études</option>
                  <option value="PARTENAIRE_RSE">Responsable Partenariats / RSE</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-gray-300 font-mono text-[11px] font-bold block">
                  {t('instModal.orgName')}
                </label>
                <input
                  type="text"
                  required
                  placeholder="Académie Ivoire Espoir U19"
                  value={organization}
                  onChange={(e) => setOrganization(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/10 text-white placeholder-gray-500 focus:border-amber-500 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-gray-300 font-mono text-[11px] font-bold block">
                  {t('instModal.whatsappPhone')}
                </label>
                <input
                  type="tel"
                  required
                  placeholder="+225 05 00 00 00 00"
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/10 text-white placeholder-gray-500 focus:border-amber-500 outline-none"
                />
              </div>
            </div>

            {/* Target Program / Specific Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="space-y-1">
                <label className="text-gray-300 font-mono text-[11px] font-bold block">
                  {isBank ? 'Type de Financement Souhaité' : isUniv ? 'Programme Académique Visé' : 'Package Sponsoring Requis'}
                </label>
                <input
                  type="text"
                  placeholder={
                    isBank 
                      ? 'Caution bancaire transfert 500k€' 
                      : isUniv 
                      ? 'Bourse BSc Sport Science U20' 
                      : 'Équipements 200 tenues + gilets GPS'
                  }
                  value={targetProgram}
                  onChange={(e) => setTargetProgram(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/10 text-white placeholder-gray-500 focus:border-amber-500 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-gray-300 font-mono text-[11px] font-bold block">
                  {isBank ? 'Montant Estimé / Garantie (€)' : isUniv ? 'Niveau d’Études du Candidat' : 'Budget / Valeur Estimée (€)'}
                </label>
                <input
                  type="text"
                  placeholder={isUniv ? 'Baccalauréat Scientifique obtenu' : '100 000 €'}
                  value={budgetOrGuarantee}
                  onChange={(e) => setBudgetOrGuarantee(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/10 text-white placeholder-gray-500 focus:border-amber-500 outline-none"
                />
              </div>
            </div>

            <div className="space-y-1 text-xs">
              <label className="text-gray-300 font-mono text-[11px] font-bold block">
                {t('instModal.projectDescription')}
              </label>
              <textarea
                required
                rows={3}
                placeholder="Présentez brièvement vos objectifs, le profil du ou des talents concernés et les retombées attendues..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/10 text-white placeholder-gray-500 focus:border-amber-500 outline-none resize-none"
              />
            </div>

            <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-white/10">
              <button
                type="button"
                onClick={handleDirectWhatsApp}
                className="px-4 py-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30 text-xs font-mono font-bold transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <span>📱</span>
                <span>{t('instModal.whatsappDesk')}</span>
              </button>

              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/20 cursor-pointer"
              >
                {t('instModal.submitDossier')}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
