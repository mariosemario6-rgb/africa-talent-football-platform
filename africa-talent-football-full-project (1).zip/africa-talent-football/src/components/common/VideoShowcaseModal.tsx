import React, { useState } from 'react';
import { usePlayers } from '../../context/PlayerContext';
import { useLanguage } from '../../context/LanguageContext';
import { FOUNDER_INFO } from '../../data/demoData';

export const VideoShowcaseModal: React.FC = () => {
  const { activeVideo, closeVideoModal } = usePlayers();
  const { t, tPosition } = useLanguage();
  const [isPlaying, setIsPlaying] = useState(true);

  if (!activeVideo) return null;

  const { player } = activeVideo;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-[#090E18] rounded-2xl border border-amber-500/40 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header Bar */}
        <div className="px-6 py-4 bg-[#050810] border-b border-gray-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-amber-400">
                Séquences Vidéo Certifiées · Africa Talent Football
              </span>
              <h3 className="text-base font-black text-white">
                {player.firstName} {player.lastName} ({player.primaryPosition}) · {player.currentClub}
              </h3>
            </div>
          </div>
          <button
            onClick={closeVideoModal}
            className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-gray-800 text-lg font-bold"
            aria-label="Fermer"
          >
            ✕
          </button>
        </div>

        {/* Video Simulation / Showcase Screen */}
        <div className="relative bg-black aspect-video w-full flex items-center justify-center overflow-hidden group">
          <img
            src={player.avatarUrl}
            alt={player.firstName}
            className="absolute inset-0 w-full h-full object-cover opacity-40 blur-xs"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />

          {/* Interactive Player Simulation overlay */}
          <div className="relative z-10 text-center space-y-4 px-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-black/70 border border-amber-500/60 text-amber-300 text-xs font-mono font-bold">
              <span>● VIDÉO DE SCOUTING OFFICIELLE</span>
              <span>·</span>
              <span>VALEUR: {player.marketValueDisplay}</span>
            </div>

            <div className="max-w-md mx-auto">
              <h4 className="text-xl sm:text-2xl font-black text-white">
                {player.videoTitle || `${player.firstName} ${player.lastName} - Temps Forts & Buts`}
              </h4>
              <p className="text-xs text-gray-300 mt-1">
                Séquences sélectionnées et validées par {FOUNDER_INFO.name}, Scout Agent & Fondateur.
              </p>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="px-5 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider flex items-center gap-2 transition-transform active:scale-95 cursor-pointer shadow-lg shadow-amber-500/20"
              >
                <span>{isPlaying ? '⏸ Pause' : '▶ Lecture Séquences'}</span>
              </button>
              <a
                href={player.videoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-wider transition-colors"
              >
                Ouvrir sur Lecteur Externe ↗
              </a>
            </div>
          </div>

          {/* Bottom video scrub / match marks */}
          <div className="absolute bottom-0 inset-x-0 bg-black/80 backdrop-blur-sm p-3 border-t border-gray-800 text-[11px] text-gray-300 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="text-amber-400 font-mono font-bold">04:18 / 08:35</span>
              <div className="hidden sm:flex items-center gap-2 text-[10px] text-gray-400">
                <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                  12' But pied droit
                </span>
                <span className="px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800">
                  34' Élimination 1v1
                </span>
                <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800">
                  68' Vitesse 34.4 km/h
                </span>
              </div>
            </div>
            <span className="text-gray-400 text-[10px]">Qualité 1080p 60fps</span>
          </div>
        </div>

        {/* Video Dossier Footer & WhatsApp Reach */}
        <div className="p-4 sm:p-5 bg-[#070B14] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs space-y-1 text-center sm:text-left">
            <div className="text-gray-400">
              Scout Superviseur : <span className="text-white font-bold">{FOUNDER_INFO.name}</span>
            </div>
            <div className="text-[11px] text-gray-500">
              Pour demander l'accès au match complet non découpé (Full 90 minutes) :
            </div>
          </div>
          <div className="flex gap-2 w-full sm:w-auto">
            <a
              href={`${FOUNDER_INFO.whatsappUrl}?text=Bonjour%20M.%20Seydou%20Mario%20TRAOR%C3%A9%2C%20je%20souhaite%20acc%C3%A9der%20au%20match%20complet%20vid%C3%A9o%20du%20joueur%20${encodeURIComponent(player.firstName + ' ' + player.lastName)}%20sur%20Africa%20Talent%20Football.`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-5 py-2.5 rounded bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs uppercase tracking-wider text-center transition-colors"
            >
              Demander le Match Complet (WhatsApp)
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
