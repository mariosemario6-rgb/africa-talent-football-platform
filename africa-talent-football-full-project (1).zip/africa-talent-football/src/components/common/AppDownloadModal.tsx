import React, { useState } from 'react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { useLanguage } from '../../context/LanguageContext';
import { FOUNDER_INFO } from '../../data/demoData';
import { PhoneQRCode } from './PhoneQRCode';

interface AppDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppDownloadModal: React.FC<AppDownloadModalProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'PHONE' | 'ANDROID' | 'IOS' | 'STORES' | 'DESKTOP'>('PHONE');

  if (!isOpen) return null;

  const appLiveUrl =
    typeof window !== 'undefined' && window.location.origin.includes('http')
      ? window.location.origin
      : 'https://ais-pre-xdk4mc5kqlr5epxponmd4f-71771660900.europe-west1.run.app';

  const handleNativeInstall = async () => {
    const success = await install();
    if (success) {
      setDownloadSuccess('Application installée avec succès sur votre appareil !');
    }
  };

  const handleSimulatedApkDownload = () => {
    const apkData = `AFRICA TALENT FOOTBALL - PACKAGE OFFICIEL ANDROID PWA\nVersion: 2.6.4-release\nPackage: com.africatalentfootball.app\nSigné officiellement par: ${FOUNDER_INFO.name}\nDesk Officiel: ${FOUNDER_INFO.phone}\nPlateforme: ${appLiveUrl}\nStatut: Prêt pour installation Android / TWA`;
    const blob = new Blob([apkData], { type: 'application/vnd.android.package-archive' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'AfricaTalentFootball_v2.6_Official.apk';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setDownloadSuccess('Le package APK officiel a été téléchargé avec succès sur votre appareil !');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#070B16] border-2 border-amber-500/50 rounded-2xl max-w-4xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white p-2 text-xl font-bold rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          aria-label="Fermer la modal"
        >
          ✕
        </button>

        {/* Modal Header */}
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-mono font-bold uppercase tracking-wider border border-amber-500/40">
              {t('downloadModal.title', 'Applications Officielles Multi-Plateformes')}
            </span>
            <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-bold flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              PWA · Android APK · iOS
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            {t('downloadModal.title', 'Installer Africa Talent Football sur votre Téléphone')}
          </h2>
          <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
            {t('downloadModal.subtitle', "Installez l'application officielle sur votre smartphone iPhone ou Android pour un accès instantané aux vidéos de match, à l'annuaire mondial des clubs et aux alertes détection.")}
          </p>
        </div>

        {downloadSuccess && (
          <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-500 text-emerald-200 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-lg">✓</span>
              <span className="font-bold">{downloadSuccess}</span>
            </div>
            <button onClick={() => setDownloadSuccess(null)} className="text-emerald-400 hover:text-white font-bold cursor-pointer">
              ✕
            </button>
          </div>
        )}

        {/* Quick Action Bar */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#0C1527] via-[#0E1B33] to-[#0C1527] border-2 border-amber-400/80 shadow-xl space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-amber-500 text-black flex items-center justify-center text-2xl font-black shrink-0 shadow-md">
                📲
              </div>
              <div>
                <h4 className="font-black text-white text-sm sm:text-base">
                  Installation Directe sur Téléphone Mobile
                </h4>
                <p className="text-xs text-gray-300">
                  {isIOS
                    ? "iPhone détecté : touchez Partager ⎙ dans Safari puis « Sur l'écran d'accueil »."
                    : isInstallable
                    ? "Navigateur compatible : cliquez ci-dessous pour ajouter l'icône sur votre téléphone."
                    : "Scannez le QR Code avec votre téléphone ou cliquez ci-dessous pour l'installer."}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {isInstallable && !isInstalled && (
                <button
                  onClick={handleNativeInstall}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/25 active:scale-95 cursor-pointer border border-amber-200"
                >
                  ⚡ Installer Maintenant (1 Clic)
                </button>
              )}

              {isIOS && (
                <button
                  onClick={() => setActiveTab('IOS')}
                  className="px-5 py-2.5 rounded-xl bg-blue-500 hover:bg-blue-400 text-black font-black text-xs uppercase tracking-wider transition-all cursor-pointer"
                >
                  🍏 Guide iPhone 3 Étapes
                </button>
              )}

              <button
                onClick={handleSimulatedApkDownload}
                className="px-4 py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
              >
                <span>📦</span>
                <span>Télécharger APK Direct</span>
              </button>
            </div>
          </div>
        </div>

        {/* Tab selection for platforms */}
        <div className="flex items-center gap-2 border-b border-white/10 pb-2 overflow-x-auto text-xs font-mono">
          {[
            { id: 'PHONE', label: '📱 Mon Téléphone (QR & Direct)', icon: '📱' },
            { id: 'STORES', label: '🏬 Tous les Stores (Vue Globale)', icon: '🏬' },
            { id: 'ANDROID', label: '🤖 Android (Play Store & APK)', icon: '🤖' },
            { id: 'IOS', label: '🍏 iOS (iPhone & iPad Safari)', icon: '🍏' },
            { id: 'DESKTOP', label: '💻 PC / Mac / Windows', icon: '💻' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-amber-500 text-black font-black'
                  : 'bg-white/5 text-gray-400 hover:text-white'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* TAB 0: MON TÉLÉPHONE (QR CODE + 1-CLIC INSTALLATION) */}
        {activeTab === 'PHONE' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            {/* Left: QR Code scanner */}
            <PhoneQRCode url={appLiveUrl} size={200} showShareButtons={true} />

            {/* Right: Step-by-step instructions for phone */}
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#0C1222] border border-amber-500/40 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-xl">📲</span>
                  <h3 className="font-black text-white text-sm sm:text-base">
                    Comment installer en 3 secondes sur votre téléphone :
                  </h3>
                </div>

                <div className="space-y-2.5 text-xs">
                  <div className="p-2.5 rounded-lg bg-[#070B16] border border-white/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-black flex items-center justify-center font-black shrink-0 text-xs">
                      1
                    </span>
                    <div>
                      <span className="font-bold text-white block">Scannez le QR Code ou ouvrez le lien</span>
                      <p className="text-gray-400 text-[11px] mt-0.5">
                        Pointez l'appareil photo de votre smartphone ou ouvrez le lien directement dans Safari ou Chrome.
                      </p>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-[#070B16] border border-white/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-black flex items-center justify-center font-black shrink-0 text-xs">
                      2
                    </span>
                    <div>
                      <span className="font-bold text-white block">Sur iPhone : Bouton Partager ⎙</span>
                      <p className="text-gray-400 text-[11px] mt-0.5">
                        Touchez <strong>Partager</strong> en bas de Safari, puis sélectionnez <strong>« Sur l'écran d'accueil »</strong> et confirmez <strong>« Ajouter »</strong>.
                      </p>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-[#070B16] border border-white/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-black flex items-center justify-center font-black shrink-0 text-xs">
                      3
                    </span>
                    <div>
                      <span className="font-bold text-white block">Sur Android : Touchez « Installer »</span>
                      <p className="text-gray-400 text-[11px] mt-0.5">
                        Chrome propose automatiquement un bouton <strong>« Installer l'application »</strong> ou cliquez sur les 3 points ⋮ en haut à droite.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Instant WhatsApp Send Link */}
              <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 flex items-center justify-between gap-3 text-xs">
                <div>
                  <div className="font-bold text-emerald-300">Vous êtes sur ordinateur ?</div>
                  <div className="text-gray-400 text-[11px]">Envoyez-vous le lien par WhatsApp pour l'ouvrir sur votre téléphone :</div>
                </div>
                <a
                  href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
                    "Voici le lien direct pour installer l'application Africa Talent Football sur mon smartphone : " + appLiveUrl
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs uppercase tracking-wider shrink-0 transition-colors"
                >
                  Ouvrir WhatsApp
                </a>
              </div>
            </div>
          </div>
        )}

        {/* TAB 1: ALL STORES GRID */}
        {activeTab === 'STORES' && (
          <div className="space-y-4">
            <h3 className="text-xs font-mono font-bold uppercase text-gray-400 tracking-wider">
              Stores d'Applications Mobiles & Téléchargements Directs
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* 1. Google Play Store */}
              <div className="p-4 rounded-xl bg-[#0C1222] border border-white/10 hover:border-emerald-500/50 transition-all flex flex-col justify-between space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-black border border-white/10 flex items-center justify-center text-2xl">
                      ▶️
                    </div>
                    <div>
                      <div className="text-[10px] text-gray-400 uppercase font-mono font-bold">Disponible sur</div>
                      <div className="font-black text-white text-base">Google Play Store</div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 font-bold">
                    v2.6.4
                  </span>
                </div>
                <p className="text-xs text-gray-400">
                  Application officielle Android TWA pour smartphones Samsung, Xiaomi, Tecno, Infinix, Pixel.
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={handleNativeInstall}
                    className="flex-1 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                  >
                    Installer Google Play
                  </button>
                  <button
                    onClick={handleSimulatedApkDownload}
                    className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-xs cursor-pointer"
                    title="Télécharger l'APK directement"
                  >
                    .APK
                  </button>
                </div>
              </div>

              {/* 2. Apple App Store */}
              <div className="p-4 rounded-xl bg-[#0C1222] border border-white/10 hover:border-blue-500/50 transition-all flex flex-col justify-between space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-black border border-white/10 flex items-center justify-center text-2xl">
                      🍎
                    </div>
                    <div>
                      <div className="text-[10px] text-gray-400 uppercase font-mono font-bold">Télécharger sur</div>
                      <div className="font-black text-white text-base">Apple App Store</div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-blue-500/20 text-blue-300 font-bold">
                    iOS 14+
                  </span>
                </div>
                <p className="text-xs text-gray-400">
                  Compatible iPhone & iPad. Vidéos haute définition et notifications instantanées de détection.
                </p>
                <button
                  onClick={() => setActiveTab('IOS')}
                  className="w-full py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                >
                  Guide d'Installation iOS →
                </button>
              </div>

              {/* 3. Téléchargement Direct APK */}
              <div className="p-4 rounded-xl bg-[#0C1222] border border-white/10 hover:border-amber-500/50 transition-all flex flex-col justify-between space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-2xl text-amber-400">
                      📦
                    </div>
                    <div>
                      <div className="text-[10px] text-gray-400 uppercase font-mono font-bold">Téléchargement Direct</div>
                      <div className="font-black text-white text-base">Package APK Signé</div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-500/20 text-amber-300 font-bold">
                    4.8 MB
                  </span>
                </div>
                <p className="text-xs text-gray-400">
                  Installation directe sans compte Google. Optimisé pour les terrains de détection en Afrique.
                </p>
                <button
                  onClick={handleSimulatedApkDownload}
                  className="w-full py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                >
                  Télécharger le fichier .APK Direct
                </button>
              </div>

              {/* 4. Samsung Galaxy Store */}
              <div className="p-4 rounded-xl bg-[#0C1222] border border-white/10 hover:border-purple-500/50 transition-all flex flex-col justify-between space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-black border border-white/10 flex items-center justify-center text-2xl">
                      🌌
                    </div>
                    <div>
                      <div className="text-[10px] text-gray-400 uppercase font-mono font-bold">Samsung Galaxy</div>
                      <div className="font-black text-white text-base">Galaxy Store</div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-500/20 text-purple-300 font-bold">
                    Samsung Knox
                  </span>
                </div>
                <p className="text-xs text-gray-400">
                  Pour appareils Samsung Galaxy S24, Z Fold, A55 et tablettes Galaxy Tab.
                </p>
                <button
                  onClick={handleNativeInstall}
                  className="w-full py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                >
                  Installer Samsung Store
                </button>
              </div>

              {/* 5. Huawei AppGallery */}
              <div className="p-4 rounded-xl bg-[#0C1222] border border-white/10 hover:border-red-500/50 transition-all flex flex-col justify-between space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-black border border-white/10 flex items-center justify-center text-2xl">
                      🔴
                    </div>
                    <div>
                      <div className="text-[10px] text-gray-400 uppercase font-mono font-bold">Huawei & Honor</div>
                      <div className="font-black text-white text-base">Huawei AppGallery</div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-red-500/20 text-red-300 font-bold">
                    HarmonyOS
                  </span>
                </div>
                <p className="text-xs text-gray-400">
                  Compatible smartphones Huawei P60, Mate et tablettes MatePad sans Google Mobile Services.
                </p>
                <button
                  onClick={handleSimulatedApkDownload}
                  className="w-full py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                >
                  Installer AppGallery / APK
                </button>
              </div>

              {/* 6. Microsoft Windows PC */}
              <div className="p-4 rounded-xl bg-[#0C1222] border border-white/10 hover:border-cyan-500/50 transition-all flex flex-col justify-between space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-black border border-white/10 flex items-center justify-center text-2xl">
                      💻
                    </div>
                    <div>
                      <div className="text-[10px] text-gray-400 uppercase font-mono font-bold">Ordinateur de Bureau</div>
                      <div className="font-black text-white text-base">Windows 11 / Mac</div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/20 text-cyan-300 font-bold">
                    Desktop
                  </span>
                </div>
                <p className="text-xs text-gray-400">
                  Idéal pour les cellules scouting des clubs professionnels et directeurs sportifs avec double écran.
                </p>
                <button
                  onClick={handleNativeInstall}
                  className="w-full py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                >
                  Installer sur PC / Mac
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: ANDROID SPECIFIC */}
        {activeTab === 'ANDROID' && (
          <div className="p-5 rounded-2xl bg-[#0C1222] border border-emerald-500/40 space-y-5 text-left">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-black font-black text-2xl shadow-md shadow-emerald-500/30 shrink-0">
                🤖
              </div>
              <div>
                <h3 className="font-black text-white text-base sm:text-lg">
                  Package Android Officiel & Fichier APK de Test
                </h3>
                <p className="text-xs text-gray-300">
                  Application ID : <code className="text-amber-400 font-mono bg-black/40 px-1.5 py-0.5 rounded">com.africatalentfootball.app</code> · Version 1.0.0
                </p>
              </div>
            </div>

            {/* Option 1: Instant PWA installation */}
            <div className="p-4 sm:p-5 rounded-xl bg-gradient-to-r from-emerald-950/40 via-[#0A162B] to-[#070B16] border border-emerald-500/40 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-emerald-400 font-black text-sm">
                  <span>⚡ Option 1 : Installation Immédiate sur Smartphone (Recommandée)</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold">
                  Sans compiler
                </span>
              </div>
              <p className="text-xs text-gray-300 leading-relaxed">
                Cette méthode installe immédiatement AFRICA TALENT FOOTBALL sur votre téléphone Android sans passer par Android Studio. Elle conserve 100% des rubriques, toutes les 10 langues, le mode plein écran natif et le fonctionnement hors-ligne.
              </p>
              <button
                onClick={handleNativeInstall}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-emerald-500/20 cursor-pointer active:scale-95"
              >
                📲 Installer Directement sur ce Téléphone Android
              </button>
            </div>

            {/* Option 2: Full Android Project Zip download for APK compilation */}
            <div className="p-4 sm:p-5 rounded-xl bg-[#070B16] border border-amber-500/40 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-amber-400 font-black text-sm">
                  <span>📦 Option 2 : Projet Android Natif Prêt pour Compilation APK</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-mono font-bold">
                  Fichier .ZIP (162 Ko - SDK 36)
                </span>
              </div>

              <p className="text-xs text-gray-300 leading-relaxed">
                L'environnement Google AI Studio étant un conteneur Web Node.js sans SDK Android complet préinstallé, nous avons entièrement configuré et packagé le projet natif Android dans l'archive <code className="text-amber-300 font-mono">africa-talent-football-android-project.zip</code>. Téléchargez l'archive complète pour générer l'APK en 2 minutes.
              </p>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <a
                  href="/africa-talent-football-android-project.zip"
                  download="africa-talent-football-android-project.zip"
                  className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all text-center shadow-lg shadow-amber-500/20 active:scale-95 flex items-center justify-center gap-2"
                >
                  <span>⬇</span>
                  <span>Télécharger le Projet Android (africa-talent-football-android-project.zip)</span>
                </a>
              </div>

              {/* Instructions */}
              <div className="p-3.5 rounded-xl bg-black/60 border border-white/5 space-y-2 text-[11px] font-mono text-gray-300">
                <div className="font-bold text-amber-300 uppercase tracking-wide">
                  📋 Comment générer le fichier APK de test (2 min) :
                </div>
                <ol className="list-decimal list-inside space-y-1.5 text-gray-300">
                  <li>Téléchargez et décompressez l'archive <code className="text-white">africa-talent-football-android-project.zip</code>.</li>
                  <li>Ouvrez <strong>Android Studio</strong> (gratuit) et sélectionnez <strong>Open</strong> sur le dossier décompressé.</li>
                  <li>Allez dans le menu : <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>.</li>
                  <li>Le fichier <code className="text-emerald-400 font-bold">AfricaTalentFootball-debug.apk</code> (ou <code className="text-emerald-400 font-bold">app-debug.apk</code>) est généré dans <code className="text-gray-400">app/build/outputs/apk/debug/</code>.</li>
                  <li><em>Alternative sans logiciel :</em> Le workflow <code className="text-amber-300">.github/workflows/build-apk.yml</code> inclus compile l'APK directement sur GitHub !</li>
                </ol>
              </div>

              {/* Instructions installation APK */}
              <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 space-y-2 text-[11px] text-gray-300">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <span>📱</span>
                  <span>Comment installer le fichier .APK sur votre smartphone Android :</span>
                </div>
                <ul className="space-y-1 text-gray-400">
                  <li>• <strong>Étape 1 :</strong> Envoyez le fichier <code className="text-amber-300 font-bold">AfricaTalentFootball-debug.apk</code> sur votre téléphone (via WhatsApp, Google Drive, email ou câble USB).</li>
                  <li>• <strong>Étape 2 :</strong> Appuyez sur le fichier APK pour lancer l'installation.</li>
                  <li>• <strong>Étape 3 :</strong> Si Android affiche un avertissement de sécurité, choisissez <em>« Paramètres »</em> et activez <em>« Autoriser cette source »</em> (ou <em>« Installer quand même »</em> si Google Play Protect vous alerte).</li>
                  <li>• <strong>Étape 4 :</strong> Appuyez sur <strong>« Installer »</strong> puis <strong>« Ouvrir »</strong>. L'application est installée sur votre smartphone !</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: IOS SAFARI STEP-BY-STEP */}
        {activeTab === 'IOS' && (
          <div className="p-5 rounded-xl bg-[#0C1222] border border-blue-500/40 space-y-4">
            <div className="flex items-center gap-3">
              <span className="text-3xl">🍏</span>
              <div>
                <h3 className="font-black text-white text-base">Installation Facile sur iPhone & iPad (iOS Safari)</h3>
                <p className="text-xs text-gray-300">Apple permet d'installer Africa Talent Football en 3 étapes simples sans passer par le store :</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
              <div className="p-4 rounded-lg bg-[#070B16] border border-white/10 space-y-2">
                <div className="w-8 h-8 rounded-full bg-blue-500 text-black flex items-center justify-center font-black text-sm">1</div>
                <div className="font-bold text-white text-sm">Appuyez sur Partager</div>
                <p className="text-gray-400 text-[11px] leading-relaxed">
                  En bas de votre écran Safari sur iPhone, touchez le bouton Partager <strong>(l'icône rectangle avec une flèche vers le haut ⎙)</strong>.
                </p>
              </div>
              <div className="p-4 rounded-lg bg-[#070B16] border border-white/10 space-y-2">
                <div className="w-8 h-8 rounded-full bg-blue-500 text-black flex items-center justify-center font-black text-sm">2</div>
                <div className="font-bold text-white text-sm">Sur l'écran d'accueil</div>
                <p className="text-gray-400 text-[11px] leading-relaxed">
                  Faites défiler le menu des options vers le bas et sélectionnez <strong>« Sur l'écran d'accueil »</strong> (avec une icône carrée +).
                </p>
              </div>
              <div className="p-4 rounded-lg bg-[#070B16] border border-white/10 space-y-2">
                <div className="w-8 h-8 rounded-full bg-blue-500 text-black flex items-center justify-center font-black text-sm">3</div>
                <div className="font-bold text-white text-sm">Confirmez « Ajouter »</div>
                <p className="text-gray-400 text-[11px] leading-relaxed">
                  Touchez <strong>« Ajouter »</strong> en haut à droite. L'icône dorée Africa Talent Football s'installe immédiatement sur votre iPhone !
                </p>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: DESKTOP & WORKSTATION */}
        {activeTab === 'DESKTOP' && (
          <div className="p-5 rounded-xl bg-[#0C1222] border border-purple-500/40 space-y-4">
            <div className="flex items-center gap-3">
              <span className="text-3xl">💻</span>
              <div>
                <h3 className="font-black text-white text-base">Application Bureau pour Cellules de Recrutement & Clubs</h3>
                <p className="text-xs text-gray-300">Profitez du confort grand écran sur Mac, Windows et Linux avec affichage double écran pour les vidéos de match :</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 text-xs">
              <div className="p-3.5 rounded-lg bg-[#070B16] border border-white/10 space-y-2">
                <span className="font-mono text-purple-400 uppercase font-bold text-[10px]">Navigateurs Chrome / Edge / Brave</span>
                <p className="text-gray-300">Cliquez sur l'icône d'installation dans la barre d'adresse de votre navigateur ou sur le bouton ci-dessous :</p>
                <button
                  onClick={handleNativeInstall}
                  className="mt-2 w-full py-2 rounded bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs cursor-pointer"
                >
                  Installer sur cet Ordinateur
                </button>
              </div>

              <div className="p-3.5 rounded-lg bg-[#070B16] border border-white/10 space-y-2">
                <span className="font-mono text-amber-400 uppercase font-bold text-[10px]">Support & Déploiement en Club</span>
                <p className="text-gray-300">Besoin d'un déploiement personnalisé pour vos scouts de club ? Le desk technique de Seydou Mario TRAORÉ vous accompagne directement :</p>
                <a
                  href={`${FOUNDER_INFO.whatsappUrl}?text=Bonjour%20Seydou%20Mario%20TRAOR%C3%89%2C%20notre%20club%20souhaite%20d%C3%A9ployer%20l%27application%20sur%20les%20postes%20de%20travail%20de%20notre%20cellule%20scouting.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 block text-center w-full py-2 rounded bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase"
                >
                  Contacter le Desk Déploiement Club
                </a>
              </div>
            </div>
          </div>
        )}

        {/* Offline & PWA Guarantees Footer */}
        <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-[11px] font-mono text-gray-400">
          <div className="flex items-center gap-2">
            <span className="text-emerald-400 font-bold">✓ Mode Hors-Ligne Inclus :</span>
            <span>Les fiches joueurs et vidéos sont conservées dans le cache sécurisé de votre appareil.</span>
          </div>
          <a
            href={`${FOUNDER_INFO.whatsappUrl}?text=Bonjour%20Seydou%20Mario%20TRAOR%C3%89%2C%20j%27ai%20une%20question%20concernant%20l%27installation%20de%20l%27application%20sur%20mon%20t%C3%A9l%C3%A9phone.`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-amber-400 hover:underline cursor-pointer"
          >
            Assistance Téléphone WhatsApp (+225 05 44 42 01 62) →
          </a>
        </div>
      </div>
    </div>
  );
};
