import React, { useEffect, useState } from 'react';
import { RegisteredPlayer } from '../../types/database';
import { FOUNDER_INFO, formatMarketValue } from '../../data/demoData';
import { useLanguage } from '../../context/LanguageContext';
import QRCode from 'qrcode';

interface PlayerPDFExportModalProps {
  player: RegisteredPlayer | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PlayerPDFExportModal: React.FC<PlayerPDFExportModalProps> = ({
  player,
  isOpen,
  onClose,
}) => {
  const { t, tPosition, tFoot, tContract, formatDate, formatCurrency } = useLanguage();
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');
  const [includeRadar, setIncludeRadar] = useState(true);
  const [includeGps, setIncludeGps] = useState(true);
  const [includeScoutReport, setIncludeScoutReport] = useState(true);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (player) {
      const liveOrigin =
        typeof window !== 'undefined' && window.location.origin.includes('http')
          ? window.location.origin
          : 'https://ais-pre-xdk4mc5kqlr5epxponmd4f-71771660900.europe-west1.run.app';
      const playerUrl = `${liveOrigin}/?view=player-detail&id=${player.id}`;

      QRCode.toString(
        playerUrl,
        {
          type: 'svg',
          margin: 1,
          color: {
            dark: '#000000',
            light: '#FFFFFF',
          },
        },
        (err, svgString) => {
          if (!err && svgString) {
            setQrCodeDataUrl('data:image/svg+xml;utf8,' + encodeURIComponent(svgString));
          }
        }
      );
    }
  }, [player]);

  if (!isOpen || !player) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadStandaloneHtml = () => {
    const el = document.getElementById('scouting-dossier-print');
    if (!el) return;

    const htmlContent = `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Dossier Scouting - ${player.firstName} ${player.lastName} - Africa Talent Football</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @page { size: A4 portrait; margin: 10mm; }
    body { font-family: system-ui, -apple-system, sans-serif; background-color: #f3f4f6; padding: 20px; }
    .print-card { max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); }
  </style>
</head>
<body>
  <div class="print-card">
    ${el.innerHTML}
  </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Rapport_Scouting_ATF_${player.firstName}_${player.lastName}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setDownloadSuccess('Dossier complet exporté avec succès !');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  const currentDate = new Date().toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });

  // Calculate Radar Geometry for print-safe SVG
  const radarAxes = [
    { key: 'pace', label: 'Vitesse', val: player.physicalRadar?.pace || 75 },
    { key: 'shooting', label: 'Tir', val: player.physicalRadar?.shooting || 65 },
    { key: 'passing', label: 'Passe', val: player.physicalRadar?.passing || 70 },
    { key: 'dribbling', label: 'Dribble', val: player.physicalRadar?.dribbling || 78 },
    { key: 'defending', label: 'Défense', val: player.physicalRadar?.defending || 55 },
    { key: 'physicality', label: 'Physique', val: player.physicalRadar?.physicality || 74 },
  ];

  const radarSize = 220;
  const radarCenter = radarSize / 2;
  const radarRadius = 75;
  const angleSlice = (Math.PI * 2) / radarAxes.length;

  const playerPointsString = radarAxes
    .map((axis, i) => {
      const angle = i * angleSlice - Math.PI / 2;
      const r = (axis.val / 100) * radarRadius;
      return `${radarCenter + r * Math.cos(angle)},${radarCenter + r * Math.sin(angle)}`;
    })
    .join(' ');

  const benchmarkPointsString = radarAxes
    .map((_, i) => {
      const angle = i * angleSlice - Math.PI / 2;
      const r = (65 / 100) * radarRadius;
      return `${radarCenter + r * Math.cos(angle)},${radarCenter + r * Math.sin(angle)}`;
    })
    .join(' ');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      {/* Print-specific style override */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #scouting-dossier-print, #scouting-dossier-print * {
            visibility: visible;
          }
          #scouting-dossier-print {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: 20px;
            background: white !important;
            color: black !important;
            box-shadow: none !important;
            border: none !important;
          }
          .no-print {
            display: none !important;
          }
        }
      `}</style>

      <div className="max-w-4xl w-full my-auto space-y-4">
        {/* Top Control Bar */}
        <div className="no-print bg-[#090E1B] border border-amber-500/50 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-2xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-black flex items-center justify-center text-xl font-black">
              📄
            </div>
            <div>
              <h3 className="text-white font-black text-sm sm:text-base">
                Rapport de Scouting & Fiche Technique Certifiée
              </h3>
              <p className="text-xs text-gray-300">
                Format d'impression officiel A4 avec sceau d'approbation Seydou Mario TRAORÉ
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-amber-500/25 active:scale-95 cursor-pointer flex items-center gap-2 border border-amber-200"
            >
              <span>🖨️</span>
              <span>Imprimer / Sauvegarder en PDF</span>
            </button>

            <button
              onClick={handleDownloadStandaloneHtml}
              className="px-4 py-2.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold uppercase transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <span>💾</span>
              <span>Télécharger Fiche (.HTML)</span>
            </button>

            <button
              onClick={onClose}
              className="px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase transition-colors cursor-pointer"
            >
              ✕ Fermer
            </button>
          </div>
        </div>

        {downloadSuccess && (
          <div className="no-print p-3 rounded-xl bg-emerald-950 border border-emerald-500 text-emerald-200 text-xs font-bold text-center">
            ✓ {downloadSuccess}
          </div>
        )}

        {/* Section Toggles */}
        <div className="no-print p-3 rounded-xl bg-black/60 border border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs text-gray-300">
          <span className="font-mono text-[11px] uppercase text-amber-400 font-bold">
            Sections à inclure dans le PDF :
          </span>
          <div className="flex flex-wrap items-center gap-4">
            <label className="flex items-center gap-1.5 cursor-pointer hover:text-white">
              <input
                type="checkbox"
                checked={includeRadar}
                onChange={(e) => setIncludeRadar(e.target.checked)}
                className="rounded accent-amber-500"
              />
              <span>Graphique Radar Athlétique</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer hover:text-white">
              <input
                type="checkbox"
                checked={includeGps}
                onChange={(e) => setIncludeGps(e.target.checked)}
                className="rounded accent-amber-500"
              />
              <span>Données Compétitives & GPS</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer hover:text-white">
              <input
                type="checkbox"
                checked={includeScoutReport}
                onChange={(e) => setIncludeScoutReport(e.target.checked)}
                className="rounded accent-amber-500"
              />
              <span>Audit Terrain Scout</span>
            </label>
          </div>
        </div>

        {/* Printable PDF Document Sheet (Simulated A4 Paper) */}
        <div
          id="scouting-dossier-print"
          className="bg-white text-gray-900 rounded-2xl shadow-2xl p-6 sm:p-10 space-y-6 max-h-[85vh] overflow-y-auto border border-gray-300 font-sans"
        >
          {/* Document Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b-2 border-gray-900 pb-5">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-xl bg-[#040711] border-2 border-amber-500 flex items-center justify-center text-amber-400 font-black text-2xl shadow-md">
                ATF
              </div>
              <div>
                <div className="text-[10px] font-mono uppercase tracking-widest text-amber-700 font-bold">
                  DIRECTION TECHNIQUE & DÉTECTION INTERNATIONALE
                </div>
                <h1 className="text-2xl sm:text-3xl font-black text-gray-950 tracking-tight leading-none">
                  AFRICA TALENT FOOTBALL
                </h1>
                <div className="text-xs text-gray-600 mt-1 font-medium">
                  Plateforme Officielle · Supervision Seydou Mario TRAORÉ
                </div>
              </div>
            </div>

            <div className="text-right space-y-1 sm:border-l sm:pl-5 sm:border-gray-200 text-xs font-mono">
              <div className="font-bold text-gray-950 uppercase tracking-wider">
                DOSSIER SCOUTING OFFICIEL
              </div>
              <div className="text-gray-600 text-[11px]">
                Réf : <strong className="text-gray-900">ATF-2026-{player.id.toUpperCase()}</strong>
              </div>
              <div className="text-gray-500 text-[11px]">Date d'émission : {currentDate}</div>
              <span className="inline-block px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[9px] font-bold border border-emerald-300">
                ● RAPPORT CERTIFIÉ VALIDE
              </span>
            </div>
          </div>

          {/* Identity & Market Value Strip */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center bg-gray-50 p-5 rounded-2xl border border-gray-200">
            {/* Portrait Photo */}
            <div className="md:col-span-3 flex justify-center">
              <div className="relative w-36 h-44 rounded-xl overflow-hidden shadow-md border-2 border-amber-500 bg-black">
                <img
                  src={player.avatarUrl}
                  alt={player.firstName}
                  className="w-full h-full object-cover object-top"
                />
                <span className="absolute top-2 left-2 bg-black/90 text-amber-400 px-2 py-0.5 rounded text-[10px] font-mono font-bold">
                  {player.primaryPosition}
                </span>
                <span className="absolute bottom-2 right-2 text-base">
                  {player.countryFlag}
                </span>
              </div>
            </div>

            {/* Main Player Info */}
            <div className="md:col-span-9 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-200 pb-3">
                <div>
                  <span className="text-[11px] font-mono uppercase text-gray-500 font-bold">
                    Fiche Athlète / Profil Mercato
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-black text-gray-950">
                    {player.firstName} {player.lastName}
                  </h2>
                </div>

                <div className="text-left sm:text-right bg-amber-50 border border-amber-300 px-4 py-2 rounded-xl">
                  <div className="text-[10px] font-mono uppercase text-amber-800 font-bold">
                    Valeur Marchande Estimée
                  </div>
                  <div className="text-2xl font-black text-emerald-700 font-mono">
                    {player.marketValueDisplay}
                  </div>
                </div>
              </div>

              {/* Bio Grid Details */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <span className="text-gray-500 block text-[10px] uppercase font-mono">Nationalité</span>
                  <span className="font-bold text-gray-900">{player.nationality} {player.countryFlag}</span>
                </div>
                <div>
                  <span className="text-gray-500 block text-[10px] uppercase font-mono">Âge / Naissance</span>
                  <span className="font-bold text-gray-900">{player.calculatedAge} ans ({player.dateOfBirth})</span>
                </div>
                <div>
                  <span className="text-gray-500 block text-[10px] uppercase font-mono">Poste / Pied Fort</span>
                  <span className="font-bold text-gray-900">{player.primaryPosition} · Pied {player.preferredFoot}</span>
                </div>
                <div>
                  <span className="text-gray-500 block text-[10px] uppercase font-mono">Taille / Poids</span>
                  <span className="font-bold text-gray-900 font-mono">{player.heightCm} cm · {player.weightKg} kg</span>
                </div>
                <div>
                  <span className="text-gray-500 block text-[10px] uppercase font-mono">Académie / Club Formateur</span>
                  <span className="font-bold text-amber-800">{player.academy}</span>
                </div>
                <div>
                  <span className="text-gray-500 block text-[10px] uppercase font-mono">Club Actuel</span>
                  <span className="font-bold text-gray-900">{player.currentClub}</span>
                </div>
                <div>
                  <span className="text-gray-500 block text-[10px] uppercase font-mono">Statut Contractuel</span>
                  <span className="font-bold text-emerald-700">{player.contractStatus}</span>
                </div>
                <div>
                  <span className="text-gray-500 block text-[10px] uppercase font-mono">Réglementation FIFA</span>
                  <span className="font-bold text-gray-900">{player.isMinor ? 'Mineur protégé (Art. 19)' : 'Majeur transférable'}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Key Statistics Matrix */}
          {includeGps && (
            <div className="space-y-2">
              <h3 className="text-xs font-mono font-bold uppercase text-gray-800 tracking-wider flex items-center justify-between border-b border-gray-200 pb-1">
                <span className="flex items-center gap-2">
                  <span>📊</span>
                  <span>Statistiques Compétitives & Données GPS Certifiées</span>
                </span>
                <span className="text-[10px] text-gray-500 font-normal">Supervision Wyscout / Catapult GPS</span>
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 text-center text-xs">
                <div className="p-3 rounded-xl bg-gray-50 border border-gray-200">
                  <div className="text-xl font-black text-gray-950 font-mono">{player.stats.matches}</div>
                  <div className="text-gray-500 text-[10px] uppercase font-mono mt-0.5">Matchs Disputés</div>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 border border-gray-200">
                  <div className="text-xl font-black text-gray-950 font-mono">{player.stats.minutes}'</div>
                  <div className="text-gray-500 text-[10px] uppercase font-mono mt-0.5">Minutes Jouées</div>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 border border-gray-200">
                  <div className="text-xl font-black text-amber-700 font-mono">
                    {player.primaryPosition === 'GB' ? (player.stats.cleanSheets ?? 0) : player.stats.goals}
                  </div>
                  <div className="text-gray-500 text-[10px] uppercase font-mono mt-0.5">
                    {player.primaryPosition === 'GB' ? 'Clean Sheets' : 'Buts Inscrits'}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 border border-gray-200">
                  <div className="text-xl font-black text-gray-950 font-mono">{player.stats.assists}</div>
                  <div className="text-gray-500 text-[10px] uppercase font-mono mt-0.5">Passes Décisives</div>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 border border-gray-200">
                  <div className="text-xl font-black text-gray-950 font-mono">{player.stats.passAccuracyPct}%</div>
                  <div className="text-gray-500 text-[10px] uppercase font-mono mt-0.5">Précision Passes</div>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 border border-gray-200">
                  <div className="text-xl font-black text-emerald-700 font-mono">{player.stats.topSpeedKmh} km/h</div>
                  <div className="text-gray-500 text-[10px] uppercase font-mono mt-0.5">Vitesse Pointe GPS</div>
                </div>
              </div>
            </div>
          )}

          {/* Athletic Radar & Physical Attributes */}
          {includeRadar && (
            <div className="space-y-3">
              <h3 className="text-xs font-mono font-bold uppercase text-gray-800 tracking-wider flex items-center justify-between border-b border-gray-200 pb-1">
                <span className="flex items-center gap-2">
                  <span>⚡</span>
                  <span>Graphique Radar & Aptitudes Athlétiques (D3 / Wyscout 360°)</span>
                </span>
                <span className="text-[10px] font-mono font-bold text-amber-700">
                  Indice Global : {Math.round(Object.values(player.physicalRadar).reduce((a, b) => a + b, 0) / 6)}/100
                </span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center bg-gray-50 p-4 rounded-xl border border-gray-200">
                {/* Embedded Vector SVG Radar */}
                <div className="md:col-span-5 flex flex-col items-center justify-center">
                  <svg width={radarSize} height={radarSize} viewBox={`0 0 ${radarSize} ${radarSize}`} className="overflow-visible">
                    {/* Concentric rings */}
                    {[0.2, 0.4, 0.6, 0.8, 1.0].map((lvl, idx) => {
                      const pts = radarAxes
                        .map((_, i) => {
                          const angle = i * angleSlice - Math.PI / 2;
                          const r = lvl * radarRadius;
                          return `${radarCenter + r * Math.cos(angle)},${radarCenter + r * Math.sin(angle)}`;
                        })
                        .join(' ');
                      return (
                        <polygon
                          key={idx}
                          points={pts}
                          stroke="#cbd5e1"
                          strokeWidth={lvl === 1 ? '1.5' : '1'}
                          strokeDasharray={lvl === 1 ? 'none' : '2,2'}
                          fill="transparent"
                        />
                      );
                    })}

                    {/* Radial axis lines */}
                    {radarAxes.map((axis, i) => {
                      const angle = i * angleSlice - Math.PI / 2;
                      const x = radarCenter + radarRadius * Math.cos(angle);
                      const y = radarCenter + radarRadius * Math.sin(angle);
                      const lx = radarCenter + (radarRadius + 16) * Math.cos(angle);
                      const ly = radarCenter + (radarRadius + 16) * Math.sin(angle);
                      return (
                        <g key={axis.key}>
                          <line x1={radarCenter} y1={radarCenter} x2={x} y2={y} stroke="#cbd5e1" strokeWidth="1" />
                          <text
                            x={lx}
                            y={ly}
                            textAnchor="middle"
                            dominantBaseline="central"
                            fontSize="9px"
                            fontWeight="bold"
                            fill="#334155"
                          >
                            {axis.label}
                          </text>
                        </g>
                      );
                    })}

                    {/* Benchmark polygon */}
                    <polygon
                      points={benchmarkPointsString}
                      stroke="#94a3b8"
                      strokeWidth="1.5"
                      strokeDasharray="3,3"
                      fill="#94a3b8"
                      fillOpacity="0.15"
                    />

                    {/* Player polygon */}
                    <polygon
                      points={playerPointsString}
                      stroke="#d97706"
                      strokeWidth="2.5"
                      fill="#f59e0b"
                      fillOpacity="0.35"
                    />
                  </svg>
                  <div className="flex items-center gap-3 text-[9px] font-mono text-gray-500 mt-2">
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 bg-amber-500 rounded-sm" /> Joueur
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-0.5 bg-gray-400" /> Moyenne Académies (65)
                    </span>
                  </div>
                </div>

                {/* Attribute bars */}
                <div className="md:col-span-7 grid grid-cols-2 gap-2 text-xs">
                  {radarAxes.map((axis) => (
                    <div key={axis.key} className="p-2 rounded-lg bg-white border border-gray-200 space-y-1 shadow-xs">
                      <div className="flex justify-between font-mono">
                        <span className="text-gray-700 uppercase font-bold text-[10px]">{axis.label}</span>
                        <span className="text-amber-800 font-bold">{axis.val}/100</span>
                      </div>
                      <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-amber-600 h-full rounded-full"
                          style={{ width: `${axis.val}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Technical Scouting Audit Report */}
          {includeScoutReport && player.scoutingReports.length > 0 && (
            <div className="p-4 rounded-xl bg-amber-50/60 border border-amber-300 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono uppercase font-bold text-amber-900 tracking-wider">
                  Synthèse de l'Audit Technique Terrain
                </span>
                <span className="text-[11px] font-mono text-gray-600">
                  Superviseur : {player.scoutingReports[0].scoutName}
                </span>
              </div>

              <p className="text-gray-800 italic leading-relaxed">
                "{player.scoutingReports[0].summary}"
              </p>

              <div className="pt-1 flex flex-wrap items-center gap-2">
                <span className="text-[10px] font-mono font-bold uppercase text-gray-600">Points Forts Remarqués :</span>
                {player.scoutingReports[0].strengths.map((s, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded bg-white text-gray-900 border border-amber-300 text-[10px] font-bold"
                  >
                    ✓ {s}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Official Seal of Approval & Digital Signature */}
          <div className="border-t-2 border-gray-900 pt-5 grid grid-cols-1 sm:grid-cols-12 gap-6 items-center">
            {/* The Official Circular Stamp / Seal */}
            <div className="sm:col-span-5 flex items-center gap-3">
              <div className="relative w-24 h-24 rounded-full border-4 border-amber-600 p-1 flex items-center justify-center shrink-0 shadow-inner bg-amber-50">
                <div className="w-full h-full rounded-full border-2 border-dashed border-amber-700 flex flex-col items-center justify-center text-center p-1">
                  <span className="text-[8px] font-mono font-black text-amber-900 uppercase tracking-tighter leading-none">
                    AFRICA TALENT FOOTBALL
                  </span>
                  <span className="text-amber-600 text-xs">★ ★ ★</span>
                  <span className="text-[9px] font-black text-emerald-800 uppercase tracking-tighter leading-none mt-0.5">
                    CERTIFIÉ APPROUVÉ
                  </span>
                  <span className="text-[7px] font-mono text-gray-600 mt-0.5">
                    VISA #2026-ATF
                  </span>
                </div>
              </div>

              <div className="space-y-0.5 text-xs">
                <div className="text-[10px] font-mono uppercase font-bold text-amber-800">
                  Sceau de Certification Officiel
                </div>
                <div className="font-black text-gray-950 text-sm">
                  {FOUNDER_INFO.name}
                </div>
                <div className="text-gray-600 text-[10px] leading-tight">
                  Scout Agent Certifié, Directeur Fondateur
                </div>
                <div className="text-gray-500 font-mono text-[9px]">
                  Desk : {FOUNDER_INFO.phone} · Abidjan
                </div>
              </div>
            </div>

            {/* Verification QR Code */}
            <div className="sm:col-span-7 flex items-center justify-end gap-3 text-right">
              <div className="space-y-1 text-xs">
                <div className="text-[10px] font-mono uppercase font-bold text-gray-600">
                  Vérification Numérique d'Authenticité
                </div>
                <div className="text-[11px] text-gray-700 leading-snug">
                  Scannez le QR Code pour consulter la fiche interactive, vidéos de match et historique de détection sur la plateforme officielle.
                </div>
                <div className="text-[9px] font-mono text-emerald-700 font-bold">
                  {typeof window !== 'undefined' ? window.location.origin : 'Africa Talent Football Platform'}
                </div>
              </div>

              {qrCodeDataUrl && (
                <div className="p-1 bg-white border border-gray-300 rounded-lg shadow-sm shrink-0">
                  <img
                    src={qrCodeDataUrl}
                    alt="QR Code Vérification"
                    className="w-16 h-16 object-contain"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Legal Compliance Footer */}
          <div className="border-t border-gray-200 pt-3 text-[9px] font-mono text-gray-500 flex flex-col sm:flex-row items-center justify-between gap-2">
            <span>
              Document conforme aux règlements FIFA RSTJ (Statut et Transfert des Joueurs) et protection des mineurs.
            </span>
            <span>
              © {new Date().getFullYear()} Africa Talent Football · Plateforme Officielle
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
