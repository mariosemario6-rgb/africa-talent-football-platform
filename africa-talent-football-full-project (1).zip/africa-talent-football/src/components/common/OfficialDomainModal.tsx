import React, { useState } from 'react';
import { FOUNDER_INFO, OFFICIAL_PLATFORM_CONFIG } from '../../data/demoData';
import { PhoneQRCode } from './PhoneQRCode';
import { useLanguage } from '../../context/LanguageContext';

interface OfficialDomainModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenDownloadModal?: () => void;
}

export const OfficialDomainModal: React.FC<OfficialDomainModalProps> = ({
  isOpen,
  onClose,
  onOpenDownloadModal,
}) => {
  const { t } = useLanguage();
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'DOMAIN' | 'STORES' | 'QR'>('DOMAIN');

  if (!isOpen) return null;

  const officialUrl = OFFICIAL_PLATFORM_CONFIG.websiteUrl;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(officialUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#070B16] border-2 border-amber-500/60 rounded-3xl max-w-4xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-gray-400 hover:text-white p-2 text-xl font-bold rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          aria-label={t('modal.close')}
        >
          ✕
        </button>

        {/* Modal Header */}
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-mono font-bold uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Online Global 24/7
            </span>
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-bold">
              SSL TLS 1.3 Certified
            </span>
            <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/40 text-[10px] font-mono font-bold">
              Worldwide App Stores
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            {t('officialDomain.title')}
          </h2>
          <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
            {t('officialDomain.desc')}{' '}
            <strong className="text-amber-400 font-mono">{officialUrl}</strong>
          </p>
        </div>

        {/* Official URL Banner */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#0C1527] via-[#0E1F3D] to-[#0C1527] border-2 border-amber-400/80 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="text-[10px] font-mono text-gray-400 uppercase font-bold">
              HTTPS URL :
            </div>
            <div className="text-lg sm:text-xl font-black text-white font-mono flex items-center gap-2 truncate">
              <span className="text-amber-400">🌐</span>
              <span className="truncate">{officialUrl}</span>
            </div>
            <div className="text-[11px] text-gray-400 flex items-center gap-2">
              <span className="text-emerald-400 font-bold">✓ HTTPS TLS 1.3</span>
              <span>· CDN Anycast 6 FIFA Confederations</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={handleCopy}
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/20 cursor-pointer"
            >
              {copied ? t('phoneQr.copied') : t('shareModal.copyLink')}
            </button>
            <a
              href={officialUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase transition-colors"
            >
              Online ↗
            </a>
          </div>
        </div>

        {/* Tabs switcher */}
        <div className="flex items-center gap-2 border-b border-white/10 pb-2 overflow-x-auto text-xs font-mono">
          {[
            { id: 'DOMAIN', label: '🌐 Network Specs', icon: '🌐' },
            { id: 'STORES', label: '🏬 App Stores', icon: '🏬' },
            { id: 'QR', label: '📱 Mobile QR Code', icon: '📱' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-amber-500 text-black font-black'
                  : 'bg-white/5 text-gray-400 hover:text-white'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* TAB 1: DOMAIN & NETWORK SPECS */}
        {activeTab === 'DOMAIN' && (
          <div className="space-y-5 animate-in fade-in duration-150">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-[#090E1B] border border-white/10 space-y-2">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold block">
                  DNS
                </span>
                <div className="text-white font-black text-xs font-mono truncate">{officialUrl}</div>
                <div className="text-xs text-emerald-400 flex items-center gap-1">
                  <span>✓</span> Active & Live
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#090E1B] border border-white/10 space-y-2">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold block">
                  SSL / TLS
                </span>
                <div className="text-white font-black text-sm font-mono">TLS 1.3 / HTTPS Strict</div>
                <div className="text-xs text-emerald-400 flex items-center gap-1">
                  <span>✓</span> Google Trust Certificate
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#090E1B] border border-white/10 space-y-2">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold block">
                  CDN Anycast
                </span>
                <div className="text-white font-black text-sm font-mono">Global Edge Anycast</div>
                <div className="text-xs text-emerald-400 flex items-center gap-1">
                  <span>✓</span> 200+ PoP
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: ALL WORLDWIDE DOWNLOAD PLATFORMS */}
        {activeTab === 'STORES' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="flex items-center justify-between">
              <h4 className="font-black text-white text-sm uppercase tracking-wider">
                {t('downloadModal.title')}
              </h4>
              <button
                onClick={() => {
                  onClose();
                  if (onOpenDownloadModal) onOpenDownloadModal();
                }}
                className="text-amber-400 hover:underline font-bold text-xs cursor-pointer"
              >
                Download Center ↗
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {OFFICIAL_PLATFORM_CONFIG.downloadPlatformsWorldwide.map((store) => (
                <div
                  key={store.id}
                  className="p-4 rounded-xl bg-[#090E1B] border border-white/10 hover:border-amber-400/50 transition-all flex flex-col justify-between space-y-3"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-2xl">{store.icon}</span>
                      <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-white/5 text-gray-300 border border-white/10">
                        {store.tag}
                      </span>
                    </div>
                    <div>
                      <h5 className="font-black text-white text-sm">{store.name}</h5>
                      <p className="text-[11px] text-gray-400 line-clamp-1">{store.availability}</p>
                    </div>
                    <div className="text-[10px] font-mono text-gray-500 border-t border-white/5 pt-1.5 flex items-center justify-between">
                      <span>{store.version}</span>
                      <span className="text-emerald-400 font-bold">{store.rating}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onClose();
                      if (onOpenDownloadModal) onOpenDownloadModal();
                    }}
                    className="w-full py-2 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 font-bold text-xs uppercase transition-colors cursor-pointer text-center"
                  >
                    {store.linkText}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: QR CODE */}
        {activeTab === 'QR' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="flex justify-center">
              <PhoneQRCode url={officialUrl} size={230} showShareButtons={true} />
            </div>
          </div>
        )}

        {/* Footer info */}
        <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-[11px] font-mono text-gray-400">
          <div>
            Fondateur : <strong>{FOUNDER_INFO.name}</strong> · {FOUNDER_INFO.phone}
          </div>
          <a
            href={FOUNDER_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-amber-400 hover:underline"
          >
            WhatsApp Support →
          </a>
        </div>
      </div>
    </div>
  );
};
