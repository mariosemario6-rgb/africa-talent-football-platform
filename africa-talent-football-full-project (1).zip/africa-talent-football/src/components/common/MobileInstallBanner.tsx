import React, { useState, useEffect } from 'react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { useLanguage } from '../../context/LanguageContext';

interface MobileInstallBannerProps {
  onOpenDownloadModal?: () => void;
}

export const MobileInstallBanner: React.FC<MobileInstallBannerProps> = ({ onOpenDownloadModal }) => {
  const { t } = useLanguage();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [isDismissed, setIsDismissed] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [isAndroidDevice, setIsAndroidDevice] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const ua = window.navigator.userAgent.toLowerCase();
      setIsAndroidDevice(/android/.test(ua));
    }
  }, []);

  // Suppress banner if already running in standalone mode (installed as an app)
  if (isInstalled || isDismissed) return null;

  const handleInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) {
        setIsDismissed(true);
      }
    } else if (isIOS) {
      setShowIOSGuide(true);
    } else if (onOpenDownloadModal) {
      onOpenDownloadModal();
    }
  };

  return (
    <>
      {/* FLOATING SMART INSTALL BANNER */}
      <aside
        aria-label="Installation de l'application"
        className="fixed bottom-3 left-3 right-3 sm:left-auto sm:right-6 sm:max-w-md z-40 bg-[#060A14]/95 backdrop-blur-xl border-2 border-amber-400/80 rounded-2xl p-4 shadow-2xl shadow-black/80 animate-in slide-in-from-bottom duration-300 ring-1 ring-amber-400/30"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            {/* App Icon */}
            <div className="relative w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black text-lg shrink-0 shadow-md shadow-amber-500/30 border border-amber-200">
              <span>ATF</span>
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-[#060A14] animate-pulse" />
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-white text-xs sm:text-sm">
                  {t('installBanner.title')}
                </span>
                <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-mono font-bold">
                  {t('installBanner.freeApp')}
                </span>
              </div>
              <p className="text-[11px] text-gray-300 mt-0.5 line-clamp-1">
                {t('installBanner.subtitle')}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsDismissed(true)}
            className="text-gray-400 hover:text-white p-1 rounded-md hover:bg-white/10 text-xs transition-colors cursor-pointer"
            title={t('installBanner.laterBtn')}
            aria-label={t('modal.close')}
          >
            ✕
          </button>
        </div>

        <div className="mt-3 flex items-center gap-2">
          <button
            onClick={handleInstallClick}
            className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/30 active:scale-95 cursor-pointer border border-amber-200 flex items-center justify-center gap-1.5"
          >
            <span>📲</span>
            <span>
              {t('installBanner.installBtn')}
            </span>
          </button>

          {onOpenDownloadModal && (
            <button
              onClick={onOpenDownloadModal}
              className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase transition-colors cursor-pointer shrink-0"
              title="Stores"
            >
              Stores ▾
            </button>
          )}
        </div>
      </aside>

      {/* IOS SAFARI GUIDED OVERLAY FOR IPHONE & IPAD */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-[#090E1B] border-2 border-blue-400 rounded-2xl max-w-md w-full p-6 space-y-5 shadow-2xl relative">
            <button
              onClick={() => setShowIOSGuide(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white text-lg font-bold cursor-pointer"
            >
              ✕
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-2xl text-white font-black shadow-lg">
                🍏
              </div>
              <div>
                <span className="text-[10px] font-mono text-blue-400 uppercase font-bold tracking-wider">
                  iPhone & iPad (Safari)
                </span>
                <h3 className="font-black text-white text-base">
                  {t('installBanner.title')}
                </h3>
              </div>
            </div>

            <p className="text-xs text-gray-300 leading-relaxed">
              Africa Talent Football PWA Web App iOS :
            </p>

            {/* Steps Visual List */}
            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-[#050810] border border-white/10 flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-blue-500 text-black font-black flex items-center justify-center text-xs shrink-0 mt-0.5">
                  1
                </div>
                <div>
                  <div className="font-bold text-white">Safari Share</div>
                  <p className="text-gray-400 text-[11px] mt-0.5">
                    ⎙ (Share / Partager)
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#050810] border border-white/10 flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-blue-500 text-black font-black flex items-center justify-center text-xs shrink-0 mt-0.5">
                  2
                </div>
                <div>
                  <div className="font-bold text-white">Add to Home Screen</div>
                  <p className="text-gray-400 text-[11px] mt-0.5">
                    ➕ Sur l'écran d'accueil / Add to Home Screen
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#050810] border border-white/10 flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-blue-500 text-black flex items-center justify-center text-xs shrink-0 mt-0.5">
                  3
                </div>
                <div>
                  <div className="font-bold text-white">Add / Ajouter</div>
                  <p className="text-gray-400 text-[11px] mt-0.5">
                    ATF App icon instant install.
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-2 flex gap-2">
              <button
                onClick={() => setShowIOSGuide(false)}
                className="w-full py-2.5 rounded-xl bg-blue-500 hover:bg-blue-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
              >
                {t('modal.close')}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
