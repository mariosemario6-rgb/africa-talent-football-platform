import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNetwork } from '../../context/NetworkContext';
import { usePlayers } from '../../context/PlayerContext';
import { useLanguage } from '../../context/LanguageContext';
import { FOUNDER_INFO } from '../../data/demoData';

interface DirectPlatformContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: string, payload?: any) => void;
  defaultRecipient?: {
    name: string;
    role: string;
    org: string;
    avatar?: string;
  };
}

export const DirectPlatformContactModal: React.FC<DirectPlatformContactModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
  defaultRecipient
}) => {
  const { t } = useLanguage();
  const { currentUser, isPremium, upgradeToPremium, toggleSimulatePremium } = useAuth();
  const { createDirectConversation } = useNetwork();
  const { players } = usePlayers();

  const [activeTab, setActiveTab] = useState<'HOTLINE' | 'TICKET' | 'PREMIUM_MEMBERS'>('HOTLINE');
  const [ticketSubject, setTicketSubject] = useState('AUDIT_TALENT');
  const [ticketMessage, setTicketMessage] = useState('');
  const [selectedPlayerId, setSelectedPlayerId] = useState('');
  const [isSubmittingTicket, setIsSubmittingTicket] = useState(false);
  const [ticketSuccess, setTicketSuccess] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSendTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketMessage.trim()) return;

    setIsSubmittingTicket(true);
    setTimeout(() => {
      const ticketId = `ATF-VIP-${Date.now().toString().slice(-6)}`;
      setTicketSuccess(ticketId);
      setIsSubmittingTicket(false);
      setTicketMessage('');
    }, 900);
  };

  const handleStartDirectConversationWithDesk = () => {
    const convId = createDirectConversation({
      id: 'desk-mario-traore',
      name: FOUNDER_INFO.name,
      title: `${FOUNDER_INFO.officialTitle} · Desk Central`,
      avatar: '/src/assets/images/founder_mario_suit_1792079172729.jpg',
      org: 'Africa Talent Football Direction',
      role: 'SCOUT_AGENT'
    });
    onClose();
    onNavigate('messages');
  };

  const handleDirectWhatsApp = () => {
    const roleText = currentUser ? `en tant que ${currentUser.role} (${currentUser.firstName} ${currentUser.lastName})` : 'visiteur certifié';
    const text = `Bonjour Seydou Mario TRAORÉ,%0A%0AJe vous contacte directement depuis la plateforme Africa Talent Football ${roleText} [Code Membre: ${currentUser?.id || 'GUEST-VIP'}].%0A%0AObjet : Consultation prioritaire technique.`;
    window.open(`https://wa.me/2250544420162?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-[#070B16] border-2 border-amber-500/50 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-[#0C1428] via-[#091022] to-[#0A1830] border-b border-amber-500/30 flex items-start justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-xl shrink-0 shadow-lg shadow-amber-500/20">
              🛡️
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                  Canal Institutionnel
                </span>
                {isPremium ? (
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30 flex items-center gap-1">
                    👑 Accès Premium Débloqué
                  </span>
                ) : (
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400 bg-white/5 px-2 py-0.5 rounded border border-white/10">
                    Adhésion Gratuite Volontaire
                  </span>
                )}
              </div>
              <h2 className="text-lg sm:text-xl font-black text-white mt-1">
                Ligne Directe avec la Plateforme Africa Talent Football
              </h2>
              <p className="text-xs text-gray-300">
                Direction Générale & Supervision : <strong className="text-amber-300">{FOUNDER_INFO.name}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer text-sm"
          >
            ✕
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-white/10 bg-[#040711] text-xs font-mono font-bold">
          <button
            onClick={() => setActiveTab('HOTLINE')}
            className={`flex-1 py-3 px-3 text-center border-b-2 transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'HOTLINE'
                ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <span>📞</span>
            <span>Hotline & WhatsApp VIP</span>
          </button>
          <button
            onClick={() => setActiveTab('TICKET')}
            className={`flex-1 py-3 px-3 text-center border-b-2 transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'TICKET'
                ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <span>✉️</span>
            <span>Ticket Desk B2B</span>
          </button>
          <button
            onClick={() => setActiveTab('PREMIUM_MEMBERS')}
            className={`flex-1 py-3 px-3 text-center border-b-2 transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'PREMIUM_MEMBERS'
                ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <span>👑</span>
            <span>Membres Premium</span>
          </button>
        </div>

        {/* Body content */}
        <div className="p-5 sm:p-6 space-y-5 overflow-y-auto flex-1">
          {/* Voluntary subscription explanation badge */}
          <div className="p-3.5 rounded-2xl bg-[#091122] border border-amber-500/30 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <span className="font-bold text-amber-300 block mb-0.5">
                ℹ️ Principe d'Abonnement Volontaire
              </span>
              <p className="text-[11px] text-gray-300 leading-relaxed">
                L'inscription et l'utilisation de base d'Africa Talent Football (profil, fiches talents, posts sur le fil) sont <strong>100% gratuites</strong>. 
                L'abonnement Premium est entièrement <strong>volontaire</strong> et débloque le contact direct prioritaire avec la direction et les autres membres VIP.
              </p>
            </div>
            <button
              onClick={() => toggleSimulatePremium()}
              className={`shrink-0 px-3 py-1.5 rounded-xl font-mono text-[11px] font-bold uppercase transition-all cursor-pointer shadow-sm ${
                isPremium
                  ? 'bg-emerald-500 text-black hover:bg-emerald-400'
                  : 'bg-amber-500 text-black hover:bg-amber-400'
              }`}
              title="Tester immédiatement le statut Premium"
            >
              {isPremium ? '👑 Premium Actif (Changer)' : '★ Activer Test Premium'}
            </button>
          </div>

          {/* TAB 1: HOTLINE & WHATSAPP VIP */}
          {activeTab === 'HOTLINE' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-[#0A1224] border border-white/10 space-y-3">
                <div className="flex items-center gap-3">
                  <img
                    src="/src/assets/images/founder_mario_suit_1792079172729.jpg"
                    alt={FOUNDER_INFO.name}
                    className="w-14 h-14 rounded-full object-cover border-2 border-amber-400 shadow-md"
                  />
                  <div>
                    <h3 className="font-black text-white text-sm">{FOUNDER_INFO.name}</h3>
                    <p className="text-xs text-amber-400 font-mono">{FOUNDER_INFO.officialTitle}</p>
                    <p className="text-[11px] text-gray-400">Desk Central · Abidjan (RCI) & Partenaires Europe</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono pt-2 border-t border-white/10">
                  <div className="p-2 rounded bg-black/40 border border-white/5">
                    <span className="text-gray-500 block text-[10px]">TÉLÉPHONE DIRECT</span>
                    <span className="text-white font-bold">{FOUNDER_INFO.phone}</span>
                  </div>
                  <div className="p-2 rounded bg-black/40 border border-white/5">
                    <span className="text-gray-500 block text-[10px]">E-MAIL OFFICIEL</span>
                    <span className="text-amber-300 font-bold truncate block">{FOUNDER_INFO.email}</span>
                  </div>
                </div>
              </div>

              {isPremium ? (
                <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/50 space-y-3">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                    <span>👑</span>
                    <span>Vos privilèges Membre Premium sont actifs</span>
                  </div>
                  <p className="text-xs text-gray-300">
                    Vous avez accès à la ligne prioritaire de la direction technique pour organiser des détections, proposer un joueur aux clubs partenaires ou demander un audit personnalisé.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-2.5 pt-1">
                    <button
                      onClick={handleDirectWhatsApp}
                      className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-emerald-900/30"
                    >
                      <span>💬 Lancer WhatsApp VIP Direct</span>
                    </button>
                    <button
                      onClick={handleStartDirectConversationWithDesk}
                      className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-amber-900/30"
                    >
                      <span>💬 Ouvrir Chat Interne B2B</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/40 space-y-3">
                  <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                    <span>★</span>
                    <span>Accès Direct Réservé aux Membres Premium</span>
                  </div>
                  <p className="text-xs text-gray-300">
                    En tant que membre gratuit, vous pouvez publier sur le fil et consulter les données. Pour contacter directement la direction technique de la plateforme et les directeurs sportifs de clubs partenaires, souscrivez à l'abonnement Premium.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-2.5 pt-1">
                    <button
                      onClick={() => upgradeToPremium('SCOUT_PRO')}
                      className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md"
                    >
                      ★ Débloquer le Contact Direct (Premium)
                    </button>
                    <button
                      onClick={() => {
                        onClose();
                        onNavigate('pricing');
                      }}
                      className="py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs transition-colors cursor-pointer"
                    >
                      Voir les Tarifs & Formules
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: TICKET DESK B2B */}
          {activeTab === 'TICKET' && (
            <div className="space-y-4">
              {ticketSuccess ? (
                <div className="p-6 rounded-2xl bg-emerald-950/80 border border-emerald-500 text-center space-y-3">
                  <div className="text-3xl">✓</div>
                  <h3 className="font-black text-white text-base">Ticket Transmis au Desk Central</h3>
                  <p className="text-xs text-emerald-200">
                    Votre demande a été enregistrée avec le numéro de référence :
                  </p>
                  <div className="inline-block px-4 py-1.5 rounded-xl bg-black border border-emerald-500 text-emerald-400 font-mono font-bold text-sm">
                    #{ticketSuccess}
                  </div>
                  <p className="text-[11px] text-gray-400">
                    {isPremium ? 'Délai de traitement garanti : Moins de 2 heures ouvrées.' : 'Délai indicatif de réponse : 24h à 48h.'}
                  </p>
                  <button
                    onClick={() => setTicketSuccess(null)}
                    className="mt-3 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-mono cursor-pointer"
                  >
                    Envoyer une autre demande
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSendTicket} className="space-y-3.5">
                  <div className="space-y-1">
                    <label className="text-xs font-mono font-bold text-gray-300 block">
                      Motif de la sollicitation :
                    </label>
                    <select
                      value={ticketSubject}
                      onChange={(e) => setTicketSubject(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
                    >
                      <option value="AUDIT_TALENT">⚽ Demande d'audit technique d'un joueur</option>
                      <option value="CLUB_INQUIRY">🏟️ Mise en relation avec un club professionnel européen</option>
                      <option value="ACADEMY_PARTNERSHIP">🎓 Convention de détection pour académie</option>
                      <option value="SHOWCASE_INVITE">🏆 Invitation ou accréditation Showcase ATF</option>
                      <option value="FIFA_AGENT_MANDATE">💼 Mandat de représentation ou de transfert</option>
                      <option value="DIRECT_DIRECTOR">👔 Demande d'audience avec Seydou Mario Traoré</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono font-bold text-gray-300 block">
                      Joueur concerné (Optionnel) :
                    </label>
                    <select
                      value={selectedPlayerId}
                      onChange={(e) => setSelectedPlayerId(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#050810] border border-white/10 text-amber-300 text-xs font-mono focus:border-amber-400 outline-none"
                    >
                      <option value="">Aucun joueur joint</option>
                      {players.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.firstName} {p.lastName} ({p.primaryPosition} · {p.marketValueDisplay})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono font-bold text-gray-300 block">
                      Description précise de votre requête :
                    </label>
                    <textarea
                      rows={4}
                      required
                      value={ticketMessage}
                      onChange={(e) => setTicketMessage(e.target.value)}
                      placeholder="Précisez votre demande, vos coordonnées directes et les éléments clés pour le desk..."
                      className="w-full p-3 rounded-xl bg-[#050810] border border-white/10 text-white text-xs placeholder:text-gray-500 focus:border-amber-400 outline-none resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmittingTicket}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer disabled:opacity-50"
                  >
                    {isSubmittingTicket ? 'Transmission en cours...' : 'Transmettre au Desk de Direction ➔'}
                  </button>
                </form>
              )}
            </div>
          )}

          {/* TAB 3: CONTACT AVEC LES MEMBRES PREMIUM */}
          {activeTab === 'PREMIUM_MEMBERS' && (
            <div className="space-y-3">
              <p className="text-xs text-gray-300">
                Les membres Premium bénéficient d'un accès direct et sans restriction pour échanger entre professionnels certifiés (Clubs, Scouts, Directeurs Sportifs, Agents FIFA).
              </p>

              <div className="space-y-2.5">
                {[
                  {
                    name: 'Jean-Luc Moreau',
                    role: 'Scout en Chef Afrique',
                    org: 'Standard de Liège (Belgique)',
                    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
                    badge: 'CLUB PARTENAIRE VIP'
                  },
                  {
                    name: 'Kolo Touré',
                    role: 'Directeur Général',
                    org: 'Académie Mimosas Abidjan',
                    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
                    badge: 'ACADÉMIE AGRÉÉE'
                  },
                  {
                    name: 'Marc Vandenberghe',
                    role: 'Agent FIFA Agréé',
                    org: 'Elite Sports Management',
                    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
                    badge: 'AGENT FIFA PRO'
                  },
                  {
                    name: 'Laurent Duprès',
                    role: 'Responsable Recrutement',
                    org: 'RC Lens (Ligue 1 France)',
                    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150',
                    badge: 'CELLULE PRO'
                  }
                ].map((member, i) => (
                  <div key={i} className="p-3 rounded-2xl bg-[#0A1224] border border-white/10 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <img src={member.avatar} alt={member.name} className="w-10 h-10 rounded-full object-cover border border-amber-400" />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-white text-xs">{member.name}</span>
                          <span className="text-[9px] font-mono font-bold text-amber-400 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/30">
                            {member.badge}
                          </span>
                        </div>
                        <p className="text-[11px] text-gray-300 font-mono">{member.role} · {member.org}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (isPremium) {
                          createDirectConversation({
                            id: `premium-member-${i}`,
                            name: member.name,
                            title: member.role,
                            avatar: member.avatar,
                            org: member.org,
                            role: 'SPORTING_DIRECTOR'
                          });
                          onClose();
                          onNavigate('messages');
                        } else {
                          upgradeToPremium('SCOUT_PRO');
                        }
                      }}
                      className={`px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase transition-all cursor-pointer shrink-0 ${
                        isPremium
                          ? 'bg-amber-500 hover:bg-amber-400 text-black'
                          : 'bg-[#0E172B] hover:bg-amber-500 hover:text-black text-amber-300 border border-amber-500/40'
                      }`}
                    >
                      {isPremium ? '💬 Message Direct' : '★ Débloquer Contact'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#050810] border-t border-white/10 flex items-center justify-between text-xs font-mono">
          <span className="text-gray-400">
            Africa Talent Football · Desk Fondateur Seydou Mario TRAORÉ
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold cursor-pointer"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
