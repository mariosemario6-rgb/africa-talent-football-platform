import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { FOUNDER_INFO } from '../../data/demoData';

interface FooterProps {
  onNavigate: (view: string, payload?: any) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const { t } = useLanguage();

  return (
    <footer className="bg-[#03060D] border-t border-white/10 text-gray-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand & Leadership */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded bg-amber-500 text-black font-black text-xs flex items-center justify-center">
                ATF
              </span>
              <span className="text-base font-black text-white uppercase tracking-tight">
                {t('brand.name')}
              </span>
            </div>
            <p className="text-gray-400 text-xs leading-relaxed">
              {t('footer.description')}
            </p>
            <div className="p-2.5 rounded bg-white/5 border border-amber-500/30 text-[11px] text-amber-300 font-mono">
              <strong className="block text-white font-bold">{FOUNDER_INFO.name}</strong>
              <span>{t('brand.founder')}</span>
            </div>
          </div>

          {/* Quick Navigation */}
          <div className="space-y-2">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider">
              {t('footer.platform')}
            </h4>
            <ul className="space-y-1.5 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  {t('nav.home')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('players')}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  {t('nav.players')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('opportunities')}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  {t('nav.opportunities')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('founder')}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  {t('nav.founder')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('register')}
                  className="text-amber-400 hover:underline transition-colors text-left font-bold"
                >
                  + {t('nav.register')}
                </button>
              </li>
            </ul>
          </div>

          {/* Direct Desk Contacts */}
          <div className="space-y-2">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider">
              {t('footer.scoutingDesk')}
            </h4>
            <div className="space-y-1.5 text-xs text-gray-300">
              <div>
                <span className="text-gray-500 block text-[11px]">Directeur Fondateur :</span>
                <span className="font-semibold text-white">{FOUNDER_INFO.name}</span>
                <span className="block text-[10px] text-amber-400">Scout Agent Agréé</span>
              </div>
              <div>
                <span className="text-gray-500 block text-[11px]">WhatsApp & Appel Direct :</span>
                <a
                  href={FOUNDER_INFO.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-amber-400 font-mono font-bold hover:underline"
                >
                  {FOUNDER_INFO.phone}
                </a>
              </div>
              <div>
                <span className="text-gray-500 block text-[11px]">Courriel Officiel :</span>
                <a
                  href={`mailto:${FOUNDER_INFO.email}`}
                  className="text-gray-300 hover:text-amber-400 font-mono"
                >
                  {FOUNDER_INFO.email}
                </a>
              </div>
              <div>
                <span className="text-gray-500 block text-[11px]">Siège des Opérations :</span>
                <span>Abidjan, République de Côte d'Ivoire</span>
              </div>
            </div>
          </div>

          {/* Compliance & FIFA Ethics */}
          <div className="space-y-2 md:col-span-1">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider">
              {t('footer.fifaEthics')}
            </h4>
            <p className="text-[11px] text-gray-400 leading-relaxed">
              {t('footer.fifaEthicsDesc')}
            </p>
            <div className="pt-2 text-[10px] text-emerald-400 font-semibold flex items-center gap-1.5">
              <span>🛡️ Protocole validé par Seydou Mario TRAORÉ</span>
            </div>
          </div>
        </div>

        {/* Official App Download Platforms Bar */}
        <div className="my-8 p-4 sm:p-5 rounded-2xl bg-[#070B16] border border-amber-500/30 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2">
              <span className="text-emerald-400 font-bold text-xs">📲 {t('footer.appAvailable')}</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 font-bold">
                Google Play · iOS · APK · Windows
              </span>
            </div>
            <p className="text-[11px] text-gray-400">
              {t('footer.appDesc')}
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2">
            <button
              onClick={() => onNavigate('download')}
              className="px-3 py-1.5 rounded-lg bg-black hover:bg-white/10 border border-white/15 text-white text-xs font-mono font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>▶️</span>
              <span>Google Play</span>
            </button>
            <button
              onClick={() => onNavigate('download')}
              className="px-3 py-1.5 rounded-lg bg-black hover:bg-white/10 border border-white/15 text-white text-xs font-mono font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>🍎</span>
              <span>App Store</span>
            </button>
            <button
              onClick={() => onNavigate('download')}
              className="px-3 py-1.5 rounded-lg bg-black hover:bg-white/10 border border-white/15 text-white text-xs font-mono font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>🌌</span>
              <span>Galaxy Store</span>
            </button>
            <button
              onClick={() => onNavigate('download')}
              className="px-3 py-1.5 rounded-lg bg-black hover:bg-white/10 border border-white/15 text-white text-xs font-mono font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>🔴</span>
              <span>AppGallery</span>
            </button>
            <button
              onClick={() => onNavigate('download')}
              className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-mono font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>📦</span>
              <span>APK Direct</span>
            </button>
            <button
              onClick={() => onNavigate('download')}
              className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 border border-white/15 text-white text-xs font-mono font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>💻</span>
              <span>PC Windows</span>
            </button>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-[11px] text-gray-500 gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="font-mono text-gray-300 font-bold">Africa Talent Football</span>
            <span>· © {new Date().getFullYear()} Africa Talent Football. Tous droits réservés.</span>
          </div>
          <div className="flex items-center space-x-3 font-mono text-[10px] text-gray-400">
            <span>DIR: SEYDOU MARIO TRAORÉ</span>
            <span>·</span>
            <span>SCOUT AGENT & DIRECTEUR</span>
            <span>·</span>
            <span className="text-emerald-400">EN LIGNE MONDIALEMENT</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
