import React from 'react';

export const PageSkeleton: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-pulse">
      {/* Top Banner Skeleton */}
      <div className="h-44 rounded-3xl bg-gradient-to-r from-[#070D1B] via-[#0C152B] to-[#070D1B] border border-white/5 relative overflow-hidden">
        <div className="p-6 space-y-3">
          <div className="h-4 w-32 bg-amber-500/20 rounded-md" />
          <div className="h-7 w-64 bg-white/10 rounded-lg" />
          <div className="h-3.5 w-96 max-w-full bg-white/5 rounded-md" />
        </div>
      </div>

      {/* Grid Cards Skeleton */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div
            key={i}
            className="h-72 rounded-2xl bg-[#090E1B] border border-white/5 p-5 space-y-4 flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="h-32 rounded-xl bg-black/40" />
              <div className="h-4 w-3/4 bg-white/10 rounded" />
              <div className="h-3 w-1/2 bg-white/5 rounded" />
            </div>
            <div className="h-8 rounded-lg bg-amber-500/10 border border-amber-500/20" />
          </div>
        ))}
      </div>
    </div>
  );
};
