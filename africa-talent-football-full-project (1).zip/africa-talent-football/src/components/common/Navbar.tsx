import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { usePlayers } from '../../context/PlayerContext';
import { useNetwork } from '../../context/NetworkContext';
import { usePayment } from '../../context/PaymentContext';
import { useLanguage } from '../../context/LanguageContext';
import { usePushNotifications } from '../../context/PushNotificationContext';
import { formatMarketValue, FOUNDER_INFO } from '../../data/demoData';
import { NavigationDrawer } from './NavigationDrawer';
import { TenLanguagesBar } from './TenLanguagesBar';

interface NavbarProps {
  onNavigate: (view: string, payload?: any) => void;
  activeView: string;
  onOpenSearch?: () => void;
  onOpenSharePlatform?: () => void;
  onOpenDownloadApp?: () => void;
  onOpenDomainModal?: () => void;
  onOpenFavorites?: () => void;
  onOpenComparison?: () => void;
  onOpenValuationModal?: () => void;
  isMenuDrawerOpen?: boolean;
  setIsMenuDrawerOpen?: (open: boolean) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onNavigate,
  activeView,
  onOpenSearch,
  onOpenSharePlatform,
  onOpenDownloadApp,
  onOpenDomainModal,
  onOpenFavorites,
  onOpenComparison,
  onOpenValuationModal,
  isMenuDrawerOpen,
  setIsMenuDrawerOpen,
}) => {
  const { currentUser, logout, isPremium } = useAuth();
  const { totalMarketValue, favorites, comparisonIds, setIsFavoritesModalOpen, setIsComparisonModalOpen } = usePlayers();
  const { totalUnreadCount } = useNetwork();
  const { activeSubscription } = usePayment();
  const { t } = useLanguage();
  const { unreadAlertsCount, setIsMercatoModalOpen, setIsPushSettingsModalOpen } = usePushNotifications();

  const handleOpenFavorites = onOpenFavorites || (() => setIsFavoritesModalOpen(true));
  const handleOpenComparison = onOpenComparison || (() => setIsComparisonModalOpen(true));

  const [internalDrawerOpen, setInternalDrawerOpen] = useState(false);
  const menuDrawerOpen = isMenuDrawerOpen !== undefined ? isMenuDrawerOpen : internalDrawerOpen;
  const setMenuDrawerOpen = setIsMenuDrawerOpen || setInternalDrawerOpen;

  // Fully localized visible navigation links
  const navLinks = [
    { id: 'directory', label: t('nav.directory'), icon: '🏢' },
    { id: 'matches', label: '📅 Matchs & Actus', icon: '📅' },
    { id: 'players', label: t('nav.players'), icon: '📹' },
    { id: 'dashboard', label: t('nav.dashboards'), icon: '📊' },
    { id: 'feed', label: t('nav.feed'), icon: '📰' },
    { id: 'opportunities', label: t('nav.opportunities'), icon: '🏆' },
    { id: 'messages', label: t('nav.messages'), icon: '💬', badge: totalUnreadCount },
    { id: 'pricing', label: t('nav.pricing'), icon: '💎' },
    { id: 'founder', label: t('nav.founder'), icon: '👤' },
    { id: 'register', label: t('nav.register'), icon: '📝' },
    { id: 'download', label: '📲 App', icon: '📲' },
  ];

  const isFounderUser = currentUser?.email === 'mariosemario6@gmail.com' || currentUser?.id === 'user-scout-01';
  const customFounderPhoto = typeof window !== 'undefined' ? localStorage.getItem('atf_founder_custom_photo') : null;
  const userDisplayAvatar = currentUser?.avatarUrl || (isFounderUser ? (customFounderPhoto || '/founder_africa_talent.jpg') : '');

  return (
    <header className="sticky top-0 z-40 bg-[#040711]/95 backdrop-blur-md border-b border-white/10">
      {/* Top micro ticker */}
      <div className="hidden lg:flex items-center justify-between px-6 py-1 bg-black/85 border-b border-amber-500/20 text-[10px] text-gray-400 font-mono">
        <div className="flex items-center gap-4">
          <button
            onClick={onOpenDomainModal || onOpenSharePlatform}
            className="text-amber-400 hover:text-amber-300 font-bold tracking-wider flex items-center gap-1.5 cursor-pointer bg-amber-500/10 px-2.5 py-0.5 rounded border border-amber-500/30 hover:border-amber-400 transition-all"
            title="Consulter le certificat officiel de déploiement et domaine en ligne"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>⚡ {t('common.officialPlatformBadge', 'AFRICA TALENT FOOTBALL · PLATEFORME OFFICIELLE EN LIGNE')}</span>
          </button>
          <span className="text-gray-600">|</span>
          <span className="text-gray-300">DIR. SEYDOU MARIO TRAORÉ</span>
          <span className="text-gray-600">|</span>
          <span className="text-emerald-400 font-bold">190+ PAYS DISPONIBLE</span>
        </div>
        <div className="flex items-center gap-4">
          {onOpenValuationModal && (
            <button
              onClick={onOpenValuationModal}
              className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 cursor-pointer transition-colors bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30"
              title={t('common.valuationCalculator', 'Cotation & Stats')}
            >
              <span>📈</span>
              <span>{t('common.valuationCalculator', 'Cotation & Stats')}</span>
            </button>
          )}
          {onOpenDownloadApp && (
            <button
              onClick={onOpenDownloadApp}
              className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 cursor-pointer transition-colors"
            >
              <span>📲 Télécharger l'App (Play Store & iOS)</span>
            </button>
          )}
          {onOpenSharePlatform && (
            <button
              onClick={onOpenSharePlatform}
              className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 cursor-pointer transition-colors"
            >
              <span>🔗 Partager la Plateforme</span>
            </button>
          )}
          <span className="text-gray-600">|</span>
          <button
            onClick={() => onNavigate('pricing')}
            className="text-amber-300 hover:text-amber-200 font-bold flex items-center gap-1 cursor-pointer"
          >
            <span>💎 Profil Premium Pro</span>
          </button>
          <span className="text-gray-600">|</span>
          <span className="text-gray-400">
            Cote Cumulée : <strong className="text-emerald-400 font-bold">{formatMarketValue(totalMarketValue)}</strong>
          </span>
          <span className="text-gray-600">|</span>
          <a
            href={FOUNDER_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-300 hover:text-amber-400"
          >
            Desk : {FOUNDER_INFO.phone}
          </a>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between min-h-[4.75rem] py-2 gap-4">
          {/* ZONE 1: Brand Wordmark */}
          <button
            onClick={() => onNavigate('home')}
            className="text-left group cursor-pointer flex items-center gap-2.5 shrink-0"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black text-xs shadow-md shadow-amber-500/20">
              ATF
            </div>
            <div>
              <span className="text-sm sm:text-base font-black tracking-tight text-white uppercase group-hover:text-amber-400 transition-colors block leading-none">
                Africa Talent Football
              </span>
              <span className="text-[9px] font-mono tracking-widest text-amber-400/90 block mt-0.5">
                LINKEDIN & EYEBALL PRO
              </span>
            </div>
          </button>

          {/* ZONE 2: 10 WORLD LANGUAGES + THREE MENU BARS COMBO (Replaced the search engine) */}
          <div className="flex items-center gap-2.5">
            {/* The Ten World Languages Bar */}
            <TenLanguagesBar />

            {/* THREE MENU BARS - POSITIONED NEXT TO THE 10 LANGUAGES */}
            <button
              onClick={() => setMenuDrawerOpen(true)}
              className="text-xs font-black px-3 sm:px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black border-2 border-amber-200 shadow-md shadow-amber-500/30 transition-all flex items-center gap-2 cursor-pointer shrink-0 active:scale-95 group"
              title="Ouvrir le Menu (Annuaire Mondial des Clubs, Vidéothèque, etc.)"
              aria-label="Menu principal à 3 barres"
            >
              {/* 3 horizontal black stripes */}
              <div className="flex flex-col justify-center items-center gap-1 w-4 h-3.5 shrink-0">
                <span className="block h-0.5 w-4 bg-black rounded-full" />
                <span className="block h-0.5 w-4 bg-black rounded-full" />
                <span className="block h-0.5 w-4 bg-black rounded-full" />
              </div>
              <span className="font-black uppercase tracking-wider text-[11px] sm:text-xs text-black">
                {t('nav.menu')}
              </span>
            </button>
          </div>

          {/* ZONE 3: ACTIONS GROUP (Mercato + Push + Favorites + Compare + Share Platform + App Install + Premium / Profile) */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
            {/* Live Mercato Alerts Button */}
            <button
              onClick={() => setIsMercatoModalOpen(true)}
              className="relative text-xs font-black px-2.5 sm:px-3 py-1.5 rounded-lg bg-gradient-to-r from-red-600/30 via-red-500/20 to-amber-500/30 hover:from-red-600/40 hover:to-amber-500/40 text-red-300 border border-red-500/60 hover:border-red-400 transition-all cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95 group"
              title="Alertes Mercato en Direct & Opportunités Flash"
              aria-label="Alertes Mercato"
            >
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping shrink-0" />
              <span className="text-sm">🚨</span>
              <span className="hidden sm:inline font-black tracking-wide">Mercato</span>
              {unreadAlertsCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-red-500 text-white text-[10px] font-black font-mono">
                  {unreadAlertsCount}
                </span>
              )}
            </button>

            {/* Push Notifications Settings Button */}
            <button
              onClick={() => setIsPushSettingsModalOpen(true)}
              className="relative text-xs font-bold p-1.5 sm:px-2 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-amber-400 hover:text-amber-300 border border-white/10 transition-all cursor-pointer flex items-center gap-1 shadow-sm active:scale-95"
              title="Centre des Notifications Push"
              aria-label="Centre des notifications push"
            >
              <span className="text-sm">🔔</span>
              <span className="hidden lg:inline text-[11px] text-gray-300 font-mono">Push</span>
            </button>

            {/* Favorites / Shortlist Button */}
            <button
              onClick={handleOpenFavorites}
              className={`relative text-xs font-bold px-2 sm:px-2.5 py-1.5 rounded-lg border transition-all cursor-pointer flex items-center gap-1 shadow-sm active:scale-95 ${
                favorites.length > 0
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/60 hover:bg-amber-500/30'
                  : 'bg-white/5 text-gray-300 border-white/10 hover:bg-white/10'
              }`}
              title="Mes Talents Favoris & Shortlist"
              aria-label="Favoris et Shortlist"
            >
              <span className="text-amber-400">★</span>
              <span className="hidden sm:inline font-bold">Shortlist</span>
              {favorites.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-black text-[10px] font-black font-mono">
                  {favorites.length}
                </span>
              )}
            </button>

            {/* Talent Comparison Button */}
            <button
              onClick={handleOpenComparison}
              className={`relative text-xs font-bold px-2 sm:px-2.5 py-1.5 rounded-lg border transition-all cursor-pointer flex items-center gap-1 shadow-sm active:scale-95 ${
                comparisonIds.length > 0
                  ? 'bg-purple-600/25 text-purple-300 border-purple-500/60 hover:bg-purple-600/35'
                  : 'bg-white/5 text-gray-400 border-white/10 hover:bg-white/10'
              }`}
              title="Comparateur de Talents & Face-à-Face Radar"
              aria-label="Comparateur de talents"
            >
              <span className="text-sm">⇄</span>
              <span className="hidden md:inline font-bold">Face-à-Face</span>
              {comparisonIds.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-purple-500 text-white text-[10px] font-black font-mono">
                  {comparisonIds.length}
                </span>
              )}
            </button>

            {/* 1. Share Platform Button */}
            {onOpenSharePlatform && (
              <button
                onClick={onOpenSharePlatform}
                className="text-xs font-bold px-2.5 sm:px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:border-amber-400 transition-all cursor-pointer flex items-center gap-1.5 shadow-sm"
                title="Partager la Plateforme en Ligne"
                aria-label="Partager la plateforme"
              >
                <span className="text-sm">🔗</span>
                <span className="hidden sm:inline font-bold">{t('nav.share')}</span>
              </button>
            )}

            {/* 2. Download App & Phone Install Button */}
            {onOpenDownloadApp && (
              <button
                onClick={onOpenDownloadApp}
                className="text-xs font-black px-2.5 sm:px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500/20 via-emerald-400/20 to-emerald-500/20 hover:from-emerald-500/30 hover:to-emerald-400/30 text-emerald-300 border border-emerald-500/50 hover:border-emerald-300 transition-all cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95"
                title="Installer sur Téléphone (Play Store, iPhone Safari, APK)"
                aria-label="Installer sur mon téléphone"
              >
                <span className="text-sm">📲</span>
                <span className="font-bold tracking-tight">Installer App</span>
              </button>
            )}

            {/* Desktop / Tablet actions: Premium upgrade & Profile */}
            <div className="hidden lg:flex items-center gap-2 pl-1 border-l border-white/10">
              {isPremium ? (
                <button
                  onClick={() => onNavigate('pricing')}
                  className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-amber-500/20 to-amber-600/20 border border-amber-400 text-amber-300 text-[10px] font-mono font-bold flex items-center gap-1 cursor-pointer hover:border-amber-300"
                  title="Abonnement Premium Actif (Gérer)"
                >
                  <span>👑 VIP ACTIF</span>
                </button>
              ) : (
                <button
                  onClick={() => onNavigate('pricing')}
                  className="text-xs font-black uppercase bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black px-3 py-1.5 rounded transition-all shadow-sm shadow-amber-500/20 cursor-pointer flex items-center gap-1"
                >
                  <span>★ Premium</span>
                </button>
              )}

              {currentUser ? (
                <div className="flex items-center space-x-1.5">
                  <button
                    onClick={() => onNavigate('profile')}
                    className={`text-xs font-bold px-2.5 py-1.5 rounded transition-all flex items-center gap-1.5 cursor-pointer ${
                      activeView === 'profile'
                        ? 'bg-amber-500 text-black font-black'
                        : 'bg-[#0E1527] border border-amber-500/40 text-amber-300 hover:bg-amber-500/20'
                    }`}
                    title="Consulter et modifier mon compte & profil"
                  >
                    {userDisplayAvatar ? (
                      <img
                        src={userDisplayAvatar}
                        alt={currentUser.firstName}
                        className="w-5 h-5 rounded-full object-cover object-[50%_20%] border border-amber-400"
                        onError={(e) => {
                          const target = e.currentTarget;
                          target.style.display = 'none';
                        }}
                      />
                    ) : (
                      <span>👤</span>
                    )}
                    <span className="max-w-[100px] truncate">{currentUser.firstName}</span>
                  </button>
                  <button
                    onClick={() => onNavigate('feed')}
                    className={`text-xs font-bold px-2 py-1.5 rounded transition-colors cursor-pointer ${
                      activeView === 'feed'
                        ? 'bg-white text-black'
                        : 'bg-white/5 border border-white/10 text-gray-200 hover:bg-white/10'
                    }`}
                    title="Ouvrir le fil réseau & mes posts"
                  >
                    Fil
                  </button>
                  <button
                    onClick={() => {
                      logout();
                      onNavigate('home');
                    }}
                    className="text-xs text-gray-400 hover:text-red-400 p-1.5 rounded hover:bg-white/5 cursor-pointer"
                    title="Déconnexion"
                  >
                    ✕
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => onNavigate('login')}
                    className="text-xs font-bold text-gray-200 hover:text-white px-2.5 py-1.5 rounded bg-[#0E1527] border border-white/10 hover:border-amber-400/50 transition-colors cursor-pointer"
                  >
                    {t('nav.login')}
                  </button>
                  <button
                    onClick={() => onNavigate('register')}
                    className="text-xs font-bold text-black px-2.5 py-1.5 rounded bg-amber-500 hover:bg-amber-400 transition-colors cursor-pointer shadow-sm"
                  >
                    Inscription
                  </button>
                </div>
              )}
            </div>

            {/* Mobile quick actions (Profile & Messages badge) */}
            <div className="flex lg:hidden items-center gap-1.5 pl-1 border-l border-white/10">
              {currentUser ? (
                <button
                  onClick={() => onNavigate('profile')}
                  className={`p-1 rounded-lg text-xs font-bold flex items-center justify-center cursor-pointer transition-colors ${
                    activeView === 'profile' ? 'bg-amber-500 text-black' : 'bg-white/10 text-amber-300 border border-amber-500/30'
                  }`}
                  title="Mon Profil & Compte"
                >
                  {userDisplayAvatar ? (
                    <img
                      src={userDisplayAvatar}
                      alt={currentUser.firstName}
                      className="w-6 h-6 rounded-full object-cover object-[50%_20%] border border-amber-400"
                      onError={(e) => {
                        const target = e.currentTarget;
                        target.style.display = 'none';
                      }}
                    />
                  ) : (
                    <span className="p-0.5">👤</span>
                  )}
                </button>
              ) : (
                <button
                  onClick={() => onNavigate('login')}
                  className="px-2 py-1 rounded bg-amber-500 text-black text-[11px] font-bold"
                >
                  Connexion
                </button>
              )}
              <button
                onClick={() => onNavigate('messages')}
                className="relative p-1.5 text-gray-300 hover:text-white text-sm cursor-pointer"
                title="Messagerie"
              >
                💬
                {totalUnreadCount > 0 && (
                  <span className="absolute top-0 right-0 w-3.5 h-3.5 rounded-full bg-red-600 text-white text-[8px] font-bold flex items-center justify-center font-mono">
                    {totalUnreadCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ZONE 4: ALWAYS-VISIBLE PRIMARY NAVIGATION MENU BAR (Visible on all devices) */}
      <nav className="bg-[#050812]/95 border-t border-white/10 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-2 overflow-x-auto scrollbar-none gap-1 sm:gap-2">
            <div className="flex items-center gap-1 sm:gap-2 shrink-0">
              {navLinks.map((link) => {
                const isActive = activeView === link.id;
                return (
                  <button
                    key={link.id}
                    onClick={() => onNavigate(link.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer shrink-0 ${
                      isActive
                        ? 'bg-amber-500 text-black shadow-md shadow-amber-500/25 font-black'
                        : 'text-gray-300 hover:text-white hover:bg-white/5 border border-transparent hover:border-white/10'
                    }`}
                  >
                    <span className="text-sm">{link.icon}</span>
                    <span>{link.label}</span>
                    {link.badge !== undefined && link.badge > 0 && (
                      <span
                        className={`px-1.5 py-0.2 rounded-full text-[9px] font-mono font-bold ${
                          isActive ? 'bg-black text-amber-400' : 'bg-red-600 text-white'
                        }`}
                      >
                        {link.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Quick status & Register button on wide screens */}
            <div className="hidden lg:flex items-center gap-3 shrink-0 pl-3 border-l border-white/10 text-xs font-mono">
              <button
                onClick={() => onNavigate('register')}
                className="px-2.5 py-1 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-bold uppercase transition-colors cursor-pointer"
              >
                + {t('nav.register')}
              </button>
              <span className="text-gray-500">|</span>
              <span className="text-emerald-400 font-bold text-[11px]">
                ● {formatMarketValue(totalMarketValue)}
              </span>
            </div>
          </div>
        </div>
      </nav>

      {/* Complete Expert Navigation Drawer with all platform sections */}
      <NavigationDrawer
        isOpen={menuDrawerOpen}
        onClose={() => setMenuDrawerOpen(false)}
        onNavigate={onNavigate}
        activeView={activeView}
        onOpenSharePlatform={onOpenSharePlatform}
        onOpenSearch={onOpenSearch}
        onOpenDownloadApp={onOpenDownloadApp}
      />
    </header>
  );
};
