import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { usePlayers } from '../../context/PlayerContext';
import { useNetwork } from '../../context/NetworkContext';
import { usePayment } from '../../context/PaymentContext';
import { useLanguage } from '../../context/LanguageContext';
import { usePushNotifications } from '../../context/PushNotificationContext';
import { formatMarketValue, FOUNDER_INFO } from '../../data/demoData';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: string, payload?: any) => void;
  activeView: string;
  onOpenSharePlatform?: () => void;
  onOpenSearch?: () => void;
  onOpenDownloadApp?: () => void;
  onOpenValuationModal?: () => void;
}

interface NavigationDrawerItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  hot?: boolean;
  count?: string;
  tag?: string;
  unreadBadge?: number;
  payload?: any;
}

interface NavigationDrawerSection {
  category: string;
  badge: string;
  badgeColor: string;
  items: NavigationDrawerItem[];
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  onNavigate,
  activeView,
  onOpenSharePlatform,
  onOpenDownloadApp,
  onOpenValuationModal,
}) => {
  const { currentUser, loginAsDemoRole, logout } = useAuth();
  const { players, totalMarketValue, favorites, comparisonIds, setIsFavoritesModalOpen, setIsComparisonModalOpen } = usePlayers();
  const { totalUnreadCount, globalSearch, setGlobalSearch } = useNetwork();
  const { activeSubscription } = usePayment();
  const { language, setLanguage, languages } = useLanguage();
  const { unreadAlertsCount, setIsMercatoModalOpen, setIsPushSettingsModalOpen } = usePushNotifications();
  const [localSearch, setLocalSearch] = useState(globalSearch);

  const isFounderUser = currentUser?.email === 'mariosemario6@gmail.com' || currentUser?.id === 'user-scout-01';
  const customFounderPhoto = typeof window !== 'undefined' ? localStorage.getItem('atf_founder_custom_photo') : null;
  const userDisplayAvatar = currentUser?.avatarUrl || (isFounderUser ? (customFounderPhoto || '/founder_africa_talent.jpg') : '');

  // Synchronize local search state
  useEffect(() => {
    setLocalSearch(globalSearch);
  }, [globalSearch]);

  // Lock body scroll when menu is open & listen for Escape key
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') onClose();
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = '';
        window.removeEventListener('keydown', handleKeyDown);
      };
    } else {
      document.body.style.overflow = '';
    }
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setGlobalSearch(localSearch);
    onClose();
    onNavigate('search');
  };

  const handleLinkClick = (viewId: string, payload?: any) => {
    if (viewId === 'valuation_calculator') {
      if (onOpenValuationModal) onOpenValuationModal();
      onClose();
      return;
    }
    if (viewId === 'favorites') {
      setIsFavoritesModalOpen(true);
      onClose();
      return;
    }
    if (viewId === 'compare') {
      setIsComparisonModalOpen(true);
      onClose();
      return;
    }
    if (viewId === 'mercato') {
      setIsMercatoModalOpen(true);
      onClose();
      return;
    }
    if (viewId === 'push_settings') {
      setIsPushSettingsModalOpen(true);
      onClose();
      return;
    }
    onNavigate(viewId, payload);
    onClose();
  };

  const SECTIONS: NavigationDrawerSection[] = [
    {
      category: '1. Annuaire Mondial & Détection Talents',
      badge: 'Clubs & Scouting',
      badgeColor: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
      items: [
        {
          id: 'mercato',
          title: 'Alertes Mercato & Direct Transferts',
          description: 'Opportunités flash, offres d’essais en Europe et détections exclusives en direct',
          icon: '🚨',
          hot: true,
          tag: 'Live Mercato',
          unreadBadge: unreadAlertsCount,
        },
        {
          id: 'push_settings',
          title: 'Notifications Push & Alertes Smartphone',
          description: 'Activer les alertes sur votre téléphone portable Android, iPhone ou ordinateur',
          icon: '🔔',
          tag: 'Push Direct',
        },
        {
          id: 'feed',
          title: 'Fil Réseau & Posts (LinkedIn Football)',
          description: 'Publier des posts, partager vos vidéos de match, rapports scouting et échanger avec les clubs',
          icon: '📰',
          hot: true,
          tag: 'Feed & Posts',
        },
        {
          id: 'profile',
          title: 'Mon Compte & Profil Professionnel',
          description: 'Consulter et modifier mes informations, gérer mon statut d’adhésion (Gratuit / Premium)',
          icon: '👤',
          tag: 'Mon Compte',
        },
        {
          id: 'directory',
          title: 'Annuaire Mondial des Clubs & Dirigeants',
          description: 'Standard de Liège, RC Lens, Chelsea FC, Brighton, clubs africains et directeurs sportifs',
          icon: '🏢',
          hot: true,
          tag: 'World Directory',
        },
        {
          id: 'matches',
          title: 'Calendriers des Matchs & Actualités Mondiales',
          description: 'Scores en direct, diffusions TV, filtres par continent (CAF, UEFA, CONMEBOL, AFC...) et flux d’actualités',
          icon: '📅',
          hot: true,
          tag: '6 Continents',
        },
        {
          id: 'favorites',
          title: 'Mes Talents Favoris & Shortlist',
          description: 'Votre sélection privée de pépites suivies, valorisation totale et export WhatsApp direct',
          icon: '★',
          count: `${favorites.length} favoris`,
          tag: 'Shortlist',
        },
        {
          id: 'compare',
          title: 'Comparateur de Talents & Radar Face-à-Face',
          description: 'Confrontation directe 2 à 3 joueurs, statistiques GPS, cotes et graphiques radar superposés',
          icon: '⇄',
          count: `${comparisonIds.length} prêts`,
          tag: 'Face-à-Face',
        },
        {
          id: 'search',
          title: 'Moteur de Recherche Global',
          description: 'Recherche universelle des clubs, directeurs, coachs et talents avec filtres multicritères',
          icon: '🔍',
          tag: 'Recherche 360°',
        },
        {
          id: 'players',
          title: 'Vidéothèque & Profils Talents',
          description: 'Vidéos de match 90 min, radars athlétiques, fiches de jeu et cotes marchandes',
          icon: '📹',
          count: `${players.length} joueurs`,
        },
        {
          id: 'opportunities',
          title: 'Détections & Tournois d\'Essai',
          description: 'Calendrier officiel des journées de détection, showcases et stages supervisés',
          icon: '🏆',
          tag: 'Calendrier 2026',
        },
        {
          id: 'register',
          title: 'Enregistrer un Joueur',
          description: 'Formulaire officiel pour soumettre la fiche d\'un talent, ses stats et ses vidéos',
          icon: '📝',
          tag: '+ Inscription',
        },
        {
          id: 'valuation_calculator',
          title: 'Simulateur Cotation & Statistiques',
          description: 'Moteur algorithmique certifié ATF : valeur marchande de transfert et statistiques complètes',
          icon: '📈',
          hot: true,
          tag: 'Calculateur ATF',
        },
      ],
    },
    {
      category: '2. Tableaux de Bord Professionnels (9 Métiers)',
      badge: 'Hub Métiers Football',
      badgeColor: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
      items: [
        {
          id: 'dashboard',
          payload: { role: 'CLUB_PRO' },
          title: 'Tableau de Bord Clubs Professionnels',
          description: 'Effectif pro, budget mercato, besoins prioritaires et convocations d\'essais',
          icon: '🏟️',
          tag: 'Club Pro',
          hot: true,
        },
        {
          id: 'dashboard',
          payload: { role: 'PLAYER' },
          title: 'Tableau de Bord Joueurs & Talents',
          description: 'Fiche athlète certifiée, vidéos de match 90 min, radar athlétique et cotes',
          icon: '⚽',
          tag: 'Athlète',
        },
        {
          id: 'dashboard',
          payload: { role: 'ACADEMY' },
          title: 'Tableau de Bord Académies & Centres',
          description: 'Gestion des effectifs U15-U21, convention de formation & passeport FIFA',
          icon: '🎓',
          tag: 'Formation',
        },
        {
          id: 'dashboard',
          payload: { role: 'COACH' },
          title: 'Tableau de Bord Entraîneurs & Staff',
          description: 'Schémas tactiques 4-3-3, analyse vidéo des séquences & fiches d\'entraînement',
          icon: '📋',
          tag: 'Tactique',
        },
        {
          id: 'dashboard',
          payload: { role: 'SCOUT' },
          title: 'Tableau de Bord Scouts & Superviseurs',
          description: 'Rapports d\'audit certifiés Eyeball, radar GPS, vitesse de pointe & missions',
          icon: '🔍',
          tag: 'Scouting',
        },
        {
          id: 'dashboard',
          payload: { role: 'SPORTING_DIRECTOR' },
          title: 'Tableau de Bord Directeurs Sportifs',
          description: 'Valorisation d\'effectif, matrice de doublure & balance financière mercato',
          icon: '👔',
          tag: 'Dir. Sportif',
        },
        {
          id: 'dashboard',
          payload: { role: 'FIFA_AGENT' },
          title: 'Tableau de Bord Agents FIFA Licenciés',
          description: 'Portefeuille de mandats officiels, sollicitations clubs et règlements FFAR',
          icon: '💼',
          tag: 'Agent FIFA',
        },
        {
          id: 'dashboard',
          payload: { role: 'PRESIDENT' },
          title: 'Tableau de Bord Présidents de Club',
          description: 'Cockpit de décision institutionnelle, valorisation du club & accords bilatéraux',
          icon: '🏛️',
          tag: 'Gouvernance',
        },
        {
          id: 'dashboard',
          payload: { role: 'RECRUITMENT_MANAGER' },
          title: 'Tableau de Bord Responsables Recrutement',
          description: 'Pipeline de recrutement Kanban, délégation de missions terrain et validation',
          icon: '🎯',
          tag: 'Recrutement',
        },
      ],
    },
    {
      category: '3. Réseau Professionnel B2B & Mercato',
      badge: 'B2B LinkedIn Style',
      badgeColor: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
      items: [
        {
          id: 'feed',
          title: 'Fil d\'Actualité Réseau',
          description: 'Annonces officielles, mercato, publications des dirigeants et actualités des académies',
          icon: '📰',
          tag: 'Direct',
        },
        {
          id: 'messages',
          title: 'Messagerie Directe Sécurisée',
          description: 'Canaux d\'échanges confidentiels entre clubs, directeurs sportifs et agents',
          icon: '💬',
          unreadBadge: totalUnreadCount,
        },
      ],
    },
    {
      category: '4. Direction Technique & Monétisation',
      badge: 'Institutionnel & Pro',
      badgeColor: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
      items: [
        {
          id: 'founder',
          title: 'Direction Technique & Fondateur',
          description: 'Supervision officielle par Seydou Mario TRAORÉ, Scout Agent & Directeur Fondateur',
          icon: '👤',
          tag: 'Mario TRAORÉ',
        },
        {
          id: 'pricing',
          title: 'Abonnements & Tarifs Pro',
          description: 'Formules Découverte, Scout Pro et Club Elite avec paiement international sécurisé',
          icon: '💎',
          tag: 'Tarifs Pro',
        },
        {
          id: 'download',
          title: 'Télécharger l\'Application (Tous les Stores Mondiaux)',
          description: 'Application officielle pour Android, iOS, Samsung Galaxy, Huawei, APK direct et Windows',
          icon: '📲',
          hot: true,
          tag: '190+ Pays',
        },
        {
          id: 'dashboard',
          title: 'Tableau de Bord Professionnel (Vue Hub)',
          description: 'Espace de veille personnalisée, gestion de votre abonnement et sélection prioritaire',
          icon: '📊',
          tag: currentUser ? 'Connecté' : 'Accès',
        },
        {
          id: 'home',
          title: 'Page d\'Accueil & Présentation',
          description: 'Présentation complète de la plateforme, vision stratégique et partenaires officiels',
          icon: '🏠',
        },
      ],
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Dimmed backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity animate-in fade-in duration-200"
        onClick={onClose}
      />

      {/* Main Drawer Container */}
      <div className="relative w-full max-w-2xl bg-[#060A14] border-l border-amber-500/30 shadow-2xl flex flex-col h-full z-10 animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-white/10 bg-[#040711] flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3">
            {/* The 3 stripes badge icon */}
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex flex-col items-center justify-center gap-1 shadow-md shadow-amber-500/20 shrink-0">
              <span className="w-5 h-0.5 bg-black rounded-full" />
              <span className="w-5 h-0.5 bg-black rounded-full" />
              <span className="w-5 h-0.5 bg-black rounded-full" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/25 font-bold">
                  Menu Principal
                </span>
                <span className="text-[10px] font-mono text-emerald-400 font-bold hidden sm:inline">
                  ● Toutes les sections accessibles
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-black text-white uppercase tracking-tight mt-0.5">
                Africa Talent Football
              </h2>
              <span className="text-[10px] font-mono text-emerald-400 block font-bold">
                ● Plateforme Internationale de Détection
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onOpenSharePlatform && (
              <button
                onClick={() => {
                  onClose();
                  onOpenSharePlatform();
                }}
                className="hidden sm:flex text-xs font-bold px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-colors items-center gap-1.5 cursor-pointer"
                title="Partager la plateforme"
              >
                <span>🔗</span>
                <span>Partager</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/10 flex items-center justify-center transition-colors cursor-pointer text-sm"
              title="Fermer le menu (Échap)"
              aria-label="Fermer"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Quick Search inside Drawer */}
        <div className="p-4 sm:px-6 border-b border-white/5 bg-[#090E1B] shrink-0">
          <form onSubmit={handleSearchSubmit} className="relative">
            <input
              type="text"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              placeholder="Rechercher rapidement un joueur, club, président, entraîneur..."
              className="w-full px-3.5 py-2.5 pl-10 pr-24 rounded-xl bg-[#040711] border border-white/15 focus:border-amber-500 text-white text-xs placeholder:text-gray-500 focus:outline-none transition-colors"
            />
            <span className="absolute left-3.5 top-3 text-gray-400 text-xs pointer-events-none">🔍</span>
            <button
              type="submit"
              className="absolute right-1.5 top-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-[11px] uppercase tracking-wider transition-colors cursor-pointer"
            >
              Rechercher
            </button>
          </form>
        </div>

        {/* World Languages Selection Bar */}
        <div className="px-4 sm:px-6 py-2.5 bg-[#050812] border-b border-white/10 shrink-0">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-mono uppercase text-gray-400 font-bold flex items-center gap-1.5">
              <span>🌍</span>
              <span>10 Langues Mondiales / World Languages</span>
            </span>
            <span className="text-[10px] font-mono text-amber-400 font-bold">
              10 Langues
            </span>
          </div>
          <div className="grid grid-cols-5 sm:grid-cols-10 gap-1.5">
            {languages.map((l) => {
              const isSelected = l.code === language;
              return (
                <button
                  key={l.code}
                  type="button"
                  onClick={() => setLanguage(l.code)}
                  className={`py-1.5 px-1 rounded-lg border text-center transition-all cursor-pointer flex flex-col items-center justify-center ${
                    isSelected
                      ? 'bg-amber-500 text-black font-black border-amber-300 shadow-sm shadow-amber-500/20'
                      : 'bg-[#090E1B] hover:bg-white/10 text-gray-300 border-white/10 hover:border-amber-500/40'
                  }`}
                  title={`${l.name} (${l.nativeName})`}
                >
                  <span className="text-sm">{l.flag}</span>
                  <span className={`text-[9px] font-mono uppercase font-bold mt-0.5 ${isSelected ? 'text-black font-black' : 'text-gray-400'}`}>
                    {l.code}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Scrollable sections list */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* USER ACCOUNT CARD & QUICK PROFILE ACCESS */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-[#0C1527] to-[#080D1A] border-2 border-amber-500/40 shadow-xl">
            {currentUser ? (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-amber-500 text-black font-black text-sm flex items-center justify-center shrink-0 border border-amber-300 overflow-hidden">
                    {userDisplayAvatar ? (
                      <img
                        src={userDisplayAvatar}
                        alt={currentUser.firstName}
                        className="w-full h-full object-cover object-[50%_20%]"
                        onError={(e) => {
                          const target = e.currentTarget;
                          target.style.display = 'none';
                        }}
                      />
                    ) : (
                      <span>{currentUser.firstName?.[0] || 'U'}{currentUser.lastName?.[0] || ''}</span>
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-white">
                        {currentUser.firstName} {currentUser.lastName}
                      </span>
                      <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-mono font-bold">
                        {currentUser.role}
                      </span>
                    </div>
                    <span className="text-[10px] text-gray-400 font-mono block">
                      {currentUser.email}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleLinkClick('profile')}
                    className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black text-xs font-black transition-colors cursor-pointer shadow-sm"
                  >
                    👤 Mon Profil
                  </button>
                  <button
                    onClick={() => {
                      logout();
                      handleLinkClick('home');
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-red-500/20 text-gray-300 hover:text-red-300 text-xs font-mono transition-colors cursor-pointer"
                  >
                    Déconnexion
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-left">
                <div>
                  <h4 className="text-xs font-black text-white">Espace Membre Professionnel</h4>
                  <p className="text-[10px] text-gray-400 font-mono">
                    Connectez-vous pour accéder à vos sélections, vidéos et fiches certifiées.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleLinkClick('login')}
                    className="px-3.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-mono font-bold border border-white/20 transition-colors cursor-pointer"
                  >
                    🔑 Connexion
                  </button>
                  <button
                    onClick={() => handleLinkClick('register')}
                    className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black text-xs font-black transition-colors cursor-pointer"
                  >
                    📝 S'inscrire
                  </button>
                </div>
              </div>
            )}
          </div>
          {SECTIONS.map((section, sIdx) => (
            <div key={sIdx} className="space-y-2.5">
              <div className="flex items-center justify-between pb-1 border-b border-white/10">
                <span className="text-xs font-black uppercase text-white tracking-wider flex items-center gap-2">
                  <span>{section.category}</span>
                </span>
                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${section.badgeColor}`}>
                  {section.badge}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {section.items.map((item) => {
                  const isActive = activeView === item.id;
                  return (
                    <button
                      key={`${item.id}-${item.title}`}
                      onClick={() => handleLinkClick(item.id, item.payload)}
                      className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between group cursor-pointer ${
                        isActive
                          ? 'bg-amber-500/15 border-amber-500/60 shadow-lg shadow-amber-500/10'
                          : 'bg-[#090E1B] border-white/10 hover:border-amber-500/40 hover:bg-[#0D1527]'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <span className="text-lg p-1.5 rounded-lg bg-black/40 border border-white/5 group-hover:scale-110 transition-transform">
                            {item.icon}
                          </span>
                          <div>
                            <span className={`text-xs font-bold block ${isActive ? 'text-amber-300' : 'text-white group-hover:text-amber-400'}`}>
                              {item.title}
                            </span>
                            {item.count && (
                              <span className="text-[10px] text-emerald-400 font-mono font-semibold">
                                {item.count}
                              </span>
                            )}
                          </div>
                        </div>

                        {item.hot && (
                          <span className="text-[9px] font-mono font-black uppercase px-1.5 py-0.5 rounded bg-amber-500 text-black animate-pulse">
                            POPULAIRE
                          </span>
                        )}

                        {item.tag && !item.hot && (
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-white/5 text-gray-400 border border-white/10">
                            {item.tag}
                          </span>
                        )}

                        {item.unreadBadge !== undefined && item.unreadBadge > 0 && (
                          <span className="px-2 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-bold font-mono">
                            {item.unreadBadge}
                          </span>
                        )}
                      </div>

                      <p className="text-[11px] text-gray-400 mt-2 line-clamp-2 leading-relaxed">
                        {item.description}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Quick Demo Role Switcher inside Drawer */}
          <div className="p-4 rounded-2xl bg-[#090E1B] border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold uppercase text-gray-300 tracking-wider">
                🔐 Accès Rapide Profils Professionnels
              </span>
              <span className="text-[10px] font-mono text-amber-400">1 Clic</span>
            </div>
            <p className="text-[11px] text-gray-400">
              Basculez instantanément pour tester la plateforme sous l'angle Scout, Club ou Joueur :
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                onClick={() => {
                  loginAsDemoRole('SCOUT');
                  handleLinkClick('dashboard');
                }}
                className="p-2.5 rounded-lg bg-[#040711] hover:bg-amber-500/10 border border-white/10 hover:border-amber-500/50 text-left transition-colors cursor-pointer group"
              >
                <div className="text-[10px] font-mono text-amber-400 font-bold">FONDAT. / SCOUT</div>
                <div className="text-xs font-bold text-white group-hover:text-amber-300 truncate">Seydou Mario TRAORÉ</div>
              </button>

              <button
                onClick={() => {
                  loginAsDemoRole('CLUB');
                  handleLinkClick('dashboard');
                }}
                className="p-2.5 rounded-lg bg-[#040711] hover:bg-blue-500/10 border border-white/10 hover:border-blue-500/50 text-left transition-colors cursor-pointer group"
              >
                <div className="text-[10px] font-mono text-blue-400 font-bold">CELLULE PRO</div>
                <div className="text-xs font-bold text-white group-hover:text-blue-300 truncate">Standard de Liège</div>
              </button>

              <button
                onClick={() => {
                  loginAsDemoRole('PLAYER');
                  handleLinkClick('dashboard');
                }}
                className="p-2.5 rounded-lg bg-[#040711] hover:bg-emerald-500/10 border border-white/10 hover:border-emerald-500/50 text-left transition-colors cursor-pointer group"
              >
                <div className="text-[10px] font-mono text-emerald-400 font-bold">ATHLÈTE</div>
                <div className="text-xs font-bold text-white group-hover:text-emerald-300 truncate">Ibrahim Kouassi</div>
              </button>
            </div>
          </div>

          {/* Platform Info & Desk Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-[#090E1B] to-[#040711] border border-amber-500/25 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="text-[10px] font-mono uppercase text-gray-400 block">
                  Direction Générale & Supervision Technique
                </span>
                <span className="text-xs font-bold text-white">
                  {FOUNDER_INFO.name} ({FOUNDER_INFO.officialTitle})
                </span>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-mono text-gray-400 block">Cote Talents ATF :</span>
                <span className="text-xs font-bold font-mono text-emerald-400">
                  {formatMarketValue(totalMarketValue)}
                </span>
              </div>
            </div>

            <div className="pt-2 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
              <a
                href={FOUNDER_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1.5 transition-colors"
              >
                <span>💬 WhatsApp Direct : {FOUNDER_INFO.phone}</span>
              </a>

              {currentUser && (
                <button
                  onClick={() => {
                    logout();
                    handleLinkClick('home');
                  }}
                  className="text-xs text-gray-400 hover:text-red-400 cursor-pointer transition-colors"
                >
                  Déconnexion ({currentUser.firstName}) ✕
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Footer actions inside Drawer */}
        <div className="p-4 sm:p-5 border-t border-white/10 bg-[#040711] flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          {onOpenSharePlatform && (
            <button
              onClick={() => {
                onClose();
                onOpenSharePlatform();
              }}
              className="w-full sm:w-auto py-2.5 px-4 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <span>🔗 Partager la Plateforme en Ligne</span>
            </button>
          )}

          <div className="flex items-center gap-2 w-full sm:w-auto">
            {activeSubscription?.status === 'ACTIVE' ? (
              <span className="w-full sm:w-auto py-2.5 px-4 rounded-xl bg-emerald-950 border border-emerald-700/60 text-emerald-300 font-bold text-xs text-center font-mono">
                👑 PREMIUM ACTIF ({activeSubscription.tier})
              </span>
            ) : (
              <button
                onClick={() => handleLinkClick('pricing')}
                className="w-full sm:w-auto py-2.5 px-5 text-center rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black uppercase text-xs shadow-md cursor-pointer transition-all"
              >
                ★ Passer Premium Pro
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
