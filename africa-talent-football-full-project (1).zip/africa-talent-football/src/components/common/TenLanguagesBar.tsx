import React, { useState, useRef, useEffect } from 'react';
import { useLanguage, WORLD_LANGUAGES, Language } from '../../context/LanguageContext';

interface TenLanguagesBarProps {
  className?: string;
}

export const TenLanguagesBar: React.FC<TenLanguagesBarProps> = ({ className = '' }) => {
  const { language, currentLanguageMeta, setLanguage } = useLanguage();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (code: Language) => {
    setLanguage(code);
    setDropdownOpen(false);
  };

  return (
    <div ref={containerRef} className={`relative flex items-center gap-1.5 ${className}`}>
      {/* 1. DESKTOP & TABLET: ALL 10 WORLD LANGUAGES INLINE STRIP */}
      <div className="hidden md:flex items-center gap-1 bg-[#070B16] border border-amber-500/40 rounded-xl px-2 py-1 shadow-inner">
        <div className="flex items-center gap-1.5 pr-2 border-r border-white/10 text-[9px] font-mono font-black uppercase text-amber-400 shrink-0">
          <span className="text-xs">🌍</span>
          <span className="hidden xl:inline tracking-wider">10 Langues :</span>
        </div>

        <div className="flex items-center gap-0.5 sm:gap-1">
          {WORLD_LANGUAGES.map((lang) => {
            const isSelected = lang.code === language;
            return (
              <button
                key={lang.code}
                onClick={() => handleSelect(lang.code)}
                title={`${lang.name} (${lang.nativeName}) - Sélectionner la langue`}
                aria-label={`Passer la plateforme en ${lang.name}`}
                className={`px-1.5 py-1 rounded-lg text-xs flex items-center gap-1 transition-all cursor-pointer font-mono font-bold shrink-0 ${
                  isSelected
                    ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black shadow-md shadow-amber-500/30 font-black scale-105 border border-amber-200'
                    : 'text-gray-300 hover:text-white hover:bg-white/10 border border-transparent'
                }`}
              >
                <span className="text-sm leading-none">{lang.flag}</span>
                <span className="text-[10px] uppercase">{lang.code}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. COMPACT DROPDOWN TRIGGER (For smaller screens or quick switcher) */}
      <div className="flex md:hidden items-center">
        <button
          type="button"
          onClick={() => setDropdownOpen(!dropdownOpen)}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border transition-all cursor-pointer shadow-sm ${
            dropdownOpen
              ? 'bg-amber-500/20 border-amber-400 text-white'
              : 'bg-[#0E1527] hover:bg-[#141E38] border-amber-500/40 text-gray-200'
          }`}
          title="Sélectionner parmi les 10 langues mondiales (Français, English, Español, Português, العربية, Deutsch, Italiano, Nederlands, Türkçe, Kiswahili)"
          aria-label="Choisir parmi les 10 langues mondiales"
          aria-expanded={dropdownOpen}
        >
          <span className="text-base leading-none">{currentLanguageMeta.flag}</span>
          <span className="text-[11px] font-mono font-black uppercase text-amber-300">
            {currentLanguageMeta.code.toUpperCase()}
          </span>
          <span className="text-[9px] font-mono text-gray-300 bg-amber-500/20 px-1 py-0.2 rounded border border-amber-500/30">
            10 Langues
          </span>
          <span className="text-[9px] text-gray-400">▾</span>
        </button>
      </div>

      {/* 3. FULL 10 LANGUAGES MODAL / DROPDOWN MENU */}
      {dropdownOpen && (
        <div className="absolute left-0 lg:right-0 top-full mt-2 w-64 rounded-2xl bg-[#090E1B] border-2 border-amber-500/60 shadow-2xl py-2 z-50 animate-in fade-in duration-100 ring-1 ring-black/80">
          <div className="px-3.5 py-2 border-b border-white/10 flex items-center justify-between">
            <span className="text-[11px] font-mono text-amber-400 uppercase tracking-wider font-black flex items-center gap-1.5">
              <span>🌍</span>
              <span>10 Langues Mondiales</span>
            </span>
            <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/40">
              FIFA Global
            </span>
          </div>

          <div className="max-h-80 overflow-y-auto py-1 divide-y divide-white/5">
            {WORLD_LANGUAGES.map((lang) => {
              const isSelected = lang.code === language;
              return (
                <button
                  key={lang.code}
                  onClick={() => handleSelect(lang.code)}
                  className={`w-full px-3.5 py-2 text-left text-xs flex items-center justify-between transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-amber-500/20 text-amber-300 font-bold'
                      : 'text-gray-300 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-xl leading-none">{lang.flag}</span>
                    <div>
                      <div className="font-bold text-white text-xs">{lang.nativeName}</div>
                      <div className="text-[10px] text-gray-400">{lang.name}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {isSelected && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    )}
                    <span
                      className={`text-[10px] font-mono font-bold uppercase px-1.5 py-0.5 rounded ${
                        isSelected
                          ? 'bg-amber-500 text-black font-black'
                          : 'bg-white/10 text-gray-300'
                      }`}
                    >
                      {lang.code}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="px-3.5 pt-2 pb-1 border-t border-white/10 text-[9px] font-mono text-gray-400 text-center">
            Prise en charge intégrale des 6 confédérations de football
          </div>
        </div>
      )}
    </div>
  );
};
