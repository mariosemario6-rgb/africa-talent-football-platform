import React, { useState } from 'react';
import { usePayment, PRICING_PLANS, CURRENCY_RATES } from '../../context/PaymentContext';
import { useLanguage } from '../../context/LanguageContext';
import { BillingInterval, PaymentMethodType, CurrencyCode } from '../../types/database';
import { FOUNDER_INFO } from '../../data/demoData';

export const CheckoutModal: React.FC = () => {
  const { t, tTier } = useLanguage();
  const {
    isCheckoutOpen,
    closeCheckout,
    selectedTier,
    formatPrice,
    currency,
    setCurrency,
    processPayment
  } = usePayment();

  const [interval, setInterval] = useState<BillingInterval>('ANNUAL');
  const [provider, setProvider] = useState<PaymentMethodType>('CARD');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [invoiceNumber, setInvoiceNumber] = useState('');

  // Form states
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  const [cardName, setCardName] = useState('');

  // Mobile Money states
  const [momoOperator, setMomoOperator] = useState('Orange Money (CI / SN / ML)');
  const [momoPhone, setMomoPhone] = useState('+225 07 ');

  if (!isCheckoutOpen || !selectedTier) return null;

  const plan = PRICING_PLANS.find((p) => p.id === selectedTier) || PRICING_PLANS[0];
  const priceEur = interval === 'ANNUAL' ? plan.annualEur : plan.monthlyEur;

  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    let details = 'Visa terminant par 4242';
    if (provider === 'CARD') {
      details = `Carte ${cardNumber.slice(-4) || '8821'}`;
    } else if (provider === 'MOBILE_MONEY') {
      details = `${momoOperator} (${momoPhone})`;
    } else if (provider === 'PAYPAL') {
      details = 'Compte PayPal vérifié';
    } else if (provider === 'BANK_TRANSFER') {
      details = 'Virement bancaire SEPA/SWIFT';
    }

    try {
      await processPayment({
        tier: selectedTier,
        interval,
        provider,
        details
      });

      const inv = `ATF-${Date.now().toString().slice(-6)}`;
      setInvoiceNumber(inv);
      setIsProcessing(false);
      setIsSuccess(true);
    } catch {
      setIsProcessing(false);
    }
  };

  const handleFinish = () => {
    setIsSuccess(false);
    closeCheckout();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-[#090E1B] rounded-2xl border border-amber-500/50 shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 bg-[#050810] border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
            <div>
              <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-amber-400">
                Africa Talent Football · Système de Paiement Sécurisé Mondial
              </span>
              <h3 className="text-base font-black text-white">
                Souscription : {plan.title}
              </h3>
            </div>
          </div>
          <button
            onClick={closeCheckout}
            className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/10 text-sm font-bold"
          >
            ✕
          </button>
        </div>

        {isSuccess ? (
          /* SUCCESS CONFIRMATION RECEIPT */
          <div className="p-8 text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 text-emerald-400 text-3xl font-black mx-auto flex items-center justify-center">
              ✓
            </div>

            <div className="space-y-1">
              <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
                Paiement Validé avec Succès
              </span>
              <h2 className="text-2xl font-black text-white">
                Félicitations, votre profil est maintenant PREMIUM PRO !
              </h2>
              <p className="text-xs text-gray-300">
                Votre accréditation officielle est activée sous la supervision de Seydou Mario TRAORÉ.
              </p>
            </div>

            {/* Receipt Summary Card */}
            <div className="p-4 rounded-xl bg-[#050810] border border-white/10 text-xs text-left space-y-2 font-mono">
              <div className="flex justify-between">
                <span className="text-gray-500">Numéro de Facture :</span>
                <span className="text-white font-bold">{invoiceNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Plan & Formule :</span>
                <span className="text-amber-400 font-bold">{plan.title} ({interval === 'ANNUAL' ? 'Annuel' : 'Mensuel'})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Montant Réglé :</span>
                <span className="text-emerald-400 font-bold text-sm">{formatPrice(priceEur, interval)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Moyen de Paiement :</span>
                <span className="text-white font-medium">{provider}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Superviseur Réseau :</span>
                <span className="text-white">{FOUNDER_INFO.name} (Directeur Fondateur)</span>
              </div>
            </div>

            <div className="flex justify-center gap-3">
              <button
                onClick={handleFinish}
                className="px-8 py-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors shadow-lg shadow-amber-500/20 cursor-pointer"
              >
                Accéder à mon Espace Premium Pro
              </button>
            </div>
          </div>
        ) : (
          /* PAYMENT FORM */
          <form onSubmit={handlePay} className="p-6 space-y-6">
            {/* Currency & Interval Selectors */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-mono font-bold text-gray-400 uppercase mb-1">
                  Devise de Paiement :
                </label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                  className="w-full px-3 py-2 rounded-lg bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-500 focus:outline-none"
                >
                  {Object.entries(CURRENCY_RATES).map(([code, info]) => (
                    <option key={code} value={code}>
                      {info.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-mono font-bold text-gray-400 uppercase mb-1">
                  Fréquence de Facturation :
                </label>
                <div className="grid grid-cols-2 gap-1 bg-[#050810] p-1 rounded-lg border border-white/10 text-xs">
                  <button
                    type="button"
                    onClick={() => setInterval('MONTHLY')}
                    className={`py-1.5 rounded font-bold transition-colors ${
                      interval === 'MONTHLY' ? 'bg-amber-500 text-black' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    Mensuel
                  </button>
                  <button
                    type="button"
                    onClick={() => setInterval('ANNUAL')}
                    className={`py-1.5 rounded font-bold transition-colors ${
                      interval === 'ANNUAL' ? 'bg-amber-500 text-black' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    Annuel (-20%)
                  </button>
                </div>
              </div>
            </div>

            {/* Price Preview Strip */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-amber-500/10 via-emerald-500/10 to-transparent border border-amber-500/30 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono font-bold uppercase text-gray-400 block">Total à régler aujourd'hui :</span>
                <span className="text-2xl font-black text-emerald-400 font-mono">
                  {formatPrice(priceEur, interval)}
                </span>
              </div>
              <div className="text-right text-[11px] font-mono text-gray-400">
                <span className="text-amber-400 font-bold block">Activation Instantanée 24/7</span>
                <span>Garantie Satisfait ou Remboursé 14 jours</span>
              </div>
            </div>

            {/* PAYMENT METHODS SELECTOR TABS */}
            <div>
              <label className="block text-[11px] font-mono font-bold text-gray-400 uppercase mb-2">
                Sélectionnez votre moyen de paiement mondial :
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => setProvider('CARD')}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-colors cursor-pointer ${
                    provider === 'CARD'
                      ? 'bg-amber-500/10 border-amber-400 text-white'
                      : 'bg-[#050810] border-white/10 text-gray-400 hover:text-white'
                  }`}
                >
                  <span className="text-base">💳</span>
                  <span className="text-xs font-bold mt-1">Carte Bancaire</span>
                  <span className="text-[9px] text-gray-500 font-mono">Visa / Mastercard / Amex</span>
                </button>

                <button
                  type="button"
                  onClick={() => setProvider('MOBILE_MONEY')}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-colors cursor-pointer ${
                    provider === 'MOBILE_MONEY'
                      ? 'bg-amber-500/10 border-amber-400 text-white'
                      : 'bg-[#050810] border-white/10 text-gray-400 hover:text-white'
                  }`}
                >
                  <span className="text-base">📱</span>
                  <span className="text-xs font-bold mt-1">Mobile Money</span>
                  <span className="text-[9px] text-gray-500 font-mono">Wave / Orange / MTN</span>
                </button>

                <button
                  type="button"
                  onClick={() => setProvider('PAYPAL')}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-colors cursor-pointer ${
                    provider === 'PAYPAL'
                      ? 'bg-amber-500/10 border-amber-400 text-white'
                      : 'bg-[#050810] border-white/10 text-gray-400 hover:text-white'
                  }`}
                >
                  <span className="text-base">🅿️</span>
                  <span className="text-xs font-bold mt-1">PayPal Express</span>
                  <span className="text-[9px] text-gray-500 font-mono">1-Clic Checkout</span>
                </button>

                <button
                  type="button"
                  onClick={() => setProvider('BANK_TRANSFER')}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-colors cursor-pointer ${
                    provider === 'BANK_TRANSFER'
                      ? 'bg-amber-500/10 border-amber-400 text-white'
                      : 'bg-[#050810] border-white/10 text-gray-400 hover:text-white'
                  }`}
                >
                  <span className="text-base">🏦</span>
                  <span className="text-xs font-bold mt-1">Virement Pro</span>
                  <span className="text-[9px] text-gray-500 font-mono">SEPA / SWIFT B2B</span>
                </button>
              </div>
            </div>

            {/* METHOD DETAILS FORM */}
            {provider === 'CARD' && (
              <div className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono font-bold text-amber-400 uppercase">
                    Informations Carte Sécurisée (SSL 256-bit)
                  </span>
                  <span className="text-[10px] text-gray-500 font-mono">Stripe & 3D Secure</span>
                </div>

                <div>
                  <label className="text-[10px] text-gray-400 block mb-1">Numéro de Carte</label>
                  <input
                    type="text"
                    required
                    placeholder="4532 •••• •••• 8821"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-[#090E1B] border border-white/10 text-white text-xs font-mono focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Expiration (MM/AA)</label>
                    <input
                      type="text"
                      required
                      placeholder="12/28"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-[#090E1B] border border-white/10 text-white text-xs font-mono focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">CVC / Cryptogramme</label>
                    <input
                      type="text"
                      required
                      placeholder="382"
                      value={cardCvc}
                      onChange={(e) => setCardCvc(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-[#090E1B] border border-white/10 text-white text-xs font-mono focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div className="col-span-2 sm:col-span-1">
                    <label className="text-[10px] text-gray-400 block mb-1">Titulaire</label>
                    <input
                      type="text"
                      required
                      placeholder="Nom sur la carte"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-[#090E1B] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {provider === 'MOBILE_MONEY' && (
              <div className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono font-bold text-amber-400 uppercase">
                    Paiement Mobile Money Direct (Afrique de l'Ouest & Centrale)
                  </span>
                  <span className="text-[10px] text-emerald-400 font-mono">Sans frais supplémentaires</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Opérateur Réseau :</label>
                    <select
                      value={momoOperator}
                      onChange={(e) => setMomoOperator(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-[#090E1B] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                    >
                      <option value="Orange Money (CI / SN / ML)">Orange Money (CI / SN / ML)</option>
                      <option value="Wave Côte d'Ivoire & Sénégal">Wave Côte d'Ivoire & Sénégal</option>
                      <option value="MTN MoMo (CI / GH / CM)">MTN MoMo (CI / GH / CM)</option>
                      <option value="Moov Money">Moov Money Flooz</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Numéro Mobile Associé :</label>
                    <input
                      type="tel"
                      required
                      value={momoPhone}
                      onChange={(e) => setMomoPhone(e.target.value)}
                      placeholder="+225 07 00 00 00 00"
                      className="w-full px-3 py-2 rounded-lg bg-[#090E1B] border border-white/10 text-white text-xs font-mono focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                </div>
                <p className="text-[11px] text-gray-400">
                  Un push de confirmation USSD apparaîtra immédiatement sur votre téléphone pour valider la transaction sécurisée.
                </p>
              </div>
            )}

            {provider === 'PAYPAL' && (
              <div className="p-4 rounded-xl bg-[#050810] border border-white/10 text-center space-y-2 text-xs">
                <span className="text-amber-400 font-bold block">Connexion Directe PayPal</span>
                <p className="text-gray-300 text-xs">
                  Vous serez redirigé vers l'interface sécurisée PayPal pour autoriser votre paiement en 1 clic.
                </p>
              </div>
            )}

            {provider === 'BANK_TRANSFER' && (
              <div className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-2 text-xs">
                <span className="text-amber-400 font-mono font-bold block uppercase">
                  Coordonnées Virement Officiel (B2B Club / Corporate)
                </span>
                <div className="p-3 rounded bg-black/60 font-mono text-[11px] space-y-1 text-gray-300">
                  <div>Bénéficiaire : <strong>AFRICA TALENT FOOTBALL INT.</strong></div>
                  <div>Banque : <strong>BNP Paribas / Société Générale CI</strong></div>
                  <div>IBAN : <strong>CI93 CI00 2010 0001 2345 6789 01</strong></div>
                  <div>SWIFT / BIC : <strong>SGCIXCIX</strong></div>
                </div>
                <p className="text-[10px] text-gray-500">
                  Votre facture officielle pro-forma sera générée immédiatement et transmise à votre service comptable.
                </p>
              </div>
            )}

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-3.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <span className="w-4 h-4 rounded-full border-2 border-black border-t-transparent animate-spin" />
                    <span>Traitement Sécurisé en Cours...</span>
                  </>
                ) : (
                  <span>
                    Valider le Paiement de {formatPrice(priceEur, interval)}
                  </span>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
