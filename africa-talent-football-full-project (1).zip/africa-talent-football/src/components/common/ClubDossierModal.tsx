import React, { useState } from 'react';
import { FootballClub, ClubVideoItem, ClubNewsItem } from '../../types/database';
import { usePushNotifications } from '../../context/PushNotificationContext';
import { useLanguage } from '../../context/LanguageContext';
import { FOUNDER_INFO } from '../../data/demoData';
import { TacticalPitchBoard } from '../tactical/TacticalPitchBoard';
import { getClubVideos, getClubNews } from '../../data/clubsMediaData';

interface ClubDossierModalProps {
  club: FootballClub | null;
  isOpen: boolean;
  onClose: () => void;
  onProposePlayer?: (club: FootballClub, need?: string) => void;
  onStartConversation?: (club: FootballClub) => void;
  initialTab?: 'OVERVIEW' | 'VIDEOS' | 'NEWS' | 'TACTICAL' | 'MERCATO' | 'ALUMNI';
}

export const ClubDossierModal: React.FC<ClubDossierModalProps> = ({
  club,
  isOpen,
  onClose,
  onProposePlayer,
  onStartConversation,
  initialTab = 'OVERVIEW',
}) => {
  const { isSubscribedToClub, toggleClubAlertSubscription } = usePushNotifications();
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'VIDEOS' | 'NEWS' | 'TACTICAL' | 'MERCATO' | 'ALUMNI'>(initialTab);
  const [selectedVideo, setSelectedVideo] = useState<ClubVideoItem | null>(null);
  const [videoFilter, setVideoFilter] = useState<'ALL' | 'MATCH' | 'TRAINING' | 'ACADEMY'>('ALL');
  const [newsFilter, setNewsFilter] = useState<'ALL' | 'MERCATO' | 'OFFICIEL' | 'FORMATION'>('ALL');
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const videoRef = React.useRef<HTMLVideoElement>(null);

  const clubVideos = React.useMemo(() => {
    return club ? getClubVideos(club) : [];
  }, [club]);

  const clubNews = React.useMemo(() => {
    return club ? getClubNews(club) : [];
  }, [club]);

  React.useEffect(() => {
    if (initialTab && isOpen) {
      setActiveTab(initialTab);
    }
    if (clubVideos.length > 0 && !selectedVideo) {
      setSelectedVideo(clubVideos[0]);
    }
  }, [initialTab, club?.id, isOpen, clubVideos]);

  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
  };

  if (!isOpen || !club) return null;

  const isSubscribed = isSubscribedToClub(club.id);

  const handleWhatsAppContact = (need?: string) => {
    const needText = need ? `\n- Besoin ciblé : ${need}` : '';
    const message = `Bonjour Seydou Mario TRAORÉ,\nJe vous contacte concernant le club "${club.name}" (${club.country}) sur Africa Talent Football :${needText}\n\nMerci de m'informer sur les modalités de détection, transferts et passerelles avec ce club.`;
    window.open(`${FOUNDER_INFO.whatsappUrl}?text=${encodeURIComponent(message)}`, '_blank');
  };

  const getConfederationBadge = (conf?: string) => {
    switch (conf) {
      case 'CAF':
        return <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-mono font-bold">CAF Afrique</span>;
      case 'UEFA':
        return <span className="px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/40 text-[10px] font-mono font-bold">UEFA Europe</span>;
      case 'CONMEBOL':
        return <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 text-[10px] font-mono font-bold">CONMEBOL Am. Sud</span>;
      case 'CONCACAF':
        return <span className="px-2.5 py-1 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 text-[10px] font-mono font-bold">CONCACAF Am. Nord</span>;
      case 'AFC':
        return <span className="px-2.5 py-1 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/40 text-[10px] font-mono font-bold">AFC Asie / Golfe</span>;
      case 'OFC':
        return <span className="px-2.5 py-1 rounded-full bg-teal-500/20 text-teal-400 border border-teal-500/40 text-[10px] font-mono font-bold">OFC Océanie</span>;
      default:
        return null;
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto text-left"
    >
      <div className="bg-[#070D1B] border-2 border-amber-500/50 rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl shadow-black/90 overflow-hidden my-auto">
        {/* HEADER */}
        <div className="relative p-5 sm:p-6 border-b border-white/10 bg-gradient-to-r from-[#0C152B] via-[#091122] to-[#070D1B]">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-4">
              <img
                src={club.logoUrl}
                alt={club.name}
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-amber-500/40 shadow-lg shadow-black/60 shrink-0"
              />
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-xl sm:text-2xl font-black text-white">
                    {club.name}
                  </h2>
                  {club.verified && (
                    <span className="text-amber-400 text-base" title="Club Vérifié & Certifié ATF">
                      ✓
                    </span>
                  )}
                  {getConfederationBadge(club.confederation)}
                </div>

                <div className="flex flex-wrap items-center gap-2 text-xs text-gray-300 font-mono">
                  <span>{club.countryFlag} {club.city}, {club.country}</span>
                  <span className="text-gray-500">•</span>
                  <span className="text-amber-400 font-bold">{club.league}</span>
                  <span className="text-gray-500">•</span>
                  <span className="text-gray-400">{club.division}</span>
                </div>

                {club.stadium && (
                  <p className="text-[11px] text-gray-400 flex items-center gap-1 font-mono">
                    <span>🏟️</span>
                    <span>{club.stadium}</span>
                  </p>
                )}
              </div>
            </div>

            <button
              onClick={onClose}
              className="absolute top-4 right-4 sm:static text-gray-400 hover:text-white p-2 rounded-xl hover:bg-white/10 text-lg transition-colors cursor-pointer"
              aria-label="Fermer"
            >
              ✕
            </button>
          </div>

          {/* Subscribed Club Alerts Push Toggle Bar */}
          <div className="mt-4 pt-3 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
            <div className="flex items-center gap-2">
              <span className="text-sm">🔔</span>
              <span className="text-xs text-gray-300">
                Abonnement Alertes Mercato :{' '}
                <strong className={isSubscribed ? 'text-emerald-400' : 'text-gray-400'}>
                  {isSubscribed ? 'Actif (Vous recevez les alertes push)' : 'Inactif'}
                </strong>
              </span>
            </div>

            <button
              onClick={() => toggleClubAlertSubscription(club.id, club.name)}
              className={`px-3.5 py-1.5 rounded-xl font-mono text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-sm active:scale-95 ${
                isSubscribed
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 hover:bg-emerald-500/30'
                  : 'bg-amber-500 text-black font-black hover:bg-amber-400'
              }`}
            >
              <span>{isSubscribed ? '✓ Abonné aux Alertes' : '+ S’abonner aux Alertes Mercato'}</span>
            </button>
          </div>
        </div>

        {/* NAVIGATION TABS */}
        <div className="px-5 pt-3 bg-[#060B18] border-b border-white/5 flex items-center gap-4 text-xs font-mono font-bold overflow-x-auto">
          <button
            onClick={() => setActiveTab('OVERVIEW')}
            className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'OVERVIEW'
                ? 'border-amber-500 text-amber-400 font-black'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <span>🏢 Fiche & Organigramme</span>
          </button>

          <button
            onClick={() => setActiveTab('VIDEOS')}
            className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'VIDEOS'
                ? 'border-amber-500 text-amber-400 font-black'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <span>🎬 Matchs & Entraînements Vidéo</span>
            <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px]">
              {clubVideos.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('NEWS')}
            className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'NEWS'
                ? 'border-amber-500 text-amber-400 font-black'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <span>📰 Actualités & Mercato</span>
            <span className="px-1.5 py-0.2 rounded-full bg-blue-500/20 text-blue-300 text-[10px]">
              {clubNews.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('TACTICAL')}
            className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'TACTICAL'
                ? 'border-amber-500 text-amber-400 font-black'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <span>📐 Analyse Tactique</span>
            <span className="px-1.5 py-0.2 rounded-full bg-blue-500/20 text-blue-300 text-[10px]">
              {club.tacticalSystem || '4-3-3'}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('MERCATO')}
            className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'MERCATO'
                ? 'border-amber-500 text-amber-400 font-black'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <span>🎯 Besoins Mercato</span>
            <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 text-[10px]">
              {club.openNeeds.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('ALUMNI')}
            className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'ALUMNI'
                ? 'border-amber-500 text-amber-400 font-black'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <span>⭐ Références & Anciens</span>
          </button>
        </div>

        {/* BODY */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto max-h-[62vh]">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'OVERVIEW' && (
            <div className="space-y-6">
              {/* Description */}
              {club.description && (
                <div className="p-4 rounded-2xl bg-[#091122] border border-white/10 text-xs text-gray-300 leading-relaxed space-y-1">
                  <span className="text-[10px] font-mono uppercase text-amber-400 font-bold block">
                    Présentation Institutionnelle & Historique
                  </span>
                  <p>{club.description}</p>
                </div>
              )}

              {/* Key Staff Directory */}
              <div className="space-y-3">
                <h3 className="text-xs font-mono font-bold uppercase text-white tracking-wider flex items-center gap-1.5">
                  <span>👔</span>
                  <span>Organigramme Officiel & Direction Sportive</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3.5 rounded-xl bg-[#050914] border border-white/5 space-y-0.5">
                    <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Président du Club</span>
                    <p className="text-xs font-bold text-white">{club.president || 'Non communiqué'}</p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#050914] border border-white/5 space-y-0.5">
                    <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Directeur Sportif / Head of Football</span>
                    <p className="text-xs font-bold text-amber-300">{club.sportingDirector || 'Direction technique'}</p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#050914] border border-white/5 space-y-0.5">
                    <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Entraîneur Principal</span>
                    <p className="text-xs font-bold text-white">{club.headCoach || 'Staff professionnel'}</p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#050914] border border-white/5 space-y-0.5">
                    <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Responsable Recrutement / Académie</span>
                    <p className="text-xs font-bold text-white">{club.headOfRecruitment || 'Cellule internationale'}</p>
                  </div>
                </div>
              </div>

              {/* Financial & Transfer Policy */}
              <div className="space-y-3">
                <h3 className="text-xs font-mono font-bold uppercase text-white tracking-wider flex items-center gap-1.5">
                  <span>💼</span>
                  <span>Données Économiques & Politique de Recrutement</span>
                </h3>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono">
                  <div className="p-3 rounded-xl bg-[#050914] border border-white/5">
                    <span className="text-[9px] text-gray-400 uppercase block font-bold">Budget Transfert</span>
                    <span className="font-bold text-emerald-400 text-[11px]">{club.budgetRange || 'Sur devis'}</span>
                  </div>

                  <div className="p-3 rounded-xl bg-[#050914] border border-white/5">
                    <span className="text-[9px] text-gray-400 uppercase block font-bold">Âge Cible</span>
                    <span className="font-bold text-amber-400 text-[11px]">{club.targetAge || 'U17 - Senior'}</span>
                  </div>

                  <div className="p-3 rounded-xl bg-[#050914] border border-white/5">
                    <span className="text-[9px] text-gray-400 uppercase block font-bold">Format Privilégié</span>
                    <span className="font-bold text-white text-[11px]">{club.transferType || 'Achat Direct'}</span>
                  </div>

                  <div className="p-3 rounded-xl bg-[#050914] border border-white/5">
                    <span className="text-[9px] text-gray-400 uppercase block font-bold">Palmarès Titres</span>
                    <span className="font-bold text-purple-400 text-[11px]">🏆 {club.trophiesCount || 0} trophées</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: VIDEOS (MATCHS & ENTRAÎNEMENTS DU CLUB) */}
          {activeTab === 'VIDEOS' && (
            <div className="space-y-6">
              {/* Filter Pills */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[11px] font-mono text-gray-400 uppercase font-bold">Filtrer par type :</span>
                  {(['ALL', 'MATCH', 'TRAINING', 'ACADEMY'] as const).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setVideoFilter(cat)}
                      className={`px-3 py-1 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                        videoFilter === cat
                          ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                          : 'bg-white/5 text-gray-400 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      {cat === 'ALL' && 'Toutes les Vidéos'}
                      {cat === 'MATCH' && '⚽ Matchs & Résumés'}
                      {cat === 'TRAINING' && '🏋️ Entraînements & Tactique'}
                      {cat === 'ACADEMY' && '🎓 Académie & Drills U19'}
                    </button>
                  ))}
                </div>

                <span className="text-xs font-mono text-emerald-400 font-bold bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/30">
                  {clubVideos.length} séquences vidéo HD
                </span>
              </div>

              {/* Main Player Display */}
              {selectedVideo && (
                <div className="p-4 sm:p-5 rounded-2xl bg-[#050914] border-2 border-amber-500/40 space-y-4 shadow-2xl">
                  <div className="relative aspect-video rounded-xl overflow-hidden bg-black border border-white/10 group shadow-inner">
                    <video
                      ref={videoRef}
                      key={selectedVideo.id}
                      controls
                      poster={selectedVideo.thumbnailUrl}
                      className="w-full h-full object-cover"
                    >
                      <source src={selectedVideo.videoUrl} type="video/mp4" />
                      Votre navigateur ne supporte pas la lecture vidéo.
                    </video>
                  </div>

                  {/* Player Controls Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-white/10">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                          selectedVideo.type === 'MATCH'
                            ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                            : selectedVideo.type === 'TRAINING'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        }`}>
                          {selectedVideo.type === 'MATCH' && 'Match Officiel'}
                          {selectedVideo.type === 'TRAINING' && 'Séance d’Entraînement'}
                          {selectedVideo.type === 'ACADEMY' && 'Drill Centre de Formation'}
                        </span>
                        <span className="text-xs text-gray-400 font-mono">⏱️ {selectedVideo.duration}</span>
                        {selectedVideo.views && (
                          <span className="text-xs text-gray-400 font-mono">👁️ {selectedVideo.views} vues</span>
                        )}
                        {selectedVideo.date && (
                          <span className="text-xs text-gray-500 font-mono">• {selectedVideo.date}</span>
                        )}
                      </div>
                      <h4 className="text-base font-black text-white">{selectedVideo.title}</h4>
                      <p className="text-xs text-gray-300 leading-relaxed">{selectedVideo.description}</p>
                      {selectedVideo.tacticalKey && (
                        <div className="text-[11px] font-mono text-amber-400 pt-1 flex items-center gap-1.5">
                          <span>📐 Clé Tactique Isolée :</span>
                          <span className="text-white font-bold">{selectedVideo.tacticalKey}</span>
                        </div>
                      )}
                    </div>

                    {/* Slow-mo Speed Selector for Scouting */}
                    <div className="flex items-center gap-2 self-end sm:self-auto shrink-0 bg-black/60 p-1.5 rounded-xl border border-white/10">
                      <span className="text-[10px] font-mono text-gray-400 uppercase font-bold px-1">Ralenti Scout :</span>
                      {[0.5, 0.75, 1, 1.25].map((spd) => (
                        <button
                          key={spd}
                          onClick={() => handleSpeedChange(spd)}
                          className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold transition-colors cursor-pointer ${
                            playbackSpeed === spd
                              ? 'bg-amber-500 text-black'
                              : 'text-gray-400 hover:text-white'
                          }`}
                        >
                          {spd}x
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Video Playlist Grid */}
              <div className="space-y-3">
                <h4 className="text-xs font-mono font-bold uppercase text-white tracking-wider flex items-center gap-2">
                  <span>📹</span>
                  <span>Catalogue Vidéothèque de {club.name}</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {clubVideos
                    .filter((v) => videoFilter === 'ALL' || v.type === videoFilter)
                    .map((vid) => {
                      const isSelected = selectedVideo?.id === vid.id;
                      return (
                        <div
                          key={vid.id}
                          onClick={() => setSelectedVideo(vid)}
                          className={`p-3 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-2 group ${
                            isSelected
                              ? 'bg-amber-500/10 border-amber-500 shadow-lg shadow-amber-500/10'
                              : 'bg-[#050914] border-white/10 hover:border-white/30'
                          }`}
                        >
                          <div className="relative aspect-video rounded-xl overflow-hidden bg-black">
                            <img
                              src={vid.thumbnailUrl}
                              alt={vid.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                            />
                            <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/20 transition-colors">
                              <span className="w-9 h-9 rounded-full bg-amber-500/90 text-black flex items-center justify-center font-bold text-sm shadow-md group-hover:scale-110 transition-transform">
                                ▶
                              </span>
                            </div>
                            <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 text-[10px] font-mono text-white font-bold">
                              {vid.duration}
                            </span>
                            <span className="absolute top-2 left-2 px-1.5 py-0.5 rounded bg-black/80 text-[9px] font-mono text-amber-400 font-bold uppercase">
                              {vid.type}
                            </span>
                          </div>

                          <div className="space-y-1">
                            <h5 className="text-xs font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-2">
                              {vid.title}
                            </h5>
                            <p className="text-[10px] text-gray-400 line-clamp-1">{vid.description}</p>
                          </div>

                          <div className="flex items-center justify-between text-[10px] font-mono text-gray-500 pt-1 border-t border-white/5">
                            <span>{vid.date || 'Récemment'}</span>
                            <span className="text-amber-400 font-bold">Visionner ↗</span>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          )}

          {/* TAB: NEWS (ACTUALITÉS & MERCATO DU CLUB) */}
          {activeTab === 'NEWS' && (
            <div className="space-y-6">
              {/* Category Filter */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[11px] font-mono text-gray-400 uppercase font-bold">Rubrique :</span>
                  {(['ALL', 'MERCATO', 'OFFICIEL', 'FORMATION'] as const).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setNewsFilter(cat)}
                      className={`px-3 py-1 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                        newsFilter === cat
                          ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                          : 'bg-white/5 text-gray-400 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      {cat === 'ALL' && 'Toutes les Actualités'}
                      {cat === 'MERCATO' && '🎯 Mercato & Transferts'}
                      {cat === 'OFFICIEL' && '📢 Communiqués Officiels'}
                      {cat === 'FORMATION' && '🎓 Formation & Détection'}
                    </button>
                  ))}
                </div>

                <span className="text-xs font-mono text-blue-400 font-bold bg-blue-500/10 px-2.5 py-1 rounded-full border border-blue-500/30">
                  Flux Certifié Africa Talent Football
                </span>
              </div>

              {/* News Feed */}
              <div className="space-y-4">
                {clubNews
                  .filter((n) => newsFilter === 'ALL' || n.category === newsFilter)
                  .map((item) => (
                    <div
                      key={item.id}
                      className="p-5 rounded-2xl bg-[#050914] border border-white/10 hover:border-amber-500/50 transition-all space-y-3 shadow-xl"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${
                            item.category === 'MERCATO'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                              : item.category === 'OFFICIEL'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                              : 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                          }`}>
                            {item.category}
                          </span>
                          <span className="text-xs font-mono text-gray-400">📅 {item.date}</span>
                        </div>

                        <span className="text-[11px] font-mono text-gray-400 bg-white/5 px-2 py-0.5 rounded border border-white/10">
                          Source : {item.source}
                        </span>
                      </div>

                      <h3 className="text-base sm:text-lg font-black text-white leading-snug">
                        {item.title}
                      </h3>

                      <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
                        {item.summary}
                      </p>

                      {item.keyHighlight && (
                        <div className="p-3 rounded-xl bg-[#0A1224] border-l-4 border-amber-500 text-xs text-amber-300 font-mono">
                          <strong>Point Clé :</strong> {item.keyHighlight}
                        </div>
                      )}

                      <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/5">
                        <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                          <span>✓</span>
                          <span>Information validée par la cellule de veille internationale</span>
                        </span>

                        <button
                          onClick={() => handleWhatsAppContact(`Information club: ${item.title}`)}
                          className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold font-mono transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <span>💬 Contacter le Desk sur ce sujet</span>
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* TAB: TACTICAL */}
          {activeTab === 'TACTICAL' && (
            <div className="space-y-4">
              <TacticalPitchBoard
                club={club}
                initialFormation={club.tacticalSystem || '4-3-3'}
                onPositionClick={(pos, need) => {
                  if (onProposePlayer) {
                    onProposePlayer(club, need || `Recrutement poste ${pos}`);
                  } else {
                    handleWhatsAppContact(need || `Recrutement poste ${pos}`);
                  }
                }}
              />
            </div>
          )}

          {/* TAB 3: MERCATO NEEDS */}
          {activeTab === 'MERCATO' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-mono font-bold uppercase text-white tracking-wider flex items-center gap-1.5">
                  <span>🎯</span>
                  <span>Besoins Mercato & Profils Recherchés Actuellement</span>
                </h3>
                <span className="text-[10px] font-mono text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">
                  {club.openNeeds.length} postes ouverts
                </span>
              </div>

              {club.openNeeds.length === 0 ? (
                <p className="text-xs text-gray-400 italic">Aucun besoin public actuellement communiqué par la cellule de recrutement.</p>
              ) : (
                <div className="space-y-2.5">
                  {club.openNeeds.map((need, index) => (
                    <div
                      key={index}
                      className="p-4 rounded-xl bg-[#091122] border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="flex items-start gap-2.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shrink-0 mt-1 animate-ping" />
                        <div>
                          <span className="text-xs font-bold text-white block">{need}</span>
                          <span className="text-[10px] text-gray-400 font-mono mt-0.5 block">
                            Profil supervisé et validé par Seydou Mario Traoré · Processus prioritaire
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                        <button
                          onClick={() => {
                            if (onProposePlayer) {
                              onProposePlayer(club, need);
                            } else {
                              handleWhatsAppContact(need);
                            }
                          }}
                          className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer active:scale-95 shadow-sm"
                        >
                          Proposer un Talent
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: ALUMNI */}
          {activeTab === 'ALUMNI' && (
            <div className="space-y-4">
              <h3 className="text-xs font-mono font-bold uppercase text-white tracking-wider flex items-center gap-1.5">
                <span>⭐</span>
                <span>Talents & Légendes Formés ou Transférés par {club.name}</span>
              </h3>

              {club.famousAlumni && club.famousAlumni.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {club.famousAlumni.map((player, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-[#050914] border border-white/10 text-xs font-mono text-gray-200 flex items-center gap-2"
                    >
                      <span className="text-amber-400 text-sm">★</span>
                      <span className="font-bold">{player}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-gray-400">Aucun historique d'anciens joueurs répertorié pour ce club.</p>
              )}
            </div>
          )}
        </div>

        {/* FOOTER ACTIONS */}
        <div className="p-4 sm:p-5 border-t border-white/10 bg-[#0A142A]/80 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {club.website && (
              <a
                href={club.website}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white text-xs font-mono font-bold border border-white/10 transition-colors"
              >
                🌐 Site Officiel
              </a>
            )}

            {onStartConversation && (
              <button
                onClick={() => onStartConversation(club)}
                className="px-3.5 py-2 rounded-xl bg-[#0E1527] hover:bg-[#131C33] text-gray-200 border border-white/15 text-xs font-bold transition-colors cursor-pointer"
              >
                💬 Message Direct
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleWhatsAppContact()}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer flex items-center gap-1.5"
            >
              <span>📱</span>
              <span>Desk Mario Traoré (WhatsApp)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
