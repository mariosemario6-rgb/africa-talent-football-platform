import React from 'react';
import { usePushNotifications } from '../../context/PushNotificationContext';
import { useLanguage } from '../../context/LanguageContext';

export const PushNotificationBanner: React.FC = () => {
  const { t } = useLanguage();
  const { activePushToast, dismissPushToast, setIsMercatoModalOpen } = usePushNotifications();

  if (!activePushToast) return null;

  return (
    <div
      role="alert"
      className="fixed top-4 left-3 right-3 sm:left-auto sm:right-6 sm:max-w-md z-50 animate-in slide-in-from-top-6 duration-300 select-none"
    >
      <div className="bg-[#070D1B]/95 backdrop-blur-xl border-2 border-amber-500/80 rounded-2xl p-4 shadow-2xl shadow-black/90 ring-1 ring-amber-400/40 flex items-start gap-3.5">
        {/* ATF Icon Badge */}
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black text-sm shrink-0 shadow-md shadow-amber-500/30">
          ATF
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] font-mono uppercase font-bold text-amber-400 tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              Notification Directe
            </span>
            <span className="text-[10px] text-gray-400 font-mono">À l’instant</span>
          </div>

          <h4 className="text-xs font-black text-white mt-0.5 truncate">
            {activePushToast.title}
          </h4>

          <p className="text-[11px] text-gray-300 mt-1 line-clamp-2 leading-relaxed">
            {activePushToast.body}
          </p>

          <div className="flex items-center gap-2 mt-2.5">
            <button
              onClick={() => {
                dismissPushToast();
                setIsMercatoModalOpen(true);
              }}
              className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-[10px] uppercase tracking-wider transition-colors cursor-pointer"
            >
              Consulter l'Alerte
            </button>
            <button
              onClick={dismissPushToast}
              className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-gray-300 text-[10px] transition-colors cursor-pointer"
            >
              Fermer
            </button>
          </div>
        </div>

        {/* Close Cross */}
        <button
          onClick={dismissPushToast}
          className="text-gray-400 hover:text-white p-1 text-xs cursor-pointer"
          aria-label="Fermer"
        >
          ✕
        </button>
      </div>
    </div>
  );
};
