import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { useLanguage } from '../../context/LanguageContext';

interface PhoneQRCodeProps {
  url?: string;
  size?: number;
  showShareButtons?: boolean;
}

export const PhoneQRCode: React.FC<PhoneQRCodeProps> = ({
  url,
  size = 220,
  showShareButtons = true,
}) => {
  const { t } = useLanguage();
  const liveDeploymentUrl =
    typeof window !== 'undefined'
      ? window.location.origin
      : 'https://ais-pre-xdk4mc5kqlr5epxponmd4f-71771660900.europe-west1.run.app';

  // Use the active live deployment URL to guarantee 100% immediate phone opening
  const activeUrl = url || liveDeploymentUrl;

  const [svgDataUrl, setSvgDataUrl] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    QRCode.toString(
      activeUrl,
      {
        type: 'svg',
        margin: 1,
        color: {
          dark: '#000000',
          light: '#FFFFFF',
        },
        errorCorrectionLevel: 'M',
      },
      (err, svgString) => {
        if (!err && svgString) {
          const encoded = 'data:image/svg+xml;utf8,' + encodeURIComponent(svgString);
          setSvgDataUrl(encoded);
        }
      }
    );
  }, [activeUrl]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(activeUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Africa Talent Football',
          text: activeUrl,
          url: activeUrl,
        });
      } catch {
        // User cancelled
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div className="flex flex-col items-center p-5 rounded-2xl bg-gradient-to-b from-[#0B1325] to-[#070B16] border border-amber-500/40 shadow-xl text-center space-y-4">
      <div className="space-y-1">
        <span className="px-2.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold uppercase tracking-wider border border-emerald-500/40">
          {t('phoneQr.badgeScan')}
        </span>
        <h4 className="text-white font-black text-sm sm:text-base">
          {t('phoneQr.scanTitle')}
        </h4>
        <p className="text-gray-300 text-xs max-w-xs mx-auto">
          {t('phoneQr.scanSubtitle')}
        </p>
      </div>

      {/* QR Code Container with High Contrast and ATF badge */}
      <div className="relative p-3 bg-white rounded-2xl shadow-2xl border-4 border-amber-400 group">
        {svgDataUrl ? (
          <img
            src={svgDataUrl}
            alt="QR Code"
            width={size}
            height={size}
            className="rounded-lg object-contain transition-transform group-hover:scale-105 duration-200"
          />
        ) : (
          <div
            style={{ width: size, height: size }}
            className="flex items-center justify-center bg-gray-100 rounded-lg text-black font-bold text-xs"
          >
            {t('imageUpload.processing')}
          </div>
        )}

        {/* Center overlay badge */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-10 h-10 rounded-xl bg-[#040711] border-2 border-amber-400 flex items-center justify-center text-amber-400 font-black text-xs shadow-lg">
            ATF
          </div>
        </div>
      </div>

      <div className="space-y-1">
        <div className="text-[11px] font-mono text-emerald-400 flex items-center justify-center gap-2 font-bold">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>{t('phoneQr.activeLink')}</span>
        </div>
        <div className="text-[10px] font-mono text-gray-400">
          SSL HTTPS · PWA & Android
        </div>
      </div>

      {/* Share / Copy Action Buttons */}
      {showShareButtons && (
        <div className="w-full flex flex-wrap items-center justify-center gap-2 pt-1">
          <button
            onClick={handleCopy}
            className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer border border-white/10"
            title={t('phoneQr.copyLink')}
          >
            <span>{copied ? '✓' : '📋'}</span>
            <span>{copied ? t('phoneQr.copied') : t('phoneQr.copyLink')}</span>
          </button>

          <a
            href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
              "Africa Talent Football App : " + activeUrl
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3.5 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-bold text-xs transition-colors flex items-center gap-1.5 border border-emerald-500/40"
            title="WhatsApp"
          >
            <span>💬</span>
            <span>WhatsApp</span>
          </a>

          {typeof navigator !== 'undefined' && 'share' in navigator && (
            <button
              onClick={handleShare}
              className="px-3.5 py-2 rounded-xl bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 font-bold text-xs transition-colors flex items-center gap-1.5 border border-blue-500/40 cursor-pointer"
              title={t('phoneQr.share')}
            >
              <span>📲</span>
              <span>{t('phoneQr.share')}</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};
