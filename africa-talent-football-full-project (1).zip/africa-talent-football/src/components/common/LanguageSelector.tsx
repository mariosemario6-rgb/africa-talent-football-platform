import React, { useState, useRef, useEffect } from 'react';
import { useLanguage, WORLD_LANGUAGES, Language } from '../../context/LanguageContext';

interface LanguageSelectorProps {
  compact?: boolean;
  showInlineFlags?: boolean;
  className?: string;
}

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  compact = false,
  showInlineFlags = true,
  className = '',
}) => {
  const { language, currentLanguageMeta, setLanguage } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (code: Language) => {
    setLanguage(code);
    setIsOpen(false);
  };

  return (
    <div ref={containerRef} className={`relative flex items-center gap-1.5 ${className}`}>
      {/* INLINE 10 WORLD LANGUAGES FLAGS STRIP (Visible on md/lg screens) */}
      {showInlineFlags && (
        <div className="hidden xl:flex items-center gap-1 bg-[#090E1B] border border-amber-500/30 rounded-xl p-1 shadow-sm">
          {WORLD_LANGUAGES.map((lang) => {
            const isSelected = lang.code === language;
            return (
              <button
                key={lang.code}
                onClick={() => handleSelect(lang.code)}
                title={`${lang.name} (${lang.nativeName})`}
                aria-label={`Passer en ${lang.name}`}
                className={`px-1.5 py-1 rounded-lg text-xs flex items-center gap-1 transition-all cursor-pointer font-mono font-bold ${
                  isSelected
                    ? 'bg-amber-500 text-black shadow-md shadow-amber-500/30 scale-105'
                    : 'text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <span className="text-sm">{lang.flag}</span>
                <span className="text-[10px] uppercase">{lang.code}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* DROPDOWN TRIGGER BUTTON (For all screen sizes or compact view) */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border transition-all cursor-pointer shadow-sm ${
          isOpen
            ? 'bg-amber-500/20 border-amber-400 text-white'
            : 'bg-[#0E1527] hover:bg-[#141E38] border-white/15 hover:border-amber-400/50 text-gray-200'
        }`}
        title="Sélectionner parmi les 10 langues mondiales / 10 World Languages"
        aria-label="Choisir la langue parmi les 10 langues"
        aria-expanded={isOpen}
      >
        <span className="text-base leading-none">{currentLanguageMeta.flag}</span>
        <span className="text-[11px] font-bold font-mono uppercase tracking-wider text-amber-300">
          {currentLanguageMeta.code.toUpperCase()}
        </span>
        <span className="hidden sm:inline text-[10px] font-mono text-gray-400">
          (10 Langues)
        </span>
        <span className="text-[9px] text-gray-400">▾</span>
      </button>

      {/* 10 LANGUAGES DROPDOWN MENU */}
      {isOpen && (
        <div className="absolute right-0 top-full mt-2 w-56 rounded-2xl bg-[#090E1B] border-2 border-amber-500/50 shadow-2xl py-2 z-50 animate-in fade-in duration-100 ring-1 ring-black/80">
          <div className="px-3.5 py-1.5 border-b border-white/10 flex items-center justify-between">
            <span className="text-[10px] font-mono text-amber-400 uppercase tracking-wider font-bold">
              🌍 10 Langues Mondiales
            </span>
            <span className="text-[9px] font-mono text-emerald-400 font-bold">
              FIFA Global
            </span>
          </div>

          <div className="max-h-80 overflow-y-auto py-1 divide-y divide-white/5">
            {WORLD_LANGUAGES.map((lang) => {
              const isSelected = lang.code === language;
              return (
                <button
                  key={lang.code}
                  onClick={() => handleSelect(lang.code)}
                  className={`w-full px-3.5 py-2 text-left text-xs flex items-center justify-between transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-amber-500/20 text-amber-300 font-bold'
                      : 'text-gray-300 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-lg">{lang.flag}</span>
                    <div>
                      <div className="font-bold text-white text-xs">{lang.nativeName}</div>
                      <div className="text-[10px] text-gray-400">{lang.name}</div>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono font-bold uppercase px-1.5 py-0.5 rounded bg-white/5 text-amber-300">
                    {lang.code}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="px-3.5 pt-2 border-t border-white/10 text-[9px] font-mono text-gray-500 text-center">
            Traduction instantanée pour les 6 confédérations FIFA
          </div>
        </div>
      )}
    </div>
  );
};
