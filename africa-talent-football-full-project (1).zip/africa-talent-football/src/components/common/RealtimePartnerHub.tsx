import React, { useState, useMemo } from 'react';
import { RealtimePartnerUpdate } from '../../types/database';
import { getRealtimePartnerUpdates, syncLivePartnerIntelligence } from '../../data/realtimePartnerData';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';

interface RealtimePartnerHubProps {
  onNavigate?: (view: string, payload?: any) => void;
  compact?: boolean;
  highlightCategory?: 'ALL' | 'CLUB' | 'BANK' | 'COMPANY';
}

export const RealtimePartnerHub: React.FC<RealtimePartnerHubProps> = ({
  onNavigate,
  compact = false,
  highlightCategory = 'ALL'
}) => {
  const { t } = useLanguage();
  const { currentUser, isPremium } = useAuth();
  const [updates, setUpdates] = useState<RealtimePartnerUpdate[]>(() => getRealtimePartnerUpdates());
  const [filterType, setFilterType] = useState<'ALL' | 'CLUB' | 'BANK' | 'COMPANY'>(highlightCategory);
  const [searchTerm, setSearchTerm] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>('En direct');
  const [selectedUpdate, setSelectedUpdate] = useState<RealtimePartnerUpdate | null>(null);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const handleSync = () => {
    setIsSyncing(true);
    setFeedbackMsg(null);
    setTimeout(() => {
      const refreshed = syncLivePartnerIntelligence();
      setUpdates(refreshed);
      setIsSyncing(false);
      const now = new Date();
      setLastSyncTime(now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setFeedbackMsg('Données synchronisées en direct depuis les serveurs des clubs, banques et entreprises.');
      setTimeout(() => setFeedbackMsg(null), 4000);
    }, 600);
  };

  const filteredUpdates = useMemo(() => {
    return updates.filter((u) => {
      const matchesType = filterType === 'ALL' || u.sourceType === filterType;
      const matchesSearch =
        searchTerm.trim() === '' ||
        u.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        u.sourceName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        u.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
        u.country.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesType && matchesSearch;
    });
  }, [updates, filterType, searchTerm]);

  const counts = useMemo(() => {
    return {
      all: updates.length,
      clubs: updates.filter((u) => u.sourceType === 'CLUB').length,
      banks: updates.filter((u) => u.sourceType === 'BANK').length,
      companies: updates.filter((u) => u.sourceType === 'COMPANY').length
    };
  }, [updates]);

  return (
    <div className="bg-[#080D1A] rounded-3xl border border-white/10 overflow-hidden shadow-2xl space-y-6 text-left">
      {/* Top Header */}
      <div className="p-6 sm:p-7 border-b border-white/10 bg-gradient-to-r from-blue-950/40 via-amber-950/20 to-transparent flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
            <span className="text-[11px] font-mono uppercase tracking-widest text-emerald-400 font-black">
              FLUX EN TEMPS RÉEL INTERCONNECTÉ
            </span>
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold">
              Clubs · Banques · Entreprises
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            Centre d'Intelligence en Direct & Opportunités Marché
          </h2>
          <p className="text-xs text-gray-400 max-w-2xl">
            Réception instantanée des appels d'offres mercatos, garanties bancaires FIFA Article 19,
            et bourses de sponsoring émises en direct par les institutions agréées.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleSync}
            disabled={isSyncing}
            className="px-4 py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 font-mono text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md disabled:opacity-50"
          >
            <span className={`text-base ${isSyncing ? 'animate-spin' : ''}`}>🔄</span>
            <span>{isSyncing ? 'Synchronisation...' : 'Actualiser en Direct'}</span>
          </button>
        </div>
      </div>

      {feedbackMsg && (
        <div className="mx-6 p-3.5 rounded-2xl bg-emerald-950/70 border border-emerald-500/50 text-emerald-200 text-xs font-mono flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <span>✓</span>
            <span>{feedbackMsg}</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-bold">Mis à jour à {lastSyncTime}</span>
        </div>
      )}

      {/* Filter Tabs & Search Bar */}
      <div className="px-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Tabs */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setFilterType('ALL')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                filterType === 'ALL'
                  ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20'
                  : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/5'
              }`}
            >
              <span>Tous les Flux</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/20">{counts.all}</span>
            </button>

            <button
              onClick={() => setFilterType('CLUB')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                filterType === 'CLUB'
                  ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/20'
                  : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/5'
              }`}
            >
              <span>🏟️ Clubs & Mercato</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/20">{counts.clubs}</span>
            </button>

            <button
              onClick={() => setFilterType('BANK')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                filterType === 'BANK'
                  ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/20'
                  : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/5'
              }`}
            >
              <span>🏦 Banques & Financements</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/20">{counts.banks}</span>
            </button>

            <button
              onClick={() => setFilterType('COMPANY')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                filterType === 'COMPANY'
                  ? 'bg-purple-500 text-white shadow-lg shadow-purple-500/20'
                  : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/5'
              }`}
            >
              <span>🏢 Entreprises & Sponsors</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/20">{counts.companies}</span>
            </button>
          </div>

          {/* Search box */}
          <div className="relative w-full sm:w-64">
            <input
              type="text"
              placeholder="Rechercher par club, banque..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
            />
            <span className="absolute left-2.5 top-2 text-gray-500 text-xs">🔍</span>
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1.5 text-gray-400 hover:text-white text-xs"
              >
                ✕
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Grid of Real-Time Updates */}
      <div className="px-6 pb-6">
        {filteredUpdates.length === 0 ? (
          <div className="p-12 text-center text-gray-500 font-mono text-xs rounded-2xl border border-dashed border-white/10">
            Aucune mise à jour ne correspond à vos critères de recherche.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredUpdates.map((item) => {
              const isClub = item.sourceType === 'CLUB';
              const isBank = item.sourceType === 'BANK';
              const isComp = item.sourceType === 'COMPANY';

              const badgeColor = isClub
                ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                : isBank
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-purple-500/20 text-purple-300 border-purple-500/40';

              return (
                <div
                  key={item.id}
                  className="p-5 rounded-2xl bg-[#050810] border border-white/10 hover:border-amber-400/50 transition-all space-y-3.5 group flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    {/* Top item badge and timestamp */}
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold border ${badgeColor}`}>
                          {item.urgentBadge || (isClub ? 'CLUB' : isBank ? 'BANQUE' : 'SPONSOR')}
                        </span>
                        {item.countryFlag && (
                          <span className="text-xs" title={item.country}>
                            {item.countryFlag}
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] font-mono text-amber-400 flex items-center gap-1 font-bold">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                        {item.timestamp}
                      </span>
                    </div>

                    {/* Source Name & Category */}
                    <div className="flex items-center gap-3">
                      {item.sourceLogo && (
                        <img
                          src={item.sourceLogo}
                          alt={item.sourceName}
                          className="w-10 h-10 rounded-xl object-cover border border-white/10 shrink-0"
                        />
                      )}
                      <div>
                        <h4 className="text-sm font-black text-white group-hover:text-amber-400 transition-colors line-clamp-1">
                          {item.sourceName}
                        </h4>
                        <span className="text-[10px] font-mono text-gray-400 block line-clamp-1">
                          {item.category} · {item.country}
                        </span>
                      </div>
                    </div>

                    {/* Title & Summary */}
                    <div>
                      <h5 className="text-xs font-bold text-gray-100 mb-1 leading-snug">
                        {item.title}
                      </h5>
                      <p className="text-xs text-gray-400 leading-relaxed line-clamp-3">
                        {item.summary}
                      </p>
                    </div>

                    {/* Specific details */}
                    {item.details?.budgetOrValuation && (
                      <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-[11px] font-mono text-gray-300 flex items-center justify-between">
                        <span className="text-gray-400">Montant / Dotation :</span>
                        <strong className="text-amber-300">{item.details.budgetOrValuation}</strong>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                    <button
                      onClick={() => setSelectedUpdate(item)}
                      className="text-xs font-mono text-gray-400 hover:text-white transition-colors cursor-pointer"
                    >
                      Détails complets ➔
                    </button>
                    <button
                      onClick={() => setSelectedUpdate(item)}
                      className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-md"
                    >
                      {item.actionLabel}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Detail / Application Modal */}
      {selectedUpdate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div
            className="w-full max-w-2xl bg-[#090D1A] border-2 border-amber-500/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="p-6 border-b border-white/10 bg-gradient-to-r from-amber-500/10 via-transparent to-transparent flex items-center justify-between">
              <div className="flex items-center gap-3">
                {selectedUpdate.sourceLogo && (
                  <img
                    src={selectedUpdate.sourceLogo}
                    alt={selectedUpdate.sourceName}
                    className="w-12 h-12 rounded-xl object-cover border border-amber-400"
                  />
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-amber-400 font-mono">
                      {selectedUpdate.urgentBadge || selectedUpdate.category}
                    </span>
                    <span className="text-xs">{selectedUpdate.countryFlag}</span>
                  </div>
                  <h3 className="text-base sm:text-lg font-black text-white">
                    {selectedUpdate.sourceName}
                  </h3>
                </div>
              </div>
              <button
                onClick={() => setSelectedUpdate(null)}
                className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white flex items-center justify-center text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-5">
              <div className="space-y-2">
                <h4 className="text-sm sm:text-base font-black text-white">
                  {selectedUpdate.title}
                </h4>
                <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
                  {selectedUpdate.summary}
                </p>
              </div>

              {/* Requirements & Info */}
              {selectedUpdate.details && (
                <div className="p-4 rounded-2xl bg-[#050810] border border-white/10 space-y-3 font-mono text-xs">
                  <h5 className="font-bold text-amber-400 uppercase tracking-wider text-[11px]">
                    Critères & Modalités Requises :
                  </h5>
                  {selectedUpdate.details.requirements && (
                    <ul className="space-y-1.5 text-gray-300 list-disc list-inside">
                      {selectedUpdate.details.requirements.map((req, i) => (
                        <li key={i}>{req}</li>
                      ))}
                    </ul>
                  )}
                  {selectedUpdate.details.budgetOrValuation && (
                    <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                      <span className="text-gray-400">Enveloppe / Valeur financière :</span>
                      <strong className="text-emerald-400 font-bold">
                        {selectedUpdate.details.budgetOrValuation}
                      </strong>
                    </div>
                  )}
                  {selectedUpdate.details.deadline && (
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Date limite de soumission :</span>
                      <strong className="text-red-400 font-bold">{selectedUpdate.details.deadline}</strong>
                    </div>
                  )}
                  {selectedUpdate.details.quotaSeats && (
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Places disponibles :</span>
                      <strong className="text-amber-300 font-bold">{selectedUpdate.details.quotaSeats}</strong>
                    </div>
                  )}
                </div>
              )}

              {/* Direct Desk Connection Info */}
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <span className="text-[11px] font-mono font-bold text-amber-400 uppercase block">
                    Desk Direct Partenaire :
                  </span>
                  <p className="text-xs text-gray-300">
                    Contact direct certifié : {selectedUpdate.contactEmail || 'desk@africatalentfoot.com'}
                  </p>
                </div>
                {selectedUpdate.contactPhone && (
                  <a
                    href={`https://wa.me/${selectedUpdate.contactPhone.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold shrink-0 transition-colors"
                  >
                    WhatsApp Direct
                  </a>
                )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-5 border-t border-white/10 bg-[#060A14] flex items-center justify-between gap-3">
              <button
                onClick={() => setSelectedUpdate(null)}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 font-mono text-xs cursor-pointer"
              >
                Fermer
              </button>
              <div className="flex items-center gap-2">
                {selectedUpdate.officialLink && (
                  <a
                    href={selectedUpdate.officialLink}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs transition-colors"
                  >
                    Site Officiel ↗
                  </a>
                )}
                <button
                  onClick={() => {
                    setFeedbackMsg(`Votre demande a été transmise en priorité aux équipes de ${selectedUpdate.sourceName}.`);
                    setSelectedUpdate(null);
                  }}
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider cursor-pointer shadow-lg"
                >
                  Confirmer ma Soumission Directe ➔
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
