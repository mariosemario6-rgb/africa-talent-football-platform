import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { FOUNDER_INFO } from '../../data/demoData';

interface SharePlatformModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SharePlatformModal: React.FC<SharePlatformModalProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();
  const [copied, setCopied] = useState(false);

  const currentUrl =
    typeof window !== 'undefined' && window.location.origin && window.location.origin.includes('http')
      ? window.location.origin
      : 'https://africa-talent-football.ai.studio';

  const shareTitle = 'AFRICA TALENT FOOTBALL - Plateforme Officielle de Détection';
  const shareText = `Découvrez AFRICA TALENT FOOTBALL, le réseau officiel de détection de talents du football africain, vidéos de matchs intégrales, fiches certifiées et annuaire mondial des clubs.\nDirection : ${FOUNDER_INFO.name}, ${FOUNDER_INFO.officialTitle}.\nAccédez immédiatement à la plateforme en ligne :`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(currentUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
      const input = document.createElement('input');
      input.value = currentUrl;
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      document.body.removeChild(input);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: `${shareText}\n${currentUrl}`,
          url: currentUrl,
        });
      } catch (err) {
        console.warn('Native share dismissed or failed', err);
      }
    } else {
      handleCopyLink();
    }
  };

  if (!isOpen) return null;

  const encodedUrl = encodeURIComponent(currentUrl);
  const encodedText = encodeURIComponent(`${shareText}\n${currentUrl}`);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#090E1B] border border-amber-500/40 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl relative text-left">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-gray-400 hover:text-white p-2 rounded-full hover:bg-white/10 transition-colors"
        >
          ✕
        </button>

        {/* Header */}
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black text-xl shadow-lg shadow-amber-500/30 shrink-0">
            ATF
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Plateforme En Ligne
              </span>
              <span className="text-[10px] font-mono text-emerald-400 font-bold">● Disponible Mondialement</span>
            </div>
            <h2 className="text-xl font-black text-white mt-0.5">
              Partager Africa Talent Football
            </h2>
            <p className="text-xs text-gray-400">
              Diffusez la plateforme auprès des clubs, directeurs sportifs, scouts et partenaires.
            </p>
          </div>
        </div>

        {/* Copy Link Input Box */}
        <div className="space-y-2">
          <label className="text-[11px] font-mono text-gray-400 uppercase tracking-wider flex items-center justify-between">
            <span>Lien direct officiel :</span>
            <span className="text-emerald-400 font-bold lowercase">immédiatement accessible</span>
          </label>
          <div className="flex items-center gap-2 bg-[#050810] border border-white/15 rounded-xl p-2 focus-within:border-amber-500">
            <span className="text-sm pl-1">🔗</span>
            <input
              type="text"
              readOnly
              value={currentUrl}
              className="bg-transparent text-white text-xs font-mono flex-1 focus:outline-none selection:bg-amber-500 selection:text-black truncate"
            />
            <button
              onClick={handleCopyLink}
              className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer shrink-0"
            >
              {copied ? '✓ Copié !' : 'Copier'}
            </button>
          </div>
          {copied && (
            <p className="text-xs text-emerald-400 font-bold flex items-center gap-1.5">
              <span>✓</span> Le lien a été copié dans votre presse-papier !
            </p>
          )}
        </div>

        {/* One-click native share if on mobile */}
        {typeof navigator !== 'undefined' && 'share' in navigator && (
          <button
            onClick={handleNativeShare}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-amber-500/20 cursor-pointer flex items-center justify-center gap-2"
          >
            <span>📲 Partager via mon smartphone / tablette</span>
          </button>
        )}

        {/* Social Share Channels */}
        <div className="space-y-2">
          <label className="text-[11px] font-mono text-gray-400 uppercase tracking-wider block">
            Partage Rapide par Canal :
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {/* WhatsApp */}
            <a
              href={`https://api.whatsapp.com/send?text=${encodedText}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-xl bg-[#25D366]/10 hover:bg-[#25D366]/20 border border-[#25D366]/30 text-[#25D366] text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-colors text-center cursor-pointer"
            >
              <span className="text-xl">💬</span>
              <span>WhatsApp</span>
            </a>

            {/* LinkedIn */}
            <a
              href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-xl bg-[#0077B5]/10 hover:bg-[#0077B5]/20 border border-[#0077B5]/30 text-[#0077B5] text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-colors text-center cursor-pointer"
            >
              <span className="text-xl">💼</span>
              <span>LinkedIn</span>
            </a>

            {/* X / Twitter */}
            <a
              href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareTitle)}&url=${encodedUrl}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-colors text-center cursor-pointer"
            >
              <span className="text-xl">𝕏</span>
              <span>X (Twitter)</span>
            </a>

            {/* Email */}
            <a
              href={`mailto:?subject=${encodeURIComponent(shareTitle)}&body=${encodedText}`}
              className="p-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-400 text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-colors text-center cursor-pointer"
            >
              <span className="text-xl">✉️</span>
              <span>Email</span>
            </a>
          </div>
        </div>

        {/* Founder Signature Badge */}
        <div className="p-3 rounded-xl bg-[#050810] border border-white/5 flex items-center justify-between text-[11px] text-gray-400">
          <div>
            <span className="text-gray-500">Direction :</span> <strong className="text-white">{FOUNDER_INFO.name}</strong>
            <span className="block text-[10px] text-amber-400 font-mono">{FOUNDER_INFO.officialTitle}</span>
          </div>
          <div className="text-right">
            <span className="text-gray-500">Contact :</span> <span className="text-white">{FOUNDER_INFO.phone}</span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors cursor-pointer"
        >
          Fermer
        </button>
      </div>
    </div>
  );
};
