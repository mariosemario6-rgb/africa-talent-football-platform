import React, { useState } from 'react';
import { FeedPost } from '../../types/database';
import { FOUNDER_INFO } from '../../data/demoData';
import { useLanguage } from '../../context/LanguageContext';

interface PostShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  post: FeedPost | null;
}

export const PostShareModal: React.FC<PostShareModalProps> = ({ isOpen, onClose, post }) => {
  const { t } = useLanguage();
  const [copied, setCopied] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  if (!isOpen || !post) return null;

  const originUrl =
    typeof window !== 'undefined' && window.location.origin && window.location.origin.includes('http')
      ? window.location.origin
      : 'https://africa-talent-football.ai.studio';

  const postShareUrl = `${originUrl}/?view=feed&post=${post.id}`;
  const shareTitle = `${t('postShare.shareTitle')} : ${post.authorName}`;
  const shareExcerpt = post.content.length > 140 ? `${post.content.slice(0, 140)}...` : post.content;
  const fullShareText = `${shareTitle} :\n"${shareExcerpt}"\n\nAfrica Talent Football Network :`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(`${fullShareText}\n${postShareUrl}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      const input = document.createElement('input');
      input.value = `${fullShareText}\n${postShareUrl}`;
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      document.body.removeChild(input);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: fullShareText,
          url: postShareUrl,
        });
      } catch (err) {
        console.warn('Share canceled', err);
      }
    } else {
      handleCopy();
    }
  };

  const handleDownloadDossier = () => {
    setIsDownloading(true);
    setTimeout(() => {
      const header = `========================================================\n` +
        `AFRICA TALENT FOOTBALL - OFFICIAL B2B DOSSIER\n` +
        `Supervision : SEYDOU MARIO TRAORÉ\n` +
        `Platform : ${originUrl}\n` +
        `========================================================\n\n`;

      const meta = `PUBLICATION ID : #${post.id}\n` +
        `AUTHOR : ${post.authorName}\n` +
        `TITLE : ${post.authorTitle}\n` +
        `ORGANIZATION : ${post.authorOrg}\n` +
        `STATUS : ${post.isPremiumAuthor ? 'PREMIUM VIP MEMBER' : 'VERIFIED MEMBER'}\n` +
        `TAGS : ${post.tags.join(' ')}\n\n` +
        `--------------------------------------------------------\n` +
        `CONTENT :\n` +
        `--------------------------------------------------------\n` +
        `${post.content}\n\n`;

      let playerSection = '';
      if (post.playerAttachment) {
        const p = post.playerAttachment;
        playerSection = `--------------------------------------------------------\n` +
          `ATTACHED TALENT PROFILE :\n` +
          `--------------------------------------------------------\n` +
          `NAME : ${p.firstName} ${p.lastName}\n` +
          `POSITION : ${p.primaryPosition} | AGE : ${p.calculatedAge}\n` +
          `CLUB : ${p.currentClub || p.academy}\n` +
          `MARKET VALUE : ${p.marketValueDisplay}\n\n`;
      }

      const footer = `========================================================\n` +
        `AFRICA TALENT FOOTBALL COMPLIANCE OFFICE\n` +
        `WhatsApp : +225 05 44 42 01 62\n` +
        `E-mail : ${FOUNDER_INFO.email}\n` +
        `========================================================\n`;

      const blob = new Blob([header + meta + playerSection + footer], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ATF_REPORT_${post.id}_${post.authorName.replace(/\s+/g, '_')}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setIsDownloading(false);
    }, 400);
  };

  const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(`${fullShareText}\n${postShareUrl}`)}`;
  const linkedInUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(postShareUrl)}`;
  const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareTitle)}&url=${encodeURIComponent(postShareUrl)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#090E1B] border-2 border-amber-500/50 rounded-3xl max-w-lg w-full p-6 sm:p-7 space-y-5 shadow-2xl relative text-left">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-gray-400 hover:text-white p-2 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
          aria-label={t('modal.close')}
        >
          ✕
        </button>

        {/* Header */}
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-xl text-amber-300 font-bold shrink-0 shadow-lg shadow-amber-500/20">
            ↗
          </div>
          <div>
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
              {t('shareModal.title')}
            </span>
            <h3 className="text-base sm:text-lg font-black text-white mt-0.5">
              {t('postShare.modalTitle')}
            </h3>
            <p className="text-xs text-gray-400">
              {post.authorName} · {post.authorOrg}
            </p>
          </div>
        </div>

        {/* Post Preview Card */}
        <div className="p-3.5 rounded-2xl bg-[#050810] border border-white/10 space-y-2">
          <p className="text-xs text-gray-300 line-clamp-3 italic">
            "{post.content}"
          </p>
          {post.playerAttachment && (
            <div className="flex items-center gap-2 pt-1 border-t border-white/5 text-[11px] text-amber-300 font-mono">
              <span>⚽</span>
              <strong>{post.playerAttachment.firstName} {post.playerAttachment.lastName} ({post.playerAttachment.primaryPosition})</strong>
            </div>
          )}
        </div>

        {/* Share Channel Buttons */}
        <div className="space-y-2.5">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 hover:border-emerald-400 hover:bg-emerald-900/50 hover:scale-105 active:scale-95 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
            >
              <span>💬</span>
              <span>WhatsApp</span>
            </a>

            <a
              href={linkedInUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-xl bg-blue-950/60 border border-blue-500/40 hover:border-blue-400 hover:bg-blue-900/50 hover:scale-105 active:scale-95 text-blue-300 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
            >
              <span>💼</span>
              <span>LinkedIn</span>
            </a>

            <a
              href={twitterUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 hover:scale-105 active:scale-95 text-gray-200 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
            >
              <span>🐦</span>
              <span>Twitter / X</span>
            </a>
          </div>

          <div className="flex gap-2 pt-1">
            <button
              onClick={handleCopy}
              className={`flex-1 py-2.5 rounded-xl font-mono text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer hover:scale-105 active:scale-95 shadow-md ${
                copied
                  ? 'bg-emerald-500 text-black'
                  : 'bg-[#0E1527] border border-amber-500/40 text-amber-300 hover:bg-amber-500 hover:text-black'
              }`}
            >
              <span>{copied ? '✓' : '📋'}</span>
              <span>{copied ? t('postShare.linkCopied') : t('postShare.copyLink')}</span>
            </button>

            {typeof navigator !== 'undefined' && typeof navigator.share === 'function' && (
              <button
                onClick={handleNativeShare}
                className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 hover:scale-105 active:scale-95 text-white text-xs font-bold transition-all cursor-pointer border border-white/20"
              >
                📲
              </button>
            )}
          </div>
        </div>

        {/* Action DOWNLOAD */}
        <div className="pt-3 border-t border-white/10 space-y-2">
          <button
            onClick={handleDownloadDossier}
            disabled={isDownloading}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 hover:shadow-xl hover:shadow-emerald-900/30 hover:scale-[1.02] active:scale-95 text-white font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50"
          >
            <span className="text-base">📥</span>
            <span>{t('postShare.downloadDossier')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
