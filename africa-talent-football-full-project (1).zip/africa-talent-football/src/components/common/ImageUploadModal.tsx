import React, { useState, useRef } from 'react';
import { compressImageFile, PRESET_AVATARS, PRESET_COVERS, PresetImage } from '../../utils/imageUpload';
import { useLanguage } from '../../context/LanguageContext';

interface ImageUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'avatar' | 'cover';
  currentImageUrl?: string;
  onSave: (newUrl: string) => Promise<void> | void;
}

export const ImageUploadModal: React.FC<ImageUploadModalProps> = ({
  isOpen,
  onClose,
  type,
  currentImageUrl,
  onSave
}) => {
  const { t } = useLanguage();
  const isAvatar = type === 'avatar';
  const title = isAvatar ? t('imageUpload.avatarTitle') : t('imageUpload.coverTitle');
  const subtitle = isAvatar
    ? t('imageUpload.avatarSubtitle')
    : t('imageUpload.coverSubtitle');

  const [previewUrl, setPreviewUrl] = useState<string>(currentImageUrl || '');
  const [isProcessing, setIsProcessing] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const presets = isAvatar ? PRESET_AVATARS : PRESET_COVERS;

  const handleFileChange = async (file: File) => {
    setErrorMsg(null);
    setIsProcessing(true);
    try {
      // For avatar: 400x400 max, for cover: 1200x450 max
      const maxWidth = isAvatar ? 400 : 1200;
      const maxHeight = isAvatar ? 400 : 450;
      const compressed = await compressImageFile(file, maxWidth, maxHeight, 0.85);
      setPreviewUrl(compressed);
    } catch (err: any) {
      setErrorMsg(err.message || t('imageUpload.errorProcessing'));
    } finally {
      setIsProcessing(false);
    }
  };

  const onFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileChange(e.target.files[0]);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  };

  const handleSelectPreset = (preset: PresetImage) => {
    setPreviewUrl(preset.url);
    setErrorMsg(null);
  };

  const handleConfirm = async () => {
    setIsProcessing(true);
    try {
      await onSave(previewUrl);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || t('imageUpload.errorSaving'));
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRemove = () => {
    setPreviewUrl('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-2xl bg-[#090D1A] border-2 border-amber-500/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-amber-500/10 via-transparent to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 text-lg font-black">
              {isAvatar ? '👤' : '🖼️'}
            </div>
            <div>
              <h3 className="text-lg font-black text-white">{title}</h3>
              <p className="text-xs text-gray-400">{subtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white flex items-center justify-center text-sm transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs font-mono flex items-center gap-2">
              <span>⚠️</span>
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Live Preview Area */}
          <div className="space-y-2">
            <label className="text-xs font-mono font-bold text-gray-300 block">
              {t('imageUpload.livePreview')}
            </label>
            <div className="relative rounded-2xl overflow-hidden border-2 border-white/10 bg-[#050810] flex items-center justify-center min-h-[160px]">
              {previewUrl ? (
                isAvatar ? (
                  <div className="p-6 flex flex-col items-center gap-3">
                    <img
                      src={previewUrl}
                      alt="Avatar preview"
                      className="w-32 h-32 rounded-2xl object-cover border-4 border-amber-400 shadow-2xl"
                    />
                    <button
                      type="button"
                      onClick={handleRemove}
                      className="text-xs text-red-400 hover:text-red-300 font-mono underline cursor-pointer"
                    >
                      {t('imageUpload.removePhoto')}
                    </button>
                  </div>
                ) : (
                  <div className="w-full relative group">
                    <img
                      src={previewUrl}
                      alt="Cover preview"
                      className="w-full h-44 object-cover"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <button
                        type="button"
                        onClick={handleRemove}
                        className="px-3 py-1.5 rounded-lg bg-red-600/90 text-white font-mono text-xs cursor-pointer hover:bg-red-500"
                      >
                        {t('imageUpload.removeBanner')}
                      </button>
                    </div>
                  </div>
                )
              ) : (
                <div className="p-8 text-center text-gray-500 font-mono text-xs flex flex-col items-center gap-2">
                  <span className="text-3xl">{isAvatar ? '👤' : '🏟️'}</span>
                  <span>{t('imageUpload.noImageSelected')}</span>
                </div>
              )}
            </div>
          </div>

          {/* Drag & Drop File Input Area */}
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-3 ${
              dragActive
                ? 'border-amber-400 bg-amber-500/10'
                : 'border-white/20 hover:border-amber-400/60 bg-[#050810]/50 hover:bg-[#050810]'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png, image/jpeg, image/webp"
              onChange={onFileInputChange}
              className="hidden"
            />
            <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 text-xl">
              {isProcessing ? '⏳' : '📥'}
            </div>
            <div>
              <p className="text-sm font-bold text-white">
                {isProcessing ? t('imageUpload.processing') : t('imageUpload.dragDropPrompt')}
              </p>
              <p className="text-xs text-gray-400 mt-1 font-mono">
                {t('imageUpload.formats')}
              </p>
            </div>
            <button
              type="button"
              className="px-4 py-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold hover:bg-amber-500/30 transition-colors pointer-events-none"
            >
              {t('imageUpload.browseFiles')}
            </button>
          </div>

          {/* Official Curated Presets */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-mono font-bold text-gray-300 block">
                {t('imageUpload.curatedSelection')}
              </label>
              <span className="text-[10px] font-mono text-amber-400">{t('imageUpload.highDefinition')}</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {presets.map((preset) => (
                <div
                  key={preset.id}
                  onClick={() => handleSelectPreset(preset)}
                  className={`group relative rounded-xl overflow-hidden border cursor-pointer transition-all ${
                    previewUrl === preset.url
                      ? 'border-amber-400 ring-2 ring-amber-400/40'
                      : 'border-white/10 hover:border-amber-400/50'
                  }`}
                >
                  <img
                    src={preset.url}
                    alt={preset.name}
                    className={`w-full object-cover group-hover:scale-105 transition-transform ${
                      isAvatar ? 'h-24' : 'h-20'
                    }`}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent p-2 flex flex-col justify-end">
                    <span className="text-[10px] font-bold text-white line-clamp-1">
                      {preset.name}
                    </span>
                    {preset.category && (
                      <span className="text-[9px] font-mono text-amber-400 font-bold">
                        {preset.category}
                      </span>
                    )}
                  </div>
                  {previewUrl === preset.url && (
                    <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-amber-400 text-black font-black text-xs flex items-center justify-center">
                      ✓
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-5 border-t border-white/10 bg-[#060A14] flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 font-mono text-xs transition-colors cursor-pointer"
          >
            {t('imageUpload.cancel')}
          </button>
          <button
            type="button"
            disabled={isProcessing}
            onClick={handleConfirm}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-amber-500/20 cursor-pointer disabled:opacity-50"
          >
            {isProcessing ? t('imageUpload.saving') : t('imageUpload.save')}
          </button>
        </div>
      </div>
    </div>
  );
};
