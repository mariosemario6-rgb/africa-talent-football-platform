import React, { useState } from 'react';
import { FootballClub } from '../../types/database';
import { usePlayers } from '../../context/PlayerContext';
import { useNetwork } from '../../context/NetworkContext';
import { FOUNDER_INFO, formatMarketValue } from '../../data/demoData';
import { useLanguage } from '../../context/LanguageContext';

interface ProposePlayerModalProps {
  club: FootballClub | null;
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: string, payload?: any) => void;
}

export const ProposePlayerModal: React.FC<ProposePlayerModalProps> = ({
  club,
  isOpen,
  onClose,
  onNavigate,
}) => {
  const { t } = useLanguage();
  const { players } = usePlayers();
  const { createDirectConversation } = useNetwork();
  const [selectedPlayerId, setSelectedPlayerId] = useState<string>(players[0]?.id || '');
  const [customNote, setCustomNote] = useState<string>('');

  if (!isOpen || !club) return null;

  const selectedPlayer = players.find((p) => p.id === selectedPlayerId) || players[0];

  const handleProposeWhatsApp = () => {
    if (!selectedPlayer) return;
    const msg = `Proposition Officielle de Joueur pour le club ${club.name} (${club.country}):\nSuperviseur: ${FOUNDER_INFO.name}\n\nJoueur proposé:\n- Nom: ${selectedPlayer.firstName} ${selectedPlayer.lastName}\n- Poste: ${selectedPlayer.primaryPosition} (${selectedPlayer.preferredFoot})\n- Âge: ${selectedPlayer.calculatedAge} ans\n- Club / Académie actuelle: ${selectedPlayer.currentClub}\n- Cote marchande estimée: ${formatMarketValue(selectedPlayer.marketValueEur)}\n- Vitesse de pointe: ${selectedPlayer.stats.topSpeedKmh} km/h\n- Vidéo certifiée: ${selectedPlayer.videoUrl}\n\nNote technique: ${customNote || 'Profil audité et recommandé par Seydou Mario Traoré pour répondre aux besoins du club.'}`;
    window.open(`${FOUNDER_INFO.whatsappUrl}?text=${encodeURIComponent(msg)}`, '_blank');
    onClose();
  };

  const handleProposeInternalMessage = () => {
    if (!selectedPlayer) return;
    createDirectConversation({
      id: `pro-club-${club.id}`,
      name: club.sportingDirector || club.president,
      title: `Directeur Sportif · ${club.name}`,
      avatar: club.logoUrl,
      org: club.name,
      role: 'SPORTING_DIRECTOR',
    });
    onClose();
    onNavigate('messages');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
    >
      <div className="bg-[#070D1B] border-2 border-amber-500/50 rounded-3xl max-w-xl w-full flex flex-col shadow-2xl shadow-black/90 overflow-hidden my-auto">
        {/* HEADER */}
        <div className="flex items-center justify-between p-5 sm:p-6 border-b border-white/10 bg-[#0A142A]/70">
          <div className="flex items-center gap-3">
            <span className="text-2xl">{club.countryFlag}</span>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white">
                {t('proposeModal.title')} : {club.name}
              </h2>
              <p className="text-xs text-gray-400 font-mono mt-0.5">
                {club.city}, {club.country} · {club.league}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-2 rounded-xl hover:bg-white/10 text-lg transition-colors cursor-pointer"
            aria-label={t('modal.close')}
          >
            ✕
          </button>
        </div>

        {/* BODY */}
        <div className="p-5 sm:p-6 space-y-4">
          {/* Club Open Needs Reminder */}
          {club.openNeeds.length > 0 && (
            <div className="p-3 rounded-xl bg-[#091122] border border-amber-500/30 text-xs">
              <span className="text-[10px] font-mono uppercase text-amber-400 font-bold block mb-1.5">
                {club.name} :
              </span>
              <div className="flex flex-wrap gap-1.5">
                {club.openNeeds.map((need, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/40 text-[10px] font-mono"
                  >
                    {need}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Select Player */}
          <div className="space-y-1.5">
            <label className="text-xs font-mono font-bold uppercase text-gray-300 block">
              {t('proposeModal.selectPlayer')}
            </label>
            <select
              value={selectedPlayerId}
              onChange={(e) => setSelectedPlayerId(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl bg-[#050914] border border-white/15 text-white text-xs focus:border-amber-500 focus:outline-none"
            >
              {players.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.firstName} {p.lastName} — {p.primaryPosition} ({p.calculatedAge} ans · {p.preferredFoot}) · {formatMarketValue(p.marketValueEur)}
                </option>
              ))}
            </select>
          </div>

          {/* Selected Player Preview Card */}
          {selectedPlayer && (
            <div className="p-3.5 rounded-2xl bg-[#060B18] border border-white/10 flex items-center gap-3">
              <img
                src={selectedPlayer.avatarUrl}
                alt={selectedPlayer.lastName}
                className="w-14 h-14 rounded-xl object-cover border border-amber-500/40 shrink-0"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono font-bold text-[10px]">
                    {selectedPlayer.primaryPosition}
                  </span>
                  <span className="text-xs font-bold text-white truncate">
                    {selectedPlayer.firstName} {selectedPlayer.lastName}
                  </span>
                </div>
                <div className="text-[11px] text-gray-400 font-mono mt-0.5">
                  {selectedPlayer.currentClub} · {selectedPlayer.stats.topSpeedKmh} km/h · {selectedPlayer.stats.goals} buts
                </div>
                <div className="text-[11px] font-bold text-emerald-400 font-mono mt-0.5">
                  {formatMarketValue(selectedPlayer.marketValueEur)}
                </div>
              </div>
            </div>
          )}

          {/* Custom Note */}
          <div className="space-y-1.5">
            <label className="text-xs font-mono font-bold uppercase text-gray-300 block">
              {t('proposeModal.customNote')}
            </label>
            <textarea
              value={customNote}
              onChange={(e) => setCustomNote(e.target.value)}
              placeholder="Scouting report & technical pitch..."
              rows={3}
              className="w-full px-3 py-2 rounded-xl bg-[#050914] border border-white/15 text-white text-xs focus:border-amber-500 focus:outline-none resize-none"
            />
          </div>
        </div>

        {/* FOOTER */}
        <div className="p-5 border-t border-white/10 bg-[#0A142A]/80 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase transition-colors cursor-pointer"
          >
            {t('modal.cancel')}
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleProposeInternalMessage}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
            >
              {t('proposeModal.internalMessage')}
            </button>

            <button
              onClick={handleProposeWhatsApp}
              className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-emerald-500/20 cursor-pointer flex items-center justify-center gap-1.5 active:scale-95"
            >
              <span>{t('proposeModal.sendWhatsApp')}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
