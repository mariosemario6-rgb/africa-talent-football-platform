import React, { useState } from 'react';
import { useNetwork } from '../../context/NetworkContext';
import { useLanguage } from '../../context/LanguageContext';

export const QuickChatDrawer: React.FC = () => {
  const { t } = useLanguage();
  const {
    conversations,
    messages,
    activeConversationId,
    setActiveConversationId,
    sendMessage,
    isQuickChatOpen,
    setIsQuickChatOpen,
    totalUnreadCount
  } = useNetwork();

  const [inputMessage, setInputMessage] = useState('');
  const [isMinimized, setIsMinimized] = useState(false);

  const activeConv = conversations.find((c) => c.id === activeConversationId) || conversations[0];
  const activeMsgs = messages[activeConversationId] || [];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;
    sendMessage(activeConversationId, inputMessage);
    setInputMessage('');
  };

  if (!isQuickChatOpen) {
    return (
      <div className="fixed bottom-4 right-4 z-40">
        <button
          onClick={() => setIsQuickChatOpen(true)}
          className="flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider shadow-2xl transition-all hover:scale-105 active:scale-95 cursor-pointer"
        >
          <span>💬 {t('quickChat.buttonLabel')}</span>
          {totalUnreadCount > 0 && (
            <span className="w-5 h-5 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center justify-center">
              {totalUnreadCount}
            </span>
          )}
        </button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-40 w-96 max-w-[calc(100vw-2rem)] bg-[#090E1B] rounded-2xl border border-amber-500/50 shadow-2xl overflow-hidden flex flex-col font-sans transition-all animate-in slide-in-from-bottom-6">
      {/* Header */}
      <div className="bg-[#050810] px-4 py-3 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <img
              src={activeConv?.participantAvatar}
              alt={activeConv?.participantName}
              className="w-8 h-8 rounded-full object-cover border border-amber-500/40"
            />
            {activeConv?.online && (
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-[#050810]" />
            )}
          </div>
          <div>
            <div className="font-bold text-white text-xs truncate max-w-[170px]">
              {activeConv?.participantName}
            </div>
            <div className="text-[10px] text-amber-400 truncate max-w-[170px] font-mono">
              {activeConv?.participantOrg}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-gray-400">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 hover:text-white hover:bg-white/10 rounded text-xs cursor-pointer"
            title={isMinimized ? 'Expand' : 'Collapse'}
          >
            {isMinimized ? '▲' : '▼'}
          </button>
          <button
            onClick={() => setIsQuickChatOpen(false)}
            className="p-1 hover:text-white hover:bg-white/10 rounded text-xs font-bold cursor-pointer"
            title={t('modal.close')}
          >
            ✕
          </button>
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Conversation Switcher Strip */}
          <div className="bg-[#070B14] px-3 py-1.5 border-b border-white/5 flex items-center gap-2 overflow-x-auto text-[11px]">
            <span className="text-gray-500 text-[10px] uppercase font-mono">💬</span>
            {conversations.map((c) => (
              <button
                key={c.id}
                onClick={() => setActiveConversationId(c.id)}
                className={`px-2 py-0.5 rounded text-[10px] font-bold whitespace-nowrap transition-colors cursor-pointer ${
                  c.id === activeConversationId
                    ? 'bg-amber-500 text-black'
                    : 'bg-white/5 text-gray-400 hover:text-white'
                }`}
              >
                {c.participantName.split(' ')[0]}
              </button>
            ))}
          </div>

          {/* Messages Feed */}
          <div className="h-72 overflow-y-auto p-3.5 space-y-3 bg-[#090E1B] text-xs">
            {activeMsgs.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${m.isMine ? 'items-end' : 'items-start'}`}
              >
                <div className="flex items-center gap-1.5 mb-1 text-[10px] text-gray-400 font-mono">
                  <span>{m.senderName}</span>
                  <span>·</span>
                  <span>{m.timestamp}</span>
                </div>

                <div
                  className={`max-w-[85%] p-3 rounded-xl leading-relaxed ${
                    m.isMine
                      ? 'bg-amber-500 text-black font-medium rounded-tr-none'
                      : 'bg-[#050810] border border-white/10 text-gray-100 rounded-tl-none'
                  }`}
                >
                  <p>{m.text}</p>

                  {m.attachment && (
                    <div className="mt-2 p-2 rounded bg-black/40 border border-white/15 text-[11px] space-y-1">
                      <div className="font-bold text-amber-300 flex items-center gap-1.5">
                        <span>📹</span>
                        <span>{m.attachment.title}</span>
                      </div>
                      {m.attachment.subtitle && (
                        <div className="text-[10px] text-gray-300">{m.attachment.subtitle}</div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Message Input Box */}
          <form onSubmit={handleSend} className="p-2.5 bg-[#050810] border-t border-white/10 flex items-center gap-2">
            <input
              type="text"
              placeholder={t('quickChat.placeholder')}
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              className="flex-grow px-3 py-2 rounded-lg bg-[#090E1B] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
            />
            <button
              type="submit"
              className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
            >
              {t('quickChat.send')}
            </button>
          </form>
        </>
      )}
    </div>
  );
};
