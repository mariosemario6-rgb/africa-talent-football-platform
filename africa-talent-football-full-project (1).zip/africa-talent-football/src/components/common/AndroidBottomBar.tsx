import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useNetwork } from '../../context/NetworkContext';
import { usePushNotifications } from '../../context/PushNotificationContext';

interface AndroidBottomBarProps {
  activeView: string;
  onNavigate: (view: string, payload?: any) => void;
  onOpenMenu: () => void;
}

export const AndroidBottomBar: React.FC<AndroidBottomBarProps> = ({
  activeView,
  onNavigate,
  onOpenMenu,
}) => {
  const { t } = useLanguage();
  const { totalUnreadCount } = useNetwork();
  const { unreadAlertsCount, setIsMercatoModalOpen } = usePushNotifications();

  const tabs = [
    {
      id: 'home',
      label: t('nav.home', 'Accueil'),
      icon: (active: boolean) => (
        <svg className={`w-5 h-5 ${active ? 'text-amber-400 stroke-2' : 'text-gray-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
        </svg>
      ),
      action: () => onNavigate('home'),
      badge: 0,
    },
    {
      id: 'feed',
      label: 'Fil Réseau',
      icon: (active: boolean) => (
        <svg className={`w-5 h-5 ${active ? 'text-amber-400 stroke-2' : 'text-gray-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
        </svg>
      ),
      action: () => onNavigate('feed'),
      badge: 0,
    },
    {
      id: 'mercato',
      label: 'Mercato',
      icon: (active: boolean) => (
        <span className="text-base leading-none">🚨</span>
      ),
      action: () => setIsMercatoModalOpen(true),
      badge: unreadAlertsCount,
    },
    {
      id: 'players',
      label: t('nav.players', 'Talents'),
      icon: (active: boolean) => (
        <svg className={`w-5 h-5 ${active ? 'text-amber-400 stroke-2' : 'text-gray-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      action: () => onNavigate('players'),
      badge: 0,
    },
    {
      id: 'messages',
      label: t('nav.messages', 'Messages'),
      icon: (active: boolean) => (
        <svg className={`w-5 h-5 ${active ? 'text-amber-400 stroke-2' : 'text-gray-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
        </svg>
      ),
      action: () => onNavigate('messages'),
      badge: totalUnreadCount,
    },
    {
      id: 'menu',
      label: t('nav.menu', 'Menu'),
      icon: (active: boolean) => (
        <svg className={`w-5 h-5 ${active ? 'text-amber-400 stroke-2' : 'text-gray-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      ),
      action: onOpenMenu,
      badge: 0,
    },
  ];

  return (
    <nav
      aria-label="Barre de navigation mobile Android"
      className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#040711]/95 backdrop-blur-xl border-t border-amber-500/30 shadow-[0_-4px_25px_rgba(0,0,0,0.8)] pb-[max(0.6rem,env(safe-area-inset-bottom))] pt-1 px-2 select-none"
    >
      <div className="max-w-md mx-auto grid grid-cols-6 gap-1 items-center">
        {tabs.map((tab) => {
          const isActive = activeView === tab.id;
          return (
            <button
              key={tab.id}
              onClick={tab.action}
              className={`relative flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all duration-200 active:scale-95 cursor-pointer min-h-[52px] ${
                isActive
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-white/5 border border-transparent'
              }`}
            >
              <div className="relative">
                {tab.icon(isActive)}
                {tab.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2.5 min-w-[16px] h-4 px-1 rounded-full bg-red-600 text-white font-mono text-[9px] font-bold flex items-center justify-center shadow-sm">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span
                className={`text-[10px] tracking-tight mt-1 line-clamp-1 font-bold ${
                  isActive ? 'text-amber-300' : 'text-gray-400'
                }`}
              >
                {tab.label}
              </span>
              {isActive && (
                <span className="w-4 h-0.5 bg-amber-400 rounded-full mt-0.5 shadow-sm shadow-amber-500" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
