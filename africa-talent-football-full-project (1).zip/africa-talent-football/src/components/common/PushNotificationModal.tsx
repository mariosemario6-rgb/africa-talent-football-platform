import React, { useState } from 'react';
import { usePushNotifications } from '../../context/PushNotificationContext';
import { useLanguage } from '../../context/LanguageContext';

export const PushNotificationModal: React.FC = () => {
  const {
    permission,
    settings,
    updateSettings,
    requestPermission,
    triggerTestPush,
    isPushSettingsModalOpen,
    setIsPushSettingsModalOpen,
    subscribedClubIds,
    notificationHistory,
    markNotificationAsRead,
    clearNotificationHistory,
    setIsMercatoModalOpen,
  } = usePushNotifications();

  const { t } = useLanguage();
  const [modalTab, setModalTab] = useState<'SETTINGS' | 'HISTORY'>('SETTINGS');

  if (!isPushSettingsModalOpen) return null;

  const handleTogglePushMaster = async () => {
    if (!settings.enabled) {
      const ok = await requestPermission();
      if (ok) {
        updateSettings({ enabled: true });
      }
    } else {
      updateSettings({ enabled: false });
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto text-left"
    >
      <div className="bg-[#070D1B] border-2 border-amber-500/50 rounded-3xl max-w-lg w-full flex flex-col shadow-2xl shadow-black/90 overflow-hidden my-auto">
        {/* HEADER */}
        <div className="flex items-center justify-between p-5 sm:p-6 border-b border-white/10 bg-[#0A142A]/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black text-xl shadow-md shadow-amber-500/30 shrink-0">
              🔔
            </div>
            <div>
              <h2 className="text-lg font-black text-white">
                Notifications Push & Centre d'Alertes
              </h2>
              <p className="text-xs text-gray-400 mt-0.5">
                Sur smartphone Android, iPhone et navigateur web
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsPushSettingsModalOpen(false)}
            className="text-gray-400 hover:text-white p-2 rounded-xl hover:bg-white/10 text-lg transition-colors cursor-pointer"
            aria-label="Fermer"
          >
            ✕
          </button>
        </div>

        {/* TABS: SETTINGS / HISTORY */}
        <div className="px-5 pt-3 bg-[#060B18] border-b border-white/5 flex items-center gap-4 text-xs font-mono font-bold">
          <button
            onClick={() => setModalTab('SETTINGS')}
            className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              modalTab === 'SETTINGS'
                ? 'border-amber-500 text-amber-400 font-black'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <span>⚙️ Paramètres & Préférences</span>
          </button>

          <button
            onClick={() => setModalTab('HISTORY')}
            className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              modalTab === 'HISTORY'
                ? 'border-amber-500 text-amber-400 font-black'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <span>📜 Historique des Alertes</span>
            <span className="px-1.5 py-0.2 rounded-full bg-white/10 text-[10px]">
              {notificationHistory.length}
            </span>
          </button>
        </div>

        {/* BODY */}
        {modalTab === 'SETTINGS' ? (
          <div className="p-5 sm:p-6 space-y-5 overflow-y-auto max-h-[60vh]">
            {/* Main Activation Card */}
            <div className="p-4 rounded-2xl bg-[#091122] border border-amber-500/40 space-y-3">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <span className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider block">
                    Statut Global
                  </span>
                  <h4 className="text-sm font-black text-white mt-0.5">
                    {settings.enabled ? 'Notifications Push Activées' : 'Notifications Push Désactivées'}
                  </h4>
                </div>

                <button
                  onClick={handleTogglePushMaster}
                  className={`px-4 py-2 rounded-xl font-black text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md active:scale-95 ${
                    settings.enabled
                      ? 'bg-emerald-500 text-black shadow-emerald-500/30 hover:bg-emerald-400'
                      : 'bg-amber-500 text-black shadow-amber-500/30 hover:bg-amber-400'
                  }`}
                >
                  {settings.enabled ? 'Désactiver' : 'Activer'}
                </button>
              </div>

              <p className="text-xs text-gray-300 leading-relaxed">
                Recevez les opportunités mercato, alertes d'essais en Europe et détections exclusives de Seydou Mario Traoré même avec l'application fermée.
              </p>

              <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-gray-400">
                <span>Clubs suivis en push : <strong className="text-amber-400">{subscribedClubIds.length}</strong></span>
                <span>Permission navigateur : <strong className="text-emerald-400">{permission}</strong></span>
              </div>
            </div>

            {/* Test Push Button */}
            <div className="p-4 rounded-2xl bg-[#050914] border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="space-y-0.5 text-center sm:text-left">
                <span className="text-xs font-bold text-white block">Tester le carillon & le vibreur</span>
                <span className="text-[11px] text-gray-400 block">Vérifiez la réception sonore et haptique immédiate</span>
              </div>

              <button
                onClick={() => triggerTestPush()}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/20 cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 shrink-0"
              >
                <span>🔔</span>
                <span>Déclencher Test</span>
              </button>
            </div>

            {/* Category Preferences */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-mono font-bold uppercase text-gray-400 tracking-wider">
                Catégories d’Alertes Souhaitées
              </h4>

              <div className="space-y-2">
                {[
                  {
                    key: 'mercatoAlerts' as const,
                    title: '🚨 Alertes Mercato & Transferts Flash',
                    desc: 'Recherches urgentes de clubs européens et maghrébins, offres d’essai',
                  },
                  {
                    key: 'newPlayersDetected' as const,
                    title: '⭐ Nouveaux Joueurs Certifiés par Mario Traoré',
                    desc: 'Publication de nouveaux cracks U17-U20 avec vidéos 90 min et rapport audit',
                  },
                  {
                    key: 'clubMessages' as const,
                    title: '💬 Messages Confidentiels B2B',
                    desc: 'Sollicitations directes des directeurs sportifs, présidents et agents FIFA',
                  },
                  {
                    key: 'scoutingShowcases' as const,
                    title: '🏆 Calendrier des Détections Officielles',
                    desc: 'Rappels 48h avant les journées de détection et tournois d’essai',
                  },
                ].map((item) => (
                  <label
                    key={item.key}
                    className="p-3 rounded-xl bg-[#081020] border border-white/5 hover:border-white/15 transition-all flex items-start gap-3 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={settings[item.key]}
                      onChange={(e) => updateSettings({ [item.key]: e.target.checked })}
                      className="mt-1 w-4 h-4 rounded text-amber-500 focus:ring-amber-400 bg-black/50 border-white/20"
                    />
                    <div>
                      <span className="text-xs font-bold text-white block">{item.title}</span>
                      <span className="text-[11px] text-gray-400 block mt-0.5">{item.desc}</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Sound & Vibration Options */}
            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-white/10">
              <label className="p-3 rounded-xl bg-[#081020] border border-white/5 flex items-center justify-between cursor-pointer">
                <span className="text-xs font-bold text-gray-200">🔊 Sonnerie</span>
                <input
                  type="checkbox"
                  checked={settings.soundEnabled}
                  onChange={(e) => updateSettings({ soundEnabled: e.target.checked })}
                  className="w-4 h-4 text-amber-500 rounded bg-black/50 border-white/20"
                />
              </label>

              <label className="p-3 rounded-xl bg-[#081020] border border-white/5 flex items-center justify-between cursor-pointer">
                <span className="text-xs font-bold text-gray-200">📳 Vibreur</span>
                <input
                  type="checkbox"
                  checked={settings.vibrationEnabled}
                  onChange={(e) => updateSettings({ vibrationEnabled: e.target.checked })}
                  className="w-4 h-4 text-amber-500 rounded bg-black/50 border-white/20"
                />
              </label>
            </div>
          </div>
        ) : (
          <div className="p-5 sm:p-6 space-y-4 overflow-y-auto max-h-[60vh]">
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-400 font-mono">
                {notificationHistory.length} notification{notificationHistory.length > 1 ? 's' : ''} reçue{notificationHistory.length > 1 ? 's' : ''}
              </span>
              {notificationHistory.length > 0 && (
                <button
                  onClick={clearNotificationHistory}
                  className="text-[11px] text-red-400 hover:text-red-300 font-mono underline cursor-pointer"
                >
                  Effacer l'historique
                </button>
              )}
            </div>

            {notificationHistory.length === 0 ? (
              <div className="py-12 text-center text-xs text-gray-400">
                Aucune notification enregistrée pour l'instant.
              </div>
            ) : (
              <div className="space-y-2.5">
                {notificationHistory.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => {
                      markNotificationAsRead(item.id);
                      setIsPushSettingsModalOpen(false);
                      setIsMercatoModalOpen(true);
                    }}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer space-y-1 ${
                      item.read
                        ? 'bg-[#050810] border-white/5 hover:border-white/15'
                        : 'bg-[#091122] border-amber-500/40 hover:border-amber-500/60 shadow-sm'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-xs text-white truncate">{item.title}</span>
                      <span className="text-[10px] text-gray-400 font-mono shrink-0">{item.timestamp}</span>
                    </div>
                    <p className="text-[11px] text-gray-300 line-clamp-2">{item.body}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* FOOTER */}
        <div className="p-5 border-t border-white/10 bg-[#0A142A]/80 flex items-center justify-end gap-3">
          <button
            onClick={() => setIsPushSettingsModalOpen(false)}
            className="w-full px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
          >
            Enregistrer & Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
