import React, { useState } from 'react';
import { FootballClub, TacticalFormation, TacticalPlayingStyle } from '../../types/database';
import { useLanguage } from '../../context/LanguageContext';

interface TacticalPitchBoardProps {
  club?: FootballClub | null;
  initialFormation?: TacticalFormation;
  onPositionClick?: (positionCode: string, needDescription?: string) => void;
  interactive?: boolean;
}

interface PlayerNode {
  id: string;
  role: string;
  label: string;
  x: number; // percentage 0-100 (horizontal: left to right)
  y: number; // percentage 0-100 (vertical: top/attack to bottom/defense)
  isRecruiting?: boolean;
  recruitmentNeed?: string;
  instruction?: string;
}

const FORMATION_LAYOUTS: Record<TacticalFormation, { name: string; styleDefault: TacticalPlayingStyle; nodes: PlayerNode[] }> = {
  '4-3-3': {
    name: '4-3-3 Offensif & Gegenpressing',
    styleDefault: 'Gegenpressing & Bloc Haut',
    nodes: [
      { id: 'gb', role: 'GB', label: 'Gardien Relanceur', x: 50, y: 88, instruction: 'Participation à la relance courte, jeu au pied' },
      { id: 'dg', role: 'DLG', label: 'Latéral Gauche', x: 18, y: 70, instruction: 'Apport offensif, dédoublements réguliers' },
      { id: 'dcg', role: 'DCG', label: 'Défenseur Central G', x: 38, y: 74, instruction: 'Relance axiale, duels aériens dominants' },
      { id: 'dcd', role: 'DCD', label: 'Défenseur Central D', x: 62, y: 74, instruction: 'Couverture en profondeur, anticipation' },
      { id: 'dd', role: 'DLD', label: 'Latéral Droit', x: 82, y: 70, instruction: 'Centres en première intention, repli rapide' },
      { id: 'mdf', role: 'MDF', label: 'Sentinelle 6', x: 50, y: 56, instruction: 'Équilibrage tactique, orientation sous pression' },
      { id: 'mcg', role: 'MCG', label: 'Relayeur Gauche (8)', x: 32, y: 44, instruction: 'Incursions dans les demi-espaces' },
      { id: 'mcd', role: 'MCD', label: 'Relayeur Droit (8)', x: 68, y: 44, instruction: 'Box-to-box, projection et frappes lointaines' },
      { id: 'ag', role: 'AG', label: 'Ailier Gauche', x: 20, y: 22, instruction: '1v1, percussion vers l’intérieur (pied droit)' },
      { id: 'bu', role: 'BU', label: 'Avant-Centre', x: 50, y: 16, instruction: 'Fixation des centraux, pressing premier rideau' },
      { id: 'ad', role: 'AD', label: 'Ailier Droit', x: 80, y: 22, instruction: 'Vitesse de rupture, appels dans le dos' },
    ]
  },
  '4-2-3-1': {
    name: '4-2-3-1 Attaque Placée & Contrôle',
    styleDefault: 'Attaque Placée & Possession',
    nodes: [
      { id: 'gb', role: 'GB', label: 'Gardien Balayeur', x: 50, y: 88, instruction: 'Soutien défensif hors surface' },
      { id: 'dg', role: 'DLG', label: 'Latéral Gauche', x: 18, y: 72, instruction: 'Circulation large, fixation' },
      { id: 'dcg', role: 'DCG', label: 'Défenseur Central G', x: 38, y: 75, instruction: 'Pied gauche pour relance verticale' },
      { id: 'dcd', role: 'DCD', label: 'Défenseur Central D', x: 62, y: 75, instruction: 'Contrôle des transitions adverses' },
      { id: 'dd', role: 'DLD', label: 'Latéral Droit', x: 82, y: 72, instruction: 'Coordination avec l’ailier' },
      { id: 'mdf1', role: 'MDF', label: 'Double Pivot (6)', x: 38, y: 55, instruction: 'Sécurisation de l’axe, tempo du jeu' },
      { id: 'mdf2', role: 'MDF', label: 'Double Pivot (8)', x: 62, y: 55, instruction: 'Percée balle au pied, relais vertical' },
      { id: 'moc', role: 'MOC', label: 'Meneur 10 Créateur', x: 50, y: 38, instruction: 'Passe décisive, jeu entre les lignes' },
      { id: 'ag', role: 'AG', label: 'Ailier Gauche', x: 20, y: 30, instruction: 'Finisseur second poteau, vivacité' },
      { id: 'bu', role: 'BU', label: 'Attaquant de Pointe', x: 50, y: 16, instruction: 'Tueur de surface, finition 1 touche' },
      { id: 'ad', role: 'AD', label: 'Ailier Droit', x: 80, y: 30, instruction: 'Centres brossés, vitesse pure' },
    ]
  },
  '3-5-2': {
    name: '3-5-2 Transition Rapide & Pistons',
    styleDefault: 'Transition Rapide & Contre',
    nodes: [
      { id: 'gb', role: 'GB', label: 'Gardien Moderne', x: 50, y: 88, instruction: 'Relance longue vers les couloirs' },
      { id: 'dc1', role: 'DCG', label: 'Central Gauche', x: 30, y: 75, instruction: 'Agressivité au duel, couverture latérale' },
      { id: 'dc2', role: 'DCA', label: 'Libéro Moderne', x: 50, y: 77, instruction: 'Lecture du jeu, commande de la ligne' },
      { id: 'dc3', role: 'DCD', label: 'Central Droit', x: 70, y: 75, instruction: 'Marquage strict, anticipation' },
      { id: 'pg', role: 'Piston G', label: 'Piston Gauche', x: 14, y: 48, instruction: 'Volume physique VMA 18+, aller-retour total' },
      { id: 'pd', role: 'Piston D', label: 'Piston Droit', x: 86, y: 48, instruction: 'Apport permanent dans le dernier tiers' },
      { id: 'mdf', role: 'MDF', label: 'Sentinelle Axe', x: 50, y: 58, instruction: 'Régulateur défensif, premier relanceur' },
      { id: 'mc1', role: 'MCG', label: 'Mezzala Gauche', x: 36, y: 42, instruction: 'Projection et combinaisons avec le piston' },
      { id: 'mc2', role: 'MCD', label: 'Mezzala Droit', x: 64, y: 42, instruction: 'Appel en rupture, présence aux 16m' },
      { id: 'bu1', role: 'BU1', label: 'Attaquant Pivot', x: 42, y: 18, instruction: 'Déviation, jeu dos au but' },
      { id: 'bu2', role: 'BU2', label: 'Attaquant de Rupture', x: 58, y: 18, instruction: 'Course dans la profondeur, finition' },
    ]
  },
  '3-4-3': {
    name: '3-4-3 Pression Totale & Largeur',
    styleDefault: 'Gegenpressing & Bloc Haut',
    nodes: [
      { id: 'gb', role: 'GB', label: 'Gardien Libéro', x: 50, y: 88, instruction: 'Défenseur supplémentaire' },
      { id: 'dc1', role: 'DCG', label: 'Central Gauche', x: 30, y: 75, instruction: 'Sortie de balle progressive' },
      { id: 'dc2', role: 'DCA', label: 'Axe Central', x: 50, y: 77, instruction: 'Chef de file défensif' },
      { id: 'dc3', role: 'DCD', label: 'Central Droit', x: 70, y: 75, instruction: 'Duels et fermetures d’intervalles' },
      { id: 'pg', role: 'PG', label: 'Piston Gauche', x: 14, y: 50, instruction: 'Prise de couloir constante' },
      { id: 'mc1', role: 'MCG', label: 'Milieu Central G', x: 38, y: 52, instruction: 'Pression à la perte immédiate' },
      { id: 'mc2', role: 'MCD', label: 'Milieu Central D', x: 62, y: 52, instruction: 'Changement d’aile rapide' },
      { id: 'pd', role: 'PD', label: 'Piston Droit', x: 86, y: 50, instruction: 'Centres tendus au second poteau' },
      { id: 'ag', role: 'AG', label: 'Ailier Intérieur G', x: 28, y: 26, instruction: 'Création dans le demi-espace' },
      { id: 'bu', role: 'BU', label: 'Avant-Centre', x: 50, y: 17, instruction: 'Appel premier poteau, pressing' },
      { id: 'ad', role: 'AD', label: 'Ailier Intérieur D', x: 72, y: 26, instruction: 'Percussion et tirs cadrés' },
    ]
  },
  '4-4-2': {
    name: '4-4-2 Bloc Compact & Lignes Serrées',
    styleDefault: 'Bloc Médian & Défense Compacte',
    nodes: [
      { id: 'gb', role: 'GB', label: 'Gardien de But', x: 50, y: 88, instruction: 'Prises de balle aériennes rassurantes' },
      { id: 'dg', role: 'DLG', label: 'Arrière Gauche', x: 18, y: 72, instruction: 'Tenue de la ligne défensive' },
      { id: 'dcg', role: 'DCG', label: 'Défenseur Central G', x: 38, y: 74, instruction: 'Dégagements et puissance' },
      { id: 'dcd', role: 'DCD', label: 'Défenseur Central D', x: 62, y: 74, instruction: 'Couverture axiale stricte' },
      { id: 'dd', role: 'DLD', label: 'Arrière Droit', x: 82, y: 72, instruction: 'Blocage du couloir' },
      { id: 'mg', role: 'MG', label: 'Milieu Gauche', x: 18, y: 46, instruction: 'Repli à 4, dédoublement réfléchi' },
      { id: 'mc1', role: 'MCG', label: 'Milieu Axe G', x: 38, y: 50, instruction: 'Récupération et transmission propre' },
      { id: 'mc2', role: 'MCD', label: 'Milieu Axe D', x: 62, y: 50, instruction: 'Impact physique et seconde balle' },
      { id: 'md', role: 'MD', label: 'Milieu Droit', x: 82, y: 46, instruction: 'Vitesse de contre et centres' },
      { id: 'bu1', role: 'BU1', label: 'Premier Buteur', x: 40, y: 20, instruction: 'Attaque du premier poteau' },
      { id: 'bu2', role: 'BU2', label: 'Second Buteur', x: 60, y: 20, instruction: 'Tourne autour du premier attaquant' },
    ]
  }
};

export const TacticalPitchBoard: React.FC<TacticalPitchBoardProps> = ({
  club,
  initialFormation = '4-3-3',
  onPositionClick,
  interactive = true,
}) => {
  const [selectedFormation, setSelectedFormation] = useState<TacticalFormation>(
    club?.tacticalSystem || initialFormation
  );
  const [activeNode, setActiveNode] = useState<PlayerNode | null>(null);

  const formationData = FORMATION_LAYOUTS[selectedFormation] || FORMATION_LAYOUTS['4-3-3'];

  // Check if position matches club open needs
  const isPositionInClubNeeds = (role: string, label: string) => {
    if (!club || !club.openNeeds || club.openNeeds.length === 0) return false;
    const lowerRole = role.toLowerCase();
    const lowerLabel = label.toLowerCase();
    return club.openNeeds.some((need) => {
      const lowerNeed = need.toLowerCase();
      if (lowerRole.includes('bu') && (lowerNeed.includes('buteur') || lowerNeed.includes('attaquant') || lowerNeed.includes('avant-centre'))) return true;
      if (lowerRole.includes('ag') && (lowerNeed.includes('ailier') || lowerNeed.includes('gauche'))) return true;
      if (lowerRole.includes('ad') && (lowerNeed.includes('ailier') || lowerNeed.includes('droit'))) return true;
      if (lowerRole.includes('mdf') && (lowerNeed.includes('sentinelle') || lowerNeed.includes('récupérateur') || lowerNeed.includes('défensif'))) return true;
      if (lowerRole.includes('mc') && (lowerNeed.includes('milieu') || lowerNeed.includes('relayeur') || lowerNeed.includes('box-to-box'))) return true;
      if (lowerRole.includes('moc') && (lowerNeed.includes('créateur') || lowerNeed.includes('meneur') || lowerNeed.includes('10'))) return true;
      if (lowerRole.includes('dc') && (lowerNeed.includes('défenseur') || lowerNeed.includes('central') || lowerNeed.includes('relanceur'))) return true;
      if ((lowerRole.includes('dl') || lowerRole.includes('piston')) && (lowerNeed.includes('latéral') || lowerNeed.includes('piston'))) return true;
      if (lowerRole.includes('gb') && (lowerNeed.includes('gardien'))) return true;
      return false;
    });
  };

  const getMatchedNeedDescription = (role: string, label: string) => {
    if (!club || !club.openNeeds) return undefined;
    const lowerRole = role.toLowerCase();
    return club.openNeeds.find((need) => {
      const lowerNeed = need.toLowerCase();
      if (lowerRole.includes('bu') && (lowerNeed.includes('buteur') || lowerNeed.includes('attaquant'))) return true;
      if (lowerRole.includes('ag') && (lowerNeed.includes('ailier') || lowerNeed.includes('gauche'))) return true;
      if (lowerRole.includes('ad') && (lowerNeed.includes('ailier') || lowerNeed.includes('droit'))) return true;
      if (lowerRole.includes('mdf') && (lowerNeed.includes('sentinelle') || lowerNeed.includes('récupérateur'))) return true;
      if (lowerRole.includes('dc') && (lowerNeed.includes('défenseur') || lowerNeed.includes('central'))) return true;
      return false;
    });
  };

  const currentPlayingStyle = club?.playingStyle || formationData.styleDefault;

  const metrics = club?.tacticalMetrics || {
    pressingIntensity: selectedFormation === '4-3-3' ? 88 : selectedFormation === '3-5-2' ? 76 : 82,
    possessionIndex: selectedFormation === '4-2-3-1' ? 85 : selectedFormation === '4-3-3' ? 80 : 70,
    transitionSpeed: selectedFormation === '3-5-2' ? 92 : selectedFormation === '4-3-3' ? 84 : 78,
    defensiveLineHeight: selectedFormation === '4-3-3' ? 82 : selectedFormation === '3-4-3' ? 85 : 74,
  };

  return (
    <div className="space-y-4 text-left">
      {/* HEADER & FORMATION SWITCHER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-[#070D1B] border border-white/10">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold uppercase text-amber-400">
              Système & Schéma Tactique
            </span>
            <span className="px-2 py-0.2 rounded-full bg-blue-500/20 text-blue-300 font-mono text-[10px] font-bold border border-blue-500/30">
              {currentPlayingStyle}
            </span>
          </div>
          <h3 className="text-sm font-black text-white mt-0.5">
            {club?.name ? `Dispositif Officiel de ${club.name}` : formationData.name}
          </h3>
          <p className="text-[11px] text-gray-400 mt-0.5">
            Coach : <strong className="text-gray-200">{club?.headCoach || 'Direction Technique ATF'}</strong> · Cliquez sur un poste pour voir l’instruction tactique.
          </p>
        </div>

        {interactive && (
          <div className="flex flex-wrap items-center gap-1">
            {(['4-3-3', '4-2-3-1', '3-5-2', '3-4-3', '4-4-2'] as TacticalFormation[]).map((fmt) => (
              <button
                key={fmt}
                onClick={() => {
                  setSelectedFormation(fmt);
                  setActiveNode(null);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                  selectedFormation === fmt
                    ? 'bg-amber-500 text-black font-black shadow-md shadow-amber-500/20'
                    : 'bg-white/5 text-gray-400 hover:text-white hover:bg-white/10'
                }`}
              >
                {fmt}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* PITCH AND SIDEBAR LAYOUT */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* THE FOOTBALL PITCH (SVG / Tailwind) */}
        <div className="lg:col-span-8 relative aspect-[3/4] sm:aspect-[4/5] rounded-3xl overflow-hidden border-2 border-emerald-500/30 shadow-2xl bg-gradient-to-b from-[#0e2c1c] via-[#091f14] to-[#06150d] p-3 select-none">
          {/* Pitch grass pattern stripes */}
          <div className="absolute inset-0 opacity-15 pointer-events-none flex flex-col justify-between">
            <div className="h-1/6 bg-white/10" />
            <div className="h-1/6 bg-transparent" />
            <div className="h-1/6 bg-white/10" />
            <div className="h-1/6 bg-transparent" />
            <div className="h-1/6 bg-white/10" />
            <div className="h-1/6 bg-transparent" />
          </div>

          {/* SVG Pitch Markings */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 100 100" preserveAspectRatio="none">
            {/* Outer boundary */}
            <rect x="5" y="4" width="90" height="92" fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="0.8" rx="2" />
            {/* Center line */}
            <line x1="5" y1="50" x2="95" y2="50" stroke="rgba(255,255,255,0.22)" strokeWidth="0.8" />
            {/* Center circle */}
            <circle cx="50" cy="50" r="11" fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="0.8" />
            <circle cx="50" cy="50" r="0.8" fill="rgba(255,255,255,0.3)" />

            {/* Top Penalty Box (Opponent / Attack) */}
            <rect x="25" y="4" width="50" height="18" fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="0.8" />
            <rect x="36" y="4" width="28" height="7" fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="0.8" />
            <path d="M 40 22 A 10 10 0 0 0 60 22" fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="0.8" />
            <circle cx="50" cy="13" r="0.8" fill="rgba(255,255,255,0.3)" />

            {/* Bottom Penalty Box (Our Team / Defense) */}
            <rect x="25" y="78" width="50" height="18" fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="0.8" />
            <rect x="36" y="89" width="28" height="7" fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="0.8" />
            <path d="M 40 78 A 10 10 0 0 1 60 78" fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="0.8" />
            <circle cx="50" cy="87" r="0.8" fill="rgba(255,255,255,0.3)" />

            {/* Corner Arcs */}
            <path d="M 5 7 A 3 3 0 0 0 8 4" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="0.8" />
            <path d="M 95 7 A 3 3 0 0 1 92 4" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="0.8" />
            <path d="M 5 93 A 3 3 0 0 1 8 96" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="0.8" />
            <path d="M 95 93 A 3 3 0 0 0 92 96" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="0.8" />
          </svg>

          {/* Direction indicators */}
          <div className="absolute top-2 left-6 right-6 flex justify-between text-[9px] font-mono font-bold text-emerald-300/40 uppercase pointer-events-none">
            <span>▲ Sens de l’Attaque (Zone Haute)</span>
            <span>Fin de Match 90’ ▲</span>
          </div>

          {/* PLAYER NODES */}
          {formationData.nodes.map((node) => {
            const isRecruiting = isPositionInClubNeeds(node.role, node.label);
            const matchedNeed = getMatchedNeedDescription(node.role, node.label);
            const isSelected = activeNode?.id === node.id;

            return (
              <div
                key={node.id}
                style={{
                  left: `${node.x}%`,
                  top: `${node.y}%`,
                  transform: 'translate(-50%, -50%)',
                }}
                onClick={() => {
                  setActiveNode({ ...node, isRecruiting, recruitmentNeed: matchedNeed });
                  if (onPositionClick) {
                    onPositionClick(node.role, matchedNeed);
                  }
                }}
                className="absolute flex flex-col items-center cursor-pointer group transition-transform active:scale-90"
              >
                {/* Node Disc */}
                <div
                  className={`relative w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center font-black text-[11px] sm:text-xs transition-all shadow-lg ${
                    isRecruiting
                      ? 'bg-gradient-to-br from-red-500 to-amber-500 text-black ring-4 ring-red-400/40 animate-pulse'
                      : isSelected
                      ? 'bg-gradient-to-br from-amber-400 to-amber-600 text-black ring-4 ring-amber-300'
                      : 'bg-[#0A142A]/90 text-white border-2 border-white/40 hover:border-amber-400 hover:scale-110'
                  }`}
                >
                  <span>{node.role}</span>

                  {/* Pulsing indicator if club actively recruits for this position */}
                  {isRecruiting && (
                    <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-red-500 border border-white animate-ping" />
                  )}
                </div>

                {/* Role / Name Tag below */}
                <span
                  className={`mt-1 px-1.5 py-0.5 rounded text-[9px] sm:text-[10px] font-mono font-bold whitespace-nowrap shadow-sm ${
                    isRecruiting
                      ? 'bg-red-500 text-white font-black'
                      : isSelected
                      ? 'bg-amber-400 text-black font-black'
                      : 'bg-black/80 text-gray-300 border border-white/10 group-hover:text-white'
                  }`}
                >
                  {node.label}
                </span>
              </div>
            );
          })}
        </div>

        {/* SIDEBAR TACTICAL PANEL */}
        <div className="lg:col-span-4 space-y-4 flex flex-col justify-between">
          {/* Active Node Detail Card */}
          <div className="p-4 rounded-2xl bg-[#070D1B] border border-amber-500/40 space-y-3">
            <span className="text-[10px] font-mono uppercase font-bold text-amber-400 tracking-wider block">
              Fiche Tactique du Poste
            </span>

            {activeNode ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-base font-black text-white">{activeNode.label}</h4>
                  <span className="px-2 py-0.5 rounded-full bg-amber-500 text-black font-mono font-black text-[10px]">
                    {activeNode.role}
                  </span>
                </div>

                <div className="p-2.5 rounded-xl bg-[#050914] border border-white/5 text-xs text-gray-300 space-y-1">
                  <span className="text-[10px] text-gray-400 uppercase font-mono block font-bold">
                    Consigne Coach & Rôle :
                  </span>
                  <p>{activeNode.instruction}</p>
                </div>

                {activeNode.isRecruiting && (
                  <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/40 space-y-1.5">
                    <span className="text-[10px] text-red-400 uppercase font-mono font-black flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-ping" />
                      Poste Actuellement Recherché au Mercato !
                    </span>
                    <p className="text-xs text-red-200">
                      {activeNode.recruitmentNeed || 'Le club a formulé un besoin officiel pour ce poste.'}
                    </p>
                    {onPositionClick && (
                      <button
                        onClick={() => onPositionClick(activeNode.role, activeNode.recruitmentNeed)}
                        className="w-full mt-1 py-1.5 rounded-lg bg-red-500 hover:bg-red-400 text-white font-black text-[10px] uppercase tracking-wider transition-colors cursor-pointer"
                      >
                        Proposer un Talent pour ce Poste
                      </button>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div className="py-4 text-center text-xs text-gray-400">
                <span>👆 Cliquez sur un joueur sur le terrain pour afficher son cahier des charges tactique et ses consignes.</span>
              </div>
            )}
          </div>

          {/* Tactical Performance Metrics */}
          <div className="p-4 rounded-2xl bg-[#070D1B] border border-white/10 space-y-3 text-xs font-mono">
            <span className="text-[10px] font-mono uppercase font-bold text-gray-400 tracking-wider block">
              Métriques de Jeu & Intensité
            </span>

            <div className="space-y-2">
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-gray-300">Intensité du Pressing (PPDA)</span>
                  <span className="text-amber-400 font-bold">{metrics.pressingIntensity}%</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full bg-amber-400 rounded-full" style={{ width: `${metrics.pressingIntensity}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-gray-300">Indice de Possession & Maîtrise</span>
                  <span className="text-blue-400 font-bold">{metrics.possessionIndex}%</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full bg-blue-400 rounded-full" style={{ width: `${metrics.possessionIndex}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-gray-300">Vitesse de Transition Offensive</span>
                  <span className="text-emerald-400 font-bold">{metrics.transitionSpeed}%</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full bg-emerald-400 rounded-full" style={{ width: `${metrics.transitionSpeed}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-gray-300">Hauteur de Ligne Défensive</span>
                  <span className="text-purple-400 font-bold">{metrics.defensiveLineHeight}%</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full bg-purple-400 rounded-full" style={{ width: `${metrics.defensiveLineHeight}%` }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
