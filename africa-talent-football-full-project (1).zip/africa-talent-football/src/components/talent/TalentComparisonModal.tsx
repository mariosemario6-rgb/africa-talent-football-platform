import React from 'react';
import { usePlayers } from '../../context/PlayerContext';
import { useLanguage } from '../../context/LanguageContext';
import { TalentRadarChart } from './TalentRadarChart';
import { formatMarketValue, FOUNDER_INFO } from '../../data/demoData';
import { RegisteredPlayer } from '../../types/database';

interface TalentComparisonModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenVideo?: (player: RegisteredPlayer) => void;
}

export const TalentComparisonModal: React.FC<TalentComparisonModalProps> = ({
  isOpen,
  onClose,
  onOpenVideo,
}) => {
  const { players, comparisonIds, toggleComparison, clearComparison, openVideoModal } = usePlayers();
  const { t } = useLanguage();

  if (!isOpen) return null;

  const comparedPlayers = players.filter((p) => comparisonIds.includes(p.id));

  const handleWhatsAppInquiry = () => {
    const names = comparedPlayers.map((p) => `${p.firstName} ${p.lastName} (${p.primaryPosition}, ${p.currentClub})`).join(' vs ');
    const msg = `Demande de Dossier Comparatif Africa Talent Football:\nSuperviseur: ${FOUNDER_INFO.name}\nJoueurs ciblés: ${names}\nDemande: Vidéos 90 min intégrales et conditions de transfert / essai.`;
    window.open(`${FOUNDER_INFO.whatsappUrl}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
    >
      <div className="bg-[#070D1B] border-2 border-amber-500/50 rounded-3xl max-w-5xl w-full max-h-[92vh] flex flex-col shadow-2xl shadow-black/90 overflow-hidden my-auto">
        {/* MODAL HEADER */}
        <div className="flex items-center justify-between p-5 sm:p-6 border-b border-white/10 bg-[#0A142A]/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black text-xl shadow-md shadow-amber-500/30">
              ⇄
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-white">
                  {t('compare.title', 'Comparateur de Talents & Face-à-Face')}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono text-[10px] font-bold border border-amber-500/40">
                  {comparedPlayers.length} / 3 sélectionnés
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">
                Supervision technique certifiée par <strong>{FOUNDER_INFO.name}</strong> · Données GPS et métriques Wyscout
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {comparedPlayers.length > 0 && (
              <button
                onClick={clearComparison}
                className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white text-xs font-mono transition-colors cursor-pointer"
              >
                {t('compare.clear', 'Vider')}
              </button>
            )}
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white p-2 rounded-xl hover:bg-white/10 text-lg transition-colors cursor-pointer"
              aria-label="Fermer"
            >
              ✕
            </button>
          </div>
        </div>

        {/* MODAL BODY */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto">
          {comparedPlayers.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <span className="text-4xl block">📊</span>
              <h3 className="text-lg font-bold text-white">Aucun joueur sélectionné pour le comparateur</h3>
              <p className="text-xs text-gray-400 max-w-md mx-auto">
                Parcourez le catalogue de talents et cliquez sur le bouton <strong>« + Comparer »</strong> pour comparer 2 ou 3 profils côte à côte.
              </p>
            </div>
          ) : (
            <>
              {/* PLAYERS PROFILE CARDS SUMMARY */}
              <div className={`grid grid-cols-1 ${comparedPlayers.length === 2 ? 'sm:grid-cols-2' : 'sm:grid-cols-3'} gap-4`}>
                {comparedPlayers.map((player, idx) => {
                  const isGold = idx === 0;
                  return (
                    <div
                      key={player.id}
                      className={`p-4 rounded-2xl border transition-all relative ${
                        isGold
                          ? 'bg-[#0A1224] border-amber-500/60 shadow-lg shadow-amber-500/10'
                          : 'bg-[#081520] border-emerald-500/60 shadow-lg shadow-emerald-500/10'
                      }`}
                    >
                      {/* Remove from comparison button */}
                      <button
                        onClick={() => toggleComparison(player.id)}
                        className="absolute top-3 right-3 text-gray-400 hover:text-red-400 p-1 text-xs rounded hover:bg-white/10 transition-colors"
                        title={t('compare.remove', 'Retirer du comparateur')}
                      >
                        ✕
                      </button>

                      <div className="flex items-center gap-3">
                        <div className="relative w-16 h-16 rounded-xl overflow-hidden border-2 border-white/20 bg-black shrink-0">
                          <img
                            src={player.avatarUrl}
                            alt={`${player.firstName} ${player.lastName}`}
                            className="w-full h-full object-cover"
                          />
                          <span className="absolute bottom-0 right-0 px-1 py-0.2 rounded-tl bg-black/80 text-[10px]">
                            {player.countryFlag}
                          </span>
                        </div>

                        <div>
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-mono font-black ${
                                isGold ? 'bg-amber-500 text-black' : 'bg-emerald-500 text-black'
                              }`}
                            >
                              {player.primaryPosition}
                            </span>
                            <span className="text-[11px] font-mono text-gray-400">
                              {player.calculatedAge} ans · {player.preferredFoot}
                            </span>
                          </div>

                          <h3 className="font-black text-white text-base mt-1 line-clamp-1">
                            {player.firstName} {player.lastName}
                          </h3>

                          <p className="text-[11px] text-gray-300 font-mono line-clamp-1">
                            {player.currentClub}
                          </p>
                        </div>
                      </div>

                      <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between">
                        <div>
                          <span className="text-[9px] uppercase font-mono text-gray-400 block">Valeur Marchande</span>
                          <span className="text-base font-black text-amber-400 font-mono">
                            {formatMarketValue(player.marketValueEur)}
                          </span>
                        </div>

                        <button
                          onClick={() => {
                            if (onOpenVideo) onOpenVideo(player);
                            else openVideoModal(player);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          <span>▶</span>
                          <span>Vidéo</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* OVERLAID RADAR CHART SECTION */}
              <div className="p-6 rounded-2xl bg-[#050A15] border border-white/10 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase text-amber-400 tracking-wider">
                      Visualisation Graphique
                    </span>
                    <h3 className="text-base font-black text-white">
                      {t('compare.radarOverlay', 'Superposition Graphique Radar des Métriques')}
                    </h3>
                  </div>
                  <span className="text-xs text-gray-400 font-mono">
                    Échelle 0 à 100 points
                  </span>
                </div>

                <div className="flex justify-center py-2">
                  <TalentRadarChart
                    player={comparedPlayers[0]}
                    comparePlayer={comparedPlayers[1] || null}
                    size={300}
                    showLegend={true}
                  />
                </div>
              </div>

              {/* HEAD-TO-HEAD DETAILED STATS MATRIX */}
              <div className="p-5 rounded-2xl bg-[#050A15] border border-white/10 space-y-4">
                <div className="border-b border-white/10 pb-3">
                  <span className="text-[10px] font-mono font-bold uppercase text-amber-400 tracking-wider">
                    Données GPS & Statistiques
                  </span>
                  <h3 className="text-base font-black text-white">
                    {t('compare.keyMetrics', 'Matrice Comparative des Performances Certifiées')}
                  </h3>
                </div>

                {/* Metrics Table / Rows */}
                <div className="space-y-3 text-xs font-mono">
                  {/* Top Speed */}
                  <div className="p-3 rounded-xl bg-[#091122] border border-white/5 space-y-1.5">
                    <div className="flex justify-between text-gray-400 text-[11px]">
                      <span>⚡ Vitesse de Pointe GPS (km/h)</span>
                      <span className="text-amber-400 font-bold">Chronométrage Officiel</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 items-center">
                      {comparedPlayers.map((p, idx) => (
                        <div key={p.id} className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-black/40">
                          <span className="text-gray-300 font-bold truncate">{p.lastName}</span>
                          <span className={`font-black ${idx === 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                            {p.stats.topSpeedKmh} km/h
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Goals & Assists */}
                  <div className="p-3 rounded-xl bg-[#091122] border border-white/5 space-y-1.5">
                    <div className="flex justify-between text-gray-400 text-[11px]">
                      <span>⚽ Buts & Passes Décisives (Saison)</span>
                      <span className="text-gray-400">Total Contribution Offensive</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 items-center">
                      {comparedPlayers.map((p, idx) => (
                        <div key={p.id} className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-black/40">
                          <span className="text-gray-300 font-bold truncate">{p.lastName}</span>
                          <span className={`font-black ${idx === 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                            {p.stats.goals} B / {p.stats.assists} PD
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Pass Accuracy */}
                  <div className="p-3 rounded-xl bg-[#091122] border border-white/5 space-y-1.5">
                    <div className="flex justify-between text-gray-400 text-[11px]">
                      <span>🎯 Précision des Passes (%)</span>
                      <span className="text-gray-400">Passe courte & diagonale</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 items-center">
                      {comparedPlayers.map((p, idx) => (
                        <div key={p.id} className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-black/40">
                          <span className="text-gray-300 font-bold truncate">{p.lastName}</span>
                          <span className={`font-black ${idx === 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                            {p.stats.passAccuracyPct}%
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Minutes & Matches */}
                  <div className="p-3 rounded-xl bg-[#091122] border border-white/5 space-y-1.5">
                    <div className="flex justify-between text-gray-400 text-[11px]">
                      <span>⏱️ Temps de Jeu Cumulé</span>
                      <span className="text-gray-400">Matchs / Minutes</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 items-center">
                      {comparedPlayers.map((p, idx) => (
                        <div key={p.id} className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-black/40">
                          <span className="text-gray-300 font-bold truncate">{p.lastName}</span>
                          <span className={`font-black ${idx === 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                            {p.stats.matches} m ({p.stats.minutes}')
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Scout Overall Rating */}
                  <div className="p-3 rounded-xl bg-[#091122] border border-white/5 space-y-1.5">
                    <div className="flex justify-between text-gray-400 text-[11px]">
                      <span>🎖️ Note Globale & Potentiel Scouting</span>
                      <span className="text-amber-400 font-bold">Certification Seydou Mario TRAORÉ</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 items-center">
                      {comparedPlayers.map((p, idx) => {
                        const report = p.scoutingReports?.[0];
                        return (
                          <div key={p.id} className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-black/40">
                            <span className="text-gray-300 font-bold truncate">{p.lastName}</span>
                            <span className={`font-black ${idx === 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                              {report ? `${report.overallRating}/100 (Pot: ${report.potentialRating})` : 'Certifié ATF'}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* MODAL FOOTER */}
        <div className="p-5 border-t border-white/10 bg-[#0A142A]/80 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-gray-400 font-mono text-center sm:text-left">
            Desk Officiel : <strong className="text-amber-400">{FOUNDER_INFO.phone}</strong> · {FOUNDER_INFO.email}
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={handleWhatsAppInquiry}
              className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-emerald-500/20 cursor-pointer flex items-center justify-center gap-2"
            >
              <span>💬</span>
              <span>Demander Dossiers Complets (WhatsApp)</span>
            </button>

            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase transition-colors cursor-pointer"
            >
              Fermer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
