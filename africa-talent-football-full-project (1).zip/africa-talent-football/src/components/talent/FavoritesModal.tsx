import React from 'react';
import { usePlayers } from '../../context/PlayerContext';
import { useLanguage } from '../../context/LanguageContext';
import { formatMarketValue, FOUNDER_INFO } from '../../data/demoData';
import { RegisteredPlayer } from '../../types/database';

interface FavoritesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: string, payload?: any) => void;
  onExportPdf?: (player: RegisteredPlayer) => void;
}

export const FavoritesModal: React.FC<FavoritesModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onExportPdf,
}) => {
  const { players, favorites, toggleFavorite, openVideoModal } = usePlayers();
  const { t } = useLanguage();

  if (!isOpen) return null;

  const favoritePlayers = players.filter((p) => favorites.includes(p.id));
  const totalValue = favoritePlayers.reduce((sum, p) => sum + p.marketValueEur, 0);

  const handleWhatsAppShortlist = () => {
    const list = favoritePlayers.map((p, i) => `${i + 1}. ${p.firstName} ${p.lastName} (${p.primaryPosition}, ${p.currentClub} - ${formatMarketValue(p.marketValueEur)})`).join('\n');
    const msg = `Demande Officielle Shortlist Recrutement Africa Talent Football:\nSuperviseur: ${FOUNDER_INFO.name}\nNombre de talents sélectionnés: ${favoritePlayers.length}\nValeur cumulée: ${formatMarketValue(totalValue)}\n\nTalents retenus:\n${list}\n\nMerci de nous transmettre les dossiers techniques complets et protocoles d'essai.`;
    window.open(`${FOUNDER_INFO.whatsappUrl}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
    >
      <div className="bg-[#070D1B] border-2 border-amber-500/50 rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl shadow-black/90 overflow-hidden my-auto">
        {/* HEADER */}
        <div className="flex items-center justify-between p-5 sm:p-6 border-b border-white/10 bg-[#0A142A]/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black text-xl shadow-md shadow-amber-500/30">
              ★
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-white">
                  {t('favorites.title', 'Mes Talents Favoris & Shortlist')}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono text-[10px] font-bold border border-amber-500/40">
                  {favoritePlayers.length} talent(s)
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">
                Cote cumulée de votre sélection : <strong className="text-emerald-400 font-mono">{formatMarketValue(totalValue)}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-2 rounded-xl hover:bg-white/10 text-lg transition-colors cursor-pointer"
            aria-label="Fermer"
          >
            ✕
          </button>
        </div>

        {/* BODY */}
        <div className="p-5 sm:p-6 space-y-4 overflow-y-auto">
          {favoritePlayers.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <span className="text-4xl block">⭐</span>
              <h3 className="text-lg font-bold text-white">Votre shortlist est actuellement vide</h3>
              <p className="text-xs text-gray-400 max-w-md mx-auto">
                {t('favorites.empty', 'Aucun talent dans vos favoris pour le moment. Cliquez sur l\'étoile ★ d\'une fiche joueur pour l\'ajouter à votre shortlist.')}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {favoritePlayers.map((player) => (
                <div
                  key={player.id}
                  className="p-4 rounded-2xl bg-[#091122] border border-white/10 hover:border-amber-500/50 transition-all flex flex-col justify-between space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-black border border-white/20 shrink-0">
                        <img src={player.avatarUrl} alt={player.lastName} className="w-full h-full object-cover" />
                        <span className="absolute bottom-0 right-0 px-1 text-[9px] bg-black/80">
                          {player.countryFlag}
                        </span>
                      </div>

                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono font-bold text-[10px]">
                            {player.primaryPosition}
                          </span>
                          <span className="text-[10px] text-gray-400 font-mono">
                            {player.calculatedAge} ans · {player.preferredFoot}
                          </span>
                        </div>

                        <h4 className="font-black text-white text-sm mt-0.5">
                          {player.firstName} {player.lastName}
                        </h4>

                        <span className="text-[11px] text-gray-400 truncate block">
                          {player.currentClub}
                        </span>
                      </div>
                    </div>

                    {/* Unfavorite button */}
                    <button
                      onClick={() => toggleFavorite(player.id)}
                      className="text-amber-400 hover:text-gray-500 p-1 text-base transition-colors"
                      title="Retirer des favoris"
                    >
                      ★
                    </button>
                  </div>

                  <div className="pt-2 border-t border-white/5 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[9px] font-mono text-gray-500 uppercase block">Cote Marchande</span>
                      <span className="font-black text-amber-400 font-mono">
                        {formatMarketValue(player.marketValueEur)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openVideoModal(player)}
                        className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                      >
                        <span>▶</span>
                        <span>Vidéo</span>
                      </button>

                      <button
                        onClick={() => {
                          onClose();
                          onNavigate('player-detail', player);
                        }}
                        className="px-2.5 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold text-[11px] cursor-pointer"
                      >
                        Fiche
                      </button>

                      {onExportPdf && (
                        <button
                          onClick={() => onExportPdf(player)}
                          className="px-2.5 py-1 rounded bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/40 font-bold text-[11px] cursor-pointer"
                          title="Télécharger PDF"
                        >
                          PDF
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* FOOTER */}
        <div className="p-5 border-t border-white/10 bg-[#0A142A]/80 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-gray-400 font-mono text-center sm:text-left">
            Direction Technique : <strong className="text-white">{FOUNDER_INFO.name}</strong> ({FOUNDER_INFO.officialTitle})
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            {favoritePlayers.length > 0 && (
              <button
                onClick={handleWhatsAppShortlist}
                className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-emerald-500/20 cursor-pointer flex items-center justify-center gap-2"
              >
                <span>💬</span>
                <span>{t('favorites.sendWhatsApp', 'Transmettre la Sélection au Desk')}</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase transition-colors cursor-pointer"
            >
              Fermer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
