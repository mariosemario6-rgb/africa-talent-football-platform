import React from 'react';
import { RegisteredPlayer } from '../../types/database';
import { useLanguage } from '../../context/LanguageContext';

interface TalentRadarChartProps {
  player: RegisteredPlayer;
  comparePlayer?: RegisteredPlayer | null;
  size?: number;
  className?: string;
  showLegend?: boolean;
}

interface MetricAxis {
  key: 'pace' | 'shooting' | 'passing' | 'dribbling' | 'defending' | 'physicality';
  labelKey: string;
  defaultLabel: string;
}

const AXES: MetricAxis[] = [
  { key: 'pace', labelKey: 'radar.pace', defaultLabel: 'Vitesse' },
  { key: 'shooting', labelKey: 'radar.shooting', defaultLabel: 'Tir' },
  { key: 'passing', labelKey: 'radar.passing', defaultLabel: 'Passe' },
  { key: 'dribbling', labelKey: 'radar.dribbling', defaultLabel: 'Dribble' },
  { key: 'defending', labelKey: 'radar.defending', defaultLabel: 'Défense' },
  { key: 'physicality', labelKey: 'radar.physicality', defaultLabel: 'Physique' },
];

export const TalentRadarChart: React.FC<TalentRadarChartProps> = ({
  player,
  comparePlayer,
  size = 280,
  className = '',
  showLegend = true,
}) => {
  const { t } = useLanguage();

  const center = size / 2;
  const radius = (size / 2) * 0.72;
  const totalAxes = AXES.length;
  const angleStep = (Math.PI * 2) / totalAxes;

  // Calculates polygon point coordinates for a specific radius & index
  const getCoordinates = (index: number, valRadius: number) => {
    // Start at top (-PI / 2)
    const angle = index * angleStep - Math.PI / 2;
    const x = center + valRadius * Math.cos(angle);
    const y = center + valRadius * Math.sin(angle);
    return { x, y };
  };

  // Convert player radar values to SVG polygon points
  const getPolygonPoints = (p: RegisteredPlayer) => {
    const radar = p.physicalRadar || {
      pace: 75,
      shooting: 70,
      passing: 70,
      dribbling: 75,
      defending: 50,
      physicality: 70,
    };

    return AXES.map((axis, i) => {
      const val = Math.min(100, Math.max(10, radar[axis.key] || 50));
      const valRadius = (val / 100) * radius;
      const { x, y } = getCoordinates(i, valRadius);
      return `${x},${y}`;
    }).join(' ');
  };

  // Concentric polygon grid levels: 20%, 40%, 60%, 80%, 100%
  const gridLevels = [0.2, 0.4, 0.6, 0.8, 1.0];

  return (
    <div className={`flex flex-col items-center select-none ${className}`}>
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="overflow-visible">
          <defs>
            <radialGradient id={`goldGlow-${player.id}`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#F59E0B" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#D97706" stopOpacity="0.15" />
            </radialGradient>
            {comparePlayer && (
              <radialGradient id={`emeraldGlow-${comparePlayer.id}`} cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#10B981" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#059669" stopOpacity="0.15" />
              </radialGradient>
            )}
          </defs>

          {/* Background Concentric Grid Polygons */}
          {gridLevels.map((lvl, idx) => {
            const points = AXES.map((_, i) => {
              const { x, y } = getCoordinates(i, lvl * radius);
              return `${x},${y}`;
            }).join(' ');

            return (
              <polygon
                key={idx}
                points={points}
                fill={lvl === 1.0 ? '#060B18' : 'none'}
                stroke="rgba(255, 255, 255, 0.08)"
                strokeWidth={lvl === 1.0 ? '1.5' : '1'}
              />
            );
          })}

          {/* Radial Axis Spokes */}
          {AXES.map((_, i) => {
            const { x, y } = getCoordinates(i, radius);
            return (
              <line
                key={i}
                x1={center}
                y1={center}
                x2={x}
                y2={y}
                stroke="rgba(255, 255, 255, 0.12)"
                strokeWidth="1"
                strokeDasharray="2 3"
              />
            );
          })}

          {/* Compare Player 2 Polygon (Emerald) if present */}
          {comparePlayer && (
            <polygon
              points={getPolygonPoints(comparePlayer)}
              fill={`url(#emeraldGlow-${comparePlayer.id})`}
              stroke="#10B981"
              strokeWidth="2.5"
              strokeLinejoin="round"
              className="transition-all duration-300"
            />
          )}

          {/* Compare Player 2 Dots */}
          {comparePlayer &&
            AXES.map((axis, i) => {
              const val = Math.min(100, Math.max(10, comparePlayer.physicalRadar?.[axis.key] || 50));
              const { x, y } = getCoordinates(i, (val / 100) * radius);
              return (
                <circle
                  key={`dot2-${i}`}
                  cx={x}
                  cy={y}
                  r="3.5"
                  fill="#10B981"
                  stroke="#040711"
                  strokeWidth="1.5"
                />
              );
            })}

          {/* Primary Player Polygon (Gold) */}
          <polygon
            points={getPolygonPoints(player)}
            fill={`url(#goldGlow-${player.id})`}
            stroke="#F59E0B"
            strokeWidth="2.5"
            strokeLinejoin="round"
            className="transition-all duration-300"
          />

          {/* Primary Player Dots */}
          {AXES.map((axis, i) => {
            const val = Math.min(100, Math.max(10, player.physicalRadar?.[axis.key] || 50));
            const { x, y } = getCoordinates(i, (val / 100) * radius);
            return (
              <circle
                key={`dot1-${i}`}
                cx={x}
                cy={y}
                r="4"
                fill="#FDE047"
                stroke="#B45309"
                strokeWidth="1.5"
              />
            );
          })}

          {/* Labels & Values around radar circumference */}
          {AXES.map((axis, i) => {
            const { x, y } = getCoordinates(i, radius + 24);
            const val1 = player.physicalRadar?.[axis.key] || 50;
            const val2 = comparePlayer?.physicalRadar?.[axis.key];

            return (
              <g key={`lbl-${i}`} transform={`translate(${x}, ${y})`}>
                <text
                  x="0"
                  y="-4"
                  textAnchor="middle"
                  className="fill-gray-300 text-[10px] font-bold tracking-tight"
                >
                  {t(axis.labelKey, axis.defaultLabel).split('&')[0].trim()}
                </text>
                <text
                  x="0"
                  y="9"
                  textAnchor="middle"
                  className="text-[10px] font-mono font-black"
                >
                  <tspan fill="#F59E0B">{val1}</tspan>
                  {val2 !== undefined && (
                    <>
                      <tspan fill="#6B7280"> / </tspan>
                      <tspan fill="#10B981">{val2}</tspan>
                    </>
                  )}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* Legend */}
      {showLegend && (
        <div className="flex flex-wrap items-center justify-center gap-4 mt-3 text-xs font-mono">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-amber-500 border border-amber-300 shadow-sm shadow-amber-500/50" />
            <span className="text-white font-bold">
              {player.firstName} {player.lastName}
            </span>
          </div>

          {comparePlayer && (
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-emerald-500 border border-emerald-300 shadow-sm shadow-emerald-500/50" />
              <span className="text-white font-bold">
                {comparePlayer.firstName} {comparePlayer.lastName}
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
