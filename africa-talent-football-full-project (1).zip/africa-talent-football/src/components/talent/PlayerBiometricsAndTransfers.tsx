import React, { useState } from 'react';
import { RegisteredPlayer } from '../../types/database';
import { useLanguage } from '../../context/LanguageContext';

interface PlayerBiometricsAndTransfersProps {
  player: RegisteredPlayer;
}

export const PlayerBiometricsAndTransfers: React.FC<PlayerBiometricsAndTransfersProps> = ({ player }) => {
  const { t, formatDate } = useLanguage();
  const [showAiAuditModal, setShowAiAuditModal] = useState(false);
  const { biometrics, transferHistory, aiCertification } = player;

  return (
    <div className="space-y-6 pt-4 border-t border-white/10">
      {/* 1. BADGE DE CERTIFICATION IA (COMPUTER VISION & BIOMÉTRIE) */}
      {aiCertification && aiCertification.isCertified && (
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#061A14] via-[#09251D] to-[#051410] border-2 border-emerald-500/50 p-4 sm:p-5 shadow-xl">
          <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
            <div className="flex items-start gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center text-xl shrink-0 shadow-lg shadow-emerald-950/40">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                </span>
              </div>

              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 text-[10px] font-mono font-black uppercase tracking-widest">
                    {aiCertification.badgeLabel}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold">
                    Score de Confiance: {aiCertification.confidenceScore}%
                  </span>
                </div>

                <h4 className="text-sm font-black text-white tracking-wide">
                  Audit IA Validé · Vision par Ordinateur & Données Biométriques
                </h4>

                <p className="text-[11px] text-gray-300 font-mono">
                  Moteur d'audit : <span className="text-gray-200">{aiCertification.modelAuditEngine}</span> · Audit du {aiCertification.auditDate}
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowAiAuditModal(true)}
              className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-emerald-500/20 shrink-0 cursor-pointer self-start sm:self-center"
            >
              Consulter l'Audit IA ➔
            </button>
          </div>

          {/* Quick list of AI Verified metrics */}
          <div className="mt-3.5 pt-3 border-t border-emerald-500/20 grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono">
            {aiCertification.verifiedMetrics.slice(0, 2).map((metric, idx) => (
              <div key={idx} className="flex items-center gap-1.5 text-emerald-200/90">
                <span className="text-emerald-400 font-bold">✓</span>
                <span className="line-clamp-1">{metric}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* AI AUDIT MODAL */}
      {showAiAuditModal && aiCertification && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg bg-[#09101E] rounded-2xl border-2 border-emerald-500/50 shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🤖</span>
                <div>
                  <h3 className="text-base font-black text-white">Rapport d'Audit IA Certifié</h3>
                  <p className="text-[10px] text-emerald-400 font-mono">{aiCertification.modelAuditEngine}</p>
                </div>
              </div>
              <button
                onClick={() => setShowAiAuditModal(false)}
                className="text-gray-400 hover:text-white p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-[#050A14] border border-white/10 flex justify-between items-center font-mono">
                <span className="text-gray-400">Athlète :</span>
                <span className="text-white font-bold">{player.firstName} {player.lastName} ({player.primaryPosition})</span>
              </div>

              <div className="p-3 rounded-xl bg-[#050A14] border border-white/10 flex justify-between items-center font-mono">
                <span className="text-gray-400">Indice de Confiance IA :</span>
                <span className="text-emerald-400 font-black text-sm">{aiCertification.confidenceScore}% (Niveau Élite)</span>
              </div>

              <div className="p-3 rounded-xl bg-[#050A14] border border-white/10 flex justify-between items-center font-mono">
                <span className="text-gray-400">Empreinte Cryptographique :</span>
                <span className="text-amber-400 font-bold">{aiCertification.verificationHash || 'ATF-CERT-OFFICIAL'}</span>
              </div>

              <div className="space-y-2 pt-1">
                <span className="text-[11px] font-mono font-bold uppercase text-gray-400 block">
                  Points de Contrôle Vérifiés par Vision par Ordinateur & Biométrie :
                </span>
                <div className="space-y-1.5">
                  {aiCertification.verifiedMetrics.map((m, idx) => (
                    <div key={idx} className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-700/40 text-emerald-200 text-xs flex items-start gap-2">
                      <span className="text-emerald-400 font-bold">✓</span>
                      <span>{m}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowAiAuditModal(false)}
              className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase cursor-pointer transition-colors"
            >
              Fermer le Rapport
            </button>
          </div>
        </div>
      )}

      {/* 2. ANALYSE BIOMÉTRIQUE APPROFONDIE */}
      {biometrics && (
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
            <h3 className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider flex items-center gap-2">
              <span>🧬 Analyse Biométrique & Tests Physiques Certifiés</span>
            </h3>
            {biometrics.laboratoryOrDevice && (
              <span className="text-[10px] text-gray-400 font-mono">
                Capteurs : {biometrics.laboratoryOrDevice}
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
            {/* VO2 Max */}
            <div className="p-3 rounded-xl bg-[#050810] border border-white/10 space-y-1">
              <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                <span>VO2 MAX</span>
                <span className="text-emerald-400 font-bold">Élite</span>
              </div>
              <div className="text-lg font-black text-white font-mono">
                {biometrics.vo2MaxMlKgMin} <span className="text-xs text-gray-400 font-normal">ml/kg/min</span>
              </div>
              <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-400 h-full rounded-full"
                  style={{ width: `${Math.min(100, (biometrics.vo2MaxMlKgMin / 65) * 100)}%` }}
                />
              </div>
            </div>

            {/* Vitesse 10m & 30m */}
            <div className="p-3 rounded-xl bg-[#050810] border border-white/10 space-y-1">
              <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                <span>SPRINT 10M / 30M</span>
                <span className="text-amber-400 font-bold">Laser</span>
              </div>
              <div className="text-lg font-black text-amber-400 font-mono">
                {biometrics.sprint10mSec}s <span className="text-xs text-gray-400 font-normal">/ {biometrics.sprint30mSec}s</span>
              </div>
              <p className="text-[9px] text-gray-400 font-mono">Accélération & Vitesse pure</p>
            </div>

            {/* Détente Verticale */}
            <div className="p-3 rounded-xl bg-[#050810] border border-white/10 space-y-1">
              <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                <span>DÉTENTE VERTICALE</span>
                <span className="text-purple-400 font-bold">Kistler</span>
              </div>
              <div className="text-lg font-black text-purple-300 font-mono">
                {biometrics.verticalJumpCm} <span className="text-xs text-gray-400 font-normal">cm</span>
              </div>
              <p className="text-[9px] text-gray-400 font-mono">Explosivité quad/ischios</p>
            </div>

            {/* VAMEVAL */}
            <div className="p-3 rounded-xl bg-[#050810] border border-white/10 space-y-1">
              <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                <span>TEST VAMEVAL</span>
                <span className="text-blue-400 font-bold">VMA</span>
              </div>
              <div className="text-lg font-black text-blue-300 font-mono">
                {biometrics.vamevalKmH} <span className="text-xs text-gray-400 font-normal">km/h</span>
              </div>
              <p className="text-[9px] text-gray-400 font-mono">Vitesse Maximale Aérobie</p>
            </div>

            {/* Composition Corporelle */}
            <div className="p-3 rounded-xl bg-[#050810] border border-white/10 space-y-1">
              <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                <span>MASSE GRASSE / IMC</span>
                <span className="text-emerald-400 font-bold">Optimal</span>
              </div>
              <div className="text-lg font-black text-white font-mono">
                {biometrics.bodyFatPct}% <span className="text-xs text-gray-400 font-normal">· {biometrics.bmi} IMC</span>
              </div>
              <p className="text-[9px] text-gray-400 font-mono">Gabarit affûté pour la D1</p>
            </div>

            {/* Fréquence Cardiaque */}
            <div className="p-3 rounded-xl bg-[#050810] border border-white/10 space-y-1">
              <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                <span>CARDIAQUE REPOS / RÉCUP</span>
                <span className="text-rose-400 font-bold">Polar H10</span>
              </div>
              <div className="text-lg font-black text-rose-300 font-mono">
                {biometrics.restingHeartRateBpm} bpm <span className="text-xs text-emerald-400 font-bold">({biometrics.heartRateRecovery1MinBpm})</span>
              </div>
              <p className="text-[9px] text-gray-400 font-mono">Récupération à 1 minute</p>
            </div>
          </div>
        </div>
      )}

      {/* 3. HISTORIQUE DES TRANSFERTS ET PARCOURS */}
      {transferHistory && transferHistory.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-mono font-bold uppercase text-white tracking-wider flex items-center gap-2">
              <span>📋 Historique des Transferts & Parcours en Club</span>
            </h3>
            <span className="text-[10px] text-gray-400 font-mono">
              Registre FIFA Transfer Matching (TMS)
            </span>
          </div>

          <div className="rounded-xl bg-[#050810] border border-white/10 overflow-hidden shadow-lg">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-white/10 bg-white/5 text-[10px] font-mono text-gray-400 uppercase">
                  <th className="py-2.5 px-3">Saison</th>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Club Cédant</th>
                  <th className="py-2.5 px-3">Club Preneur</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3 text-right">Indemnité / Accord</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono">
                {transferHistory.map((tr) => (
                  <tr key={tr.id} className="hover:bg-white/5 transition-colors">
                    <td className="py-2.5 px-3 text-amber-400 font-bold">{tr.season}</td>
                    <td className="py-2.5 px-3 text-gray-400">{tr.date}</td>
                    <td className="py-2.5 px-3 text-gray-300 font-sans font-medium">{tr.fromClub}</td>
                    <td className="py-2.5 px-3 text-white font-sans font-bold">{tr.toClub}</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                        {tr.type}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right text-emerald-400 font-bold">
                      {tr.feeDisplay}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
