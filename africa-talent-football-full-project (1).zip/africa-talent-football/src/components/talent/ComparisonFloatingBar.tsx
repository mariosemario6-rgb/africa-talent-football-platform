import React from 'react';
import { usePlayers } from '../../context/PlayerContext';
import { useLanguage } from '../../context/LanguageContext';

export const ComparisonFloatingBar: React.FC = () => {
  const { comparisonIds, players, toggleComparison, clearComparison, setIsComparisonModalOpen } = usePlayers();
  const { t } = useLanguage();

  if (comparisonIds.length === 0) return null;

  const selectedPlayers = players.filter((p) => comparisonIds.includes(p.id));

  return (
    <aside
      aria-label="Barre de comparaison des talents"
      className="fixed bottom-20 lg:bottom-6 left-3 right-3 sm:left-auto sm:right-6 sm:max-w-xl z-40 bg-[#070D1B]/95 backdrop-blur-xl border-2 border-amber-500/80 rounded-2xl p-3 sm:p-4 shadow-2xl shadow-black/90 animate-in slide-in-from-bottom duration-300 ring-1 ring-amber-400/30"
    >
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Selected Players Row */}
        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto">
          <span className="text-[10px] font-mono uppercase font-bold text-amber-400 tracking-wider shrink-0">
            Comparateur ({selectedPlayers.length}/3) :
          </span>

          <div className="flex items-center gap-2">
            {selectedPlayers.map((player) => (
              <div
                key={player.id}
                className="flex items-center gap-1.5 bg-[#040813] border border-white/10 px-2 py-1 rounded-xl shrink-0"
              >
                <div className="w-6 h-6 rounded-full overflow-hidden bg-black shrink-0 border border-amber-500/40">
                  <img src={player.avatarUrl} alt={player.lastName} className="w-full h-full object-cover" />
                </div>
                <span className="text-xs text-white font-bold max-w-[80px] truncate">
                  {player.lastName}
                </span>
                <button
                  onClick={() => toggleComparison(player.id)}
                  className="text-gray-400 hover:text-red-400 text-xs p-0.5"
                  title="Retirer"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <button
            onClick={() => setIsComparisonModalOpen(true)}
            className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/30 flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
          >
            <span>⇄</span>
            <span>{t('compare.launch', 'Lancer le Face-à-Face')}</span>
          </button>

          <button
            onClick={clearComparison}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white text-xs font-mono transition-colors cursor-pointer"
            title={t('compare.clear', 'Vider')}
          >
            ✕
          </button>
        </div>
      </div>
    </aside>
  );
};
