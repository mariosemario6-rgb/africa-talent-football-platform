import React, { useState, useMemo } from 'react';
import { usePushNotifications } from '../../context/PushNotificationContext';
import { useLanguage } from '../../context/LanguageContext';
import { FOUNDER_INFO } from '../../data/demoData';
import { COMPREHENSIVE_WORLD_CLUBS } from '../../data/clubsData';
import { MercatoAlert, MercatoAlertType, ConfederationCode } from '../../types/database';

export const MercatoAlertsModal: React.FC = () => {
  const {
    mercatoAlerts,
    isMercatoModalOpen,
    setIsMercatoModalOpen,
    markAllAlertsAsRead,
    triggerTestPush,
    setIsPushSettingsModalOpen,
    settings,
    simulateIncomingMercatoAlert,
    isSubscribedToClub,
    subscribedClubIds,
    toggleClubAlertSubscription,
    customAlerts,
    addCustomAlert,
    removeCustomAlert,
  } = usePushNotifications();

  const { t } = useLanguage();

  const [activeTab, setActiveTab] = useState<'ALERTS' | 'CUSTOM_WATCH' | 'FOLLOWED'>('ALERTS');
  const [filterType, setFilterType] = useState<string>('ALL');
  const [filterConfed, setFilterConfed] = useState<string>('ALL');
  const [filterPosition, setFilterPosition] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Custom alert creator form state
  const [showCreateCustom, setShowCreateCustom] = useState<boolean>(false);
  const [customTitle, setCustomTitle] = useState<string>('');
  const [customPosition, setCustomPosition] = useState<string>('BU');
  const [customConfed, setCustomConfed] = useState<string>('UEFA');

  const filteredAlerts = useMemo(() => {
    if (!isMercatoModalOpen) return [];
    return mercatoAlerts.filter((a) => {
      const matchesType = filterType === 'ALL' || a.type === filterType;
      const matchesConfed = filterConfed === 'ALL' || a.confederation === filterConfed;
      const matchesPosition =
        filterPosition === 'ALL' ||
        (a.positionTarget && a.positionTarget.toLowerCase().includes(filterPosition.toLowerCase()));

      const queryLower = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !queryLower ||
        a.title.toLowerCase().includes(queryLower) ||
        a.clubName.toLowerCase().includes(queryLower) ||
        a.clubCountry.toLowerCase().includes(queryLower) ||
        (a.positionTarget && a.positionTarget.toLowerCase().includes(queryLower)) ||
        a.summary.toLowerCase().includes(queryLower);

      if (activeTab === 'FOLLOWED') {
        const isFollowed =
          subscribedClubIds.some((subId) => {
            const club = COMPREHENSIVE_WORLD_CLUBS.find((c) => c.id === subId);
            if (!club) return false;
            return (
              a.clubName.toLowerCase().includes(club.name.toLowerCase()) ||
              club.name.toLowerCase().includes(a.clubName.toLowerCase())
            );
          }) ||
          (a.clubName &&
            (a.clubName.toLowerCase().includes('genk') ||
              a.clubName.toLowerCase().includes('lens') ||
              a.clubName.toLowerCase().includes('asec')));
        return matchesType && matchesConfed && matchesPosition && matchesSearch && isFollowed;
      }

      return matchesType && matchesConfed && matchesPosition && matchesSearch;
    });
  }, [isMercatoModalOpen, mercatoAlerts, filterType, filterConfed, filterPosition, searchQuery, activeTab, subscribedClubIds]);

  if (!isMercatoModalOpen) return null;

  const handleClose = () => {
    markAllAlertsAsRead();
    setIsMercatoModalOpen(false);
  };

  const handleApplyToAlert = (alert: MercatoAlert) => {
    const message = `Bonjour Seydou Mario TRAORÉ,\nJe vous contacte suite à l'alerte Mercato Africa Talent Football suivante :\n- Club : ${alert.clubName} (${alert.clubCountry})\n- Opportunité : ${alert.title}\n- Poste ciblé : ${alert.positionTarget || 'Non spécifié'}\n\nMerci de bien vouloir examiner mon profil ou celui de mon joueur pour cette sélection.`;
    window.open(`${FOUNDER_INFO.whatsappUrl}?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleCreateCustomAlert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTitle.trim()) return;
    addCustomAlert({
      title: customTitle.trim(),
      position: customPosition,
      confederation: customConfed,
    });
    setCustomTitle('');
    setShowCreateCustom(false);
  };

  const getAlertBadge = (type: MercatoAlertType, urgent?: boolean) => {
    if (urgent) {
      return (
        <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/40 text-[10px] font-mono font-bold uppercase tracking-wider flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-ping" />
          Urgent Mercato
        </span>
      );
    }
    switch (type) {
      case 'OFFICIAL_TRANSFER':
        return (
          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-mono font-bold uppercase">
            ✍️ Transfert Officiel
          </span>
        );
      case 'TRIAL_OFFER':
        return (
          <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-bold uppercase">
            🏆 Offre d’Essai Pro
          </span>
        );
      case 'SCOUTING_INQUIRY':
        return (
          <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/40 text-[10px] font-mono font-bold uppercase">
            🔍 Demande Supervision
          </span>
        );
      case 'URGENT_NEED':
        return (
          <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[10px] font-mono font-bold uppercase">
            🎯 Recherche Active
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded-full bg-white/10 text-gray-300 border border-white/20 text-[10px] font-mono font-bold uppercase">
            🤝 Convention
          </span>
        );
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
    >
      <div className="bg-[#070D1B] border-2 border-amber-500/50 rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl shadow-black/90 overflow-hidden my-auto text-left">
        {/* HEADER */}
        <div className="flex items-center justify-between p-5 sm:p-6 border-b border-white/10 bg-[#0A142A]/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black text-xl shadow-md shadow-amber-500/30 shrink-0">
              🚨
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-white">
                  Centre des Alertes Mercato & Transferts Directs
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 font-mono text-[10px] font-bold border border-red-500/40 animate-pulse">
                  Direct Live
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">
                Supervision technique certifiée par <strong>{FOUNDER_INFO.name}</strong> · Desk Mercato International
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPushSettingsModalOpen(true)}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-amber-400 hover:text-amber-300 text-sm transition-colors cursor-pointer"
              title="Paramètres des notifications push"
              aria-label="Paramètres notifications"
            >
              ⚙️
            </button>
            <button
              onClick={handleClose}
              className="text-gray-400 hover:text-white p-2 rounded-xl hover:bg-white/10 text-lg transition-colors cursor-pointer"
              aria-label="Fermer"
            >
              ✕
            </button>
          </div>
        </div>

        {/* PUSH STATUS & SIMULATION CONTROL BANNER */}
        <div className="px-5 py-3 bg-[#0A1224] border-b border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-gray-300">
            <span className="text-base">🔔</span>
            <span>
              Notifications Push :{' '}
              <strong className={settings.enabled ? 'text-emerald-400' : 'text-gray-400'}>
                {settings.enabled ? 'Activées (Son + Vibration)' : 'Désactivées'}
              </strong>
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
            {/* Simulate live mercato alert button */}
            <button
              onClick={() => simulateIncomingMercatoAlert()}
              className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-red-600/30 to-amber-600/30 hover:from-red-600/40 hover:to-amber-600/40 text-amber-300 border border-amber-500/50 font-bold text-xs transition-all cursor-pointer flex items-center gap-1.5 active:scale-95 shadow-sm"
              title="Déclencher instantanément une alerte mercato en direct pour tester la notification"
            >
              <span>⚡</span>
              <span>Simuler une Alerte Direct</span>
            </button>

            <button
              onClick={() => triggerTestPush()}
              className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/10 font-bold text-xs transition-all cursor-pointer flex items-center gap-1 active:scale-95"
            >
              <span>🔔</span>
              <span>Test Push</span>
            </button>
          </div>
        </div>

        {/* TABS (Toutes les Alertes / Alertes Personnalisées / Clubs Suivis) */}
        <div className="px-5 pt-3 bg-[#060B18] border-b border-white/5 flex items-center gap-4 text-xs font-mono font-bold">
          <button
            onClick={() => setActiveTab('ALERTS')}
            className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'ALERTS'
                ? 'border-amber-500 text-amber-400 font-black'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <span>🚨 Flux en Direct</span>
            <span className="px-1.5 py-0.2 rounded-full bg-white/10 text-[10px]">
              {mercatoAlerts.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('CUSTOM_WATCH')}
            className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'CUSTOM_WATCH'
                ? 'border-amber-500 text-amber-400 font-black'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <span>🎯 Alertes Sur-Mesure</span>
            <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 text-[10px]">
              {customAlerts.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('FOLLOWED')}
            className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'FOLLOWED'
                ? 'border-amber-500 text-amber-400 font-black'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <span>⭐ Clubs Suivis</span>
          </button>
        </div>

        {/* FILTERS TOOLBAR */}
        {activeTab === 'ALERTS' && (
          <div className="p-4 sm:p-5 border-b border-white/5 bg-[#060B18] space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              {/* Type filters */}
              <div className="flex flex-wrap items-center gap-1.5 text-xs">
                {[
                  { id: 'ALL', label: 'Toutes les Alertes' },
                  { id: 'URGENT_NEED', label: '🎯 Recherches Urgentes' },
                  { id: 'TRIAL_OFFER', label: '🏆 Offres d’Essai' },
                  { id: 'OFFICIAL_TRANSFER', label: '✍️ Transferts' },
                  { id: 'SCOUTING_INQUIRY', label: '🔍 Demandes Scouts' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setFilterType(tab.id)}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      filterType === tab.id
                        ? 'bg-amber-500 text-black font-black'
                        : 'bg-white/5 text-gray-400 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Selectors */}
              <div className="flex items-center gap-2">
                {/* Confederation Filter */}
                <select
                  value={filterConfed}
                  onChange={(e) => setFilterConfed(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg bg-[#091122] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                >
                  <option value="ALL">🌍 Toutes Confédérations</option>
                  <option value="UEFA">🏆 UEFA (Europe)</option>
                  <option value="CAF">🌍 CAF (Afrique)</option>
                  <option value="CONMEBOL">⚽ CONMEBOL (Am. Sud)</option>
                  <option value="CONCACAF">🌎 CONCACAF (Am. Nord)</option>
                  <option value="AFC">⭐ AFC (Asie / Golfe)</option>
                </select>

                {/* Position Filter */}
                <select
                  value={filterPosition}
                  onChange={(e) => setFilterPosition(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg bg-[#091122] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                >
                  <option value="ALL">🎯 Tous Postes</option>
                  <option value="BU">Buteur (BU)</option>
                  <option value="AG">Ailier (AG / AD)</option>
                  <option value="Milieu">Milieu (MC / MOC)</option>
                  <option value="MDF">Sentinelle (MDF)</option>
                  <option value="Défenseur">Défenseur (DC)</option>
                  <option value="Piston">Latéral / Piston (DL)</option>
                </select>
              </div>
            </div>

            {/* Keyword Search */}
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher par club, joueur ciblé, pays ou mots-clés..."
                className="w-full px-3 py-1.5 pl-8 rounded-lg bg-[#091122] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none placeholder:text-gray-500"
              />
              <span className="absolute left-2.5 top-1.5 text-gray-500 text-xs">🔍</span>
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1.5 text-gray-400 hover:text-white text-xs"
                >
                  ✕
                </button>
              )}
            </div>
          </div>
        )}

        {/* CUSTOM ALERTS TAB */}
        {activeTab === 'CUSTOM_WATCH' && (
          <div className="p-5 sm:p-6 space-y-4 overflow-y-auto max-h-[58vh]">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black text-white">Mes Alertes & Veilles Personnalisées</h3>
                <p className="text-xs text-gray-400">
                  Configurez vos critères spécifiques pour recevoir des alertes push dès qu'un besoin correspondant apparaît.
                </p>
              </div>

              <button
                onClick={() => setShowCreateCustom(!showCreateCustom)}
                className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase cursor-pointer"
              >
                {showCreateCustom ? '✕ Annuler' : '+ Créer une Alerte'}
              </button>
            </div>

            {showCreateCustom && (
              <form
                onSubmit={handleCreateCustomAlert}
                className="p-4 rounded-2xl bg-[#091122] border border-amber-500/40 space-y-3"
              >
                <h4 className="text-xs font-bold text-amber-400 uppercase font-mono">
                  Nouvelle Alerte Mercato Personnalisée
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="block text-gray-400 text-[10px] font-mono uppercase mb-1">
                      Intitulé de la Veille
                    </label>
                    <input
                      type="text"
                      value={customTitle}
                      onChange={(e) => setCustomTitle(e.target.value)}
                      placeholder="Ex: Pépites Buteurs U20 en Belgique"
                      required
                      className="w-full px-3 py-2 rounded-lg bg-[#050914] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-400 text-[10px] font-mono uppercase mb-1">
                      Poste Ciblé
                    </label>
                    <select
                      value={customPosition}
                      onChange={(e) => setCustomPosition(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-[#050914] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    >
                      <option value="BU">Avant-centre (BU)</option>
                      <option value="AG">Ailier Gauche / Droit</option>
                      <option value="MOC">Meneur de Jeu (MOC / MC)</option>
                      <option value="MDF">Sentinelle (MDF)</option>
                      <option value="DC">Défenseur Central (DC)</option>
                      <option value="DL">Latéraux & Pistons (DL)</option>
                      <option value="GB">Gardien de But (GB)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-gray-400 text-[10px] font-mono uppercase mb-1">
                      Confédération
                    </label>
                    <select
                      value={customConfed}
                      onChange={(e) => setCustomConfed(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-[#050914] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    >
                      <option value="UEFA">UEFA (Europe)</option>
                      <option value="CAF">CAF (Afrique)</option>
                      <option value="CONMEBOL">CONMEBOL (Amérique du Sud)</option>
                      <option value="CONCACAF">CONCACAF (Amérique du Nord / MLS)</option>
                      <option value="AFC">AFC (Asie / Saudi Pro League)</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase cursor-pointer"
                >
                  Enregistrer l'Alerte Push
                </button>
              </form>
            )}

            <div className="space-y-2">
              {customAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className="p-3.5 rounded-xl bg-[#091122] border border-white/10 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-0.5">
                    <h4 className="font-bold text-white flex items-center gap-2">
                      <span>🎯 {alert.title}</span>
                      <span className="px-2 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono text-[10px]">
                        Poste : {alert.position || 'Tous'}
                      </span>
                    </h4>
                    <p className="text-[11px] text-gray-400 font-mono">
                      Zone : {alert.confederation || alert.country || 'Mondiale'} · Créée le {alert.createdAt}
                    </p>
                  </div>

                  <button
                    onClick={() => removeCustomAlert(alert.id)}
                    className="p-1.5 rounded-lg text-gray-400 hover:text-red-400 text-xs hover:bg-white/5 transition-colors"
                    title="Supprimer cette alerte"
                  >
                    🗑️
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ALERTS FEED */}
        {(activeTab === 'ALERTS' || activeTab === 'FOLLOWED') && (
          <div className="p-5 sm:p-6 space-y-4 overflow-y-auto max-h-[58vh]">
            {filteredAlerts.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <span className="text-4xl block">📭</span>
                <h3 className="text-lg font-bold text-white">Aucune alerte pour ces critères</h3>
                <p className="text-xs text-gray-400">
                  Modifiez vos filtres ci-dessus ou cliquez sur "Simuler une Alerte Direct" pour déclencher une opportunité instantanée.
                </p>
              </div>
            ) : (
              filteredAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className="p-5 rounded-2xl bg-[#091122] border border-white/10 hover:border-amber-500/50 transition-all space-y-3 shadow-md"
                >
                  {/* Alert Header */}
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        {getAlertBadge(alert.type, alert.urgent)}
                        <span className="text-[10px] font-mono text-gray-400">
                          {alert.clubCountryFlag} {alert.clubCountry} · {alert.confederation}
                        </span>
                        <span className="text-[10px] font-mono text-amber-400/90 font-bold">
                          · {alert.timestamp}
                        </span>
                      </div>

                      <h3 className="text-base font-black text-white mt-1">
                        {alert.title}
                      </h3>

                      <div className="flex items-center gap-2 text-xs text-gray-300 font-mono">
                        <strong className="text-white">{alert.clubName}</strong>
                        {alert.positionTarget && (
                          <>
                            <span>·</span>
                            <span className="text-amber-400 font-bold">Cible : {alert.positionTarget}</span>
                          </>
                        )}
                      </div>
                    </div>

                    {alert.amountDisplay && (
                      <div className="px-3 py-1.5 rounded-xl bg-black/60 border border-white/10 text-right shrink-0">
                        <span className="text-[9px] font-mono text-gray-400 uppercase block">Conditions / Cote</span>
                        <span className="text-xs font-black text-emerald-400 font-mono">
                          {alert.amountDisplay}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Summary & Details */}
                  <p className="text-xs text-gray-300 leading-relaxed">
                    {alert.summary}
                  </p>

                  {alert.details && (
                    <div className="p-3 rounded-xl bg-[#050914] border border-white/5 text-[11px] text-gray-400">
                      <strong className="text-gray-300 font-mono block mb-1">Cahier des charges club :</strong>
                      {alert.details}
                    </div>
                  )}

                  {/* Footer action buttons */}
                  <div className="pt-2 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                    <span className="text-[10px] text-gray-400 font-mono">
                      ✓ Validé par le desk Mario Traoré · Processus officiel
                    </span>

                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <button
                        onClick={() => handleApplyToAlert(alert)}
                        className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-emerald-500/20 cursor-pointer flex items-center justify-center gap-1.5 active:scale-95"
                      >
                        <span>💬</span>
                        <span>Postuler via WhatsApp</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* MODAL FOOTER */}
        <div className="p-5 border-t border-white/10 bg-[#0A142A]/80 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-gray-400 font-mono text-center sm:text-left">
            Desk Mercato & Relations Clubs : <strong className="text-white">{FOUNDER_INFO.name}</strong> ({FOUNDER_INFO.phone})
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => {
                const text = `Bonjour Seydou Mario TRAORÉ,\nJe souhaite proposer un mandat de transfert / recherche de profil joueur pour le compte de mon club ou académie.`;
                window.open(`${FOUNDER_INFO.whatsappUrl}?text=${encodeURIComponent(text)}`, '_blank');
              }}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
            >
              + Déposer une Recherche de Club
            </button>

            <button
              onClick={handleClose}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase transition-colors cursor-pointer"
            >
              Fermer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
