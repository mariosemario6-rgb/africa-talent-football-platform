import React, { useState, useMemo } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { usePlayer } from '../../context/PlayerContext';
import { FOUNDER_INFO } from '../../data/demoData';
import {
  calculateMarketValuation,
  ValuationInput,
  ValuationResult,
  formatValuationCurrency
} from '../../utils/marketValuationEngine';

interface MarketValuationCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPlayerId?: string;
}

export const MarketValuationCalculatorModal: React.FC<MarketValuationCalculatorModalProps> = ({
  isOpen,
  onClose,
  initialPlayerId
}) => {
  const { t } = useLanguage();
  const { players } = usePlayer();

  const [selectedPlayerId, setSelectedPlayerId] = useState<string>(initialPlayerId || (players[0]?.id || 'custom'));

  // Custom form state
  const [age, setAge] = useState<number>(19);
  const [position, setPosition] = useState<ValuationInput['primaryPosition']>('BU');
  const [preferredFoot, setPreferredFoot] = useState<ValuationInput['preferredFoot']>('DROIT');
  const [heightCm, setHeightCm] = useState<number>(182);
  const [topSpeedKmh, setTopSpeedKmh] = useState<number>(33.8);
  const [divisionLevel, setDivisionLevel] = useState<ValuationInput['divisionLevel']>('ACADEMY_ELITE');
  const [nationalTeamLevel, setNationalTeamLevel] = useState<ValuationInput['nationalTeamLevel']>('U20');
  const [contractStatus, setContractStatus] = useState<ValuationInput['contractStatus']>('TRAINING_AGREEMENT');
  const [videoCertified, setVideoCertified] = useState<boolean>(true);

  // Stats
  const [matches, setMatches] = useState<number>(14);
  const [minutes, setMinutes] = useState<number>(1120);
  const [goals, setGoals] = useState<number>(9);
  const [assists, setAssists] = useState<number>(4);
  const [passAccuracyPct, setPassAccuracyPct] = useState<number>(82);
  const [aerialDuelsWonPct, setAerialDuelsWonPct] = useState<number>(68);
  const [yellowCards, setYellowCards] = useState<number>(1);
  const [redCards, setRedCards] = useState<number>(0);

  // Sync with selected player if chosen
  const handleSelectPlayer = (id: string) => {
    setSelectedPlayerId(id);
    if (id === 'custom') return;
    const p = players.find((item) => item.id === id);
    if (p) {
      setAge(p.calculatedAge || 19);
      setPosition((p.primaryPosition as any) || 'BU');
      setPreferredFoot(p.preferredFoot === 'Gauche' ? 'GAUCHE' : p.preferredFoot === 'Ambidextre' ? 'LES_DEUX' : 'DROIT');
      setHeightCm(p.heightCm || 182);
      setTopSpeedKmh(p.stats.topSpeedKmh || 33.5);
      setMatches(p.stats.matches || 12);
      setMinutes(p.stats.minutes || 980);
      setGoals(p.stats.goals || 6);
      setAssists(p.stats.assists || 3);
      setPassAccuracyPct(p.stats.passAccuracyPct || 82);
      setVideoCertified(Boolean(p.videoUrl));
    }
  };

  // Compute live valuation
  const valuationResult: ValuationResult = useMemo(() => {
    const input: ValuationInput = {
      age,
      primaryPosition: position,
      preferredFoot,
      heightCm,
      topSpeedKmh,
      divisionLevel,
      nationalTeamLevel,
      contractStatus,
      isMinor: age < 18,
      videoCertified,
      stats: {
        matches,
        minutes,
        goals,
        assists,
        passAccuracyPct,
        aerialDuelsWonPct,
        yellowCards,
        redCards
      }
    };
    return calculateMarketValuation(input);
  }, [
    age,
    position,
    preferredFoot,
    heightCm,
    topSpeedKmh,
    divisionLevel,
    nationalTeamLevel,
    contractStatus,
    videoCertified,
    matches,
    minutes,
    goals,
    assists,
    passAccuracyPct,
    aerialDuelsWonPct,
    yellowCards,
    redCards
  ]);

  if (!isOpen) return null;

  const isMinor = age < 18;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#080D1A] border-2 border-amber-500/60 rounded-3xl max-w-4xl w-full max-h-[94vh] overflow-y-auto p-5 sm:p-8 space-y-6 shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-gray-400 hover:text-white p-2 text-xl font-bold rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          aria-label="Fermer"
        >
          ✕
        </button>

        {/* Modal Header */}
        <div className="space-y-2 pr-10">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 text-[10px] font-mono font-bold uppercase tracking-wider flex items-center gap-1.5">
              <span>⚡</span>
              <span>{t('valuation.engineTitle', 'Moteur Algorithmique Certifié ATF')}</span>
            </span>
            <span className="px-2.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-bold">
              ● FIFA RSTJ Compliant
            </span>
            {isMinor && (
              <span className="px-2.5 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/40 text-[10px] font-mono font-bold flex items-center gap-1">
                <span>🛡️</span>
                <span>{t('valuation.minorProtection', 'Protection Mineur <18 ans')}</span>
              </span>
            )}
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
            <span>{t('valuation.modalHeadline', 'Cotation Marchande & Statistiques du Joueur')}</span>
          </h2>
          <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
            {t('valuation.modalDesc', 'Évaluez la valeur de transfert marchande et l’indice statistique certifié d’un talent à partir de critères athlétiques, techniques, contractuels et de temps de jeu vérifiés.')}
          </p>
        </div>

        {/* Select Player Preset or Custom Mode */}
        <div className="p-3 rounded-2xl bg-[#050812] border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs font-mono text-gray-300">
            <span className="text-amber-400 font-bold">👤 {t('valuation.loadProfile', 'Profil Testé :')}</span>
          </div>
          <select
            value={selectedPlayerId}
            onChange={(e) => handleSelectPlayer(e.target.value)}
            className="w-full sm:w-auto bg-[#0A1020] text-white border border-amber-500/40 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            <option value="custom">{t('valuation.customSimulator', '⚡ Simulateur Personnalisé (Saisie libre)')}</option>
            {players.map((p) => (
              <option key={p.id} value={p.id}>
                {p.firstName} {p.lastName} ({p.primaryPosition} · {p.calculatedAge} ans · {p.currentClub})
              </option>
            ))}
          </select>
        </div>

        {/* PROMINENT LIVE VALUATION CARD */}
        <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-[#0D182E] via-[#091020] to-[#050814] border-2 border-amber-400/80 shadow-2xl relative overflow-hidden space-y-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-[10px] font-mono text-gray-400 uppercase font-bold tracking-wider block">
                {t('valuation.estimatedValueLabel', 'Valeur Marchande Estimée ATF (Transfer Valuation Index)')}
              </span>
              <div className="flex items-baseline gap-3">
                <span className="text-3xl sm:text-4xl lg:text-5xl font-black text-amber-400 font-mono tracking-tight drop-shadow-md">
                  {valuationResult.estimatedValueDisplay}
                </span>
                <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                  <span>{valuationResult.trend === 'RAPID_GROWTH' ? '🚀' : '↗'}</span>
                  <span>{valuationResult.trend === 'RAPID_GROWTH' ? t('valuation.rapidGrowth', 'Forte Progression') : t('valuation.positiveTrend', 'Tendance Haussière')}</span>
                </span>
              </div>
              <div className="text-xs text-gray-400 font-mono flex items-center gap-2 pt-1">
                <span>{t('valuation.confidenceInterval', 'Fourchette Marché :')}</span>
                <span className="text-white font-bold">{valuationResult.valueRange.minDisplay} – {valuationResult.valueRange.maxDisplay}</span>
              </div>
            </div>

            {/* Confidence Score Pill */}
            <div className="flex md:flex-col items-center md:items-end justify-between gap-2 border-t md:border-t-0 border-white/10 pt-3 md:pt-0">
              <div className="text-right">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold block">
                  {t('valuation.dataCertScore', 'Indice Fiabilité')}
                </span>
                <span className="text-xl font-black text-emerald-400 font-mono">
                  {valuationResult.confidenceScore}%
                </span>
              </div>
              <div className="w-24 h-2 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 rounded-full transition-all duration-500"
                  style={{ width: `${valuationResult.confidenceScore}%` }}
                />
              </div>
            </div>
          </div>

          {/* Benchmark Advisory Box */}
          <div className="p-3.5 rounded-2xl bg-black/50 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="space-y-0.5">
              <span className="text-[10px] font-mono uppercase text-amber-400 font-bold block">
                {t('valuation.benchmarkCategory', 'Profil Type & Étalonnage Recrutement :')}
              </span>
              <span className="text-gray-200 font-medium">{valuationResult.comparableProfile}</span>
            </div>
            <a
              href={`${FOUNDER_INFO.whatsappUrl}?text=${encodeURIComponent(
                `Bonjour M. Seydou Mario TRAORÉ,\nJe souhaite une expertise technique et un audit de scouting officiel pour un joueur évalué à ${valuationResult.estimatedValueDisplay} sur le moteur Africa Talent Football.`
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shrink-0 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>💬</span>
              <span>{t('valuation.requestAudit', 'Demander Audit Vidéo Certifié')}</span>
            </a>
          </div>
        </div>

        {/* INTERACTIVE METRICS FORM */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Column 1: Identity, Physical & Level */}
          <div className="p-5 rounded-2xl bg-[#060A14] border border-white/10 space-y-4">
            <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2 border-b border-white/10 pb-2">
              <span>🏃</span>
              <span>{t('valuation.biometricsSection', '1. Biométrie, Poste & Niveau')}</span>
            </h3>

            {/* Position & Age */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-mono text-gray-400 block">{t('valuation.position', 'Poste Principal')}</label>
                <select
                  value={position}
                  onChange={(e) => setPosition(e.target.value as any)}
                  className="w-full bg-[#0A1020] text-white border border-white/15 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:border-amber-400"
                >
                  <option value="BU">BU - Buteur de pointe</option>
                  <option value="AG">AG - Ailier Gauche</option>
                  <option value="AD">AD - Ailier Droit</option>
                  <option value="MOC">MOC - Milieu Offensif</option>
                  <option value="MC">MC - Milieu Central</option>
                  <option value="MDF">MDF - Milieu Défensif</option>
                  <option value="DC">DC - Défenseur Central</option>
                  <option value="DLG">DLG - Latéral Gauche</option>
                  <option value="DLD">DLD - Latéral Droit</option>
                  <option value="GB">GB - Gardien de But</option>
                </select>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-[11px] font-mono text-gray-400">
                  <span>{t('valuation.age', 'Âge')}</span>
                  <span className="text-amber-400 font-bold">{age} ans</span>
                </div>
                <input
                  type="range"
                  min={15}
                  max={32}
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>
            </div>

            {/* Preferred Foot & Height */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-mono text-gray-400 block">{t('valuation.foot', 'Pied Fort')}</label>
                <select
                  value={preferredFoot}
                  onChange={(e) => setPreferredFoot(e.target.value as any)}
                  className="w-full bg-[#0A1020] text-white border border-white/15 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:border-amber-400"
                >
                  <option value="DROIT">Droitier</option>
                  <option value="GAUCHE">Gaucher (Premium)</option>
                  <option value="LES_DEUX">Ambidextre (Rare)</option>
                </select>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-[11px] font-mono text-gray-400">
                  <span>{t('valuation.height', 'Taille')}</span>
                  <span className="text-amber-400 font-bold">{heightCm} cm</span>
                </div>
                <input
                  type="range"
                  min={165}
                  max={205}
                  value={heightCm}
                  onChange={(e) => setHeightCm(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>
            </div>

            {/* Speed GPS Slider */}
            <div className="space-y-1 bg-black/30 p-3 rounded-xl border border-white/5">
              <div className="flex justify-between text-[11px] font-mono text-gray-400">
                <span>⚡ {t('valuation.topSpeed', 'Vitesse de Pointe GPS')}</span>
                <span className="text-emerald-400 font-bold font-mono">{topSpeedKmh.toFixed(1)} km/h</span>
              </div>
              <input
                type="range"
                min={28}
                max={37}
                step={0.1}
                value={topSpeedKmh}
                onChange={(e) => setTopSpeedKmh(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            {/* Division Level */}
            <div className="space-y-1">
              <label className="text-[11px] font-mono text-gray-400 block">{t('valuation.division', 'Niveau de Compétition')}</label>
              <select
                value={divisionLevel}
                onChange={(e) => setDivisionLevel(e.target.value as any)}
                className="w-full bg-[#0A1020] text-white border border-white/15 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:border-amber-400"
              >
                <option value="PRO_D1">Division 1 Professionnelle Nationale</option>
                <option value="PRO_D2">Division 2 Professionnelle</option>
                <option value="ACADEMY_ELITE">Académie Élite Agréée / Centre Fédéral</option>
                <option value="AMATEUR_U20">Championnat National U20 / U18</option>
                <option value="REGIONAL">Championnat Régional / Tournoi Détection</option>
              </select>
            </div>

            {/* National Selection */}
            <div className="space-y-1">
              <label className="text-[11px] font-mono text-gray-400 block">{t('valuation.nationalTeam', 'Sélection Nationale')}</label>
              <select
                value={nationalTeamLevel}
                onChange={(e) => setNationalTeamLevel(e.target.value as any)}
                className="w-full bg-[#0A1020] text-white border border-white/15 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:border-amber-400"
              >
                <option value="SENIOR_A">Sélection Nationale Senior A (+120k€)</option>
                <option value="U23_OLYMPIC">Sélection Olympique U23 (+75k€)</option>
                <option value="U20">Sélection Nationale U20 (+50k€)</option>
                <option value="U17">Sélection Nationale U17 (+35k€)</option>
                <option value="NONE">Aucune sélection internationale</option>
              </select>
            </div>
          </div>

          {/* Column 2: Performance Statistics & Contract */}
          <div className="p-5 rounded-2xl bg-[#060A14] border border-white/10 space-y-4">
            <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2 border-b border-white/10 pb-2">
              <span>📊</span>
              <span>{t('valuation.statsSection', '2. Statistiques en Matchs & Contrat')}</span>
            </h3>

            {/* Matches & Minutes */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <div className="flex justify-between text-[11px] font-mono text-gray-400">
                  <span>{t('valuation.matches', 'Matchs joués')}</span>
                  <span className="text-white font-bold">{matches}</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={45}
                  value={matches}
                  onChange={(e) => setMatches(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-[11px] font-mono text-gray-400">
                  <span>{t('valuation.minutes', 'Minutes effectives')}</span>
                  <span className="text-white font-bold">{minutes} min</span>
                </div>
                <input
                  type="range"
                  min={90}
                  max={3600}
                  step={45}
                  value={minutes}
                  onChange={(e) => setMinutes(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>
            </div>

            {/* Goals & Assists */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <div className="flex justify-between text-[11px] font-mono text-gray-400">
                  <span>⚽ {t('valuation.goals', 'Buts')}</span>
                  <span className="text-emerald-400 font-bold font-mono">{goals}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={30}
                  value={goals}
                  onChange={(e) => setGoals(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-[11px] font-mono text-gray-400">
                  <span>🎯 {t('valuation.assists', 'Passes Décisives')}</span>
                  <span className="text-emerald-400 font-bold font-mono">{assists}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={25}
                  value={assists}
                  onChange={(e) => setAssists(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>
            </div>

            {/* Pass Accuracy */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono text-gray-400">
                <span>🎯 {t('valuation.passAccuracy', 'Précision des Passes')}</span>
                <span className="text-amber-400 font-bold font-mono">{passAccuracyPct}%</span>
              </div>
              <input
                type="range"
                min={50}
                max={98}
                value={passAccuracyPct}
                onChange={(e) => setPassAccuracyPct(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Contractual Status */}
            <div className="space-y-1">
              <label className="text-[11px] font-mono text-gray-400 block">{t('valuation.contract', 'Situation Contractuelle')}</label>
              <select
                value={contractStatus}
                onChange={(e) => setContractStatus(e.target.value as any)}
                className="w-full bg-[#0A1020] text-white border border-white/15 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:border-amber-400"
              >
                <option value="UNDER_CONTRACT">Sous contrat professionnel (Indemnité requise)</option>
                <option value="TRAINING_AGREEMENT">Convention de formation académie (Indemnité FIFA)</option>
                <option value="EXPIRING_SOON">Fin de contrat dans moins de 6 mois</option>
                <option value="FREE_AGENT">Joueur libre (Signature immédiate)</option>
              </select>
            </div>

            {/* Video Certification Toggle */}
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white block">🎥 {t('valuation.videoAudit', 'Vidéo Complète 90 Min Certifiée')}</span>
                <span className="text-[10px] text-gray-400">{t('valuation.videoAuditSub', 'Bonus de valorisation et confiance maximale (+25k€)')}</span>
              </div>
              <input
                type="checkbox"
                checked={videoCertified}
                onChange={(e) => setVideoCertified(e.target.checked)}
                className="w-5 h-5 accent-amber-500 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Strengths & Development Axes */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 space-y-2">
            <span className="text-xs font-mono font-bold uppercase text-emerald-400 flex items-center gap-1.5">
              <span>✓</span>
              <span>{t('valuation.pointsForts', 'Points Forts Détectés par l’Algorithme :')}</span>
            </span>
            <ul className="space-y-1 text-xs text-gray-300">
              {valuationResult.keyStrengths.map((s, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <span className="text-emerald-400">●</span>
                  <span>{s}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="p-4 rounded-2xl bg-blue-950/20 border border-blue-500/30 space-y-2">
            <span className="text-xs font-mono font-bold uppercase text-blue-400 flex items-center gap-1.5">
              <span>🎯</span>
              <span>{t('valuation.axesProgression', 'Axes de Progression Recommandés :')}</span>
            </span>
            <ul className="space-y-1 text-xs text-gray-300">
              {valuationResult.developmentAxes.map((a, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <span className="text-blue-400">●</span>
                  <span>{a}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Footer info & Actions */}
        <div className="pt-3 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-400">
          <span className="text-[11px] font-mono">
            {t('valuation.disclaimer', 'Méthodologie certifiée Africa Talent Football. Données vérifiées par observateurs agréés et conformes FIFA.')}
          </span>
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
          >
            {t('common.close', 'Fermer')}
          </button>
        </div>
      </div>
    </div>
  );
};
