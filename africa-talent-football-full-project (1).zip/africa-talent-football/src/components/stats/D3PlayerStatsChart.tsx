import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { RegisteredPlayer } from '../../types/database';
import { useLanguage } from '../../context/LanguageContext';

interface D3PlayerStatsChartProps {
  player: RegisteredPlayer;
  comparePlayer?: RegisteredPlayer | null;
  width?: number;
  height?: number;
  mode?: 'radar' | 'bars' | 'percentiles';
  interactive?: boolean;
  className?: string;
}

interface RadarMetric {
  key: string;
  label: string;
  value: number;
  benchmark: number;
  unit?: string;
  description: string;
}

export const D3PlayerStatsChart: React.FC<D3PlayerStatsChartProps> = ({
  player,
  comparePlayer,
  width = 380,
  height = 340,
  mode: initialMode = 'radar',
  interactive = true,
  className = '',
}) => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'radar' | 'bars' | 'percentiles'>(initialMode);
  const [hoveredMetric, setHoveredMetric] = useState<RadarMetric | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);

  const radarData: RadarMetric[] = [
    {
      key: 'pace',
      label: t('radar.pace'),
      value: player.physicalRadar?.pace || 75,
      benchmark: 70,
      unit: '/100',
      description: 'Accélération sur 10m et vitesse de pointe GPS',
    },
    {
      key: 'shooting',
      label: t('radar.shooting'),
      value: player.physicalRadar?.shooting || 65,
      benchmark: 60,
      unit: '/100',
      description: 'Précision devant le but et tirs cadrés',
    },
    {
      key: 'passing',
      label: t('radar.passing'),
      value: player.physicalRadar?.passing || 70,
      benchmark: 65,
      unit: '/100',
      description: 'Jeu court, transmissions progressives et transversales',
    },
    {
      key: 'dribbling',
      label: t('radar.dribbling'),
      value: player.physicalRadar?.dribbling || 78,
      benchmark: 68,
      unit: '/100',
      description: 'Élimination 1v1, percussion et premier contrôle orienté',
    },
    {
      key: 'defending',
      label: t('radar.defending'),
      value: player.physicalRadar?.defending || 55,
      benchmark: 58,
      unit: '/100',
      description: 'Repli défensif, pressing haut et interceptions',
    },
    {
      key: 'physicality',
      label: t('radar.physical'),
      value: player.physicalRadar?.physicality || 74,
      benchmark: 66,
      unit: '/100',
      description: 'Puissance musculaire, duels au sol et dans les airs',
    },
  ];

  // GPS / Performance metrics for Bar Chart
  const gpsMetrics = [
    { label: 'Vitesse Max (km/h)', value: player.stats.topSpeedKmh, max: 37, benchmark: 31.5, unit: 'km/h' },
    { label: 'Précision Passes (%)', value: player.stats.passAccuracyPct, max: 100, benchmark: 76, unit: '%' },
    {
      label: 'Buts / 90min',
      value: player.stats.minutes > 0 ? Number(((player.stats.goals / player.stats.minutes) * 90).toFixed(2)) : 0,
      max: 1.2,
      benchmark: 0.35,
      unit: '',
    },
    {
      label: 'Passes Décs. / 90min',
      value: player.stats.minutes > 0 ? Number(((player.stats.assists / player.stats.minutes) * 90).toFixed(2)) : 0,
      max: 0.8,
      benchmark: 0.22,
      unit: '',
    },
    {
      label: 'Temps de Jeu (%)',
      value: Math.min(100, Math.round((player.stats.minutes / (Math.max(1, player.stats.matches) * 90)) * 100)),
      max: 100,
      benchmark: 75,
      unit: '%',
    },
  ];

  // RENDER D3 VISUALIZATION
  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove(); // Clear previous render

    const w = width;
    const h = height;

    if (activeTab === 'radar') {
      renderD3Radar(svg, w, h);
    } else if (activeTab === 'bars') {
      renderD3Bars(svg, w, h);
    } else {
      renderD3Percentiles(svg, w, h);
    }
  }, [activeTab, player, comparePlayer, width, height]);

  // 1. D3 RADAR / SPIDER CHART
  const renderD3Radar = (
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    w: number,
    h: number
  ) => {
    const margin = 45;
    const radius = Math.min(w, h) / 2 - margin;
    const center = { x: w / 2, y: h / 2 };
    const numAxes = radarData.length;
    const angleSlice = (Math.PI * 2) / numAxes;

    const rScale = d3.scaleLinear().domain([0, 100]).range([0, radius]);

    const g = svg.append('g').attr('transform', `translate(${center.x},${center.y})`);

    // Circular/Polygon Grid Levels (20%, 40%, 60%, 80%, 100%)
    const levels = [20, 40, 60, 80, 100];
    levels.forEach((lvl) => {
      const levelRadius = rScale(lvl);

      // Polygon contour
      const levelPoints: [number, number][] = radarData.map((_, i) => {
        const angle = i * angleSlice - Math.PI / 2;
        return [levelRadius * Math.cos(angle), levelRadius * Math.sin(angle)];
      });

      g.append('polygon')
        .attr('points', levelPoints.map((p) => p.join(',')).join(' '))
        .attr('stroke', lvl === 100 ? '#F59E0B' : '#ffffff20')
        .attr('stroke-width', lvl === 100 ? 1.5 : 1)
        .attr('stroke-dasharray', lvl === 100 ? 'none' : '3,3')
        .attr('fill', lvl % 40 === 0 ? '#ffffff05' : 'transparent');

      // Grid level text
      g.append('text')
        .attr('x', 4)
        .attr('y', -levelRadius + 4)
        .attr('font-size', '8px')
        .attr('font-family', 'monospace')
        .attr('fill', '#9CA3AF')
        .text(`${lvl}`);
    });

    // Radial Axis Lines & Labels
    radarData.forEach((metric, i) => {
      const angle = i * angleSlice - Math.PI / 2;
      const x = rScale(100) * Math.cos(angle);
      const y = rScale(100) * Math.sin(angle);

      // Axis Line
      g.append('line')
        .attr('x1', 0)
        .attr('y1', 0)
        .attr('x2', x)
        .attr('y2', y)
        .attr('stroke', '#ffffff30')
        .attr('stroke-width', 1);

      // Label positioning
      const labelDistance = radius + 22;
      const lx = labelDistance * Math.cos(angle);
      const ly = labelDistance * Math.sin(angle);

      const labelGroup = g
        .append('g')
        .attr('transform', `translate(${lx},${ly})`)
        .attr('cursor', 'pointer')
        .on('mouseenter', () => setHoveredMetric(metric))
        .on('mouseleave', () => setHoveredMetric(null));

      labelGroup
        .append('text')
        .attr('text-anchor', 'middle')
        .attr('dy', '0.35em')
        .attr('font-size', '10px')
        .attr('font-weight', 'bold')
        .attr('font-family', 'sans-serif')
        .attr('fill', hoveredMetric?.key === metric.key ? '#F59E0B' : '#E5E7EB')
        .text(metric.label.split(' ')[0]);

      labelGroup
        .append('text')
        .attr('text-anchor', 'middle')
        .attr('dy', '1.5em')
        .attr('font-size', '9px')
        .attr('font-family', 'monospace')
        .attr('font-weight', 'bold')
        .attr('fill', '#F59E0B')
        .text(`${metric.value}/100`);
    });

    // 1. Benchmark CAF/UEFA Academies Polygon (Gray outline)
    const benchmarkPoints: [number, number][] = radarData.map((d, i) => {
      const angle = i * angleSlice - Math.PI / 2;
      const r = rScale(d.benchmark);
      return [r * Math.cos(angle), r * Math.sin(angle)];
    });

    g.append('polygon')
      .attr('points', benchmarkPoints.map((p) => p.join(',')).join(' '))
      .attr('stroke', '#6B7280')
      .attr('stroke-width', 1.5)
      .attr('stroke-dasharray', '4,4')
      .attr('fill', '#6B728015');

    // 2. Comparison Player (if selected)
    if (comparePlayer) {
      const compPoints: [number, number][] = radarData.map((d, i) => {
        const val = comparePlayer.physicalRadar?.[d.key as keyof typeof comparePlayer.physicalRadar] || 60;
        const angle = i * angleSlice - Math.PI / 2;
        const r = rScale(val);
        return [r * Math.cos(angle), r * Math.sin(angle)];
      });

      g.append('polygon')
        .attr('points', compPoints.map((p) => p.join(',')).join(' '))
        .attr('stroke', '#10B981')
        .attr('stroke-width', 2)
        .attr('fill', '#10B98125');
    }

    // 3. Main Player Radar Polygon (Gold Gradient Fill)
    const playerPoints: [number, number][] = radarData.map((d, i) => {
      const angle = i * angleSlice - Math.PI / 2;
      const r = rScale(d.value);
      return [r * Math.cos(angle), r * Math.sin(angle)];
    });

    // Outer glow
    g.append('polygon')
      .attr('points', playerPoints.map((p) => p.join(',')).join(' '))
      .attr('stroke', '#F59E0B')
      .attr('stroke-width', 2.5)
      .attr('fill', '#F59E0B35');

    // Data points dots
    playerPoints.forEach(([x, y], i) => {
      const metric = radarData[i];
      const isHovered = hoveredMetric?.key === metric.key;

      const circle = g
        .append('circle')
        .attr('cx', x)
        .attr('cy', y)
        .attr('r', isHovered ? 6 : 4)
        .attr('fill', '#F59E0B')
        .attr('stroke', '#000000')
        .attr('stroke-width', 2)
        .attr('cursor', 'pointer')
        .on('mouseenter', () => setHoveredMetric(metric))
        .on('mouseleave', () => setHoveredMetric(null));

      // Quick pulse on hover
      if (isHovered) {
        circle.attr('filter', 'drop-shadow(0 0 6px #F59E0B)');
      }
    });
  };

  // 2. D3 HORIZONTAL COMPARATIVE BAR CHART (GPS & STATS)
  const renderD3Bars = (
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    w: number,
    h: number
  ) => {
    const margin = { top: 25, right: 35, bottom: 25, left: 140 };
    const innerW = w - margin.left - margin.right;
    const innerH = h - margin.top - margin.bottom;

    const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);

    const yScale = d3
      .scaleBand()
      .domain(gpsMetrics.map((d) => d.label))
      .range([0, innerH])
      .padding(0.35);

    const xScale = d3.scaleLinear().domain([0, 100]).range([0, innerW]);

    // Grid lines
    g.append('g')
      .attr('stroke', '#ffffff15')
      .selectAll('line')
      .data([25, 50, 75, 100])
      .enter()
      .append('line')
      .attr('x1', (d) => xScale(d))
      .attr('x2', (d) => xScale(d))
      .attr('y1', 0)
      .attr('y2', innerH)
      .attr('stroke-dasharray', '2,2');

    // Row elements
    gpsMetrics.forEach((d) => {
      const y = yScale(d.label) || 0;
      const barH = yScale.bandwidth();
      const pct = Math.min(100, Math.round((d.value / d.max) * 100));
      const benchPct = Math.min(100, Math.round((d.benchmark / d.max) * 100));

      // Row background
      g.append('rect')
        .attr('x', 0)
        .attr('y', y)
        .attr('width', innerW)
        .attr('height', barH)
        .attr('rx', 4)
        .attr('fill', '#ffffff08');

      // Benchmark marker line
      g.append('line')
        .attr('x1', xScale(benchPct))
        .attr('x2', xScale(benchPct))
        .attr('y1', y - 2)
        .attr('y2', y + barH + 2)
        .attr('stroke', '#60A5FA')
        .attr('stroke-width', 2)
        .attr('stroke-dasharray', '2,2');

      // Player bar
      g.append('rect')
        .attr('x', 0)
        .attr('y', y)
        .attr('width', xScale(pct))
        .attr('height', barH)
        .attr('rx', 4)
        .attr('fill', pct >= benchPct ? '#10B981' : '#F59E0B')
        .attr('opacity', 0.85);

      // Label left
      g.append('text')
        .attr('x', -8)
        .attr('y', y + barH / 2 + 4)
        .attr('text-anchor', 'end')
        .attr('font-size', '10px')
        .attr('font-family', 'sans-serif')
        .attr('font-weight', '600')
        .attr('fill', '#D1D5DB')
        .text(d.label);

      // Value label right
      g.append('text')
        .attr('x', xScale(pct) + 6)
        .attr('y', y + barH / 2 + 4)
        .attr('font-size', '10px')
        .attr('font-family', 'monospace')
        .attr('font-weight', 'bold')
        .attr('fill', '#FFFFFF')
        .text(`${d.value}${d.unit ? ' ' + d.unit : ''}`);
    });
  };

  // 3. D3 PERCENTILE DONUTS & RANKS
  const renderD3Percentiles = (
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    w: number,
    h: number
  ) => {
    const margin = { top: 20, right: 20, bottom: 20, left: 20 };
    const innerW = w - margin.left - margin.right;
    const innerH = h - margin.top - margin.bottom;

    const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);

    const percentiles = [
      { label: 'Indice Global ATF', value: 88, color: '#F59E0B', rank: 'Top 5%' },
      { label: 'Vitesse & Explosivité', value: 94, color: '#10B981', rank: 'Top 3%' },
      { label: 'Vision & Précision', value: 82, color: '#3B82F6', rank: 'Top 12%' },
      { label: 'Volume Athlétique GPS', value: 90, color: '#EC4899', rank: 'Top 6%' },
    ];

    const cols = 2;
    const colW = innerW / cols;
    const rowH = innerH / 2;

    percentiles.forEach((p, idx) => {
      const col = idx % cols;
      const row = Math.floor(idx / cols);
      const cx = col * colW + colW / 2;
      const cy = row * rowH + rowH / 2;
      const r = Math.min(colW, rowH) * 0.34;

      const card = g.append('g').attr('transform', `translate(${cx},${cy})`);

      // Donut background
      const arc = d3.arc().innerRadius(r - 7).outerRadius(r).startAngle(0);

      card
        .append('path')
        .datum({ endAngle: Math.PI * 2 })
        .attr('d', arc as any)
        .attr('fill', '#ffffff15');

      // Value arc
      const angle = (p.value / 100) * Math.PI * 2;
      card
        .append('path')
        .datum({ endAngle: angle })
        .attr('d', arc as any)
        .attr('fill', p.color);

      // Center value
      card
        .append('text')
        .attr('text-anchor', 'middle')
        .attr('dy', '-0.1em')
        .attr('font-size', '15px')
        .attr('font-family', 'monospace')
        .attr('font-weight', 'black')
        .attr('fill', '#FFFFFF')
        .text(`${p.value}%`);

      // Rank badge
      card
        .append('text')
        .attr('text-anchor', 'middle')
        .attr('dy', '1.3em')
        .attr('font-size', '9px')
        .attr('font-family', 'monospace')
        .attr('font-weight', 'bold')
        .attr('fill', p.color)
        .text(p.rank);

      // Title below
      card
        .append('text')
        .attr('text-anchor', 'middle')
        .attr('y', r + 16)
        .attr('font-size', '10px')
        .attr('font-weight', 'bold')
        .attr('fill', '#D1D5DB')
        .text(p.label);
    });
  };

  return (
    <div className={`p-4 rounded-2xl bg-[#060A16] border border-amber-500/30 flex flex-col items-center shadow-xl space-y-3 ${className}`}>
      {/* Top Controls / Tabs */}
      {interactive && (
        <div className="w-full flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
            <span className="text-[11px] font-mono uppercase text-amber-400 font-bold tracking-wider">
              Statistiques D3.js Avancées
            </span>
          </div>

          <div className="flex rounded-lg bg-black/60 p-1 border border-white/10 gap-1 text-[10px] font-mono font-bold">
            <button
              onClick={() => setActiveTab('radar')}
              className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                activeTab === 'radar' ? 'bg-amber-500 text-black shadow' : 'text-gray-400 hover:text-white'
              }`}
            >
              🕸️ Radar Polaire
            </button>
            <button
              onClick={() => setActiveTab('bars')}
              className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                activeTab === 'bars' ? 'bg-amber-500 text-black shadow' : 'text-gray-400 hover:text-white'
              }`}
            >
              📊 Données GPS
            </button>
            <button
              onClick={() => setActiveTab('percentiles')}
              className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                activeTab === 'percentiles' ? 'bg-amber-500 text-black shadow' : 'text-gray-400 hover:text-white'
              }`}
            >
              🎯 Percentiles Wyscout
            </button>
          </div>
        </div>
      )}

      {/* SVG Canvas rendered with D3 */}
      <div className="relative flex items-center justify-center">
        <svg
          ref={svgRef}
          width={width}
          height={height}
          viewBox={`0 0 ${width} ${height}`}
          className="overflow-visible"
        />
      </div>

      {/* Hover Information Banner / Metric Insight */}
      {hoveredMetric ? (
        <div className="w-full p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-between text-xs animate-in fade-in duration-150">
          <div>
            <strong className="text-white font-bold">{hoveredMetric.label}</strong>
            <p className="text-[10px] text-gray-300">{hoveredMetric.description}</p>
          </div>
          <div className="text-right">
            <span className="text-base font-black text-amber-400 font-mono">
              {hoveredMetric.value}{hoveredMetric.unit}
            </span>
            <span className="block text-[9px] text-gray-400 font-mono">
              Moy. Académies : {hoveredMetric.benchmark}
            </span>
          </div>
        </div>
      ) : (
        <div className="w-full flex items-center justify-between text-[10px] font-mono text-gray-400 pt-1 border-t border-white/5 px-2">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2.5 h-2.5 bg-amber-500 rounded-sm" />
            <span className="text-white font-bold">{player.firstName} {player.lastName}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="inline-block w-2.5 h-1 border-t-2 border-dashed border-gray-400" />
            <span>Moyenne U20 Académies (CAF/UEFA)</span>
          </div>
        </div>
      )}
    </div>
  );
};
