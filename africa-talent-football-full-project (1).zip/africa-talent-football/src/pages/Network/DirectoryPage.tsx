import React, { useState, useMemo } from 'react';
import { useNetwork } from '../../context/NetworkContext';
import { usePushNotifications } from '../../context/PushNotificationContext';
import { useLanguage } from '../../context/LanguageContext';
import { FootballClub, FootballProfessional, FootballCompany, ConfederationCode } from '../../types/database';
import { matchesQuery } from '../../utils/searchEngine';
import { WorldwideNetworkBanner } from '../../components/common/WorldwideNetworkBanner';
import { ProposePlayerModal } from '../../components/common/ProposePlayerModal';
import { ClubDossierModal } from '../../components/common/ClubDossierModal';
import { InstitutionalConnectionModal } from '../../components/common/InstitutionalConnectionModal';
import { FOUNDER_INFO } from '../../data/demoData';

interface DirectoryPageProps {
  onNavigate: (view: string, payload?: any) => void;
}

export const DirectoryPage: React.FC<DirectoryPageProps> = ({ onNavigate }) => {
  const {
    clubs,
    professionals,
    companies,
    createDirectConversation,
    toggleConnection,
    globalSearch,
    setGlobalSearch
  } = useNetwork();

  const {
    isSubscribedToClub,
    toggleClubAlertSubscription,
    setIsMercatoModalOpen,
    unreadAlertsCount
  } = usePushNotifications();

  const { t } = useLanguage();

  const [activeTab, setActiveTab] = useState<'ALL' | 'CLUBS' | 'PRESIDENTS' | 'DIRECTORS' | 'COACHES' | 'COMPANIES' | 'BANKS' | 'UNIVERSITIES' | 'TELEVISION' | 'TELECOM' | 'FOOD'>('CLUBS');
  const [selectedCountryFilter, setSelectedCountryFilter] = useState<string>('ALL');
  const [selectedConfederation, setSelectedConfederation] = useState<string>('ALL');
  const [selectedLeagueFilter, setSelectedLeagueFilter] = useState<string>('ALL');
  const [selectedNeedFilter, setSelectedNeedFilter] = useState<string>('ALL');
  const [selectedBudgetFilter, setSelectedBudgetFilter] = useState<string>('ALL');
  const [selectedTransferType, setSelectedTransferType] = useState<string>('ALL');
  const [selectedPartnerFilter, setSelectedPartnerFilter] = useState<string>('ALL');
  const [selectedTacticalFormation, setSelectedTacticalFormation] = useState<string>('ALL');
  const [selectedPlayingStyle, setSelectedPlayingStyle] = useState<string>('ALL');
  const [selectedSortBy, setSelectedSortBy] = useState<'PRESTIGE' | 'TROPHIES_DESC' | 'NEEDS_DESC' | 'NAME_ASC' | 'COUNTRY_ASC'>('PRESTIGE');
  const [quickChip, setQuickChip] = useState<string>('ALL');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState<boolean>(false);

  // Modals state
  const [selectedClubDossier, setSelectedClubDossier] = useState<FootballClub | null>(null);
  const [clubDossierInitialTab, setClubDossierInitialTab] = useState<'OVERVIEW' | 'VIDEOS' | 'NEWS' | 'TACTICAL' | 'MERCATO' | 'ALUMNI'>('OVERVIEW');
  const [proposePlayerClub, setProposePlayerClub] = useState<FootballClub | null>(null);
  const [selectedInstitution, setSelectedInstitution] = useState<FootballCompany | null>(null);
  const [institutionSuccessToast, setInstitutionSuccessToast] = useState<string | null>(null);

  // Progressive list loading limits for low-end mobile performance
  const [visibleClubsLimit, setVisibleClubsLimit] = useState<number>(18);
  const [visibleProsLimit, setVisibleProsLimit] = useState<number>(18);
  const [visibleCompaniesLimit, setVisibleCompaniesLimit] = useState<number>(18);

  // Extracted unique countries from clubs dynamically
  const availableCountries = useMemo(() => {
    const set = new Set<string>();
    clubs.forEach((c) => {
      if (c.country) set.add(c.country);
    });
    return Array.from(set).sort();
  }, [clubs]);

  // Extracted unique leagues from clubs
  const availableLeagues = useMemo(() => {
    const set = new Set<string>();
    clubs.forEach((c) => {
      if (c.league) set.add(c.league);
    });
    return Array.from(set).sort();
  }, [clubs]);

  // Extracted unique open needs
  const availableNeeds = useMemo(() => {
    const set = new Set<string>();
    clubs.forEach((c) => {
      c.openNeeds.forEach((n) => set.add(n));
    });
    return Array.from(set).sort();
  }, [clubs]);

  // Confederation club counts
  const confedCounts = useMemo(() => {
    const counts: Record<string, number> = {
      ALL: clubs.length,
      CAF: 0,
      UEFA: 0,
      CONMEBOL: 0,
      CONCACAF: 0,
      AFC: 0,
      OFC: 0
    };
    clubs.forEach((c) => {
      if (c.confederation && counts[c.confederation] !== undefined) {
        counts[c.confederation]++;
      }
    });
    return counts;
  }, [clubs]);

  // Count active filters
  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (selectedCountryFilter !== 'ALL') count++;
    if (selectedConfederation !== 'ALL') count++;
    if (selectedLeagueFilter !== 'ALL') count++;
    if (selectedNeedFilter !== 'ALL') count++;
    if (selectedBudgetFilter !== 'ALL') count++;
    if (selectedTransferType !== 'ALL') count++;
    if (selectedPartnerFilter !== 'ALL') count++;
    if (selectedTacticalFormation !== 'ALL') count++;
    if (selectedPlayingStyle !== 'ALL') count++;
    if (quickChip !== 'ALL') count++;
    return count;
  }, [
    selectedCountryFilter,
    selectedConfederation,
    selectedLeagueFilter,
    selectedNeedFilter,
    selectedBudgetFilter,
    selectedTransferType,
    selectedPartnerFilter,
    selectedTacticalFormation,
    selectedPlayingStyle,
    quickChip
  ]);

  const resetAllFilters = () => {
    setSelectedCountryFilter('ALL');
    setSelectedConfederation('ALL');
    setSelectedLeagueFilter('ALL');
    setSelectedNeedFilter('ALL');
    setSelectedBudgetFilter('ALL');
    setSelectedTransferType('ALL');
    setSelectedPartnerFilter('ALL');
    setSelectedTacticalFormation('ALL');
    setSelectedPlayingStyle('ALL');
    setQuickChip('ALL');
    setGlobalSearch('');
  };

  // Helper to map country or club to confederation
  const matchesConfederation = (club: FootballClub, conf: string) => {
    if (conf === 'ALL') return true;
    if (club.confederation) return club.confederation === conf;
    const africanCountries = ["Côte d'Ivoire", "Mali", "Sénégal", "Burkina Faso", "Maroc", "Égypte", "RD Congo", "Ghana", "Nigéria", "Cameroun", "Tunisie", "Algérie", "Afrique du Sud", "Tanzanie", "Guinée"];
    const europeanCountries = ["Belgique", "France", "Angleterre", "Espagne", "Portugal", "Suisse", "Italie", "Allemagne", "Pays-Bas", "Turquie", "Autriche", "Écosse"];
    if (conf === 'CAF') return africanCountries.some(c => club.country.includes(c));
    if (conf === 'UEFA') return europeanCountries.some(c => club.country.includes(c));
    if (conf === 'CONMEBOL') return ["Brésil", "Argentine", "Colombie", "Uruguay"].some(c => club.country.includes(c));
    if (conf === 'CONCACAF') return ["États-Unis", "USA", "Mexique", "Canada"].some(c => club.country.includes(c));
    if (conf === 'AFC') return ["Arabie Saoudite", "Qatar", "Émirats", "Japon", "Corée"].some(c => club.country.includes(c));
    if (conf === 'OFC') return ["Nouvelle-Zélande", "Australie"].some(c => club.country.includes(c));
    return true;
  };

  // Filtered clubs with expert matchesQuery & advanced filters
  const filteredClubs = useMemo(() => {
    return clubs
      .filter((c) => {
        const searchBlob = `${c.name} ${c.league} ${c.division} ${c.country} ${c.city} ${c.president} ${c.sportingDirector} ${c.headCoach} ${c.headOfRecruitment || ''} ${c.openNeeds.join(' ')} ${c.description} ${c.famousAlumni?.join(' ') || ''}`;
        const matchesSearch = matchesQuery(searchBlob, globalSearch);
        const matchesCountry = selectedCountryFilter === 'ALL' || c.country === selectedCountryFilter;
        const matchesConfed = matchesConfederation(c, selectedConfederation);
        const matchesLeague = selectedLeagueFilter === 'ALL' || c.league === selectedLeagueFilter;
        const matchesNeed = selectedNeedFilter === 'ALL' || c.openNeeds.some((n) => n.toLowerCase().includes(selectedNeedFilter.toLowerCase()));
        const matchesBudget = selectedBudgetFilter === 'ALL' || c.budgetRange === selectedBudgetFilter;
        const matchesTransfer = selectedTransferType === 'ALL' || c.transferType === selectedTransferType;
        const matchesPartner =
          selectedPartnerFilter === 'ALL' ||
          (selectedPartnerFilter === 'OFFICIAL' && (c.partnerStatus === 'PARTENAIRE_OFFICIEL' || c.verified)) ||
          (selectedPartnerFilter === 'AFFILIATE' && c.partnerStatus === 'AFFILIÉ_ATF') ||
          (selectedPartnerFilter === 'PROSPECTOR' && c.partnerStatus === 'CLUB_PROSPECTEUR');

        // Quick chip filter conditions
        if (quickChip === 'UEFA' && !matchesConfederation(c, 'UEFA')) return false;
        if (quickChip === 'CAF' && !matchesConfederation(c, 'CAF')) return false;
        if (quickChip === 'BELGIUM' && !c.country.includes('Belgique')) return false;
        if (quickChip === 'AMERICAS' && !matchesConfederation(c, 'CONMEBOL') && !matchesConfederation(c, 'CONCACAF')) return false;
        if (quickChip === 'GULF_ASIA' && !matchesConfederation(c, 'AFC')) return false;
        if (quickChip === 'PARTNERS' && c.partnerStatus !== 'PARTENAIRE_OFFICIEL') return false;
        if (quickChip === 'NEEDS' && c.openNeeds.length === 0) return false;
        if (quickChip === 'FOLLOWED' && !isSubscribedToClub(c.id)) return false;
        if (quickChip === 'TACTICAL_433' && c.tacticalSystem !== '4-3-3') return false;
        if (quickChip === 'TACTICAL_4231' && c.tacticalSystem !== '4-2-3-1') return false;
        if (quickChip === 'TACTICAL_352' && c.tacticalSystem !== '3-5-2') return false;

        const matchesTactical = selectedTacticalFormation === 'ALL' || c.tacticalSystem === selectedTacticalFormation;
        const matchesStyle = selectedPlayingStyle === 'ALL' || c.playingStyle === selectedPlayingStyle;

        return matchesSearch && matchesCountry && matchesConfed && matchesLeague && matchesNeed && matchesBudget && matchesTransfer && matchesPartner && matchesTactical && matchesStyle;
      })
      .sort((a, b) => {
        if (selectedSortBy === 'NAME_ASC') return a.name.localeCompare(b.name);
        if (selectedSortBy === 'COUNTRY_ASC') return a.country.localeCompare(b.country);
        if (selectedSortBy === 'NEEDS_DESC') return b.openNeeds.length - a.openNeeds.length;
        if (selectedSortBy === 'TROPHIES_DESC') return (b.trophiesCount || 0) - (a.trophiesCount || 0);
        return (b.followersCount || 0) - (a.followersCount || 0);
      });
  }, [
    clubs,
    globalSearch,
    selectedCountryFilter,
    selectedConfederation,
    selectedLeagueFilter,
    selectedNeedFilter,
    selectedBudgetFilter,
    selectedTransferType,
    selectedPartnerFilter,
    selectedTacticalFormation,
    selectedPlayingStyle,
    selectedSortBy,
    quickChip,
    isSubscribedToClub
  ]);

  const filteredProfessionals = useMemo(() => {
    return professionals.filter((p) => {
      const searchBlob = `${p.name} ${p.title} ${p.clubOrOrg} ${p.country} ${p.bio}`;
      const matchesSearch = matchesQuery(searchBlob, globalSearch);
      const matchesCountry = selectedCountryFilter === 'ALL' || p.country === selectedCountryFilter;

      if (activeTab === 'PRESIDENTS') return matchesSearch && matchesCountry && p.role === 'PRESIDENT';
      if (activeTab === 'DIRECTORS') return matchesSearch && matchesCountry && (p.role === 'SPORTING_DIRECTOR' || p.role === 'CHIEF_SCOUT');
      if (activeTab === 'COACHES') return matchesSearch && matchesCountry && p.role === 'HEAD_COACH';

      return matchesSearch && matchesCountry;
    });
  }, [professionals, globalSearch, selectedCountryFilter, activeTab]);

  const filteredCompanies = useMemo(() => {
    return companies.filter((c) => {
      const searchBlob = `${c.name} ${c.category} ${c.country} ${c.contactPerson} ${c.description} ${c.partnershipOpportunities.join(' ')}`;
      const matchesSearch = matchesQuery(searchBlob, globalSearch);
      const matchesCountry = selectedCountryFilter === 'ALL' || c.country.includes(selectedCountryFilter);

      if (!matchesSearch || !matchesCountry) return false;

      if (activeTab === 'BANKS') {
        return c.entityType === 'BANK' || c.category === 'Banque & Financement Sportif';
      }
      if (activeTab === 'UNIVERSITIES') {
        return c.entityType === 'UNIVERSITY' || c.category === 'Université & Bourses Sport-Études';
      }
      if (activeTab === 'TELEVISION') {
        return c.entityType === 'TELEVISION' || c.category === 'Chaîne Télévision & Médias Mondiaux' || c.entityType === 'MEDIA' || c.category === 'Médias & Diffusion';
      }
      if (activeTab === 'TELECOM') {
        return c.entityType === 'TELECOM' || c.category === 'Opérateur Télécom & Communication';
      }
      if (activeTab === 'FOOD') {
        return c.entityType === 'FOOD' || c.category === 'Agroalimentaire, Boissons & Nutrition';
      }
      if (activeTab === 'COMPANIES') {
        return c.entityType === 'CORPORATE' || c.category === 'Grandes Entreprises & Sponsors Mondiaux' || c.entityType === 'TECH';
      }

      return true;
    });
  }, [companies, globalSearch, selectedCountryFilter, activeTab]);

  const getConfederationBadge = (conf?: string) => {
    switch (conf) {
      case 'CAF':
        return <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[9px] font-mono font-bold">CAF Afrique</span>;
      case 'UEFA':
        return <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/40 text-[9px] font-mono font-bold">UEFA Europe</span>;
      case 'CONMEBOL':
        return <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 text-[9px] font-mono font-bold">CONMEBOL Am. Sud</span>;
      case 'CONCACAF':
        return <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 text-[9px] font-mono font-bold">CONCACAF Am. Nord</span>;
      case 'AFC':
        return <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/40 text-[9px] font-mono font-bold">AFC Asie / Golfe</span>;
      case 'OFC':
        return <span className="px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-400 border border-teal-500/40 text-[9px] font-mono font-bold">OFC Océanie</span>;
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-left">
      {/* HEADER & MERCATO LIVE TICKER BANNER */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
              Base de Données & Réseau B2B International
            </span>
            <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 font-mono text-[10px] font-bold border border-red-500/40 animate-pulse">
              Live Mercato 2026
            </span>
          </div>
          <h1 className="text-3xl font-black text-white mt-1">
            Annuaire Mondial : Tous les Clubs du Monde & Dirigeants
          </h1>
          <p className="text-xs text-gray-400 mt-1 max-w-3xl leading-relaxed">
            Consultez les effectifs, organigrammes officiels (présidents, directeurs sportifs, entraîneurs, recruteurs), stades et besoins prioritaires au mercato pour les clubs de la <strong>CAF</strong>, <strong>UEFA</strong>, <strong>CONMEBOL</strong>, <strong>CONCACAF</strong>, <strong>AFC</strong> et <strong>OFC</strong>.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => setIsMercatoModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-red-600/30 via-red-500/20 to-amber-500/30 hover:from-red-600/40 hover:to-amber-500/40 text-red-300 hover:text-white font-bold text-xs border border-red-500/50 transition-all cursor-pointer flex items-center gap-2 shadow-lg active:scale-95"
            title="Consulter les alertes et opportunités mercato en direct"
          >
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
            <span>🚨 Alertes Mercato Flash</span>
            {unreadAlertsCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-red-500 text-white font-black text-[10px] font-mono">
                {unreadAlertsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => onNavigate('register')}
            className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-md shadow-amber-500/20"
          >
            + Affilier mon Club
          </button>
        </div>
      </div>

      {/* CONFEDERATION QUICK SELECTOR TABS */}
      <div className="flex flex-wrap items-center gap-2 p-2 rounded-2xl bg-[#090E1B] border border-white/10 shadow-lg">
        {[
          { id: 'ALL', label: '🌍 Tous les Clubs', count: confedCounts.ALL },
          { id: 'CAF', label: '🌍 CAF Afrique', count: confedCounts.CAF, color: 'text-emerald-400' },
          { id: 'UEFA', label: '🏆 UEFA Europe', count: confedCounts.UEFA, color: 'text-blue-400' },
          { id: 'CONMEBOL', label: '⚽ CONMEBOL Am. Sud', count: confedCounts.CONMEBOL, color: 'text-amber-400' },
          { id: 'CONCACAF', label: '🌎 CONCACAF Am. Nord', count: confedCounts.CONCACAF, color: 'text-cyan-400' },
          { id: 'AFC', label: '⭐ AFC Asie / Golfe', count: confedCounts.AFC, color: 'text-purple-400' },
          { id: 'OFC', label: '🌊 OFC Océanie', count: confedCounts.OFC, color: 'text-teal-400' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              setSelectedConfederation(tab.id);
              setQuickChip('ALL');
            }}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              selectedConfederation === tab.id
                ? 'bg-amber-500 text-black font-black shadow-md shadow-amber-500/20'
                : 'bg-white/5 text-gray-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <span>{tab.label}</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono font-black ${
                selectedConfederation === tab.id ? 'bg-black text-amber-400' : 'bg-white/10 text-gray-400'
              }`}
            >
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* SEARCH AND FILTER BAR */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#090E1B] border border-white/10 space-y-4 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {/* Main Search */}
          <div className="relative md:col-span-2">
            <input
              type="text"
              value={globalSearch}
              onChange={(e) => setGlobalSearch(e.target.value)}
              placeholder="Rechercher un club, pays, ville, stade, président, directeur sportif, coach ou besoin mercato..."
              className="w-full px-3.5 py-2.5 pl-9 rounded-xl bg-[#050810] border border-white/15 text-white text-xs focus:border-amber-500 focus:outline-none placeholder:text-gray-500"
            />
            <span className="absolute left-3 top-2.5 text-gray-500 text-xs">🔍</span>
            {globalSearch && (
              <button
                onClick={() => setGlobalSearch('')}
                className="absolute right-3 top-2.5 text-gray-400 hover:text-white text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Country selector */}
          <div>
            <select
              value={selectedCountryFilter}
              onChange={(e) => setSelectedCountryFilter(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl bg-[#050810] border border-white/15 text-white text-xs focus:border-amber-500 focus:outline-none"
            >
              <option value="ALL">🌍 Tous les Pays ({availableCountries.length})</option>
              {availableCountries.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Sort By selector */}
          <div>
            <select
              value={selectedSortBy}
              onChange={(e) => setSelectedSortBy(e.target.value as any)}
              className="w-full px-3 py-2.5 rounded-xl bg-[#050810] border border-white/15 text-white text-xs focus:border-amber-500 focus:outline-none font-mono"
            >
              <option value="PRESTIGE">⭐ Notoriété & Followers</option>
              <option value="TROPHIES_DESC">🏆 Palmarès & Trophées</option>
              <option value="NEEDS_DESC">🎯 Besoins Mercato Ouverts</option>
              <option value="NAME_ASC">🔤 Nom de Club (A à Z)</option>
              <option value="COUNTRY_ASC">🌍 Pays (Alphabétique)</option>
            </select>
          </div>
        </div>

        {/* ONE-TOUCH QUICK FILTER CHIPS */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          {[
            { id: 'ALL', label: '🌍 Tous les Clubs du Monde' },
            { id: 'TACTICAL_433', label: '📐 4-3-3 Gegenpressing' },
            { id: 'TACTICAL_4231', label: '📐 4-2-3-1 Attaque Placée' },
            { id: 'TACTICAL_352', label: '📐 3-5-2 Pistons & Contre' },
            { id: 'NEEDS', label: '🚨 Besoins Mercato Actifs' },
            { id: 'PARTNERS', label: '🤝 Partenaires Officiels ATF' },
            { id: 'CAF', label: '🌍 Géants CAF (Afrique)' },
            { id: 'UEFA', label: '🇪🇺 Élite UEFA (Europe)' },
            { id: 'AMERICAS', label: '🌎 Amériques (CONMEBOL/CONCACAF)' },
            { id: 'GULF_ASIA', label: '🇸🇦 Saudi Pro League & Asie' },
            { id: 'FOLLOWED', label: '🔔 Mes Clubs Suivis' },
          ].map((chip) => (
            <button
              key={chip.id}
              onClick={() => {
                setQuickChip(chip.id);
                if (chip.id === 'CAF') setSelectedConfederation('CAF');
                else if (chip.id === 'UEFA') setSelectedConfederation('UEFA');
                else if (chip.id === 'ALL') setSelectedConfederation('ALL');
                else if (chip.id === 'TACTICAL_433') setSelectedTacticalFormation('4-3-3');
                else if (chip.id === 'TACTICAL_4231') setSelectedTacticalFormation('4-2-3-1');
                else if (chip.id === 'TACTICAL_352') setSelectedTacticalFormation('3-5-2');
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
                quickChip === chip.id
                  ? 'bg-amber-500 text-black font-black'
                  : 'bg-[#050810] text-gray-400 hover:text-white border border-white/5'
              }`}
            >
              {chip.label}
            </button>
          ))}
        </div>

        {/* ADVANCED CLUBS FILTERS TOGGLE & CONTROLS */}
        <div className="pt-2 border-t border-white/5 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <button
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className="text-xs font-mono font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1.5 cursor-pointer"
            >
              <span>⚙️</span>
              <span>Filtres Avancés des Clubs & Besoins Mercato</span>
              {activeFiltersCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-black text-[10px] font-black">
                  {activeFiltersCount} actif{activeFiltersCount > 1 ? 's' : ''}
                </span>
              )}
              <span>{showAdvancedFilters ? '▲' : '▼'}</span>
            </button>

            {activeFiltersCount > 0 && (
              <button
                onClick={resetAllFilters}
                className="text-[11px] font-mono text-red-400 hover:text-red-300 underline cursor-pointer"
              >
                ✕ Réinitialiser tous les filtres ({activeFiltersCount})
              </button>
            )}
          </div>

          {showAdvancedFilters && (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 p-3.5 rounded-xl bg-[#050810] border border-white/5 animate-in fade-in duration-200">
              {/* League Selector */}
              <div>
                <label className="block text-[10px] font-mono text-gray-400 uppercase font-bold mb-1">
                  Ligue / Championnat
                </label>
                <select
                  value={selectedLeagueFilter}
                  onChange={(e) => setSelectedLeagueFilter(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#090E1B] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                >
                  <option value="ALL">Toutes les Ligues ({availableLeagues.length})</option>
                  {availableLeagues.map((league) => (
                    <option key={league} value={league}>
                      {league}
                    </option>
                  ))}
                </select>
              </div>

              {/* Need / Profile Selector */}
              <div>
                <label className="block text-[10px] font-mono text-gray-400 uppercase font-bold mb-1">
                  Profil Recherché au Mercato
                </label>
                <select
                  value={selectedNeedFilter}
                  onChange={(e) => setSelectedNeedFilter(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#090E1B] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                >
                  <option value="ALL">Tous les Postes & Besoins</option>
                  <option value="Buteur">Avant-centre / Buteur (BU)</option>
                  <option value="Ailier">Ailier / Vitesse 1v1 (AG / AD)</option>
                  <option value="Milieu">Milieu Créatif / Relayeur / Box-to-Box</option>
                  <option value="Sentinelle">Sentinelle / Numéro 6 Récupérateur</option>
                  <option value="Défenseur">Défenseur Central (DC) Relanceur</option>
                  <option value="Piston">Pistons & Latéraux (DL)</option>
                  <option value="Gardien">Gardien de But Moderne</option>
                  <option value="U17">Pépites U17 & Académies</option>
                  <option value="U19">Espoirs U19 & Post-formation</option>
                  <option value="U21">Groupe Pro U21</option>
                </select>
              </div>

              {/* Budget Range Selector */}
              <div>
                <label className="block text-[10px] font-mono text-gray-400 uppercase font-bold mb-1">
                  Budget Transfert Club
                </label>
                <select
                  value={selectedBudgetFilter}
                  onChange={(e) => setSelectedBudgetFilter(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#090E1B] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                >
                  <option value="ALL">Toutes les Fourchettes</option>
                  <option value="ÉLITE (+15M€)">Élite (+15M€)</option>
                  <option value="MOYEN (2M€ - 15M€)">Moyen (2M€ - 15M€)</option>
                  <option value="TREMPLIN (< 2M€)">Tremplin (&lt; 2M€)</option>
                  <option value="CONVENTION ACADÉMIE">Convention Académie</option>
                </select>
              </div>

              {/* Transfer Type Selector */}
              <div>
                <label className="block text-[10px] font-mono text-gray-400 uppercase font-bold mb-1">
                  Format de Transfert
                </label>
                <select
                  value={selectedTransferType}
                  onChange={(e) => setSelectedTransferType(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#090E1B] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                >
                  <option value="ALL">Tous Formats</option>
                  <option value="ACHAT DIRECT">Achat Direct</option>
                  <option value="PRÊT AVEC OPTION">Prêt avec Option</option>
                  <option value="CONVENTION PARTENARIAT">Convention Partenariat</option>
                  <option value="ESSAI SUPERVISÉ">Essai Supervisé</option>
                </select>
              </div>

              {/* Tactical System Selector */}
              <div>
                <label className="block text-[10px] font-mono text-blue-400 uppercase font-bold mb-1">
                  📐 Schéma Tactique Privilégié
                </label>
                <select
                  value={selectedTacticalFormation}
                  onChange={(e) => setSelectedTacticalFormation(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#090E1B] border border-blue-500/30 text-white text-xs focus:border-amber-500 focus:outline-none"
                >
                  <option value="ALL">Tous Dispositifs Tactiques</option>
                  <option value="4-3-3">4-3-3 (Offensif / Gegenpressing)</option>
                  <option value="4-2-3-1">4-2-3-1 (Attaque Placée / Meneur)</option>
                  <option value="3-5-2">3-5-2 (Transition Rapide / Pistons)</option>
                  <option value="3-4-3">3-4-3 (Largeur & Pressing Haut)</option>
                  <option value="4-4-2">4-4-2 (Bloc Médian / Compact)</option>
                </select>
              </div>

              {/* Playing Style Selector */}
              <div>
                <label className="block text-[10px] font-mono text-blue-400 uppercase font-bold mb-1">
                  ⚡ Style de Jeu & Animation
                </label>
                <select
                  value={selectedPlayingStyle}
                  onChange={(e) => setSelectedPlayingStyle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#090E1B] border border-blue-500/30 text-white text-xs focus:border-amber-500 focus:outline-none"
                >
                  <option value="ALL">Tous Styles de Jeu</option>
                  <option value="Gegenpressing & Bloc Haut">Gegenpressing & Bloc Haut</option>
                  <option value="Attaque Placée & Possession">Attaque Placée & Possession</option>
                  <option value="Transition Rapide & Contre">Transition Rapide & Contre</option>
                  <option value="Bloc Médian & Défense Compacte">Bloc Médian & Défense Compacte</option>
                </select>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* TABS: ALL / CLUBS / PRESIDENTS / DIRECTORS / COACHES / COMPANIES */}
      <div className="flex border-b border-white/10 space-x-6 overflow-x-auto text-xs font-bold font-mono">
        <button
          onClick={() => setActiveTab('CLUBS')}
          className={`pb-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'CLUBS'
              ? 'border-amber-500 text-amber-400 font-black'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <span>🏟️ Clubs du Monde</span>
          <span className="px-1.5 py-0.2 rounded-full bg-white/10 text-[10px]">
            {filteredClubs.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('ALL')}
          className={`pb-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'ALL'
              ? 'border-amber-500 text-amber-400 font-black'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <span>🌐 Écosystème Global</span>
        </button>

        <button
          onClick={() => setActiveTab('PRESIDENTS')}
          className={`pb-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'PRESIDENTS'
              ? 'border-amber-500 text-amber-400 font-black'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <span>🏛️ Présidents</span>
          <span className="px-1.5 py-0.2 rounded-full bg-white/10 text-[10px]">
            {professionals.filter((p) => p.role === 'PRESIDENT').length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('DIRECTORS')}
          className={`pb-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'DIRECTORS'
              ? 'border-amber-500 text-amber-400 font-black'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <span>👔 Directeurs Sportifs & Recruteurs</span>
          <span className="px-1.5 py-0.2 rounded-full bg-white/10 text-[10px]">
            {professionals.filter((p) => p.role === 'SPORTING_DIRECTOR' || p.role === 'CHIEF_SCOUT').length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('COACHES')}
          className={`pb-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'COACHES'
              ? 'border-amber-500 text-amber-400 font-black'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <span>📋 Entraîneurs</span>
          <span className="px-1.5 py-0.2 rounded-full bg-white/10 text-[10px]">
            {professionals.filter((p) => p.role === 'HEAD_COACH').length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('COMPANIES')}
          className={`pb-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'COMPANIES'
              ? 'border-amber-500 text-amber-400 font-black'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <span>🏢 Grandes Entreprises</span>
          <span className="px-1.5 py-0.2 rounded-full bg-white/10 text-[10px]">
            {companies.filter((c) => c.entityType === 'CORPORATE' || c.category === 'Grandes Entreprises & Sponsors Mondiaux').length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('BANKS')}
          className={`pb-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'BANKS'
              ? 'border-purple-500 text-purple-400 font-black'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <span>🏦 Banques & Financements</span>
          <span className="px-1.5 py-0.2 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-bold">
            {companies.filter((c) => c.entityType === 'BANK' || c.category === 'Banque & Financement Sportif').length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('UNIVERSITIES')}
          className={`pb-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'UNIVERSITIES'
              ? 'border-blue-500 text-blue-400 font-black'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <span>🎓 Universités & Bourses</span>
          <span className="px-1.5 py-0.2 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-bold">
            {companies.filter((c) => c.entityType === 'UNIVERSITY' || c.category === 'Université & Bourses Sport-Études').length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('TELEVISION')}
          className={`pb-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'TELEVISION'
              ? 'border-red-500 text-red-400 font-black'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <span>📺 Chaînes TV & Médias</span>
          <span className="px-1.5 py-0.2 rounded-full bg-red-500/20 text-red-300 text-[10px] font-bold">
            {companies.filter((c) => c.entityType === 'TELEVISION' || c.category === 'Chaîne Télévision & Médias Mondiaux' || c.entityType === 'MEDIA').length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('TELECOM')}
          className={`pb-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'TELECOM'
              ? 'border-cyan-500 text-cyan-400 font-black'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <span>📡 Télécoms & Connectivité</span>
          <span className="px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-bold">
            {companies.filter((c) => c.entityType === 'TELECOM' || c.category === 'Opérateur Télécom & Communication').length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('FOOD')}
          className={`pb-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'FOOD'
              ? 'border-emerald-500 text-emerald-400 font-black'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <span>🥤 Agroalimentaire & Nutrition</span>
          <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
            {companies.filter((c) => c.entityType === 'FOOD' || c.category === 'Agroalimentaire, Boissons & Nutrition').length}
          </span>
        </button>
      </div>

      {/* CLUBS SECTION */}
      {(activeTab === 'ALL' || activeTab === 'CLUBS') && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <span>🏟️ Clubs du Monde Répertoriés</span>
                <span className="text-amber-400 text-sm font-mono font-normal">
                  ({filteredClubs.length} résultat{filteredClubs.length > 1 ? 's' : ''})
                </span>
              </h2>
            </div>
            <span className="text-xs text-gray-400 font-mono">
              Filtre actif : {selectedConfederation === 'ALL' ? 'Toutes confédérations' : selectedConfederation} · Tri par {selectedSortBy}
            </span>
          </div>

          {filteredClubs.length === 0 ? (
            <div className="py-16 text-center space-y-4 bg-[#090E1B] rounded-2xl border border-white/10 p-6">
              <span className="text-5xl block">🔍</span>
              <h3 className="text-lg font-bold text-white">Aucun club ne correspond à ces critères</h3>
              <p className="text-xs text-gray-400 max-w-md mx-auto">
                Essayez d'élargir votre recherche, de changer de confédération ou de réinitialiser vos filtres avancés.
              </p>
              <button
                onClick={resetAllFilters}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase cursor-pointer"
              >
                Réinitialiser les Filtres
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredClubs.slice(0, visibleClubsLimit).map((club) => {
                  const isSubscribed = isSubscribedToClub(club.id);
                  return (
                    <div
                      key={club.id}
                      className="bg-[#090E1B] rounded-2xl border border-white/10 p-5 flex flex-col justify-between space-y-4 hover:border-amber-500/50 transition-all shadow-xl group relative overflow-hidden"
                    >
                      {/* Top confederation stripe */}
                      <div className="space-y-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <img
                              src={club.logoUrl}
                              alt={club.name}
                              loading="lazy"
                              decoding="async"
                              className="w-14 h-14 rounded-xl object-cover border border-white/10 shadow-md group-hover:scale-105 transition-transform shrink-0"
                            />
                          <div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <h3 className="font-black text-white text-base leading-tight group-hover:text-amber-400 transition-colors">
                                {club.name}
                              </h3>
                              {club.verified && (
                                <span className="text-amber-400 text-xs font-bold" title="Vérifié ATF">
                                  ✓
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-gray-300 font-mono mt-0.5">
                              {club.countryFlag} {club.city}, {club.country}
                            </p>
                            <p className="text-[11px] text-amber-400/90 font-mono font-bold mt-0.5">
                              {club.league}
                            </p>
                          </div>
                        </div>

                        {/* Push alert subscription toggle */}
                        <button
                          onClick={() => toggleClubAlertSubscription(club.id, club.name)}
                          className={`p-2 rounded-xl border text-sm transition-all cursor-pointer ${
                            isSubscribed
                              ? 'bg-amber-500/20 text-amber-400 border-amber-500/40 hover:bg-amber-500/30'
                              : 'bg-white/5 text-gray-500 border-white/10 hover:text-amber-400 hover:bg-white/10'
                          }`}
                          title={isSubscribed ? "Abonné aux alertes mercato de ce club" : "S'abonner aux alertes de ce club"}
                          aria-label="Alerte club"
                        >
                          {isSubscribed ? '🔔' : '🔕'}
                        </button>
                      </div>

                      {/* Confederation & Status Badges */}
                      <div className="flex flex-wrap items-center gap-1.5">
                        {getConfederationBadge(club.confederation)}
                        {club.tacticalSystem && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedClubDossier(club);
                              setClubDossierInitialTab('TACTICAL');
                            }}
                            className="px-2 py-0.5 rounded-full bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/40 text-[9px] font-mono text-blue-300 font-bold flex items-center gap-1 cursor-pointer transition-colors"
                            title="Ouvrir l'Analyse Tactique & Dispositif du club"
                          >
                            <span>📐</span>
                            <span>{club.tacticalSystem}</span>
                            <span className="text-[8px] text-blue-400">↗</span>
                          </button>
                        )}
                        {club.budgetRange && (
                          <span className="px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-[9px] font-mono text-gray-300">
                            💰 {club.budgetRange}
                          </span>
                        )}
                        {club.targetAge && (
                          <span className="px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-[9px] font-mono text-gray-300">
                            🎯 {club.targetAge}
                          </span>
                        )}
                      </div>

                      {/* Staff Directory Brief */}
                      <div className="p-3 rounded-xl bg-[#050810] text-[11px] text-gray-300 space-y-1 font-mono">
                        {club.president && (
                          <div className="flex justify-between truncate">
                            <span className="text-gray-500">Président :</span>
                            <span className="text-white font-semibold truncate ml-2">{club.president}</span>
                          </div>
                        )}
                        {club.sportingDirector && (
                          <div className="flex justify-between truncate">
                            <span className="text-gray-500">Dir. Sportif :</span>
                            <span className="text-amber-300 font-semibold truncate ml-2">{club.sportingDirector}</span>
                          </div>
                        )}
                        {club.headCoach && (
                          <div className="flex justify-between truncate">
                            <span className="text-gray-500">Coach :</span>
                            <span className="text-gray-200 truncate ml-2">{club.headCoach}</span>
                          </div>
                        )}
                      </div>

                      {/* Open Recruitment Needs */}
                      {club.openNeeds && club.openNeeds.length > 0 && (
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-[10px] font-mono font-bold uppercase text-amber-400">
                            <span className="flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                              Besoins Mercato Prioritaires :
                            </span>
                            <span className="text-gray-400">{club.openNeeds.length} ouvert{club.openNeeds.length > 1 ? 's' : ''}</span>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {club.openNeeds.slice(0, 3).map((need, idx) => (
                              <span
                                key={idx}
                                className="px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30 text-[10px] text-amber-200 truncate max-w-full font-mono"
                              >
                                • {need}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Card Actions */}
                    <div className="pt-2 border-t border-white/5 flex flex-col gap-2">
                      <div className="grid grid-cols-3 gap-1.5">
                        <button
                          onClick={() => {
                            setSelectedClubDossier(club);
                            setClubDossierInitialTab('OVERVIEW');
                          }}
                          className="py-2 px-1 rounded-xl bg-white/5 hover:bg-white/10 text-white font-bold text-[11px] uppercase tracking-wider transition-colors cursor-pointer text-center truncate"
                          title="Voir le dossier complet du club"
                        >
                          📋 Dossier
                        </button>
                        <button
                          onClick={() => {
                            setSelectedClubDossier(club);
                            setClubDossierInitialTab('TACTICAL');
                          }}
                          className="py-2 px-1 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 text-blue-300 font-bold text-[11px] uppercase tracking-wider transition-colors cursor-pointer text-center truncate"
                          title="Consulter l'Analyse Tactique et le Pitch Board"
                        >
                          📐 Tactique
                        </button>
                        <button
                          onClick={() => setProposePlayerClub(club)}
                          className="py-2 px-1 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-[11px] uppercase tracking-wider transition-colors cursor-pointer text-center shadow-md active:scale-95 truncate"
                          title="Proposer un joueur à ce club"
                        >
                          ★ Proposer
                        </button>
                      </div>

                      <div className="flex items-center justify-between text-[10px] font-mono text-gray-400 pt-1">
                        <span>{club.trophiesCount ? `🏆 ${club.trophiesCount} titres` : 'Club Certifié'}</span>
                        <a
                          href={`${FOUNDER_INFO.whatsappUrl}?text=${encodeURIComponent(`Bonjour Seydou Mario TRAORÉ, je souhaite entrer en contact avec le club ${club.name} (${club.country}) pour un transfert ou une détection.`)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-emerald-400 hover:text-emerald-300 font-bold"
                        >
                          WhatsApp Desk ↗
                        </a>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {filteredClubs.length > visibleClubsLimit && (
              <div className="pt-4 text-center">
                <button
                  onClick={() => setVisibleClubsLimit(prev => prev + 18)}
                  className="px-6 py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 font-mono text-xs font-bold transition-all cursor-pointer shadow-md"
                >
                  Afficher 18 clubs supplémentaires ({Math.min(visibleClubsLimit, filteredClubs.length)} / {filteredClubs.length}) ➔
                </button>
              </div>
            )}
          </div>
        )}
      </div>
      )}

      {/* PROFESSIONALS SECTION (PRESIDENTS / DIRECTORS / COACHES) */}
      {(activeTab === 'ALL' || activeTab === 'PRESIDENTS' || activeTab === 'DIRECTORS' || activeTab === 'COACHES') && (
        <div className="space-y-4 pt-4 border-t border-white/5">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-white flex items-center gap-2">
              <span>👔 Dirigeants, Présidents & Entraîneurs</span>
              <span className="text-amber-400 text-sm font-mono font-normal">
                ({filteredProfessionals.length} profils)
              </span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredProfessionals.slice(0, visibleProsLimit).map((pro) => (
              <div
                key={pro.id}
                className="bg-[#090E1B] rounded-2xl border border-white/10 p-5 flex flex-col justify-between space-y-4 hover:border-amber-500/50 transition-all shadow-xl"
              >
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={pro.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80'}
                      alt={pro.name}
                      loading="lazy"
                      decoding="async"
                      className="w-14 h-14 rounded-xl object-cover border border-white/10 shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="font-black text-white text-base">{pro.name}</h3>
                        {pro.verified && <span className="text-amber-400 text-xs">✓</span>}
                      </div>
                      <p className="text-xs text-amber-400 font-mono font-semibold">{pro.title}</p>
                      <p className="text-[11px] text-gray-400 font-mono">
                        {pro.countryFlag} {pro.clubOrOrg} · {pro.country}
                      </p>
                    </div>
                  </div>

                  <p className="text-xs text-gray-300 leading-relaxed line-clamp-3">{pro.bio}</p>

                  <div className="flex items-center justify-between text-[11px] font-mono text-gray-400 pt-2 border-t border-white/5">
                    <span>{pro.connectionsCount} relations directes</span>
                    <span className="text-emerald-400 font-bold">Actif aujourd'hui</span>
                  </div>
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    onClick={() => {
                      createDirectConversation({
                        id: pro.id,
                        name: pro.name,
                        title: pro.title,
                        avatar: pro.avatarUrl,
                        org: pro.clubOrOrg,
                        role: pro.role
                      });
                      onNavigate('messages');
                    }}
                    className="flex-1 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    Message Confidentiel
                  </button>

                  <button
                    onClick={() => toggleConnection(pro.id)}
                    className={`px-3 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      pro.connectionStatus === 'CONNECTED'
                        ? 'bg-[#050810] text-emerald-400 border border-emerald-500/30'
                        : pro.connectionStatus === 'PENDING'
                        ? 'bg-[#050810] text-amber-400 border border-amber-500/30'
                        : 'bg-white/10 hover:bg-white/20 text-white'
                    }`}
                  >
                    {pro.connectionStatus === 'CONNECTED' ? 'Connecté' : pro.connectionStatus === 'PENDING' ? 'En attente' : '+ Connecter'}
                  </button>
                </div>
              </div>
            ))}
          </div>

          {filteredProfessionals.length > visibleProsLimit && (
            <div className="pt-4 text-center">
              <button
                onClick={() => setVisibleProsLimit(prev => prev + 18)}
                className="px-6 py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 font-mono text-xs font-bold transition-all cursor-pointer shadow-md"
              >
                Afficher 18 dirigeants supplémentaires ({Math.min(visibleProsLimit, filteredProfessionals.length)} / {filteredProfessionals.length}) ➔
              </button>
            </div>
          )}
        </div>
      )}

      {/* COMPANIES, BANKS, UNIVERSITIES, TV, TELECOM, FOOD SECTION */}
      {(activeTab === 'ALL' || activeTab === 'COMPANIES' || activeTab === 'BANKS' || activeTab === 'UNIVERSITIES' || activeTab === 'TELEVISION' || activeTab === 'TELECOM' || activeTab === 'FOOD') && (
        <div className="space-y-4 pt-4 border-t border-white/5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <span>
                  {activeTab === 'BANKS'
                    ? '🏦 Banques & Institutions Financières Agréées'
                    : activeTab === 'UNIVERSITIES'
                    ? '🎓 Grandes Universités Mondiales & Bourses Sport-Études'
                    : activeTab === 'TELEVISION'
                    ? '📺 Chaînes Télévision, Médias & Diffuseurs Mondiaux'
                    : activeTab === 'TELECOM'
                    ? '📡 Opérateurs Télécom & Partenaires Communication'
                    : activeTab === 'FOOD'
                    ? '🥤 Entreprises Agroalimentaires, Boissons & Nutrition Sportive'
                    : activeTab === 'COMPANIES'
                    ? '🏢 Grandes Entreprises, Sponsors & Marques Mondiales'
                    : '🤝 Entreprises, Banques, Universités & Partenaires'}
                </span>
                <span className="text-amber-400 text-sm font-mono font-normal">
                  ({filteredCompanies.length} institution{filteredCompanies.length > 1 ? 's' : ''})
                </span>
              </h2>
              <p className="text-xs text-gray-400 font-mono mt-0.5">
                Passerelles directes pour cautionnements de transferts, bourses sport-études universitaires, diffusion TV, connectivité télécom et contrats de sponsoring nutrition.
              </p>
            </div>

            {/* Quick Filter Switcher */}
            <div className="flex flex-wrap items-center gap-1.5 self-start sm:self-auto">
              <button
                onClick={() => setActiveTab('COMPANIES')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold transition-all cursor-pointer ${
                  activeTab === 'COMPANIES'
                    ? 'bg-amber-500 text-black'
                    : 'bg-white/5 text-gray-400 hover:text-white'
                }`}
              >
                🏢 Entreprises
              </button>
              <button
                onClick={() => setActiveTab('BANKS')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold transition-all cursor-pointer ${
                  activeTab === 'BANKS'
                    ? 'bg-purple-500 text-white'
                    : 'bg-white/5 text-gray-400 hover:text-white'
                }`}
              >
                🏦 Banques
              </button>
              <button
                onClick={() => setActiveTab('UNIVERSITIES')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold transition-all cursor-pointer ${
                  activeTab === 'UNIVERSITIES'
                    ? 'bg-blue-500 text-white'
                    : 'bg-white/5 text-gray-400 hover:text-white'
                }`}
              >
                🎓 Universités
              </button>
              <button
                onClick={() => setActiveTab('TELEVISION')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold transition-all cursor-pointer ${
                  activeTab === 'TELEVISION'
                    ? 'bg-red-500 text-white'
                    : 'bg-white/5 text-gray-400 hover:text-white'
                }`}
              >
                📺 Télévision
              </button>
              <button
                onClick={() => setActiveTab('TELECOM')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold transition-all cursor-pointer ${
                  activeTab === 'TELECOM'
                    ? 'bg-cyan-500 text-white'
                    : 'bg-white/5 text-gray-400 hover:text-white'
                }`}
              >
                📡 Télécoms
              </button>
              <button
                onClick={() => setActiveTab('FOOD')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold transition-all cursor-pointer ${
                  activeTab === 'FOOD'
                    ? 'bg-emerald-500 text-white'
                    : 'bg-white/5 text-gray-400 hover:text-white'
                }`}
              >
                🥤 Nutrition
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredCompanies.slice(0, visibleCompaniesLimit).map((comp) => {
              const isBank = comp.entityType === 'BANK' || comp.category === 'Banque & Financement Sportif';
              const isUniv = comp.entityType === 'UNIVERSITY' || comp.category === 'Université & Bourses Sport-Études';
              const isTV = comp.entityType === 'TELEVISION' || comp.category === 'Chaîne Télévision & Médias Mondiaux';
              const isTelecom = comp.entityType === 'TELECOM' || comp.category === 'Opérateur Télécom & Communication';
              const isFood = comp.entityType === 'FOOD' || comp.category === 'Agroalimentaire, Boissons & Nutrition';
              return (
                <div
                  key={comp.id}
                  className={`bg-[#090E1B] rounded-2xl border p-5 flex flex-col justify-between space-y-4 transition-all shadow-xl hover:scale-[1.01] ${
                    isBank
                      ? 'border-purple-500/40 hover:border-purple-400'
                      : isUniv
                      ? 'border-blue-500/40 hover:border-blue-400'
                      : isTV
                      ? 'border-red-500/40 hover:border-red-400'
                      : isTelecom
                      ? 'border-cyan-500/40 hover:border-cyan-400'
                      : isFood
                      ? 'border-emerald-500/40 hover:border-emerald-400'
                      : 'border-white/10 hover:border-amber-500/50'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={comp.logoUrl}
                          alt={comp.name}
                          loading="lazy"
                          decoding="async"
                          className="w-14 h-14 rounded-2xl object-cover border border-white/10 shadow-md shrink-0"
                        />
                        <div>
                          <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded border inline-block ${
                            isBank
                              ? 'bg-purple-500/20 text-purple-300 border-purple-500/40'
                              : isUniv
                              ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                              : isTV
                              ? 'bg-red-500/20 text-red-300 border-red-500/40'
                              : isTelecom
                              ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                              : isFood
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                              : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                          }`}>
                            {comp.category}
                          </span>
                          <h3 className="font-black text-white text-base mt-1 leading-snug">{comp.name}</h3>
                          <p className="text-xs text-gray-400 font-mono">
                            {comp.countryFlag} Siège : {comp.country}
                          </p>
                        </div>
                      </div>
                      <span className="text-[10px] text-emerald-400 font-mono shrink-0">✓ Certifié</span>
                    </div>

                    <p className="text-xs text-gray-300 leading-relaxed">{comp.description}</p>

                    {/* Specific Bank or University Badges */}
                    {comp.programDetails?.scholarshipFundEur && (
                      <div className="p-2.5 rounded-xl bg-[#050810] border border-blue-500/30 text-[11px] font-mono text-blue-300 flex items-center justify-between">
                        <span>Bourses Disponibles :</span>
                        <strong className="text-white">{comp.programDetails.scholarshipFundEur}</strong>
                      </div>
                    )}

                    {comp.programDetails?.financingTypes && (
                      <div className="p-2.5 rounded-xl bg-[#050810] border border-purple-500/30 text-[11px] font-mono text-purple-300 space-y-1">
                        <span className="block text-[10px] uppercase text-gray-400">Solutions Financières :</span>
                        <div className="flex flex-wrap gap-1">
                          {comp.programDetails.financingTypes.map((t, idx) => (
                            <span key={idx} className="px-1.5 py-0.5 rounded bg-purple-500/10 text-purple-200 text-[10px]">
                              • {t}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="p-3 rounded-xl bg-[#050810] text-[11px] text-gray-300 space-y-0.5">
                      <span className="text-gray-500 block text-[10px] uppercase font-bold font-mono">
                        Contact Référent :
                      </span>
                      <div className="font-semibold text-white">{comp.contactPerson}</div>
                      <div className="text-amber-400 font-mono text-[10px]">{comp.contactRole}</div>
                    </div>

                    {comp.partnershipOpportunities.length > 0 && (
                      <div className="space-y-1">
                        <span className="text-[10px] font-mono font-bold uppercase text-amber-400 block">
                          Opportunités Ouvertes :
                        </span>
                        <div className="flex flex-wrap gap-1">
                          {comp.partnershipOpportunities.map((opp, idx) => (
                            <span
                              key={idx}
                              className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-[10px] text-gray-300"
                            >
                              🤝 {opp}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="pt-2 flex flex-col gap-2">
                    <button
                      onClick={() => setSelectedInstitution(comp)}
                      className={`w-full py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md flex items-center justify-center gap-1.5 active:scale-95 ${
                        isBank
                          ? 'bg-purple-600 hover:bg-purple-500 text-white shadow-purple-600/30'
                          : isUniv
                          ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-600/30'
                          : isTV
                          ? 'bg-red-600 hover:bg-red-500 text-white shadow-red-600/30'
                          : isTelecom
                          ? 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-cyan-600/30'
                          : isFood
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
                          : 'bg-amber-500 hover:bg-amber-400 text-black shadow-amber-500/20'
                      }`}
                    >
                      {isBank && '🏦 Demander Caution / Financement'}
                      {isUniv && '🎓 Postuler Bourse Sport-Études'}
                      {isTV && '📺 Proposer Droits & Couverture TV'}
                      {isTelecom && '📡 Demande Connectivité / Sponsoring'}
                      {isFood && '🥤 Demander Dotation Nutritionnelle'}
                      {!isBank && !isUniv && !isTV && !isTelecom && !isFood && '🤝 Proposer Partenariat'}
                    </button>

                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          createDirectConversation({
                            id: comp.id,
                            name: comp.contactPerson,
                            title: `${comp.contactRole} · ${comp.name}`,
                            avatar: comp.logoUrl,
                            org: comp.name,
                            role: 'EXECUTIVE'
                          });
                          onNavigate('messages');
                        }}
                        className="flex-1 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 text-xs font-mono transition-colors cursor-pointer"
                      >
                        💬 Message Direct
                      </button>
                      <a
                        href={comp.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 rounded-xl bg-[#050810] hover:bg-white/10 text-white text-xs font-mono transition-colors text-center"
                      >
                        Site Web ↗
                      </a>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredCompanies.length > visibleCompaniesLimit && (
            <div className="pt-4 text-center">
              <button
                onClick={() => setVisibleCompaniesLimit(prev => prev + 18)}
                className="px-6 py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 font-mono text-xs font-bold transition-all cursor-pointer shadow-md"
              >
                Afficher 18 partenaires supplémentaires ({Math.min(visibleCompaniesLimit, filteredCompanies.length)} / {filteredCompanies.length}) ➔
              </button>
            </div>
          )}
        </div>
      )}

      {/* PAN-AFRICAN & WORLDWIDE SCOUTING CORRIDOR BANNER */}
      <WorldwideNetworkBanner />

      {/* SUCCESS TOAST */}
      {institutionSuccessToast && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-emerald-950/90 border border-emerald-500/50 shadow-2xl text-emerald-200 text-xs font-mono animate-in slide-in-from-bottom duration-300 max-w-md">
          {institutionSuccessToast}
        </div>
      )}

      {/* INSTITUTIONAL CONNECTION MODAL */}
      <InstitutionalConnectionModal
        company={selectedInstitution}
        isOpen={Boolean(selectedInstitution)}
        onClose={() => setSelectedInstitution(null)}
        onSuccess={(msg) => {
          setSelectedInstitution(null);
          setInstitutionSuccessToast(msg);
          setTimeout(() => setInstitutionSuccessToast(null), 5000);
        }}
      />

      {/* CLUB DOSSIER MODAL */}
      <ClubDossierModal
        club={selectedClubDossier}
        isOpen={Boolean(selectedClubDossier)}
        initialTab={clubDossierInitialTab}
        onClose={() => setSelectedClubDossier(null)}
        onProposePlayer={(club) => {
          setSelectedClubDossier(null);
          setProposePlayerClub(club);
        }}
        onStartConversation={(club) => {
          setSelectedClubDossier(null);
          createDirectConversation({
            id: club.id,
            name: club.sportingDirector || club.president || club.name,
            title: `Direction Sportive · ${club.name}`,
            avatar: club.logoUrl,
            org: club.name,
            role: 'SPORTING_DIRECTOR'
          });
          onNavigate('messages');
        }}
      />

      {/* PROPOSE PLAYER MODAL */}
      {proposePlayerClub && (
        <ProposePlayerModal
          club={proposePlayerClub}
          isOpen={Boolean(proposePlayerClub)}
          onClose={() => setProposePlayerClub(null)}
          onNavigate={onNavigate}
        />
      )}
    </div>
  );
};
