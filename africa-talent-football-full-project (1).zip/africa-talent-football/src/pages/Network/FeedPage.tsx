import React, { useState, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNetwork } from '../../context/NetworkContext';
import { usePlayers } from '../../context/PlayerContext';
import { FOUNDER_INFO, formatMarketValue } from '../../data/demoData';
import { FeedPost, ProfessionalRole, RealtimePartnerUpdate } from '../../types/database';
import { DirectPlatformContactModal } from '../../components/common/DirectPlatformContactModal';
import { PostShareModal } from '../../components/common/PostShareModal';
import { compressImageFile } from '../../utils/imageUpload';
import { getRealtimePartnerUpdates, syncLivePartnerIntelligence } from '../../data/realtimePartnerData';
import { useLanguage } from '../../context/LanguageContext';

interface FeedPageProps {
  onNavigate: (view: string, payload?: any) => void;
}

const COMMON_TAGS = [
  '#AfricaTalentFootball',
  '#ScoutingPro',
  '#MercatoB2B',
  '#TalentAfricain',
  '#U20',
  '#EssaiEurope',
  '#Academie',
  '#Detection',
  '#Buteur',
  '#MeneurDeJeu',
  '#Defenseur'
];

export const FeedPage: React.FC<FeedPageProps> = ({ onNavigate }) => {
  const { t, formatDate, formatNumber } = useLanguage();
  const { currentUser, isPremium, toggleSimulatePremium, upgradeToPremium } = useAuth();
  const {
    feedPosts,
    addFeedPost,
    deleteFeedPost,
    likePost,
    addComment,
    clubs,
    professionals,
    createDirectConversation,
    toggleConnection
  } = useNetwork();

  const { players, openVideoModal, totalMarketValue } = usePlayers();

  // Post composer state
  const [newPostContent, setNewPostContent] = useState('');
  const [selectedPlayerForPost, setSelectedPlayerForPost] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<'GENERAL' | 'TALENT' | 'MERCATO' | 'TRIAL' | 'TACTICAL' | 'OFFICIAL'>('GENERAL');
  const [selectedTags, setSelectedTags] = useState<string[]>(['#AfricaTalentFootball']);
  const [mediaUrlInput, setMediaUrlInput] = useState<string>('');
  const [showMediaInput, setShowMediaInput] = useState<boolean>(false);
  const [isUploadingMedia, setIsUploadingMedia] = useState<boolean>(false);
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const mediaFileInputRef = React.useRef<HTMLInputElement>(null);

  // Real-time Partner Alerts state
  const [realtimeAlerts, setRealtimeAlerts] = useState<RealtimePartnerUpdate[]>(() => getRealtimePartnerUpdates());
  const [isSyncingAlerts, setIsSyncingAlerts] = useState<boolean>(false);
  const [selectedRealtimeAlert, setSelectedRealtimeAlert] = useState<RealtimePartnerUpdate | null>(null);

  const handleSyncRealtimeAlerts = () => {
    setIsSyncingAlerts(true);
    setTimeout(() => {
      const refreshed = syncLivePartnerIntelligence();
      setRealtimeAlerts(refreshed);
      setIsSyncingAlerts(false);
    }, 500);
  };

  const handleMediaFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setIsUploadingMedia(true);
      try {
        const compressed = await compressImageFile(e.target.files[0], 900, 600, 0.85);
        setMediaUrlInput(compressed);
        setShowMediaInput(true);
      } catch (err: any) {
        alert(err.message || 'Erreur lors de l’importation du fichier média.');
      } finally {
        setIsUploadingMedia(false);
      }
    }
  };

  // Feed Filter state
  const [activeFeedFilter, setActiveFeedFilter] = useState<'ALL' | 'TALENT' | 'MERCATO' | 'PREMIUM' | 'MY_POSTS'>('ALL');

  // Contact Modal state
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [selectedRecipientForModal, setSelectedRecipientForModal] = useState<any>(null);

  // Post Share & Download state
  const [selectedPostForShare, setSelectedPostForShare] = useState<FeedPost | null>(null);
  const [downloadToast, setDownloadToast] = useState<string | null>(null);

  const handleDownloadPost = (post: FeedPost) => {
    try {
      const header = `========================================================\n` +
        `AFRICA TALENT FOOTBALL - RAPPORT OFFICIEL RÉSEAU B2B\n` +
        `Supervision : SEYDOU MARIO TRAORÉ\n` +
        `Directeur Fondateur – Agent Scout Agréé\n` +
        `Plateforme : ${typeof window !== 'undefined' ? window.location.origin : 'https://africa-talent-football.ai.studio'}\n` +
        `========================================================\n\n`;

      const meta = `RÉFÉRENCE PUBLICATION : #${post.id}\n` +
        `DATE D'ÉMISSION : ${new Date().toLocaleDateString('fr-FR')} à ${new Date().toLocaleTimeString('fr-FR')}\n` +
        `AUTEUR : ${post.authorName}\n` +
        `TITRE / FONCTION : ${post.authorTitle}\n` +
        `STRUCTURE : ${post.authorOrg}\n` +
        `ACCRÉDITATION : ${post.isPremiumAuthor ? 'MEMBRE PREMIUM VIP VÉRIFIÉ' : 'MEMBRE INSCRIT VÉRIFIÉ'}\n` +
        `CATÉGORIE : ${post.category || 'GÉNÉRAL'}\n` +
        `TAGS THÉMATIQUES : ${post.tags.join(' ')}\n\n` +
        `--------------------------------------------------------\n` +
        `CONTENU DÉTAILLÉ DE LA PUBLICATION :\n` +
        `--------------------------------------------------------\n` +
        `${post.content}\n\n`;

      let playerSection = '';
      if (post.playerAttachment) {
        const p = post.playerAttachment;
        playerSection = `--------------------------------------------------------\n` +
          `FICHE TECHNIQUE DU TALENT CERTIFIÉ ATTACHÉ :\n` +
          `--------------------------------------------------------\n` +
          `NOM : ${p.firstName} ${p.lastName}\n` +
          `POSTE : ${p.primaryPosition} | ÂGE : ${p.calculatedAge} ANS (${p.dateOfBirth})\n` +
          `CLUB / ACADÉMIE : ${p.currentClub || p.academy}\n` +
          `NATIONALITÉ : ${p.nationality}\n` +
          `TAILLE / POIDS : ${p.heightCm} cm / ${p.weightKg} kg\n` +
          `PIED DE PRÉDILECTION : ${p.preferredFoot}\n` +
          `COTE MARCHANDE ESTIMÉE : ${p.marketValueDisplay}\n` +
          `STATUT : ${p.status}\n\n`;
      }

      const footer = `========================================================\n` +
        `CERTIFICAT DE CONFORMITÉ AFRICA TALENT FOOTBALL\n` +
        `Hotline WhatsApp Direction : +225 05 44 42 01 62\n` +
        `E-mail : ${FOUNDER_INFO.email}\n` +
        `Plateforme B2B Mondiale : Abidjan · Liège · Lens · Europe\n` +
        `========================================================\n`;

      const blob = new Blob([header + meta + playerSection + footer], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ATF_RAPPORT_${post.id}_${post.authorName.replace(/\s+/g, '_')}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setDownloadToast(`Dossier #${post.id.slice(-6)} téléchargé avec succès !`);
      setTimeout(() => setDownloadToast(null), 3500);
    } catch (err) {
      console.error('Download failed', err);
    }
  };

  // Filter posts
  const filteredFeedPosts = useMemo(() => {
    return feedPosts.filter((post) => {
      if (activeFeedFilter === 'TALENT') {
        return post.category === 'TALENT' || Boolean(post.playerAttachment);
      }
      if (activeFeedFilter === 'MERCATO') {
        return post.category === 'MERCATO' || post.tags.some(t => t.toLowerCase().includes('mercato') || t.toLowerCase().includes('transfert') || t.toLowerCase().includes('essai'));
      }
      if (activeFeedFilter === 'PREMIUM') {
        return Boolean(post.isPremiumAuthor);
      }
      if (activeFeedFilter === 'MY_POSTS') {
        if (!currentUser) return false;
        return post.authorId === currentUser.id || post.authorName.toLowerCase() === `${currentUser.firstName} ${currentUser.lastName}`.toLowerCase();
      }
      return true;
    });
  }, [feedPosts, activeFeedFilter, currentUser]);

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(prev => prev.filter(t => t !== tag));
    } else {
      setSelectedTags(prev => [...prev, tag]);
    }
  };

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostContent.trim()) return;

    const attachedPlayer = players.find(p => p.id === selectedPlayerForPost);

    // Compute author data dynamically from currentUser or fallback
    const authorName = currentUser ? `${currentUser.firstName} ${currentUser.lastName}` : FOUNDER_INFO.name;
    const authorTitle = currentUser
      ? currentUser.role === 'PLAYER'
        ? `Joueur · ${currentUser.clubName || currentUser.primaryPosition || 'Athlète'}`
        : currentUser.role === 'ACADEMY'
        ? `Directeur · ${currentUser.academyName || 'Académie de Formation'}`
        : currentUser.role === 'CLUB'
        ? `Recruteur · ${currentUser.clubName || 'Club Professionnel'}`
        : currentUser.role === 'FIFA_AGENT'
        ? `Agent Licencié FIFA (${currentUser.fifaLicenseNumber || 'Agréé'})`
        : currentUser.role === 'SCOUT'
        ? `Scout Pro · ${currentUser.country}`
        : `Membre Réseau · ${currentUser.role}`
      : FOUNDER_INFO.officialTitle;

    const authorAvatar = currentUser?.avatarUrl || (currentUser
      ? `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(authorName)}`
      : '/src/assets/images/founder_mario_suit_1792079172729.jpg');

    const authorOrg = currentUser?.clubName || currentUser?.academyName || currentUser?.scoutOrg || currentUser?.country || 'Africa Talent Football Platform';
    const authorRole: ProfessionalRole = currentUser ? (currentUser.role as any) : 'SCOUT_AGENT';

    addFeedPost(
      newPostContent,
      selectedTags.length > 0 ? selectedTags : ['#AfricaTalentFootball'],
      attachedPlayer,
      {
        authorId: currentUser?.id,
        authorName,
        authorTitle,
        authorAvatar,
        authorOrg,
        authorRole,
        isVerified: currentUser?.verified !== undefined ? currentUser.verified : true,
        isPremiumAuthor: isPremium,
        category: selectedCategory,
        mediaUrl: mediaUrlInput.trim() || undefined
      }
    );

    setNewPostContent('');
    setSelectedPlayerForPost('');
    setMediaUrlInput('');
    setShowMediaInput(false);
  };

  const handleCommentSubmit = (postId: string, e: React.FormEvent) => {
    e.preventDefault();
    const comment = commentInputs[postId];
    if (!comment?.trim()) return;

    const commenterName = currentUser ? `${currentUser.firstName} ${currentUser.lastName}` : FOUNDER_INFO.name;
    const commenterTitle = currentUser ? `${currentUser.role} · ${currentUser.country}` : 'Scout Agent & Directeur ATF';

    addComment(postId, comment, { name: commenterName, title: commenterTitle });
    setCommentInputs(prev => ({ ...prev, [postId]: '' }));
  };

  const getRoleBadge = (role?: string) => {
    switch (role) {
      case 'PLAYER':
        return <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-mono font-bold">⚽ Joueur</span>;
      case 'CLUB':
        return <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/40 text-[10px] font-mono font-bold">🏟️ Club Pro</span>;
      case 'ACADEMY':
        return <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-400 border border-purple-500/40 text-[10px] font-mono font-bold">🎓 Académie</span>;
      case 'FIFA_AGENT':
        return <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/40 text-[10px] font-mono font-bold">💼 Agent FIFA</span>;
      default:
        return <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/40 text-[10px] font-mono font-bold">🔍 Scout / Pro</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300">
      {/* Top Banner explaining Free & Voluntary Subscription model with Premium benefits */}
      <div className="mb-6 p-4 rounded-3xl bg-gradient-to-r from-[#0C152B] via-[#091022] to-[#0D1C34] border border-amber-500/30 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-2xl shrink-0 shadow-lg shadow-amber-500/20">
            🤝
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 px-2.5 py-0.5 rounded border border-amber-500/30">
                Réseau Professionnel Mondial du Football Africain (Style LinkedIn)
              </span>
              <span className="text-[10px] font-mono font-bold uppercase text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                Inscription 100% Gratuite
              </span>
            </div>
            <h1 className="text-lg sm:text-xl font-black text-white mt-1">
              Partagez vos rapports, annonces et actualités avec clubs, scouts et académies
            </h1>
            <p className="text-xs text-gray-300 mt-0.5">
              L'adhésion est gratuite pour tous. L'abonnement Premium est entièrement volontaire et débloque le contact direct prioritaire avec la direction de la plateforme et les décideurs VIP.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            onClick={() => setIsContactModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-all cursor-pointer shadow-lg shadow-amber-500/20 flex items-center gap-1.5"
          >
            <span>📞 Contact Direct Plateforme</span>
          </button>
          {!currentUser ? (
            <button
              onClick={() => onNavigate('register')}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs transition-colors cursor-pointer border border-white/20"
            >
              Créer Mon Compte Gratuit
            </button>
          ) : (
            <button
              onClick={() => onNavigate('profile')}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs transition-colors cursor-pointer border border-white/20 flex items-center gap-1.5"
            >
              <span>👤 Mon Profil</span>
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: User Account / Profile Card & Fast Navigation */}
        <div className="lg:col-span-3 space-y-5">
          {/* Authenticated user profile card */}
          {currentUser ? (
            <div className="bg-[#090E1B] rounded-3xl border border-white/10 overflow-hidden shadow-xl">
              <div className="h-24 w-full relative overflow-hidden bg-[#050810]">
                <img
                  src={currentUser.coverUrl || 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&auto=format&fit=crop&q=80'}
                  alt="User banner"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                {isPremium && (
                  <div className="absolute top-2 right-2 bg-black/80 backdrop-blur-sm border border-amber-400 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold text-amber-300 flex items-center gap-1 shadow-md">
                    <span>👑 VIP</span>
                  </div>
                )}
              </div>
              <div className="px-5 pb-5 text-center -mt-11 space-y-2.5">
                <div className="w-20 h-20 mx-auto rounded-2xl overflow-hidden border-2 border-amber-400 shadow-2xl bg-black flex items-center justify-center text-white font-black text-2xl relative">
                  {currentUser.avatarUrl ? (
                    <img src={currentUser.avatarUrl} alt={currentUser.firstName} className="w-full h-full object-cover" />
                  ) : (
                    <span>{currentUser.firstName?.[0]}{currentUser.lastName?.[0]}</span>
                  )}
                </div>
                <div>
                  <div className="flex items-center justify-center gap-1.5">
                    <h3 className="font-black text-white text-sm">{currentUser.firstName} {currentUser.lastName}</h3>
                    {currentUser.verified && (
                      <span className="text-amber-400 text-xs" title="Certifié ATF">★</span>
                    )}
                  </div>
                  <div className="pt-0.5">{getRoleBadge(currentUser.role)}</div>
                  <p className="text-[11px] text-gray-400 font-mono mt-1">
                    {currentUser.clubName || currentUser.academyName || currentUser.scoutOrg || currentUser.country}
                  </p>
                </div>

                {/* Subscription status pill */}
                <div className="p-2.5 rounded-xl bg-black/40 border border-white/10 text-left text-xs font-mono space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-gray-400 uppercase">Statut Abonnement</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                      isPremium ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-gray-800 text-gray-300'
                    }`}>
                      {isPremium ? '👑 PREMIUM VIP' : 'GRATUIT (Volontaire)'}
                    </span>
                  </div>
                  <p className="text-[10px] text-gray-400">
                    {isPremium ? 'Ligne directe ouverte avec le fondateur et membres VIP.' : 'Passez au Premium pour contacter directement la direction.'}
                  </p>
                </div>

                {/* Quick actions */}
                <div className="pt-1 space-y-1.5">
                  <button
                    onClick={() => onNavigate('profile')}
                    className="w-full py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-200 border border-white/10 text-[11px] font-bold uppercase transition-colors cursor-pointer"
                  >
                    Gérer Mon Profil & Compte
                  </button>
                  <button
                    onClick={() => toggleSimulatePremium()}
                    className="w-full py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold uppercase transition-colors cursor-pointer"
                  >
                    {isPremium ? '👑 Mode Premium Actif (Basculer)' : '★ Activer Test Premium'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-5 rounded-3xl bg-[#090E1B] border border-amber-500/30 text-center space-y-3 shadow-xl">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/10 border border-amber-500/40 flex items-center justify-center text-2xl">
                🚀
              </div>
              <h3 className="font-black text-white text-sm">Votre Compte Africa Talent</h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                Connectez-vous ou inscrivez-vous gratuitement pour publier des posts, échanger avec les recruteurs et valoriser vos talents.
              </p>
              <div className="space-y-2 pt-1">
                <button
                  onClick={() => onNavigate('login')}
                  className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-md"
                >
                  Se Connecter
                </button>
                <button
                  onClick={() => onNavigate('register')}
                  className="w-full py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10 text-xs font-mono transition-colors cursor-pointer"
                >
                  Inscription Gratuite
                </button>
              </div>
            </div>
          )}

          {/* Quick Platform Navigation Shortcuts */}
          <div className="p-4 rounded-2xl bg-[#090E1B] border border-white/10 text-xs space-y-2.5 font-medium hover:border-white/20 transition-all duration-300">
            <span className="text-[10px] font-mono font-bold uppercase text-gray-400 block mb-1">
              Modules & Annuaire B2B
            </span>
            <button
              onClick={() => onNavigate('directory')}
              className="w-full text-left py-1 text-gray-300 hover:text-amber-400 hover:translate-x-1.5 transition-all duration-200 flex items-center justify-between cursor-pointer"
            >
              <span>🏢 Annuaire Clubs & Dirigeants</span>
              <span className="text-amber-400 font-mono">{clubs.length}</span>
            </button>
            <button
              onClick={() => onNavigate('players')}
              className="w-full text-left py-1 text-gray-300 hover:text-amber-400 hover:translate-x-1.5 transition-all duration-200 flex items-center justify-between cursor-pointer"
            >
              <span>📹 Vidéothèque & Talents (Eyeball)</span>
              <span className="text-emerald-400 font-mono">{players.length}</span>
            </button>
            <button
              onClick={() => onNavigate('matches')}
              className="w-full text-left py-1 text-gray-300 hover:text-amber-400 hover:translate-x-1.5 transition-all duration-200 flex items-center justify-between cursor-pointer"
            >
              <span>📅 Calendriers des Matchs & Actus</span>
              <span className="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-400 rounded text-[9px] font-mono">6 Continents</span>
            </button>
            <button
              onClick={() => onNavigate('messages')}
              className="w-full text-left py-1 text-gray-300 hover:text-amber-400 hover:translate-x-1.5 transition-all duration-200 flex items-center justify-between cursor-pointer"
            >
              <span>💬 Messagerie Institutionnelle</span>
              <span className="px-1.5 py-0.2 bg-amber-500 text-black rounded text-[10px] font-bold">Direct</span>
            </button>
            <button
              onClick={() => setIsContactModalOpen(true)}
              className="w-full text-left py-1 text-amber-300 hover:text-amber-200 hover:translate-x-1.5 transition-all duration-200 flex items-center justify-between font-bold cursor-pointer"
            >
              <span>🛡️ Desk Direction Technique</span>
              <span className="text-amber-400">➔</span>
            </button>
          </div>

          {/* Founder Executive Card */}
          <div className="p-4 rounded-2xl bg-[#090E1B] border border-amber-500/30 text-xs space-y-3 hover:border-amber-400/60 hover:shadow-xl hover:-translate-y-0.5 transition-all duration-300">
            <div className="flex items-center gap-2.5">
              <img
                src="/src/assets/images/founder_mario_suit_1792079172729.jpg"
                alt={FOUNDER_INFO.name}
                className="w-10 h-10 rounded-full object-cover border border-amber-400 group-hover:scale-105 transition-transform"
              />
              <div>
                <div className="font-bold text-white text-xs">{FOUNDER_INFO.name}</div>
                <div className="text-[10px] text-amber-400 font-mono">{FOUNDER_INFO.officialTitle}</div>
              </div>
            </div>
            <p className="text-[11px] text-gray-400 leading-tight">
              Supervision technique des détections et partenariats européens (Standard de Liège, Lens, Jupiler Pro League).
            </p>
            <button
              onClick={() => setIsContactModalOpen(true)}
              className="w-full py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 hover:scale-105 active:scale-95 text-white text-[10px] font-mono font-bold uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
            >
              <span>Ligne Directe Seydou Mario TRAORÉ</span>
            </button>
          </div>
        </div>

        {/* CENTER COLUMN: B2B POST COMPOSER & ACTIVITY FEED */}
        <div className="lg:col-span-6 space-y-6">
          {/* Post Composer (LinkedIn Style) */}
          <div className="p-5 sm:p-6 rounded-3xl bg-[#090E1B] border border-white/10 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-white font-bold text-sm shrink-0 overflow-hidden">
                {currentUser?.avatarUrl ? (
                  <img src={currentUser.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <span>{currentUser ? currentUser.firstName?.[0] : 'U'}</span>
                )}
              </div>
              <div className="flex-grow">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-white font-bold">
                    {currentUser ? `${currentUser.firstName} ${currentUser.lastName}` : 'Publier en tant que membre'}
                  </span>
                  {currentUser && getRoleBadge(currentUser.role)}
                  {isPremium && (
                    <span className="text-[9px] font-mono font-bold text-amber-400 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/30">
                      👑 PREMIUM
                    </span>
                  )}
                </div>
                <span className="text-[10px] text-gray-400 font-mono block">
                  Partager une opportunité sur le Réseau B2B Africa Talent Football
                </span>
              </div>
            </div>

            <form onSubmit={handleCreatePost} className="space-y-3.5">
              {/* Category pills */}
              <div className="flex flex-wrap gap-1.5 text-[11px] font-mono">
                {[
                  { id: 'GENERAL', label: '📢 Général' },
                  { id: 'TALENT', label: '⚽ Pépite & Vidéo' },
                  { id: 'MERCATO', label: '💼 Mercato & Appel d\'offre' },
                  { id: 'TRIAL', label: '🎯 Détection & Essais' },
                  { id: 'TACTICAL', label: '📊 Analyse & Stats' },
                  { id: 'OFFICIAL', label: '🏛️ Annonce Officielle' }
                ].map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedCategory(cat.id as any)}
                    className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                      selectedCategory === cat.id
                        ? 'bg-amber-500 text-black font-bold'
                        : 'bg-[#050810] text-gray-400 hover:text-white border border-white/5'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>

              {/* Textarea */}
              <textarea
                rows={3}
                required
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                placeholder={
                  currentUser?.role === 'PLAYER'
                    ? "Partagez votre actualité sportive, vos matchs, séquences vidéo ou convocations..."
                    : currentUser?.role === 'CLUB'
                    ? "Publiez un appel d'offre de recrutement, un profil de joueur recherché ou un besoin par poste..."
                    : currentUser?.role === 'ACADEMY'
                    ? "Présentez une nouvelle promotion de jeunes talents, un stage de détection ou une convention..."
                    : "Partagez un rapport de scouting, un appel d’offre pour un club ou une actualité transfert..."
                }
                className="w-full p-3.5 rounded-2xl bg-[#050810] border border-white/10 text-white text-xs placeholder:text-gray-500 focus:border-amber-400 focus:outline-none resize-none"
              />

              {/* Tag selector */}
              <div className="space-y-1">
                <span className="text-[10px] font-mono text-gray-400 block">Hashtags recommandés (cliquez pour ajouter) :</span>
                <div className="flex flex-wrap gap-1.5 text-[10px] font-mono">
                  {COMMON_TAGS.map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => toggleTag(tag)}
                      className={`px-2 py-0.5 rounded transition-all cursor-pointer ${
                        selectedTags.includes(tag)
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold'
                          : 'bg-[#050810] text-gray-500 hover:text-gray-300 border border-white/5'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>

              {/* Media URL optional input or Image Preview */}
              {mediaUrlInput && (
                <div className="p-3 rounded-2xl bg-[#050810] border border-amber-500/40 space-y-2 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-amber-400 font-bold">
                      ✓ Média prêt à être publié avec votre post :
                    </span>
                    <button
                      type="button"
                      onClick={() => setMediaUrlInput('')}
                      className="text-[10px] font-mono text-red-400 hover:text-red-300 underline cursor-pointer"
                    >
                      Retirer le média
                    </button>
                  </div>
                  {mediaUrlInput.startsWith('data:image') || mediaUrlInput.match(/\.(jpeg|jpg|gif|png|webp)/i) ? (
                    <img
                      src={mediaUrlInput}
                      alt="Aperçu média"
                      className="max-h-48 w-full object-cover rounded-xl border border-white/10"
                    />
                  ) : (
                    <div className="text-xs text-gray-300 font-mono p-2 bg-black/40 rounded-lg truncate">
                      {mediaUrlInput}
                    </div>
                  )}
                </div>
              )}

              {showMediaInput && !mediaUrlInput && (
                <div className="p-3 rounded-xl bg-[#050810] border border-white/10 space-y-1.5 animate-in fade-in duration-200">
                  <label className="text-[10px] font-mono text-gray-400 block">
                    URL d'une vidéo ou photo (YouTube, Vimeo, MP4, image) :
                  </label>
                  <input
                    type="url"
                    value={mediaUrlInput}
                    onChange={(e) => setMediaUrlInput(e.target.value)}
                    placeholder="https://..."
                    className="w-full px-3 py-1.5 rounded-lg bg-black border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
                  />
                </div>
              )}

              {/* Actions row: Attach player, media toggle, submit button */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-white/5">
                <div className="flex flex-wrap items-center gap-2">
                  <select
                    value={selectedPlayerForPost}
                    onChange={(e) => setSelectedPlayerForPost(e.target.value)}
                    className="px-2.5 py-1.5 rounded-lg bg-[#050810] border border-white/10 text-xs text-amber-300 focus:outline-none max-w-[200px] truncate"
                  >
                    <option value="">📎 Joindre une fiche joueur</option>
                    {players.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.firstName} {p.lastName} ({p.primaryPosition} · {p.marketValueDisplay})
                      </option>
                    ))}
                  </select>

                  <input
                    ref={mediaFileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleMediaFileUpload}
                    className="hidden"
                  />
                  <button
                    type="button"
                    disabled={isUploadingMedia}
                    onClick={() => mediaFileInputRef.current?.click()}
                    className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 text-xs font-mono flex items-center gap-1 border border-white/10 transition-colors cursor-pointer"
                  >
                    <span>📷</span>
                    <span>{isUploadingMedia ? 'Importation...' : 'Importer Photo'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowMediaInput(!showMediaInput)}
                    className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 text-xs font-mono flex items-center gap-1 border border-white/10 transition-colors cursor-pointer"
                  >
                    <span>🔗</span>
                    <span>Lien Vidéo / Web</span>
                  </button>
                </div>

                <button
                  type="submit"
                  className="px-6 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md shadow-amber-500/20"
                >
                  Publier sur le Réseau
                </button>
              </div>
            </form>
          </div>

          {/* Activity Feed Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1">
            {[
              { id: 'ALL', label: '🌐 Tous les Posts' },
              { id: 'TALENT', label: '⚽ Pépites & Fiches' },
              { id: 'MERCATO', label: '💼 Mercato & Appels d\'Offres' },
              { id: 'PREMIUM', label: '👑 Membres Premium' },
              { id: 'MY_POSTS', label: '👤 Mes Publications' }
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setActiveFeedFilter(f.id as any)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold whitespace-nowrap transition-all cursor-pointer ${
                  activeFeedFilter === f.id
                    ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                    : 'bg-[#090E1B] text-gray-400 hover:text-white border border-white/10'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Activity Feed Posts List */}
          <div className="space-y-5">
            {filteredFeedPosts.length === 0 ? (
              <div className="p-8 rounded-3xl bg-[#090E1B] border border-white/10 text-center space-y-2">
                <div className="text-3xl">📭</div>
                <h4 className="font-bold text-white text-sm">Aucune publication dans cette catégorie</h4>
                <p className="text-xs text-gray-400">Soyez le premier à partager une actualité ou un rapport de scouting !</p>
              </div>
            ) : (
              filteredFeedPosts.map((post: FeedPost) => {
                const isMyPost = currentUser && (post.authorId === currentUser.id || post.authorName.toLowerCase() === `${currentUser.firstName} ${currentUser.lastName}`.toLowerCase());

                return (
                  <div
                    key={post.id}
                    className={`p-5 sm:p-6 rounded-3xl bg-[#090E1B] shadow-xl space-y-4 transition-all duration-300 ease-out hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-amber-500/10 group ${
                      post.isPremiumAuthor
                        ? 'border-2 border-amber-500/50 hover:border-amber-400 bg-gradient-to-b from-[#0C152A] to-[#090E1B]'
                        : 'border border-white/10 hover:border-amber-500/40'
                    }`}
                  >
                    {/* Premium badge ribbon */}
                    {post.isPremiumAuthor && (
                      <div className="flex items-center justify-between pb-2 border-b border-amber-500/20 text-[10px] font-mono text-amber-400 font-bold">
                        <span className="flex items-center gap-1">
                          <span>👑</span>
                          <span>MEMBRE PREMIUM VÉRIFIÉ · ACCÈS DIRECT DÉBLOQUÉ</span>
                        </span>
                        <span className="text-gray-400">Prioritaire B2B</span>
                      </div>
                    )}

                    {/* Author row */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={post.authorAvatar}
                          alt={post.authorName}
                          className={`w-11 h-11 rounded-full object-cover ${
                            post.isPremiumAuthor ? 'border-2 border-amber-400 shadow-md' : 'border border-white/10'
                          }`}
                        />
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-bold text-white text-sm">{post.authorName}</span>
                            {post.isVerified && (
                              <span className="text-amber-400 text-xs" title="Vérifié B2B">★</span>
                            )}
                            {post.authorRole && getRoleBadge(post.authorRole)}
                          </div>
                          <p className="text-[11px] text-gray-400 leading-tight">
                            {post.authorTitle} · {post.authorOrg}
                          </p>
                          <span className="text-[10px] text-gray-500 font-mono">{post.timeAgo}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {isMyPost && (
                          <button
                            onClick={() => deleteFeedPost(post.id)}
                            className="text-gray-500 hover:text-red-400 text-xs p-1 rounded hover:bg-white/5 transition-colors cursor-pointer"
                            title="Supprimer ma publication"
                          >
                            🗑️
                          </button>
                        )}

                        <button
                          onClick={() => {
                            if (isPremium || post.isPremiumAuthor) {
                              createDirectConversation({
                                id: `author-${post.id}`,
                                name: post.authorName,
                                title: post.authorTitle,
                                avatar: post.authorAvatar,
                                org: post.authorOrg,
                                role: post.authorRole
                              });
                              onNavigate('messages');
                            } else {
                              setSelectedRecipientForModal({
                                name: post.authorName,
                                role: post.authorTitle,
                                org: post.authorOrg
                              });
                              setIsContactModalOpen(true);
                            }
                          }}
                          className={`px-3 py-1 rounded-xl text-[10px] font-bold uppercase transition-all cursor-pointer ${
                            isPremium || post.isPremiumAuthor
                              ? 'bg-amber-500 hover:bg-amber-400 text-black font-black shadow-sm'
                              : 'bg-[#0E1527] hover:bg-amber-500 hover:text-black text-amber-300 border border-amber-500/40'
                          }`}
                        >
                          {isPremium || post.isPremiumAuthor ? '💬 Contact Direct' : '★ Contacter (VIP)'}
                        </button>
                      </div>
                    </div>

                    {/* Content */}
                    <p className="text-xs sm:text-sm text-gray-200 whitespace-pre-line leading-relaxed">
                      {post.content}
                    </p>

                    {/* Media preview if attached */}
                    {post.mediaUrl && (
                      <div className="rounded-2xl overflow-hidden border border-white/10 bg-black/60 max-h-80">
                        <img
                          src={post.mediaUrl}
                          alt="Media post"
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                      </div>
                    )}

                    {/* Tags */}
                    {post.tags && post.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 text-[10px] font-mono text-amber-400">
                        {post.tags.map((tag, idx) => (
                          <span key={idx} className="hover:underline cursor-pointer">
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Attached Eyeball Player Dossier Card */}
                    {post.playerAttachment && (
                      <div className="p-4 rounded-2xl bg-[#050810] border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={post.playerAttachment.avatarUrl}
                            alt={post.playerAttachment.firstName}
                            className="w-16 h-16 rounded-xl object-cover border border-white/10"
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white text-sm">
                                {post.playerAttachment.firstName} {post.playerAttachment.lastName}
                              </span>
                              <span className="px-2 py-0.5 rounded bg-black text-amber-400 font-mono text-[10px] font-bold border border-amber-500/40">
                                {post.playerAttachment.primaryPosition}
                              </span>
                            </div>
                            <div className="text-xs text-gray-400 font-mono mt-0.5">
                              {post.playerAttachment.calculatedAge} ans · {post.playerAttachment.currentClub}
                            </div>
                            <div className="text-xs text-emerald-400 font-mono font-bold mt-1">
                              Cote Marchande : {post.playerAttachment.marketValueDisplay}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 w-full sm:w-auto">
                          <button
                            onClick={() => openVideoModal(post.playerAttachment!)}
                            className="flex-1 sm:flex-none px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                          >
                            <span>▶ Vidéo Match</span>
                          </button>
                          <button
                            onClick={() => onNavigate('player-detail', post.playerAttachment)}
                            className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase transition-colors cursor-pointer"
                          >
                            Fiche Complète
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Social Counters */}
                    <div className="flex items-center justify-between pt-2 border-t border-white/10 text-[11px] text-gray-400 font-mono">
                      <span>{post.likesCount} Recommandations</span>
                      <span>{post.commentsCount} Commentaires · {post.sharesCount} Partages</span>
                    </div>

                    {/* Action Buttons: Like, Comment, Share, Download */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-white/5 text-xs font-bold">
                      <button
                        onClick={() => likePost(post.id)}
                        className={`py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 transition-all duration-200 cursor-pointer hover:scale-105 active:scale-95 ${
                          post.isLiked
                            ? 'text-amber-400 bg-amber-500/15 border border-amber-500/30 shadow-sm'
                            : 'text-gray-400 hover:text-white hover:bg-white/5 border border-transparent'
                        }`}
                      >
                        <span>👍</span>
                        <span>{post.isLiked ? 'Recommandé' : 'Recommander'}</span>
                      </button>

                      <button
                        onClick={() => {
                          const el = document.getElementById(`comment-input-${post.id}`);
                          el?.focus();
                        }}
                        className="py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 text-gray-400 hover:text-white hover:bg-white/5 border border-transparent hover:border-white/10 transition-all duration-200 cursor-pointer hover:scale-105 active:scale-95"
                      >
                        <span>💬</span>
                        <span>Commenter</span>
                      </button>

                      <button
                        onClick={() => setSelectedPostForShare(post)}
                        className="py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 text-gray-400 hover:text-amber-300 hover:bg-amber-500/15 border border-transparent hover:border-amber-500/30 transition-all duration-200 cursor-pointer hover:scale-105 active:scale-95"
                        title="Partager cette publication (WhatsApp, LinkedIn, Twitter, Copier)"
                      >
                        <span className="text-sm">↗</span>
                        <span>Partager</span>
                      </button>

                      <button
                        onClick={() => handleDownloadPost(post)}
                        className="py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 text-gray-400 hover:text-emerald-300 hover:bg-emerald-500/15 border border-transparent hover:border-emerald-500/30 transition-all duration-200 cursor-pointer hover:scale-105 active:scale-95"
                        title="Télécharger le rapport officiel de la publication (.txt / dossier)"
                      >
                        <span className="text-sm">📥</span>
                        <span>Télécharger</span>
                      </button>
                    </div>

                    {/* Comments Section */}
                    {post.comments && post.comments.length > 0 && (
                      <div className="space-y-2 pt-2 border-t border-white/5">
                        {post.comments.map((c) => (
                          <div key={c.id} className="p-3 rounded-2xl bg-[#050810] text-xs space-y-1">
                            <div className="flex justify-between items-center">
                              <span className="font-bold text-white">{c.author}</span>
                              <span className="text-[10px] text-gray-500 font-mono">{c.time}</span>
                            </div>
                            <p className="text-gray-300">{c.text}</p>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Comment Input Form */}
                    <form onSubmit={(e) => handleCommentSubmit(post.id, e)} className="flex gap-2 pt-1">
                      <input
                        id={`comment-input-${post.id}`}
                        type="text"
                        placeholder="Écrire un commentaire professionnel..."
                        value={commentInputs[post.id] || ''}
                        onChange={(e) =>
                          setCommentInputs((prev) => ({ ...prev, [post.id]: e.target.value }))
                        }
                        className="flex-grow px-3.5 py-2 rounded-xl bg-[#050810] border border-white/10 text-white text-xs placeholder:text-gray-500 focus:border-amber-400 focus:outline-none"
                      />
                      <button
                        type="submit"
                        className="px-4 py-2 rounded-xl bg-white/10 hover:bg-amber-500 hover:text-black text-white text-xs font-bold transition-colors cursor-pointer"
                      >
                        Envoyer
                      </button>
                    </form>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: RECOMMENDED CLUBS & GLOBAL LEADERS */}
        <div className="lg:col-span-3 space-y-6">
          {/* Voluntary Subscription VIP Perks Card */}
          <div className="p-5 rounded-3xl bg-gradient-to-b from-[#0E1A33] to-[#080E1C] border border-amber-500/40 shadow-xl space-y-3.5">
            <div className="flex items-center gap-2">
              <span className="text-xl">💎</span>
              <div>
                <h4 className="font-black text-white text-xs uppercase tracking-wider">Avantages Premium B2B</h4>
                <p className="text-[10px] text-amber-300 font-mono">Souscription 100% volontaire</p>
              </div>
            </div>

            <ul className="text-xs text-gray-300 space-y-2 font-mono">
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-400">✓</span>
                <span>Ligne directe avec Seydou Mario TRAORÉ</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-400">✓</span>
                <span>Contact direct avec directeurs de clubs pro</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-400">✓</span>
                <span>Badge Officiel VIP sur vos publications</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-400">✓</span>
                <span>Priorité de visionnage pour vos vidéos</span>
              </li>
            </ul>

            <button
              onClick={() => {
                if (isPremium) {
                  setIsContactModalOpen(true);
                } else {
                  upgradeToPremium('SCOUT_PRO');
                }
              }}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md shadow-amber-500/20"
            >
              {isPremium ? '📞 Ouvrir Ligne Directe' : '★ Débloquer les Avantages VIP'}
            </button>
          </div>

          {/* Real-time Institutional Intelligence Widget (Clubs, Banques, Entreprises) */}
          <div className="p-5 rounded-3xl bg-[#090E1B] border border-amber-500/40 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
                <span className="text-xs font-mono font-bold uppercase text-amber-400">
                  Alertes Directes Marché
                </span>
              </div>
              <button
                onClick={handleSyncRealtimeAlerts}
                disabled={isSyncingAlerts}
                className="text-[10px] text-amber-300 hover:text-amber-200 font-mono font-bold flex items-center gap-1 cursor-pointer"
                title="Synchroniser en direct avec les clubs, banques et entreprises"
              >
                <span className={isSyncingAlerts ? 'animate-spin' : ''}>🔄</span>
                <span>{isSyncingAlerts ? 'Sync...' : 'Actualiser'}</span>
              </button>
            </div>
            <p className="text-[10px] text-gray-400 font-mono">
              Flux temps réel des clubs, banques et sponsors partenaires
            </p>

            <div className="space-y-2.5">
              {realtimeAlerts.slice(0, 3).map((alert) => (
                <div
                  key={alert.id}
                  onClick={() => setSelectedRealtimeAlert(alert)}
                  className="p-3 rounded-2xl bg-[#050810] border border-white/5 hover:border-amber-400/40 transition-all cursor-pointer space-y-1.5 group"
                >
                  <div className="flex items-center justify-between gap-1 text-[10px] font-mono">
                    <span className="text-amber-400 font-bold truncate max-w-[130px]">
                      {alert.urgentBadge || alert.sourceName}
                    </span>
                    <span className="text-emerald-400 shrink-0 font-bold">{alert.timestamp}</span>
                  </div>
                  <h5 className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors line-clamp-1">
                    {alert.title}
                  </h5>
                  <p className="text-[10px] text-gray-400 line-clamp-2">
                    {alert.summary}
                  </p>
                  <div className="pt-1 flex items-center justify-between text-[10px] font-mono text-gray-400">
                    <span className="truncate max-w-[120px]">{alert.sourceName}</span>
                    <span className="text-amber-400 font-bold">Consulter ➔</span>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => onNavigate('profile')}
              className="w-full py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold uppercase transition-colors cursor-pointer text-center block"
            >
              Voir Tout sur le Hub Partenaires ➔
            </button>
          </div>

          {/* Recommended European & Global Clubs */}
          <div className="p-5 rounded-3xl bg-[#090E1B] border border-white/10 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold uppercase text-amber-400">
                Clubs & Cellules Pro
              </span>
              <button
                onClick={() => onNavigate('directory')}
                className="text-[10px] text-gray-400 hover:text-white underline cursor-pointer"
              >
                Voir tout ({clubs.length})
              </button>
            </div>

            <div className="space-y-3">
              {clubs.slice(0, 4).map((club) => (
                <div key={club.id} className="p-3 rounded-2xl bg-[#050810] border border-white/5 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white text-xs">{club.name}</div>
                      <div className="text-[10px] text-gray-400 font-mono">
                        {club.countryFlag} {club.league}
                      </div>
                    </div>
                    <span className="text-[10px] text-emerald-400 font-mono">Vérifié</span>
                  </div>

                  <p className="text-[11px] text-gray-300 line-clamp-1">
                    Directeur : {club.sportingDirector}
                  </p>

                  <div className="flex gap-2 pt-1">
                    <button
                      onClick={() => {
                        createDirectConversation({
                          id: `club-${club.id}`,
                          name: club.headOfRecruitment || club.sportingDirector,
                          title: `Recrutement · ${club.name}`,
                          avatar: club.logoUrl,
                          org: club.name,
                          role: 'SPORTING_DIRECTOR'
                        });
                        onNavigate('messages');
                      }}
                      className="w-full py-1.5 rounded-xl bg-[#0E1527] hover:bg-amber-500 hover:text-black text-amber-300 text-[10px] font-bold uppercase transition-colors cursor-pointer"
                    >
                      Message Direct
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Leaders & Sporting Directors */}
          <div className="p-5 rounded-3xl bg-[#090E1B] border border-white/10 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold uppercase text-amber-400">
                Décideurs & Directeurs Sportifs
              </span>
            </div>

            <div className="space-y-3">
              {professionals.filter(p => p.role !== 'SCOUT_AGENT').slice(0, 3).map((pro) => (
                <div key={pro.id} className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-[#050810] border border-white/5">
                  <div className="flex items-center gap-2">
                    <img src={pro.avatarUrl} alt={pro.name} className="w-8 h-8 rounded-full object-cover" />
                    <div>
                      <div className="font-bold text-white text-xs">{pro.name}</div>
                      <div className="text-[10px] text-gray-400 truncate max-w-[120px]">{pro.clubOrOrg}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleConnection(pro.id)}
                    className={`px-2.5 py-1 rounded-xl text-[10px] font-bold uppercase transition-colors cursor-pointer ${
                      pro.connectionStatus === 'CONNECTED'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : pro.connectionStatus === 'PENDING'
                        ? 'bg-amber-950 text-amber-400 border border-amber-800'
                        : 'bg-white/10 hover:bg-amber-500 hover:text-black text-white'
                    }`}
                  >
                    {pro.connectionStatus === 'CONNECTED' ? 'Connecté' : pro.connectionStatus === 'PENDING' ? 'En attente' : '+ Suivre'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Direct Platform Contact Modal */}
      <DirectPlatformContactModal
        isOpen={isContactModalOpen}
        onClose={() => setIsContactModalOpen(false)}
        onNavigate={onNavigate}
        defaultRecipient={selectedRecipientForModal}
      />

      {/* Post Share & Download Modal */}
      <PostShareModal
        isOpen={Boolean(selectedPostForShare)}
        onClose={() => setSelectedPostForShare(null)}
        post={selectedPostForShare}
      />

      {/* Real-time Alert Detail Popup */}
      {selectedRealtimeAlert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div
            className="w-full max-w-lg bg-[#090D1A] border-2 border-amber-500/40 rounded-3xl shadow-2xl p-6 space-y-4 text-left"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                  {selectedRealtimeAlert.urgentBadge || selectedRealtimeAlert.category}
                </span>
                <span className="text-xs">{selectedRealtimeAlert.countryFlag}</span>
              </div>
              <button
                onClick={() => setSelectedRealtimeAlert(null)}
                className="w-7 h-7 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white flex items-center justify-center text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2">
              <h3 className="text-base font-black text-white">
                {selectedRealtimeAlert.title}
              </h3>
              <p className="text-xs text-gray-300 leading-relaxed">
                {selectedRealtimeAlert.summary}
              </p>
            </div>

            {selectedRealtimeAlert.details?.requirements && (
              <div className="p-3.5 rounded-xl bg-[#050810] border border-white/5 space-y-1.5 text-xs font-mono">
                <span className="text-gray-400 block font-bold text-[10px] uppercase">
                  Conditions :
                </span>
                <ul className="list-disc list-inside text-gray-300 space-y-1 text-[11px]">
                  {selectedRealtimeAlert.details.requirements.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex items-center justify-between pt-2 border-t border-white/10">
              <button
                onClick={() => {
                  setSelectedRealtimeAlert(null);
                  onNavigate('profile');
                }}
                className="text-xs text-amber-400 hover:underline font-mono cursor-pointer"
              >
                Voir dans le Hub Partenaires ➔
              </button>
              <button
                onClick={() => {
                  alert(`Votre profil a été soumis directement auprès de ${selectedRealtimeAlert.sourceName}.`);
                  setSelectedRealtimeAlert(null);
                }}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider cursor-pointer shadow-md"
              >
                {selectedRealtimeAlert.actionLabel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Download confirmation toast */}
      {downloadToast && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-emerald-950 border-2 border-emerald-500 text-white text-xs font-mono font-bold shadow-2xl flex items-center gap-3 animate-in slide-in-from-bottom duration-300">
          <span className="text-xl">📥</span>
          <span>{downloadToast}</span>
          <button
            onClick={() => setDownloadToast(null)}
            className="text-gray-400 hover:text-white ml-2 text-sm cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
};
