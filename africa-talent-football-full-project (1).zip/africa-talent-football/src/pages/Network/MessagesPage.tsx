import React, { useState } from 'react';
import { useNetwork } from '../../context/NetworkContext';
import { usePlayers } from '../../context/PlayerContext';
import { useLanguage } from '../../context/LanguageContext';
import { FOUNDER_INFO } from '../../data/demoData';

interface MessagesPageProps {
  onNavigate: (view: string, payload?: any) => void;
}

export const MessagesPage: React.FC<MessagesPageProps> = ({ onNavigate }) => {
  const { t, formatDate } = useLanguage();
  const {
    conversations,
    messages,
    activeConversationId,
    setActiveConversationId,
    sendMessage
  } = useNetwork();

  const { players, openVideoModal } = usePlayers();

  const [inputText, setInputText] = useState('');
  const [selectedPlayerToAttach, setSelectedPlayerToAttach] = useState<string>('');
  const [searchConv, setSearchConv] = useState('');

  const activeConv = conversations.find((c) => c.id === activeConversationId) || conversations[0];
  const activeMsgs = messages[activeConversationId] || [];

  const filteredConversations = conversations.filter((c) =>
    `${c.participantName} ${c.participantOrg} ${c.participantTitle}`
      .toLowerCase()
      .includes(searchConv.toLowerCase())
  );

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() && !selectedPlayerToAttach) return;

    let attachment = undefined;
    if (selectedPlayerToAttach) {
      const p = players.find(x => x.id === selectedPlayerToAttach);
      if (p) {
        attachment = {
          type: 'PLAYER_DOSSIER' as const,
          title: `${p.firstName} ${p.lastName} (${p.primaryPosition})`,
          subtitle: `Cote Marchande: ${p.marketValueDisplay} · ${p.currentClub}`,
          targetId: p.id
        };
      }
    }

    sendMessage(activeConversationId, inputText, attachment);
    setInputText('');
    setSelectedPlayerToAttach('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-[#090E1B] rounded-2xl border border-white/10 shadow-2xl overflow-hidden h-[82vh] flex flex-col md:flex-row">
        {/* LEFT COLUMN: CONVERSATIONS LIST */}
        <div className="w-full md:w-80 lg:w-96 border-b md:border-b-0 md:border-r border-white/10 flex flex-col bg-[#050810]">
          {/* Header */}
          <div className="p-4 border-b border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-black text-white uppercase font-mono">
                {t('network.messagesTitle', 'Messagerie B2B')}
              </h2>
              <span className="text-[10px] font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                Desk Mario TRAORÉ
              </span>
            </div>

            {/* Search conversations */}
            <div className="relative">
              <input
                type="text"
                value={searchConv}
                onChange={(e) => setSearchConv(e.target.value)}
                placeholder={t('network.searchConversations', 'Rechercher une discussion club, scout...')}
                className="w-full px-3 py-1.5 pl-8 rounded-lg bg-[#090E1B] border border-white/10 text-white text-xs placeholder:text-gray-500 focus:outline-none focus:border-amber-500"
              />
              <span className="absolute left-2.5 top-2 text-gray-500 text-xs">🔍</span>
            </div>
          </div>

          {/* Conversations list */}
          <div className="flex-grow overflow-y-auto divide-y divide-white/5">
            {filteredConversations.map((c) => {
              const isActive = c.id === activeConversationId;
              return (
                <button
                  key={c.id}
                  onClick={() => setActiveConversationId(c.id)}
                  className={`w-full p-4 text-left flex items-start gap-3 transition-colors cursor-pointer ${
                    isActive ? 'bg-[#090E1B] border-l-4 border-amber-400' : 'hover:bg-white/5'
                  }`}
                >
                  <div className="relative shrink-0">
                    <img
                      src={c.participantAvatar}
                      alt={c.participantName}
                      className="w-11 h-11 rounded-full object-cover border border-white/10"
                    />
                    {c.online && (
                      <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-[#050810]" />
                    )}
                  </div>

                  <div className="flex-grow min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs truncate">
                        {c.participantName}
                      </span>
                      <span className="text-[10px] text-gray-500 font-mono">
                        {c.lastMessageTime}
                      </span>
                    </div>

                    <div className="text-[11px] text-amber-400 font-mono truncate">
                      {c.participantOrg}
                    </div>

                    <p className="text-xs text-gray-400 truncate mt-1">
                      {c.lastMessage}
                    </p>
                  </div>

                  {c.unreadCount > 0 && (
                    <span className="w-5 h-5 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0">
                      {c.unreadCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* RIGHT COLUMN: ACTIVE THREAD & COMPOSER */}
        <div className="flex-1 flex flex-col bg-[#090E1B]">
          {/* Thread Header */}
          <div className="p-4 bg-[#050810] border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <img
                  src={activeConv?.participantAvatar}
                  alt={activeConv?.participantName}
                  className="w-10 h-10 rounded-full object-cover border border-amber-500/40"
                />
                {activeConv?.online && (
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-[#050810]" />
                )}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-black text-white text-sm">{activeConv?.participantName}</h3>
                  <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] font-mono border border-emerald-800">
                    Officiel B2B
                  </span>
                </div>
                <p className="text-xs text-amber-400 font-mono">
                  {activeConv?.participantTitle}
                </p>
              </div>
            </div>

            {/* Direct WhatsApp Transfer Bridge */}
            <a
              href={`${FOUNDER_INFO.whatsappUrl}?text=Bonjour%20M.%20Seydou%20Mario%20TRAOR%C3%A9%2C%20suite%20%C3%A0%20notre%20%C3%A9change%20sur%20Africa%20Talent%20Football%20avec%20${encodeURIComponent(activeConv?.participantName || '')}.`}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-black font-black text-xs uppercase tracking-wider transition-colors shadow-md"
            >
              <span>Bascule WhatsApp</span>
            </a>
          </div>

          {/* Message History */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            {activeMsgs.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.isMine ? 'items-end' : 'items-start'}`}
              >
                <div className="flex items-center gap-2 mb-1 text-[11px] text-gray-400 font-mono">
                  <span className="font-bold text-gray-300">{msg.senderName}</span>
                  <span>·</span>
                  <span>{msg.timestamp}</span>
                </div>

                <div
                  className={`max-w-[80%] sm:max-w-[70%] p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                    msg.isMine
                      ? 'bg-amber-500 text-black font-medium rounded-tr-none shadow-lg'
                      : 'bg-[#050810] border border-white/10 text-gray-100 rounded-tl-none shadow-xl'
                  }`}
                >
                  <p className="whitespace-pre-line">{msg.text}</p>

                  {/* Attachment Card */}
                  {msg.attachment && (
                    <div className="mt-3 p-3 rounded-xl bg-black/50 border border-white/15 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold uppercase text-amber-300">
                          {msg.attachment.type === 'VIDEO' ? '📹 SÉQUENCE VIDÉO EYEBALL' : '📋 DOSSIER JOUEUR OFFICIEL'}
                        </span>
                      </div>
                      <div className="font-black text-white text-xs">{msg.attachment.title}</div>
                      {msg.attachment.subtitle && (
                        <div className="text-[11px] text-gray-300 font-mono">{msg.attachment.subtitle}</div>
                      )}
                      {msg.attachment.targetId && (
                        <button
                          onClick={() => {
                            const p = players.find(x => x.id === msg.attachment!.targetId);
                            if (p) onNavigate('player-detail', p);
                          }}
                          className="mt-1 px-3 py-1 rounded bg-amber-400 text-black font-black text-[10px] uppercase cursor-pointer"
                        >
                          {t('players.openVideo', 'Ouvrir la fiche complète')}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Composer */}
          <div className="p-4 bg-[#050810] border-t border-white/10 space-y-2">
            {/* Quick Attach player selector */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-gray-400 text-[11px] font-mono">{t('chat.attachPlayer', 'Joindre profil / vidéo :')}</span>
              <select
                value={selectedPlayerToAttach}
                onChange={(e) => setSelectedPlayerToAttach(e.target.value)}
                className="px-2.5 py-1 rounded bg-[#090E1B] border border-white/10 text-amber-300 text-xs focus:outline-none"
              >
                <option value="">{t('common.cancel', 'Aucun fichier joint')}</option>
                {players.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.firstName} {p.lastName} ({p.primaryPosition} · {p.marketValueDisplay})
                  </option>
                ))}
              </select>
            </div>

            <form onSubmit={handleSend} className="flex gap-2">
              <input
                type="text"
                placeholder={t('chat.placeholder', `Rédiger un message officiel à ${activeConv?.participantName}...`)}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                className="flex-grow px-4 py-2.5 rounded-xl bg-[#090E1B] border border-white/10 text-white text-xs sm:text-sm placeholder:text-gray-500 focus:outline-none focus:border-amber-500"
              />
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-lg shadow-amber-500/20"
              >
                {t('chat.send', 'Envoyer')}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
