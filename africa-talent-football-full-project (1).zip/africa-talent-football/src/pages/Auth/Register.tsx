import React, { useState, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { usePlayers } from '../../context/PlayerContext';
import { estimateMarketValue, formatMarketValue, FOUNDER_INFO } from '../../data/demoData';
import { UserRole } from '../../types/database';

interface RegisterProps {
  onNavigate: (view: string, payload?: any) => void;
}

export type RegistrationRoleKey =
  | 'CLUB'
  | 'PLAYER'
  | 'ACADEMY'
  | 'SCOUT'
  | 'FIFA_AGENT'
  | 'HEAD_COACH'
  | 'SPORTING_DIRECTOR'
  | 'PRESIDENT'
  | 'RECRUITMENT_MANAGER';

interface RoleOption {
  key: RegistrationRoleKey;
  label: string;
  icon: string;
  badge: string;
  shortDesc: string;
  dashboardRole: string;
}

const REGISTRATION_ROLES: RoleOption[] = [
  {
    key: 'CLUB',
    label: 'Club Professionnel',
    icon: '🏟️',
    badge: 'Club Pro Hub',
    shortDesc: 'Cellule sportive, dirigeants et administration de club',
    dashboardRole: 'CLUB_PRO',
  },
  {
    key: 'PLAYER',
    label: 'Joueur & Athlète',
    icon: '⚽',
    badge: 'Fiche Joueur',
    shortDesc: 'Talents émergents, vidéos de match et cotes marchandes',
    dashboardRole: 'PLAYER',
  },
  {
    key: 'ACADEMY',
    label: 'Académie de Football',
    icon: '🎓',
    badge: 'Centre Formation',
    shortDesc: 'Centres agréés, écoles de foot et passeports FIFA',
    dashboardRole: 'ACADEMY',
  },
  {
    key: 'SCOUT',
    label: 'Scout / Recruteur',
    icon: '🔍',
    badge: 'Scouting Terrain',
    shortDesc: 'Superviseurs, observateurs et détecteurs indépendants',
    dashboardRole: 'SCOUT',
  },
  {
    key: 'FIFA_AGENT',
    label: 'Agent Licencié FIFA',
    icon: '💼',
    badge: 'Licence FIFA #2024',
    shortDesc: 'Intermédiaires officiels et mandataires de transferts',
    dashboardRole: 'FIFA_AGENT',
  },
  {
    key: 'HEAD_COACH',
    label: 'Entraîneur & Staff',
    icon: '📋',
    badge: 'Direction Technique',
    shortDesc: 'Coachs principaux, préparateurs et analystes tactiques',
    dashboardRole: 'COACH',
  },
  {
    key: 'SPORTING_DIRECTOR',
    label: 'Directeur Sportif',
    icon: '👔',
    badge: 'Management Sportif',
    shortDesc: 'Gestionnaires d\'effectif, mercato et planification',
    dashboardRole: 'SPORTING_DIRECTOR',
  },
  {
    key: 'PRESIDENT',
    label: 'Président de Club',
    icon: '🏛️',
    badge: 'Haute Gouvernance',
    shortDesc: 'Présidents, actionnaires et instances décisionnaires',
    dashboardRole: 'PRESIDENT',
  },
  {
    key: 'RECRUITMENT_MANAGER',
    label: 'Resp. Recrutement',
    icon: '🎯',
    badge: 'Head of Recruitment',
    shortDesc: 'Chefs de recrutement et coordinateurs de cellules',
    dashboardRole: 'RECRUITMENT_MANAGER',
  },
];

export const Register: React.FC<RegisterProps> = ({ onNavigate }) => {
  const { register } = useAuth();
  const { language } = useLanguage();
  const { registerNewPlayer } = usePlayers();

  const [selectedRole, setSelectedRole] = useState<RegistrationRoleKey>('CLUB');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successReceipt, setSuccessReceipt] = useState<{
    id: string;
    roleLabel: string;
    name: string;
    org: string;
    date: string;
    dashboardRole: string;
  } | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    // Common
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    country: "Côte d'Ivoire",
    city: 'Abidjan',
    // Club Specs
    clubName: '',
    league: 'Ligue 1 Professionnelle',
    division: 'D1 Nationale',
    stadium: '',
    clubWebsite: '',
    federationAffiliationId: '',
    openNeeds: 'Ailier percutant, Milieu relayeur, Latéral gauche',
    // Player Specs
    dateOfBirth: '2007-05-20',
    position: 'BU' as const,
    preferredFoot: 'Droit' as const,
    heightCm: 184,
    weightKg: 76,
    academy: 'Académie Espoir Abidjan',
    currentClub: 'AS Elite Junior',
    matches: 20,
    minutes: 1650,
    goals: 12,
    assists: 6,
    cleanSheets: 0,
    passAccuracyPct: 83,
    topSpeedKmh: 33.8,
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    videoTitle: '',
    guardianName: '',
    guardianPhone: '',
    // Academy Specs
    academyName: '',
    directorName: '',
    traineesCount: 45,
    facilitiesSummary: '2 terrains pelouse synthétique, vestiaires & salle de musculation',
    partnerClubs: 'Standard de Liège, RC Lens',
    // Scout Specs
    scoutOrg: 'Indépendant & Mandataire',
    territoriesCovered: 'Côte d\'Ivoire, Sénégal, Mali, Ghana, Cameroun',
    yearsExperience: 8,
    specialty: 'Détection Eyeball, Analyse Athlétique GPS, U17-U21',
    // FIFA Agent Specs
    agencyName: '',
    fifaLicenseNumber: 'FIFA-2024-8842',
    activeMandatesCount: 14,
    targetMarkets: 'Europe (France, Belgique, Portugal), Golfe',
    // Coach Specs
    coachingBadge: 'Licence UEFA Pro / CAF A',
    teamCategory: 'Équipe Première (Séniors)',
    tacticalPhilosophy: '4-3-3 Offensif / Pressing haut & transitions rapides',
    // Sporting Director Specs
    mercatoBudgetBracket: '1M€ - 5M€',
    priorityTargetProfiles: 'Attaquant U21 à fort potentiel, Milieu récupérateur',
    // President Specs
    clubValuationRange: '10M€ - 30M€',
    strategicGoal: 'Développement académie & conventions bilatérales européennes',
    // Recruitment Manager Specs
    scoutsDelegatedCount: 6,
    pipelineCriteria: 'Joueurs U20 à vitesse > 33.0 km/h, convention formation enregistrée',
  });

  const activeRoleOption = REGISTRATION_ROLES.find((r) => r.key === selectedRole) || REGISTRATION_ROLES[0];

  // Calculated age for player
  const calculatedAge = useMemo(() => {
    if (!formData.dateOfBirth) return 18;
    const birthYear = parseInt(formData.dateOfBirth.split('-')[0]) || 2007;
    return Math.max(15, 2026 - birthYear);
  }, [formData.dateOfBirth]);

  const isMinor = calculatedAge < 18;

  // Real-time market value estimation
  const liveEstimatedValue = useMemo(() => {
    return estimateMarketValue(calculatedAge, formData.position, {
      matches: formData.matches,
      goals: formData.goals,
      assists: formData.assists,
      passAccuracyPct: formData.passAccuracyPct,
      topSpeedKmh: formData.topSpeedKmh,
    });
  }, [calculatedAge, formData.position, formData.matches, formData.goals, formData.assists, formData.passAccuracyPct, formData.topSpeedKmh]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const generatedId = `REG-${Date.now().toString().slice(-6)}`;
    const fullName = `${formData.firstName || 'Représentant'} ${formData.lastName || 'Officiel'}`.trim();
    const orgName =
      selectedRole === 'CLUB'
        ? formData.clubName || 'Club Professionnel'
        : selectedRole === 'ACADEMY'
        ? formData.academyName || 'Académie de Football'
        : selectedRole === 'FIFA_AGENT'
        ? formData.agencyName || 'Cabinet Mandataire FIFA'
        : selectedRole === 'SCOUT'
        ? formData.scoutOrg || 'Cellule Détection'
        : selectedRole === 'HEAD_COACH' || selectedRole === 'SPORTING_DIRECTOR' || selectedRole === 'PRESIDENT' || selectedRole === 'RECRUITMENT_MANAGER'
        ? formData.clubName || 'Structure Sportive'
        : formData.academy || 'Académie Mimosas';

    // If player, register in PlayerContext
    if (selectedRole === 'PLAYER') {
      const newPlayer = registerNewPlayer({
        firstName: formData.firstName || 'Jeune',
        lastName: formData.lastName || 'Talent',
        dateOfBirth: formData.dateOfBirth,
        calculatedAge,
        isMinor,
        nationality: formData.country,
        countryFlag: formData.country === 'Mali' ? '🇲🇱' : formData.country === 'Sénégal' ? '🇸🇳' : '🇨🇮',
        primaryPosition: formData.position,
        preferredFoot: formData.preferredFoot,
        heightCm: formData.heightCm,
        weightKg: formData.weightKg,
        currentClub: formData.currentClub,
        academy: formData.academy,
        videoUrl: formData.videoUrl || 'https://www.youtube.com',
        videoTitle: formData.videoTitle || `${formData.firstName} ${formData.lastName} - Highlights & Séquences Clés`,
        marketValueEur: liveEstimatedValue,
        stats: {
          matches: formData.matches,
          minutes: formData.minutes,
          goals: formData.goals,
          assists: formData.assists,
          cleanSheets: formData.cleanSheets,
          passAccuracyPct: formData.passAccuracyPct,
          topSpeedKmh: formData.topSpeedKmh,
          duelsWonPct: 62,
          yellowCards: 1,
        },
        guardianContact: isMinor
          ? {
              name: formData.guardianName || 'Tuteur Légal Agréé',
              phone: formData.guardianPhone || '+225 05 44 42 01 62',
              relationship: 'Tuteur / Parent',
            }
          : undefined,
        certifiedBy: `${FOUNDER_INFO.name}, Scout Agent & Fondateur`,
      });

      const regResult = await register({
        email: formData.email || `${formData.firstName.toLowerCase() || 'joueur'}@talent.ci`,
        password: formData.password || 'Mario2026!',
        role: 'PLAYER',
        firstName: formData.firstName || 'Jeune',
        lastName: formData.lastName || 'Talent',
        country: formData.country,
        phone: formData.phone,
        clubName: formData.currentClub,
        academyName: formData.academy,
        primaryPosition: formData.position,
        dateOfBirth: formData.dateOfBirth,
        preferredFoot: formData.preferredFoot,
      });

      if (!regResult.success) {
        setErrorMessage(regResult.error || 'Erreur lors de la création du compte.');
        setIsSubmitting(false);
        return;
      }

      setSuccessReceipt({
        id: generatedId,
        roleLabel: 'Joueur & Athlète Certifié',
        name: fullName,
        org: formData.academy,
        date: new Date().toLocaleDateString('fr-FR'),
        dashboardRole: 'PLAYER',
      });
      setIsSubmitting(false);
      return;
    }

    // Other Stakeholder Roles
    const mappedUserRole: UserRole =
      selectedRole === 'CLUB'
        ? 'CLUB'
        : selectedRole === 'ACADEMY'
        ? 'ACADEMY'
        : selectedRole === 'FIFA_AGENT'
        ? 'FIFA_AGENT'
        : selectedRole === 'HEAD_COACH'
        ? 'HEAD_COACH'
        : selectedRole === 'SPORTING_DIRECTOR'
        ? 'SPORTING_DIRECTOR'
        : selectedRole === 'PRESIDENT'
        ? 'PRESIDENT'
        : selectedRole === 'RECRUITMENT_MANAGER'
        ? 'RECRUITMENT_MANAGER'
        : 'SCOUT';

    const regResult = await register({
      email: formData.email || `${selectedRole.toLowerCase()}@africatalentfootball.app`,
      password: formData.password || 'Mario2026!',
      role: mappedUserRole,
      firstName: formData.firstName || 'Responsable',
      lastName: formData.lastName || 'Officiel',
      country: formData.country,
      phone: formData.phone,
      clubName: formData.clubName,
      academyName: formData.academyName,
      fifaLicenseNumber: formData.fifaLicenseNumber,
      coachingBadge: formData.coachingBadge,
      organization: orgName,
      leagueOrDivision: formData.league,
    });

    if (!regResult.success) {
      setErrorMessage(regResult.error || 'Erreur lors de la création du compte.');
      setIsSubmitting(false);
      return;
    }

    setSuccessReceipt({
      id: generatedId,
      roleLabel: activeRoleOption.label,
      name: fullName,
      org: orgName,
      date: new Date().toLocaleDateString('fr-FR'),
      dashboardRole: activeRoleOption.dashboardRole,
    });
    setIsSubmitting(false);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-2 text-[11px] font-mono font-bold uppercase tracking-widest text-amber-400 bg-amber-500/10 border border-amber-500/30 px-3.5 py-1 rounded-full">
          <span>★</span>
          <span>Système d'Enregistrement Officiel des Métiers du Football</span>
          <span>★</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
          Inscription & Accréditation Internationale
        </h1>
        <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
          Sélectionnez votre profil pour accéder à votre espace de travail certifié. Supervision technique directe par <strong>{FOUNDER_INFO.name}</strong> ({FOUNDER_INFO.officialTitle}).
        </p>
        <div className="pt-1">
          <button
            type="button"
            onClick={() => onNavigate('login')}
            className="text-xs font-mono font-bold text-amber-400 hover:text-amber-300 hover:underline cursor-pointer inline-flex items-center gap-1.5"
          >
            <span>Déjà inscrit sur Africa Talent Football ?</span>
            <span className="underline">Se connecter à mon compte ➔</span>
          </button>
        </div>
      </div>

      {/* SUCCESS CONFIRMATION RECEIPT */}
      {successReceipt && (
        <div className="p-8 rounded-2xl bg-gradient-to-r from-emerald-950 via-[#0B1728] to-emerald-950 border-2 border-emerald-400 text-center space-y-5 shadow-2xl animate-in zoom-in-95 duration-200">
          <div className="w-16 h-16 rounded-2xl bg-emerald-500 text-black mx-auto flex items-center justify-center text-3xl font-black shadow-lg">
            ✓
          </div>
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-emerald-300 px-3 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40">
              Accréditation Officielle Enregistrée
            </span>
            <h2 className="text-2xl font-black text-white">
              Bienvenue sur la Plateforme, {successReceipt.name} !
            </h2>
            <p className="text-xs text-gray-300 max-w-lg mx-auto">
              Votre compte a été créé avec succès et vos identifiants sont désormais actifs et persistants sur Africa Talent Football.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-black/60 border border-emerald-500/40 max-w-lg mx-auto text-xs font-mono grid grid-cols-2 gap-3 text-left">
            <div>
              <span className="text-gray-500 block text-[10px]">Rôle Validé :</span>
              <span className="font-bold text-amber-400">{successReceipt.roleLabel}</span>
            </div>
            <div>
              <span className="text-gray-500 block text-[10px]">N° Accréditation :</span>
              <span className="font-bold text-emerald-400">{successReceipt.id}</span>
            </div>
            <div>
              <span className="text-gray-500 block text-[10px]">Organisation / Club :</span>
              <span className="font-bold text-white truncate block">{successReceipt.org}</span>
            </div>
            <div>
              <span className="text-gray-500 block text-[10px]">Supervision Technique :</span>
              <span className="font-bold text-gray-300">Mario TRAORÉ (+225)</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
            <button
              onClick={() => onNavigate('profile')}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/20 cursor-pointer"
            >
              👤 Consulter mon Profil Membre
            </button>
            <button
              onClick={() => onNavigate('dashboard', { role: successReceipt.dashboardRole })}
              className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono font-bold text-xs transition-colors cursor-pointer border border-white/20"
            >
              📊 Ouvrir mon Tableau de Bord
            </button>
            <button
              onClick={() => onNavigate('players')}
              className="px-5 py-2.5 rounded-xl bg-emerald-600/30 text-emerald-300 hover:bg-emerald-600/40 font-mono font-bold text-xs transition-colors cursor-pointer border border-emerald-500/40"
            >
              ⚽ Vidéothèque & Talents
            </button>
          </div>
        </div>
      )}

      {/* REGISTRATION FORM CONTAINER */}
      {!successReceipt && (
        <div className="bg-[#080D1A] rounded-3xl border border-amber-500/40 p-6 sm:p-10 shadow-2xl space-y-8">
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs font-mono flex items-center gap-2">
              <span className="text-base shrink-0">⚠️</span>
              <span>{errorMessage}</span>
            </div>
          )}
          {/* STEP 1: ROLE SELECTOR (9 STAKEHOLDER PERSONAS) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
                1. Choisissez votre Statut / Métier :
              </span>
              <span className="text-[11px] font-mono text-gray-400">
                Formulaire dynamique adapté
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-9 gap-2">
              {REGISTRATION_ROLES.map((role) => {
                const isSelected = selectedRole === role.key;
                return (
                  <button
                    type="button"
                    key={role.key}
                    onClick={() => setSelectedRole(role.key)}
                    className={`p-3 rounded-xl text-left transition-all duration-200 cursor-pointer flex flex-col justify-between border relative overflow-hidden group ${
                      isSelected
                        ? 'bg-[#0E1527] border-amber-400 shadow-xl shadow-amber-500/15 ring-2 ring-amber-400/30'
                        : 'bg-[#050810] border-white/10 hover:border-amber-500/40 hover:bg-[#090E1B]'
                    }`}
                  >
                    <div>
                      <div className="text-2xl mb-1 group-hover:scale-110 transition-transform">
                        {role.icon}
                      </div>
                      <div className={`font-black text-xs leading-tight ${isSelected ? 'text-white' : 'text-gray-200'}`}>
                        {role.label}
                      </div>
                    </div>
                    <div className="mt-2">
                      <span
                        className={`text-[9px] font-mono font-bold px-1 py-0.5 rounded block truncate ${
                          isSelected
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            : 'bg-white/5 text-gray-400'
                        }`}
                      >
                        {role.badge}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Selected Role Description Banner */}
            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-3 text-xs text-amber-200">
              <div className="flex items-center gap-2">
                <span className="text-xl">{activeRoleOption.icon}</span>
                <span>
                  Vous vous enregistrez en tant que <strong>{activeRoleOption.label}</strong> : {activeRoleOption.shortDesc}.
                </span>
              </div>
              <span className="font-mono font-bold text-[10px] text-amber-400 uppercase hidden sm:inline">
                Certifié ATF
              </span>
            </div>
          </div>

          {/* STEP 2: REGISTRATION FORM */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* SECTION A: IDENTITY & CONTACT (COMMON TO ALL) */}
            <div className="space-y-4">
              <h3 className="text-xs font-mono font-bold uppercase text-gray-400 tracking-wider border-b border-white/10 pb-2">
                2. Informations Générales & Coordonnées Officielles
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
                <div>
                  <label className="block text-gray-400 mb-1 font-bold">Prénom *</label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    placeholder="Ex: Seydou, Jean-Luc, Kolo..."
                    className="w-full px-3 py-2 rounded-lg bg-[#050810] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-gray-400 mb-1 font-bold">Nom de Famille *</label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    placeholder="Ex: Traoré, Diallo, Moreau..."
                    className="w-full px-3 py-2 rounded-lg bg-[#050810] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-gray-400 mb-1 font-bold">Email Professionnel *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="direction@club.com"
                    className="w-full px-3 py-2 rounded-lg bg-[#050810] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-gray-400 mb-1 font-bold">Téléphone / WhatsApp Direct *</label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+225 05... ou +33 6..."
                    className="w-full px-3 py-2 rounded-lg bg-[#050810] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block text-gray-400 mb-1 font-bold">Pays d'Attache / Siège *</label>
                  <select
                    value={formData.country}
                    onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#050810] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                  >
                    <option value="Côte d'Ivoire">🇨🇮 Côte d'Ivoire</option>
                    <option value="Sénégal">🇸🇳 Sénégal</option>
                    <option value="Mali">🇲🇱 Mali</option>
                    <option value="Cameroun">🇨🇲 Cameroun</option>
                    <option value="Ghana">🇬🇭 Ghana</option>
                    <option value="Nigeria">🇳🇬 Nigeria</option>
                    <option value="France">🇫🇷 France</option>
                    <option value="Belgique">🇧🇪 Belgique</option>
                    <option value="Portugal">🇵🇹 Portugal</option>
                    <option value="Suisse">🇨🇭 Suisse</option>
                    <option value="Angleterre">🇬🇧 Angleterre</option>
                    <option value="Espagne">🇪🇸 Espagne</option>
                    <option value="Maroc">🇲🇦 Maroc</option>
                    <option value="Autre">🌍 Autre Pays</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-400 mb-1 font-bold">Ville de Résidence / Siège</label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="Abidjan, Dakar, Paris, Liège..."
                    className="w-full px-3 py-2 rounded-lg bg-[#050810] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Password credentials */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-2 border-t border-white/5">
                <div>
                  <label className="block text-amber-400 mb-1 font-bold font-mono">
                    Mot de Passe de Connexion *
                  </label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    placeholder="Min. 6 caractères"
                    className="w-full px-3 py-2 rounded-lg bg-[#050810] border border-amber-500/30 text-white focus:border-amber-400 focus:outline-none font-mono"
                  />
                  <span className="text-[10px] text-gray-500 font-mono mt-0.5 block">
                    Sert à vous reconnecter sur tous vos appareils
                  </span>
                </div>

                <div>
                  <label className="block text-amber-400 mb-1 font-bold font-mono">
                    Confirmer le Mot de Passe *
                  </label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    placeholder="Répétez le mot de passe"
                    className="w-full px-3 py-2 rounded-lg bg-[#050810] border border-amber-500/30 text-white focus:border-amber-400 focus:outline-none font-mono"
                  />
                </div>
              </div>
            </div>

            {/* SECTION B: TAILORED FIELDS BY PERSONA */}
            {/* 1. CLUBS PROFESSIONNELS */}
            {selectedRole === 'CLUB' && (
              <div className="p-5 rounded-2xl bg-[#050810] border border-amber-500/30 space-y-4 text-xs">
                <h3 className="font-mono font-bold uppercase text-amber-400 tracking-wider flex items-center gap-2">
                  <span>🏟️</span>
                  <span>Informations Club Professionnel</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Nom Officiel du Club *</label>
                    <input
                      type="text"
                      required
                      value={formData.clubName}
                      onChange={(e) => setFormData({ ...formData, clubName: e.target.value })}
                      placeholder="Ex: Standard de Liège, RC Lens, ASEC..."
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Championnat / Ligue *</label>
                    <input
                      type="text"
                      value={formData.league}
                      onChange={(e) => setFormData({ ...formData, league: e.target.value })}
                      placeholder="Ex: Ligue 1, Pro League, D1 Lonaci..."
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">N° Affiliation Fédération</label>
                    <input
                      type="text"
                      value={formData.federationAffiliationId}
                      onChange={(e) => setFormData({ ...formData, federationAffiliationId: e.target.value })}
                      placeholder="Ex: FFF-49219 / FIF-0082"
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-gray-400 mb-1 font-bold">Profils & Postes Prioritaires Recherchés</label>
                  <input
                    type="text"
                    value={formData.openNeeds}
                    onChange={(e) => setFormData({ ...formData, openNeeds: e.target.value })}
                    placeholder="Ex: Ailier gauche percutant, Milieu défensif U20, Gardien moderne..."
                    className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>
            )}

            {/* 2. JOUEURS & TALENTS */}
            {selectedRole === 'PLAYER' && (
              <div className="p-5 rounded-2xl bg-[#050810] border border-emerald-500/30 space-y-4 text-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h3 className="font-mono font-bold uppercase text-emerald-400 tracking-wider flex items-center gap-2">
                    <span>⚽</span>
                    <span>Profil Sportif & Données Athlétiques du Joueur</span>
                  </h3>
                  <div className="text-xs font-mono">
                    <span className="text-gray-400">Cote en Direct : </span>
                    <span className="text-emerald-400 font-bold text-sm">{formatMarketValue(liveEstimatedValue)}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Date de Naissance *</label>
                    <input
                      type="date"
                      required
                      value={formData.dateOfBirth}
                      onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none font-mono"
                    />
                    <span className="text-[10px] text-gray-400 font-mono mt-1 block">
                      Âge calculé : <strong>{calculatedAge} ans</strong> {isMinor && '(Mineur)'}
                    </span>
                  </div>

                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Poste Principal *</label>
                    <select
                      value={formData.position}
                      onChange={(e) => setFormData({ ...formData, position: e.target.value as any })}
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none font-mono"
                    >
                      <option value="BU">BU - Avant-Centre</option>
                      <option value="AD">AD - Ailier Droit</option>
                      <option value="AG">AG - Ailier Gauche</option>
                      <option value="MOC">MOC - Milieu Offensif</option>
                      <option value="MC">MC - Milieu Central</option>
                      <option value="MDF">MDF - Milieu Défensif</option>
                      <option value="DC">DC - Défenseur Central</option>
                      <option value="DL">DL - Défenseur Latéral</option>
                      <option value="GB">GB - Gardien de But</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Pied Fort *</label>
                    <select
                      value={formData.preferredFoot}
                      onChange={(e) => setFormData({ ...formData, preferredFoot: e.target.value as any })}
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    >
                      <option value="Droit">Pied Droit</option>
                      <option value="Gauche">Pied Gauche</option>
                      <option value="Ambidextre">Ambidextre</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Taille (cm) / Poids (kg)</label>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        value={formData.heightCm}
                        onChange={(e) => setFormData({ ...formData, heightCm: parseInt(e.target.value) || 180 })}
                        placeholder="184 cm"
                        className="w-1/2 px-2 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white text-center font-mono"
                      />
                      <input
                        type="number"
                        value={formData.weightKg}
                        onChange={(e) => setFormData({ ...formData, weightKg: parseInt(e.target.value) || 75 })}
                        placeholder="76 kg"
                        className="w-1/2 px-2 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white text-center font-mono"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Académie / Centre de Formation d'Origine *</label>
                    <input
                      type="text"
                      required
                      value={formData.academy}
                      onChange={(e) => setFormData({ ...formData, academy: e.target.value })}
                      placeholder="Ex: Académie Mimosas, Ivoire Football Academy..."
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Lien Vidéo de Match (YouTube / Vimeo / Drive) *</label>
                    <input
                      type="url"
                      required
                      value={formData.videoUrl}
                      onChange={(e) => setFormData({ ...formData, videoUrl: e.target.value })}
                      placeholder="https://www.youtube.com/watch?v=..."
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Minor protection if < 18 */}
                {isMinor && (
                  <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-600/40 space-y-2">
                    <span className="font-bold text-amber-300 block text-[11px]">
                      ⚠️ Encadrement Joueur Mineur (Conformité FIFA Article 19) :
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <input
                        type="text"
                        required
                        value={formData.guardianName}
                        onChange={(e) => setFormData({ ...formData, guardianName: e.target.value })}
                        placeholder="Nom du Tuteur Légal / Parent Agréé"
                        className="px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white text-xs"
                      />
                      <input
                        type="tel"
                        required
                        value={formData.guardianPhone}
                        onChange={(e) => setFormData({ ...formData, guardianPhone: e.target.value })}
                        placeholder="Téléphone Tuteur Légal"
                        className="px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white text-xs"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 3. ACADÉMIES DE FOOTBALL */}
            {selectedRole === 'ACADEMY' && (
              <div className="p-5 rounded-2xl bg-[#050810] border border-blue-500/30 space-y-4 text-xs">
                <h3 className="font-mono font-bold uppercase text-blue-400 tracking-wider flex items-center gap-2">
                  <span>🎓</span>
                  <span>Informations de l'Académie ou du Centre de Formation</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Nom de l'Académie *</label>
                    <input
                      type="text"
                      required
                      value={formData.academyName}
                      onChange={(e) => setFormData({ ...formData, academyName: e.target.value })}
                      placeholder="Ex: Académie Sol Béni, Génération Foot..."
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Directeur de la Formation</label>
                    <input
                      type="text"
                      value={formData.directorName}
                      onChange={(e) => setFormData({ ...formData, directorName: e.target.value })}
                      placeholder="Nom du directeur technique"
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Nombre de Pensionnaires U15-U21</label>
                    <input
                      type="number"
                      value={formData.traineesCount}
                      onChange={(e) => setFormData({ ...formData, traineesCount: parseInt(e.target.value) || 30 })}
                      placeholder="Ex: 50"
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-gray-400 mb-1 font-bold">Infrastructures & Équipements</label>
                  <input
                    type="text"
                    value={formData.facilitiesSummary}
                    onChange={(e) => setFormData({ ...formData, facilitiesSummary: e.target.value })}
                    placeholder="Terrains en herbe, internat, salle vidéo, staff médical..."
                    className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>
            )}

            {/* 4. SCOUTS & RECRUTEURS TERRAIN */}
            {selectedRole === 'SCOUT' && (
              <div className="p-5 rounded-2xl bg-[#050810] border border-amber-400/30 space-y-4 text-xs">
                <h3 className="font-mono font-bold uppercase text-amber-400 tracking-wider flex items-center gap-2">
                  <span>🔍</span>
                  <span>Accréditation Scout & Superviseur de Terrain</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Structure / Organisme Mandant *</label>
                    <input
                      type="text"
                      required
                      value={formData.scoutOrg}
                      onChange={(e) => setFormData({ ...formData, scoutOrg: e.target.value })}
                      placeholder="Ex: Scout Indépendant, Cellule Pro Club..."
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Territoires Couverts</label>
                    <input
                      type="text"
                      value={formData.territoriesCovered}
                      onChange={(e) => setFormData({ ...formData, territoriesCovered: e.target.value })}
                      placeholder="Côte d'Ivoire, Sénégal, Mali..."
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Années d'Expérience Terrain</label>
                    <input
                      type="number"
                      value={formData.yearsExperience}
                      onChange={(e) => setFormData({ ...formData, yearsExperience: parseInt(e.target.value) || 5 })}
                      placeholder="8"
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 5. AGENTS LICENCIÉS FIFA */}
            {selectedRole === 'FIFA_AGENT' && (
              <div className="p-5 rounded-2xl bg-[#050810] border border-yellow-400/30 space-y-4 text-xs">
                <h3 className="font-mono font-bold uppercase text-yellow-400 tracking-wider flex items-center gap-2">
                  <span>💼</span>
                  <span>Accréditation Agent de Joueurs Licencié FIFA</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Cabinet / Agence de Représentation *</label>
                    <input
                      type="text"
                      required
                      value={formData.agencyName}
                      onChange={(e) => setFormData({ ...formData, agencyName: e.target.value })}
                      placeholder="Ex: Elite Sports Management..."
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">N° de Licence FIFA Officiel *</label>
                    <input
                      type="text"
                      required
                      value={formData.fifaLicenseNumber}
                      onChange={(e) => setFormData({ ...formData, fifaLicenseNumber: e.target.value })}
                      placeholder="FIFA-2024-XXXX"
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Nombre de Mandats Joueurs Actifs</label>
                    <input
                      type="number"
                      value={formData.activeMandatesCount}
                      onChange={(e) => setFormData({ ...formData, activeMandatesCount: parseInt(e.target.value) || 10 })}
                      placeholder="15"
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 6. ENTRAÎNEURS & STAFF TECHNIQUE */}
            {selectedRole === 'HEAD_COACH' && (
              <div className="p-5 rounded-2xl bg-[#050810] border border-purple-400/30 space-y-4 text-xs">
                <h3 className="font-mono font-bold uppercase text-purple-400 tracking-wider flex items-center gap-2">
                  <span>📋</span>
                  <span>Profil Entraîneur & Diplômes d'État / Confédération</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Diplôme d'Entraîneur / Licence *</label>
                    <input
                      type="text"
                      required
                      value={formData.coachingBadge}
                      onChange={(e) => setFormData({ ...formData, coachingBadge: e.target.value })}
                      placeholder="Ex: Licence UEFA Pro, CAF A, FFF..."
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Équipe / Catégorie Prise en Charge</label>
                    <input
                      type="text"
                      value={formData.teamCategory}
                      onChange={(e) => setFormData({ ...formData, teamCategory: e.target.value })}
                      placeholder="Séniors Pro, U19 Nationaux, Réserve..."
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Philosophie de Jeu Privilégiée</label>
                    <input
                      type="text"
                      value={formData.tacticalPhilosophy}
                      onChange={(e) => setFormData({ ...formData, tacticalPhilosophy: e.target.value })}
                      placeholder="Ex: 4-3-3 pressing haut, transitions..."
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 7. DIRECTEURS SPORTIFS */}
            {selectedRole === 'SPORTING_DIRECTOR' && (
              <div className="p-5 rounded-2xl bg-[#050810] border border-cyan-400/30 space-y-4 text-xs">
                <h3 className="font-mono font-bold uppercase text-cyan-400 tracking-wider flex items-center gap-2">
                  <span>👔</span>
                  <span>Direction Sportive & Gestion du Mercato</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Club / Institution Représentée *</label>
                    <input
                      type="text"
                      required
                      value={formData.clubName}
                      onChange={(e) => setFormData({ ...formData, clubName: e.target.value })}
                      placeholder="Nom du club professionnel"
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Fourchette Budget Mercato Annuel</label>
                    <select
                      value={formData.mercatoBudgetBracket}
                      onChange={(e) => setFormData({ ...formData, mercatoBudgetBracket: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none font-mono"
                    >
                      <option value="Moins de 500K€">Moins de 500 000 €</option>
                      <option value="500K€ - 2M€">500 000 € - 2 000 000 €</option>
                      <option value="2M€ - 10M€">2 000 000 € - 10 000 000 €</option>
                      <option value="Plus de 10M€">Plus de 10 000 000 €</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* 8. PRÉSIDENTS DE CLUB */}
            {selectedRole === 'PRESIDENT' && (
              <div className="p-5 rounded-2xl bg-[#050810] border border-red-400/30 space-y-4 text-xs">
                <h3 className="font-mono font-bold uppercase text-red-400 tracking-wider flex items-center gap-2">
                  <span>🏛️</span>
                  <span>Gouvernance & Présidence de Club</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Club Représenté *</label>
                    <input
                      type="text"
                      required
                      value={formData.clubName}
                      onChange={(e) => setFormData({ ...formData, clubName: e.target.value })}
                      placeholder="Nom du club"
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Priorité Stratégique Principale</label>
                    <input
                      type="text"
                      value={formData.strategicGoal}
                      onChange={(e) => setFormData({ ...formData, strategicGoal: e.target.value })}
                      placeholder="Partenariats académie, valorisation sportive..."
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 9. RESPONSABLES DU RECRUTEMENT */}
            {selectedRole === 'RECRUITMENT_MANAGER' && (
              <div className="p-5 rounded-2xl bg-[#050810] border border-indigo-400/30 space-y-4 text-xs">
                <h3 className="font-mono font-bold uppercase text-indigo-400 tracking-wider flex items-center gap-2">
                  <span>🎯</span>
                  <span>Responsable Recrutement / Head of Recruitment</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Club / Agence Mandante *</label>
                    <input
                      type="text"
                      required
                      value={formData.clubName}
                      onChange={(e) => setFormData({ ...formData, clubName: e.target.value })}
                      placeholder="Nom du club employeur"
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1 font-bold">Scouts Régionaux dans votre Équipe</label>
                    <input
                      type="number"
                      value={formData.scoutsDelegatedCount}
                      onChange={(e) => setFormData({ ...formData, scoutsDelegatedCount: parseInt(e.target.value) || 4 })}
                      placeholder="4"
                      className="w-full px-3 py-2 rounded-lg bg-[#080D1A] border border-white/10 text-white focus:border-amber-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* SUBMIT BUTTON */}
            <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-[11px] text-gray-400 font-mono">
                Certification sous la supervision de <strong>{FOUNDER_INFO.name}</strong> · Desk officiel WhatsApp (+225 05 44 42 01 62).
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-xl shadow-amber-500/20 cursor-pointer active:scale-95 disabled:opacity-50 border border-amber-300"
              >
                {isSubmitting ? 'Traitement & Certification en cours...' : `Valider l'Accréditation (${activeRoleOption.label}) →`}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
