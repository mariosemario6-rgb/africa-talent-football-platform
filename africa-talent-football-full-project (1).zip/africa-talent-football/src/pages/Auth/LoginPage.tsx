import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { FOUNDER_INFO } from '../../data/demoData';
import { UserRole } from '../../types/database';

interface LoginPageProps {
  onNavigate: (view: string, payload?: any) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onNavigate }) => {
  const { login, loginAsDemoRole, currentUser } = useAuth();
  const { t } = useLanguage();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loginSuccess, setLoginSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsSubmitting(true);

    const result = await login(email, password, rememberMe);

    if (result.success) {
      setLoginSuccess(true);
      setTimeout(() => {
        onNavigate('dashboard', { role: result.user?.role || 'SCOUT' });
      }, 1000);
    } else {
      setErrorMsg(result.error || t('login.invalidCredentials', 'Identifiants invalides. Veuillez vérifier vos accès.'));
      setIsSubmitting(false);
    }
  };

  const handleQuickDemo = (role: UserRole, demoEmail: string) => {
    setEmail(demoEmail);
    setPassword('Mario2026!');
    loginAsDemoRole(role);
    setLoginSuccess(true);
    setTimeout(() => {
      onNavigate('dashboard', { role });
    }, 800);
  };

  return (
    <div className="max-w-md mx-auto px-4 sm:px-6 py-12 space-y-8 animate-in fade-in duration-300 text-left">
      {/* Brand Header */}
      <div className="text-center space-y-2">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 flex items-center justify-center text-black font-black text-xl mx-auto shadow-lg shadow-amber-500/20">
          ATF
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
          {t('auth.loginTitle', 'Connexion Espace Membre')}
        </h1>
        <p className="text-xs text-gray-400">
          {t('auth.loginSubtitle', 'Accédez à votre espace professionnel certifié Africa Talent Football.')}
        </p>
      </div>

      {/* Success banner */}
      {loginSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-950/80 border border-emerald-500/60 text-center space-y-2 animate-in zoom-in-95">
          <div className="w-10 h-10 rounded-full bg-emerald-500 text-black flex items-center justify-center text-lg font-black mx-auto">
            ✓
          </div>
          <h3 className="text-sm font-black text-white">{t('login.success', 'Connexion réussie !')}</h3>
          <p className="text-xs text-emerald-300 font-mono">
            {t('login.redirecting', 'Redirection vers votre espace de travail en cours...')}
          </p>
        </div>
      )}

      {/* Form Card */}
      {!loginSuccess && (
        <div className="bg-[#080D1A] rounded-3xl border border-amber-500/40 p-6 sm:p-8 shadow-2xl space-y-6">
          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs font-mono flex items-center gap-2">
              <span className="text-base shrink-0">⚠️</span>
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono font-bold text-gray-300 block">
                {t('login.email', 'Adresse E-mail Professionnelle :')}
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="votre.nom@club.com"
                className="w-full px-4 py-3 rounded-xl bg-[#050810] border border-white/10 text-white placeholder-gray-500 text-sm font-mono focus:border-amber-400 outline-none transition-colors"
              />
            </div>

            {/* Password */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-mono font-bold text-gray-300 block">
                  {t('login.password', 'Mot de passe :')}
                </label>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-[11px] font-mono text-amber-400 hover:underline cursor-pointer"
                >
                  {showPassword ? t('login.hide', 'Masquer') : t('login.show', 'Afficher')}
                </button>
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-4 py-3 rounded-xl bg-[#050810] border border-white/10 text-white placeholder-gray-500 text-sm font-mono focus:border-amber-400 outline-none transition-colors"
              />
            </div>

            {/* Remember Me */}
            <div className="flex items-center justify-between text-xs font-mono text-gray-400 pt-1">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded border-white/20 bg-black text-amber-500 focus:ring-0 cursor-pointer"
                />
                <span>{t('auth.rememberMe', 'Rester connecté sur cet appareil')}</span>
              </label>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-amber-500/20 cursor-pointer border border-amber-300 disabled:opacity-50 mt-2"
            >
              {isSubmitting ? t('common.loading', 'Vérification en cours...') : t('login.submit', 'Se Connecter')}
            </button>
          </form>

          {/* Quick Demo Accounts Helper */}
          <div className="space-y-3 pt-4 border-t border-white/10">
            <span className="text-[11px] font-mono text-gray-400 block font-bold uppercase">
              {t('auth.quickDemoTitle', 'Comptes Rapides de Démonstration :')}
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <button
                type="button"
                onClick={() => handleQuickDemo('SCOUT', 'mariosemario6@gmail.com')}
                className="p-2.5 rounded-xl bg-[#050810] border border-white/10 hover:border-amber-400 text-left text-gray-300 hover:text-white transition-all cursor-pointer"
              >
                <span className="block font-bold text-amber-400">🔍 {t('role.scout', 'Scout / Fondateur')}</span>
                <span className="text-[10px] text-gray-500 truncate block">Seydou Mario Traoré</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemo('CLUB', 'recrutement@standard.be')}
                className="p-2.5 rounded-xl bg-[#050810] border border-white/10 hover:border-amber-400 text-left text-gray-300 hover:text-white transition-all cursor-pointer"
              >
                <span className="block font-bold text-blue-400">🏟️ {t('role.club', 'Club Pro')}</span>
                <span className="text-[10px] text-gray-500 truncate block">Standard de Liège</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemo('PLAYER', 'amadou.diallo@talent.ci')}
                className="p-2.5 rounded-xl bg-[#050810] border border-white/10 hover:border-amber-400 text-left text-gray-300 hover:text-white transition-all cursor-pointer"
              >
                <span className="block font-bold text-emerald-400">⚽ {t('role.player', 'Joueur / Athlète')}</span>
                <span className="text-[10px] text-gray-500 truncate block">Amadou Diallo (DC)</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemo('ACADEMY', 'direction@academiemimosas.ci')}
                className="p-2.5 rounded-xl bg-[#050810] border border-white/10 hover:border-amber-400 text-left text-gray-300 hover:text-white transition-all cursor-pointer"
              >
                <span className="block font-bold text-purple-400">🎓 {t('role.academy', 'Académie Form.')}</span>
                <span className="text-[10px] text-gray-500 truncate block">Académie Mimosas</span>
              </button>
            </div>
            <p className="text-[10px] text-gray-500 font-mono text-center">
              {t('login.demoAccounts', 'Mot de passe démo :')} <code className="text-amber-400">Mario2026!</code>
            </p>
          </div>

          {/* Switch to Register */}
          <div className="pt-2 text-center text-xs font-mono text-gray-400 border-t border-white/10">
            <span>{t('auth.noAccount', "Vous n'avez pas encore de compte ?")} </span>
            <button
              type="button"
              onClick={() => onNavigate('register')}
              className="text-amber-400 hover:underline font-bold cursor-pointer ml-1"
            >
              {t('auth.createAccount', 'Créer un compte professionnel')} ➔
            </button>
          </div>
        </div>
      )}

      {/* Footer support */}
      <div className="text-center text-[11px] font-mono text-gray-500">
        {t('footer.support', 'Assistance technique :')} <strong className="text-gray-300">{FOUNDER_INFO.email}</strong> · Desk : {FOUNDER_INFO.phone}
      </div>
    </div>
  );
};
