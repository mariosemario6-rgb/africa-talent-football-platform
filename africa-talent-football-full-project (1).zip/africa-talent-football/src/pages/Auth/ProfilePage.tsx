import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNetwork } from '../../context/NetworkContext';
import { FOUNDER_INFO } from '../../data/demoData';
import { DirectPlatformContactModal } from '../../components/common/DirectPlatformContactModal';
import { ImageUploadModal } from '../../components/common/ImageUploadModal';
import { RealtimePartnerHub } from '../../components/common/RealtimePartnerHub';
import { useLanguage } from '../../context/LanguageContext';

interface ProfilePageProps {
  onNavigate: (view: string, payload?: any) => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ onNavigate }) => {
  const { t, tRole, formatDate } = useLanguage();
  const { currentUser, updateUser, changePassword, logout, isPremium, upgradeToPremium, toggleSimulatePremium } = useAuth();
  const { feedPosts, deleteFeedPost } = useNetwork();

  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
  const [isCoverModalOpen, setIsCoverModalOpen] = useState(false);

  // Profile Form state
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState('');
  const [bio, setBio] = useState('');
  const [clubName, setClubName] = useState('');
  const [academyName, setAcademyName] = useState('');
  const [fifaLicenseNumber, setFifaLicenseNumber] = useState('');
  const [coachingBadge, setCoachingBadge] = useState('');
  const [primaryPosition, setPrimaryPosition] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [coverUrl, setCoverUrl] = useState('');

  // Password change state
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPasswordSection, setShowPasswordSection] = useState(false);

  // Status feedback
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (currentUser) {
      setFirstName(currentUser.firstName || '');
      setLastName(currentUser.lastName || '');
      setPhone(currentUser.phone || '');
      setCountry(currentUser.country || "Côte d'Ivoire");
      setBio(currentUser.bio || '');
      setClubName(currentUser.clubName || '');
      setAcademyName(currentUser.academyName || '');
      setFifaLicenseNumber(currentUser.fifaLicenseNumber || '');
      setCoachingBadge(currentUser.coachingBadge || '');
      setPrimaryPosition(currentUser.primaryPosition || '');
      setAvatarUrl(currentUser.avatarUrl || '');
      setCoverUrl(currentUser.coverUrl || '');
    }
  }, [currentUser]);

  if (!currentUser) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4">
        <div className="text-4xl">🔒</div>
        <h2 className="text-xl font-black text-white">Espace Non Connecté</h2>
        <p className="text-xs text-gray-400">
          Veuillez vous connecter pour accéder à votre profil et modifier vos informations.
        </p>
        <button
          onClick={() => onNavigate('login')}
          className="px-6 py-2.5 rounded-xl bg-amber-500 text-black font-black text-xs uppercase tracking-wider cursor-pointer"
        >
          Se Connecter ➔
        </button>
      </div>
    );
  }

  const handleSaveAvatar = async (newUrl: string) => {
    setAvatarUrl(newUrl);
    await updateUser({ avatarUrl: newUrl });
    if (currentUser?.email === 'mariosemario6@gmail.com' || currentUser?.id === 'user-scout-01') {
      if (typeof window !== 'undefined') {
        localStorage.setItem('atf_founder_custom_photo', newUrl);
      }
    }
    setStatusMsg({
      type: 'success',
      text: 'Photo de profil mise à jour et synchronisée en temps réel.'
    });
    setTimeout(() => setStatusMsg(null), 3500);
  };

  const handleSaveCover = async (newUrl: string) => {
    setCoverUrl(newUrl);
    await updateUser({ coverUrl: newUrl });
    setStatusMsg({
      type: 'success',
      text: 'Photo de couverture mise à jour et synchronisée en temps réel.'
    });
    setTimeout(() => setStatusMsg(null), 3500);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setStatusMsg(null);

    const res = await updateUser({
      firstName,
      lastName,
      phone,
      country,
      bio,
      clubName,
      academyName,
      fifaLicenseNumber,
      coachingBadge,
      primaryPosition,
      avatarUrl,
      coverUrl
    });

    setIsSaving(false);
    if (res.success) {
      setStatusMsg({
        type: 'success',
        text: 'Profil et visuels enregistrés durablement ! Flux temps réel synchronisés.'
      });
      setTimeout(() => setStatusMsg(null), 4000);
    } else {
      setStatusMsg({ type: 'error', text: res.error || 'Erreur lors de la mise à jour.' });
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg(null);

    if (newPassword !== confirmPassword) {
      setStatusMsg({ type: 'error', text: 'Les deux nouveaux mots de passe ne correspondent pas.' });
      return;
    }

    const res = await changePassword(oldPassword, newPassword);
    if (res.success) {
      setStatusMsg({ type: 'success', text: 'Votre mot de passe a été modifié avec succès.' });
      setOldPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setShowPasswordSection(false);
      setTimeout(() => setStatusMsg(null), 4000);
    } else {
      setStatusMsg({ type: 'error', text: res.error || 'Impossible de modifier le mot de passe.' });
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'PLAYER':
        return <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold">⚽ Joueur & Athlète</span>;
      case 'CLUB':
        return <span className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/40 text-xs font-mono font-bold">🏟️ Club Professionnel</span>;
      case 'ACADEMY':
        return <span className="px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 text-xs font-mono font-bold">🎓 Académie Agréée</span>;
      case 'FIFA_AGENT':
        return <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold">💼 Agent Licencié FIFA</span>;
      case 'HEAD_COACH':
        return <span className="px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-mono font-bold">📋 Entraîneur / Staff</span>;
      case 'SPORTING_DIRECTOR':
        return <span className="px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-xs font-mono font-bold">👔 Directeur Sportif</span>;
      case 'PRESIDENT':
        return <span className="px-3 py-1 rounded-full bg-yellow-500/20 text-yellow-300 border border-yellow-500/40 text-xs font-mono font-bold">🏛️ Président de Club</span>;
      default:
        return <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold">🔍 Recruteur / Scout</span>;
    }
  };

  const activeCover = coverUrl || currentUser.coverUrl || 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=1200&auto=format&fit=crop&q=80';
  const isFounderUser = currentUser.email === 'mariosemario6@gmail.com' || currentUser.id === 'user-scout-01';
  const customFounderPhoto = typeof window !== 'undefined' ? localStorage.getItem('atf_founder_custom_photo') : null;
  const activeAvatar = avatarUrl || currentUser.avatarUrl || (isFounderUser ? (customFounderPhoto || '/founder_africa_talent.jpg') : '');

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300 text-left">
      {/* LinkedIn-Style Cover & Profile Hero Header */}
      <div className="rounded-3xl bg-[#080D1A] border-2 border-amber-500/40 shadow-2xl overflow-hidden relative">
        {/* Cover Photo Banner */}
        <div className="relative h-44 sm:h-60 md:h-72 w-full bg-gradient-to-r from-blue-950 via-slate-900 to-amber-950/50 group overflow-hidden">
          <img
            src={activeCover}
            alt="Cover banner"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-black/35 pointer-events-none" />

          {/* Network tag on cover */}
          <div className="absolute top-4 left-4">
            <span className="px-3 py-1 rounded-full bg-amber-500/95 text-black font-mono font-black text-[10px] uppercase tracking-wider shadow-lg flex items-center gap-1.5 backdrop-blur-sm">
              <span>★</span> Africa Talent Football Pro Network
            </span>
          </div>

          {/* Action on Cover: Change cover photo */}
          <div className="absolute top-4 right-4 flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsCoverModalOpen(true)}
              className="px-3.5 py-1.5 rounded-xl bg-black/75 hover:bg-black/95 text-white border border-white/20 hover:border-amber-400 text-xs font-mono font-bold flex items-center gap-1.5 backdrop-blur-md transition-all shadow-xl cursor-pointer"
            >
              <span>📷</span>
              <span className="hidden sm:inline">Changer la Photo de Couverture</span>
              <span className="sm:hidden">Couverture</span>
            </button>
          </div>
        </div>

        {/* Profile Info & Overlapping Avatar */}
        <div className="px-6 sm:px-8 pb-8 pt-0 relative">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-16 sm:-mt-24 mb-4">
            {/* Avatar with Camera badge */}
            <div className="relative group self-start">
              <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-3xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black text-3xl sm:text-5xl shadow-2xl overflow-hidden border-4 border-[#080D1A] ring-2 ring-amber-400/60">
                {activeAvatar ? (
                  <img
                    src={activeAvatar}
                    alt={currentUser.firstName}
                    className="w-full h-full object-cover object-[50%_20%]"
                    onError={(e) => {
                      const target = e.currentTarget;
                      target.style.display = 'none';
                    }}
                  />
                ) : (
                  <span>{currentUser.firstName?.[0] || 'U'}{currentUser.lastName?.[0] || ''}</span>
                )}
              </div>
              <button
                type="button"
                onClick={() => setIsAvatarModalOpen(true)}
                title="Modifier ma photo de profil"
                className="absolute bottom-1 right-1 w-10 h-10 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black border-3 border-[#080D1A] flex items-center justify-center shadow-2xl transition-transform hover:scale-110 cursor-pointer text-base"
              >
                📷
              </button>
            </div>

            {/* Quick buttons */}
            <div className="flex flex-wrap items-center gap-2.5 self-start sm:self-auto pt-2 sm:pt-0">
              <button
                type="button"
                onClick={() => setIsAvatarModalOpen(true)}
                className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-200 border border-white/10 text-xs font-mono transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <span>👤</span>
                <span>Changer Avatar</span>
              </button>
              <button
                type="button"
                onClick={() => setIsCoverModalOpen(true)}
                className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-200 border border-white/10 text-xs font-mono transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <span>🖼️</span>
                <span>Changer Bannière</span>
              </button>
              <button
                onClick={() => onNavigate('dashboard', { role: currentUser.role })}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-md"
              >
                Dashboard ➔
              </button>
              <button
                onClick={() => {
                  logout();
                  onNavigate('home');
                }}
                className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-red-500/20 hover:text-red-300 hover:border-red-500/40 text-gray-400 border border-white/10 font-mono text-xs transition-colors cursor-pointer"
              >
                Déconnexion
              </button>
            </div>
          </div>

          {/* User Details */}
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2.5">
              <h1 className="text-xl sm:text-2xl font-black text-white">
                {currentUser.firstName} {currentUser.lastName}
              </h1>
              {currentUser.verified && (
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-mono font-bold flex items-center gap-1">
                  ✓ Profil Certifié ATF
                </span>
              )}
              {isPremium ? (
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/50 text-[10px] font-mono font-black flex items-center gap-1 shadow-sm">
                  👑 VIP PREMIUM
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full bg-white/10 text-gray-400 border border-white/10 text-[10px] font-mono font-bold">
                  Membre Gratuit (Adhésion Libre)
                </span>
              )}
            </div>

            <p className="text-xs text-gray-300 font-mono">
              E-mail : <strong className="text-amber-400">{currentUser.email}</strong>
              {currentUser.phone && <span className="ml-3 text-gray-400">· WhatsApp : {currentUser.phone}</span>}
              {currentUser.country && <span className="ml-3 text-gray-400">· Pays : {currentUser.country}</span>}
            </p>

            {currentUser.bio && (
              <p className="text-xs text-gray-400 max-w-3xl pt-1 leading-relaxed">
                {currentUser.bio}
              </p>
            )}

            <div className="pt-2">{getRoleBadge(currentUser.role)}</div>
          </div>
        </div>
      </div>

      {/* Accreditation Telemetry */}
      <div className="p-4 rounded-2xl bg-[#080D1A] border border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
        <div>
          <span className="text-gray-500 block text-[10px]">ID MEMBRE</span>
          <span className="text-emerald-400 font-bold truncate block">{currentUser.id}</span>
        </div>
        <div>
          <span className="text-gray-500 block text-[10px]">ENREGISTRÉ LE</span>
          <span className="text-gray-300 font-bold block">
            {new Date(currentUser.registeredAt).toLocaleDateString('fr-FR')}
          </span>
        </div>
        <div>
          <span className="text-gray-500 block text-[10px]">PAYS D'EXERCICE</span>
          <span className="text-white font-bold block">{currentUser.country}</span>
        </div>
        <div>
          <span className="text-gray-500 block text-[10px]">SUPERVISION TECHNIQUE</span>
          <span className="text-amber-400 font-bold block">Seydou Mario TRAORÉ</span>
        </div>
      </div>

      {/* Status banner */}
      {statusMsg && (
        <div
          className={`p-4 rounded-2xl text-xs font-mono flex items-center gap-2 ${
            statusMsg.type === 'success'
              ? 'bg-emerald-950/80 border border-emerald-500/60 text-emerald-200'
              : 'bg-red-950/80 border border-red-500/60 text-red-200'
          }`}
        >
          <span className="text-base">{statusMsg.type === 'success' ? '✓' : '⚠️'}</span>
          <span>{statusMsg.text}</span>
        </div>
      )}

      {/* REAL-TIME INFORMATION HUB FROM CLUBS, COMPANIES, AND BANKS */}
      <div className="space-y-3">
        <RealtimePartnerHub onNavigate={onNavigate} />
      </div>

      {/* VOLUNTARY MEMBERSHIP & SUBSCRIPTION STATUS CARD */}
      <div className="p-6 sm:p-7 rounded-3xl bg-gradient-to-br from-[#091122] via-[#080D1A] to-[#0D1829] border border-amber-500/30 space-y-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                Adhésion Volontaire : Gratuite ou Premium
              </span>
              <span className="text-[10px] font-mono font-bold uppercase text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                Sans Engagement Forcé
              </span>
            </div>
            <h2 className="text-lg font-black text-white mt-1">Statut de votre Compte & Abonnement</h2>
            <p className="text-xs text-gray-400">
              L'adhésion est gratuite pour tous les utilisateurs. L'abonnement Premium est entièrement volontaire et confère des avantages exclusifs.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className={`px-3 py-1 rounded-full text-xs font-mono font-black ${
              isPremium 
                ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20' 
                : 'bg-gray-800 text-gray-300 border border-white/10'
            }`}>
              {isPremium ? '👑 MEMBRE PREMIUM ACTIF' : '🆓 ADHÉSION GRATUITE'}
            </span>
          </div>
        </div>

        {/* Benefits comparison table */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-gray-200">Fonctionnalités Incluses (Gratuit) :</span>
              <span className="text-[10px] text-emerald-400 font-bold">100% Inclus</span>
            </div>
            <ul className="space-y-1.5 text-gray-400 text-[11px]">
              <li className="flex items-center gap-1.5">✓ Accès complet au profil et modification des coordonnées</li>
              <li className="flex items-center gap-1.5">✓ Consultation des talents et statistiques certifiées</li>
              <li className="flex items-center gap-1.5">✓ Publication de posts, actualités et vidéos sur le Fil Réseau</li>
              <li className="flex items-center gap-1.5">✓ Consultation des flux en temps réel clubs, banques et sponsors</li>
            </ul>
          </div>

          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-amber-300">Avantages Exclusifs Premium (Optionnel) :</span>
              <span className="text-[10px] text-amber-400 font-bold">👑 Privilèges VIP</span>
            </div>
            <ul className="space-y-1.5 text-gray-300 text-[11px]">
              <li className="flex items-center gap-1.5">★ <strong>Contact direct avec les membres Premium et clubs</strong></li>
              <li className="flex items-center gap-1.5">★ <strong>Ligne directe WhatsApp / Téléphone avec la direction ATF</strong></li>
              <li className="flex items-center gap-1.5">★ Badge VIP doré certifié visible sur toutes vos publications</li>
              <li className="flex items-center gap-1.5">★ Accès illimité à la banque de vidéos de matches brutes Eyeball</li>
              <li className="flex items-center gap-1.5">★ Support technique et audit de scouting prioritaire sous 2h</li>
            </ul>
          </div>
        </div>

        {/* Action button bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="flex items-center gap-2">
            <button
              onClick={() => toggleSimulatePremium()}
              className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10 text-xs font-mono transition-colors cursor-pointer"
            >
              {isPremium ? '🔄 Désactiver le statut Premium (Test)' : '⚡ Activer le Statut Premium (Test 1-Clic)'}
            </button>
            <button
              onClick={() => onNavigate('pricing')}
              className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold transition-colors cursor-pointer"
            >
              Voir la Grille Tarifaire ➔
            </button>
          </div>

          <button
            onClick={() => setIsContactModalOpen(true)}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-mono font-bold text-xs uppercase tracking-wider transition-all shadow-lg flex items-center gap-2 cursor-pointer"
          >
            <span>📞</span>
            <span>Contacter Directement la Plateforme</span>
          </button>
        </div>
      </div>

      {/* PROFILE EDIT FORM */}
      <div className="bg-[#080D1A] rounded-3xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div>
            <h2 className="text-lg font-black text-white">Modifier mes Informations Personnelles</h2>
            <p className="text-xs text-gray-400">
              Mettez à jour vos coordonnées professionnelles, visuels et biographie technique.
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-400 font-bold">
            ● Données sauvegardées en temps réel
          </span>
        </div>

        <form onSubmit={handleSaveProfile} className="space-y-6">
          {/* Visuals Management Sub-Section */}
          <div className="p-5 rounded-2xl bg-[#050810] border border-amber-500/30 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-white font-mono uppercase tracking-wider flex items-center gap-2">
                <span>🖼️</span> Photos et Visuels Officiels (Profil & Bannière)
              </h3>
              <span className="text-[10px] font-mono text-amber-400 font-bold">
                Optimisation Haute Résolution Automatique
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Photo de profil Card */}
              <div className="p-4 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-400 overflow-hidden flex items-center justify-center text-amber-400 font-black text-xl shrink-0">
                    {activeAvatar ? (
                      <img src={activeAvatar} alt="Avatar" className="w-full h-full object-cover" />
                    ) : (
                      <span>👤</span>
                    )}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">Photo de Profil</h4>
                    <p className="text-[10px] text-gray-400 font-mono">Format carré 1:1</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsAvatarModalOpen(true)}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-mono font-bold text-xs cursor-pointer transition-colors shadow-md"
                >
                  Téléverser ➔
                </button>
              </div>

              {/* Photo de couverture Card */}
              <div className="p-4 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 overflow-hidden">
                  <div className="w-20 h-14 rounded-xl bg-blue-500/20 border border-blue-400 overflow-hidden shrink-0">
                    <img src={activeCover} alt="Cover" className="w-full h-full object-cover" />
                  </div>
                  <div className="truncate">
                    <h4 className="text-xs font-bold text-white truncate">Photo de Couverture</h4>
                    <p className="text-[10px] text-gray-400 font-mono">Bannière panoramique</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsCoverModalOpen(true)}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-mono font-bold text-xs cursor-pointer transition-colors shadow-md shrink-0"
                >
                  Téléverser ➔
                </button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Prénom */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono font-bold text-gray-300 block">Prénom :</label>
              <input
                type="text"
                required
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
              />
            </div>

            {/* Nom */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono font-bold text-gray-300 block">Nom de famille :</label>
              <input
                type="text"
                required
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
              />
            </div>

            {/* Téléphone */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono font-bold text-gray-300 block">Téléphone / WhatsApp :</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+225 05..."
                className="w-full px-4 py-2.5 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
              />
            </div>

            {/* Pays */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono font-bold text-gray-300 block">Pays de résidence :</label>
              <input
                type="text"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
              />
            </div>

            {/* Role specific: Club or Organization */}
            {(currentUser.role === 'CLUB' || currentUser.role === 'SPORTING_DIRECTOR' || currentUser.role === 'PRESIDENT') && (
              <div className="space-y-1.5">
                <label className="text-xs font-mono font-bold text-gray-300 block">Club Professionnel :</label>
                <input
                  type="text"
                  value={clubName}
                  onChange={(e) => setClubName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
                />
              </div>
            )}

            {/* Role specific: Academy */}
            {currentUser.role === 'ACADEMY' && (
              <div className="space-y-1.5">
                <label className="text-xs font-mono font-bold text-gray-300 block">Nom de l'Académie :</label>
                <input
                  type="text"
                  value={academyName}
                  onChange={(e) => setAcademyName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
                />
              </div>
            )}

            {/* Role specific: FIFA Agent */}
            {currentUser.role === 'FIFA_AGENT' && (
              <div className="space-y-1.5">
                <label className="text-xs font-mono font-bold text-gray-300 block">N° Licence FIFA Officielle :</label>
                <input
                  type="text"
                  value={fifaLicenseNumber}
                  onChange={(e) => setFifaLicenseNumber(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
                />
              </div>
            )}

            {/* Role specific: Coach */}
            {currentUser.role === 'HEAD_COACH' && (
              <div className="space-y-1.5">
                <label className="text-xs font-mono font-bold text-gray-300 block">Diplômes / Licence d'entraîneur :</label>
                <input
                  type="text"
                  value={coachingBadge}
                  onChange={(e) => setCoachingBadge(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
                />
              </div>
            )}

            {/* Role specific: Player */}
            {currentUser.role === 'PLAYER' && (
              <div className="space-y-1.5">
                <label className="text-xs font-mono font-bold text-gray-300 block">Poste Préférentiel :</label>
                <select
                  value={primaryPosition}
                  onChange={(e) => setPrimaryPosition(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
                >
                  <option value="">Sélectionnez un poste</option>
                  <option value="BU">Avant-Centre (BU)</option>
                  <option value="AG">Ailier Gauche (AG)</option>
                  <option value="AD">Ailier Droit (AD)</option>
                  <option value="MOC">Milieu Offensif (MOC)</option>
                  <option value="MC">Milieu Central (MC)</option>
                  <option value="MDF">Milieu Défensif (MDF)</option>
                  <option value="DC">Défenseur Central (DC)</option>
                  <option value="DL">Défenseur Latéral (DL)</option>
                  <option value="GB">Gardien de But (GB)</option>
                </select>
              </div>
            )}

            {/* Avatar URL direct input */}
            <div className="space-y-1.5 sm:col-span-2">
              <label className="text-xs font-mono font-bold text-gray-300 block">
                Photo de profil (URL directe ou téléversement ci-dessus) :
              </label>
              <input
                type="url"
                value={avatarUrl}
                onChange={(e) => setAvatarUrl(e.target.value)}
                placeholder="https://images.unsplash.com/..."
                className="w-full px-4 py-2.5 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
              />
            </div>

            {/* Cover URL direct input */}
            <div className="space-y-1.5 sm:col-span-2">
              <label className="text-xs font-mono font-bold text-gray-300 block">
                Photo de couverture / Bannière (URL directe ou téléversement ci-dessus) :
              </label>
              <input
                type="url"
                value={coverUrl}
                onChange={(e) => setCoverUrl(e.target.value)}
                placeholder="https://images.unsplash.com/photo-..."
                className="w-full px-4 py-2.5 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
              />
            </div>

            {/* Bio */}
            <div className="space-y-1.5 sm:col-span-2">
              <label className="text-xs font-mono font-bold text-gray-300 block">Biographie / Description d'activité :</label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Présentez votre parcours, vos ambitions ou les besoins prioritaires de votre effectif..."
                className="w-full px-4 py-2.5 rounded-xl bg-[#050810] border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none resize-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={() => setShowPasswordSection(!showPasswordSection)}
              className="text-xs font-mono text-amber-400 hover:underline cursor-pointer"
            >
              {showPasswordSection ? 'Masquer la sécurité mot de passe' : '🔒 Modifier mon mot de passe'}
            </button>

            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/20 cursor-pointer disabled:opacity-50"
            >
              {isSaving ? 'Enregistrement...' : 'Enregistrer les Modifications'}
            </button>
          </div>
        </form>

        {/* Change password sub-card */}
        {showPasswordSection && (
          <div className="p-5 rounded-2xl bg-[#050810] border border-amber-500/30 space-y-4 animate-in fade-in duration-200">
            <h3 className="text-sm font-black text-white font-mono uppercase tracking-wider">
              Sécurité : Renouvellement du mot de passe
            </h3>
            <form onSubmit={handleChangePassword} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-mono text-gray-400 block">Ancien mot de passe :</label>
                  <input
                    type="password"
                    required
                    value={oldPassword}
                    onChange={(e) => setOldPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-mono text-gray-400 block">Nouveau mot de passe :</label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-mono text-gray-400 block">Confirmer :</label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white text-xs font-mono focus:border-amber-400 outline-none"
                  />
                </div>
              </div>
              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-500 text-black font-black text-xs font-mono uppercase tracking-wider cursor-pointer shadow-md"
                >
                  Mettre à Jour le Mot de Passe
                </button>
              </div>
            </form>
          </div>
        )}
      </div>

      {/* USER'S NETWORK POSTS */}
      <div className="bg-[#080D1A] rounded-3xl border border-white/10 p-6 sm:p-8 space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div>
            <h3 className="text-base font-black text-white">Mes Publications sur le Fil Réseau</h3>
            <p className="text-xs text-gray-400">
              Retrouvez l'historique de vos posts, partages de pépites et analyses techniques.
            </p>
          </div>
          <button
            onClick={() => onNavigate('feed')}
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md"
          >
            + Publier un Post sur le Fil
          </button>
        </div>

        {(() => {
          const myPosts = feedPosts.filter(
            p => p.authorId === currentUser.id || p.authorName.toLowerCase() === `${currentUser.firstName} ${currentUser.lastName}`.toLowerCase()
          );

          if (myPosts.length === 0) {
            return (
              <div className="p-6 rounded-2xl bg-[#050810] border border-white/5 text-center space-y-2">
                <span className="text-2xl">📝</span>
                <p className="text-xs text-gray-300">Vous n'avez pas encore publié de post sur le réseau.</p>
                <button
                  onClick={() => onNavigate('feed')}
                  className="text-xs text-amber-400 hover:underline font-bold cursor-pointer"
                >
                  Accéder au Fil Réseau pour publier ➔
                </button>
              </div>
            );
          }

          return (
            <div className="space-y-3">
              {myPosts.map((post) => (
                <div
                  key={post.id}
                  className="p-4 rounded-2xl bg-[#050810] border border-white/10 space-y-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:-translate-y-0.5 hover:border-amber-400/40 hover:shadow-lg transition-all duration-300"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono text-gray-400">{post.timeAgo}</span>
                      {post.tags && post.tags.slice(0, 2).map((t, idx) => (
                        <span key={idx} className="text-[10px] text-amber-400 font-mono">{t}</span>
                      ))}
                    </div>
                    <p className="text-xs text-gray-200 line-clamp-2">{post.content}</p>
                    <div className="text-[10px] text-gray-400 font-mono">
                      👍 {post.likesCount} Recommandations · 💬 {post.commentsCount} Commentaires
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => onNavigate('feed')}
                      className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 hover:scale-105 active:scale-95 text-white text-xs font-mono cursor-pointer transition-all duration-200"
                    >
                      Voir sur le Fil
                    </button>
                    <button
                      onClick={() => deleteFeedPost(post.id)}
                      className="px-3 py-1.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 hover:scale-105 active:scale-95 text-red-300 border border-red-500/30 text-xs font-mono cursor-pointer transition-all duration-200"
                    >
                      Supprimer
                    </button>
                  </div>
                </div>
              ))}
            </div>
          );
        })()}
      </div>

      {/* Technical Desk Contact */}
      <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-xl">🛡️</span>
          <span className="text-amber-200">
            Besoin d'une mise à jour de licence FIFA ou d'une certification prioritaire de club ?
          </span>
        </div>
        <button
          onClick={() => setIsContactModalOpen(true)}
          className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs shrink-0 flex items-center gap-1.5 shadow-md cursor-pointer"
        >
          <span>Ligne Directe Desk & WhatsApp</span>
        </button>
      </div>

      {/* Direct Platform Contact Modal */}
      <DirectPlatformContactModal
        isOpen={isContactModalOpen}
        onClose={() => setIsContactModalOpen(false)}
        onNavigate={onNavigate}
      />

      {/* Avatar Upload Modal */}
      <ImageUploadModal
        isOpen={isAvatarModalOpen}
        onClose={() => setIsAvatarModalOpen(false)}
        type="avatar"
        currentImageUrl={activeAvatar}
        onSave={handleSaveAvatar}
      />

      {/* Cover Upload Modal */}
      <ImageUploadModal
        isOpen={isCoverModalOpen}
        onClose={() => setIsCoverModalOpen(false)}
        type="cover"
        currentImageUrl={activeCover}
        onSave={handleSaveCover}
      />
    </div>
  );
};
