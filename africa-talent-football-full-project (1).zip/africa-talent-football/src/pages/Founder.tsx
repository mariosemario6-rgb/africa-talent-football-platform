import React, { useState, useRef } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { ASSETS, FOUNDER_INFO } from '../data/demoData';

export const Founder: React.FC = () => {
  const { language, t } = useLanguage();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [founderPhoto, setFounderPhoto] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('atf_founder_custom_photo');
      if (saved) return saved;
    }
    return '/founder_africa_talent.jpg';
  });

  const [photoFeedback, setPhotoFeedback] = useState<string | null>(null);
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryOrg, setInquiryOrg] = useState('');
  const [inquiryRole, setInquiryRole] = useState('Club Professionnel');
  const [inquiryMessage, setInquiryMessage] = useState('');
  const [sentSuccess, setSentSuccess] = useState(false);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setFounderPhoto(reader.result);
          if (typeof window !== 'undefined') {
            localStorage.setItem('atf_founder_custom_photo', reader.result);
          }
          setPhotoFeedback(t('founder.photoUploadedSuccess', 'Photo officielle du fondateur mise à jour avec succès !'));
          setTimeout(() => setPhotoFeedback(null), 4000);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleResetPhoto = () => {
    setFounderPhoto('/founder_africa_talent.jpg');
    if (typeof window !== 'undefined') {
      localStorage.removeItem('atf_founder_custom_photo');
    }
    setPhotoFeedback('Photo réinitialisée.');
    setTimeout(() => setPhotoFeedback(null), 3000);
  };

  const handleSubmitInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    const encodedText = encodeURIComponent(
      `Demande Officielle Direction Technique Africa Talent Football:\nSuperviseur: ${FOUNDER_INFO.name} (${FOUNDER_INFO.officialTitle})\nDemandeur: ${inquiryName}\nOrganisation: ${inquiryOrg} (${inquiryRole})\nMessage: ${inquiryMessage}`
    );
    window.open(`${FOUNDER_INFO.whatsappUrl}?text=${encodedText}`, '_blank');
    setSentSuccess(true);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-14 space-y-12">
      {/* HEADER CARD */}
      <div className="bg-[#090E1B] rounded-2xl border border-amber-500/40 p-6 sm:p-10 shadow-2xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          <div className="space-y-4">
            <div className="w-56 h-56 mx-auto rounded-2xl overflow-hidden border-2 border-amber-500/60 shadow-xl bg-black relative group">
              <img
                src={founderPhoto}
                alt={`${FOUNDER_INFO.name} - ${FOUNDER_INFO.officialTitle}`}
                className="w-full h-full object-cover object-[50%_20%] transition-transform duration-300 group-hover:scale-105"
                onError={(e) => {
                  const target = e.currentTarget;
                  if (target.src !== ASSETS.founder) {
                    target.src = ASSETS.founder;
                  }
                }}
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Photo Management Actions */}
            <div className="flex flex-col items-center gap-2">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handlePhotoUpload}
                accept="image/*"
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/20 transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
              >
                <span>📷</span>
                <span>{t('founder.changePhoto', 'Mettre à jour la photo')}</span>
              </button>

              {typeof window !== 'undefined' && localStorage.getItem('atf_founder_custom_photo') && (
                <button
                  type="button"
                  onClick={handleResetPhoto}
                  className="text-[10px] text-gray-500 hover:text-gray-300 font-mono underline cursor-pointer"
                >
                  {t('common.cancel', 'Réinitialiser la photo')}
                </button>
              )}

              {photoFeedback && (
                <span className="text-[11px] text-emerald-400 font-mono animate-pulse">
                  ✓ {photoFeedback}
                </span>
              )}
            </div>

            {/* Guide direct pour le fondateur */}
            <div className="p-3 rounded-xl bg-[#050810] border border-amber-500/25 text-[11px] text-gray-400 space-y-1.5 text-left">
              <div className="font-bold text-amber-400 font-mono text-[10px] uppercase flex items-center gap-1">
                <span>🛡️</span>
                <span>Photo Officielle Certifiée</span>
              </div>
              <p className="text-[11px] text-gray-300 leading-snug">
                Vous pouvez sélectionner votre fichier <strong className="text-amber-300">founder_africa_talent (11).jpg</strong> en cliquant sur le bouton ci-dessus pour l'appliquer immédiatement sur l'ensemble de la plateforme.
              </p>
            </div>

            <div className="text-center space-y-1">
              <span className="text-xs font-mono font-bold text-amber-400">{t('founder.location', 'Abidjan, Côte d\'Ivoire')}</span>
              <p className="text-[11px] text-gray-400">{t('founder.networkSubtitle', 'Réseau Détection & Scouting International')}</p>
            </div>
          </div>

          <div className="md:col-span-2 space-y-4">
            <div className="inline-block text-xs font-mono font-bold uppercase tracking-widest text-amber-400 bg-amber-500/10 border border-amber-500/30 px-3.5 py-1 rounded">
              {t('founder.badge', 'Direction Technique & Fondateur')}
            </div>

            <h1 className="text-3xl sm:text-4xl font-black text-white">
              {FOUNDER_INFO.name}
            </h1>

            <div className="text-base font-bold text-amber-400 font-mono">
              {t('founder.officialTitle', FOUNDER_INFO.officialTitle)}
            </div>

            <p className="text-sm text-gray-300 leading-relaxed">
              {t('founder.bioLead', 'Scout Agent de premier plan et bâtisseur de passerelles d\'élite entre le vivier du football africain et les scènes professionnelles internationales. À l\'origine de la création de la plateforme Africa Talent Football, conçue pour certifier les performances athlétiques réelles, archiver des vidéos de match incontestables et établir des estimations de valeur marchande justes et transparentes.')}
            </p>

            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 rounded bg-[#050810] border border-white/10">
                <span className="text-gray-500 block text-[10px] uppercase font-bold">{t('home.whatsappDesk', 'WhatsApp Direct & Bureau')}</span>
                <a href={FOUNDER_INFO.whatsappUrl} target="_blank" rel="noopener noreferrer" className="text-amber-400 font-mono font-bold hover:underline">
                  {FOUNDER_INFO.phone}
                </a>
              </div>
              <div className="p-3.5 rounded bg-[#050810] border border-white/10">
                <span className="text-gray-500 block text-[10px] uppercase font-bold">{t('home.officialEmail', 'Courriel Officiel')}</span>
                <a href={`mailto:${FOUNDER_INFO.email}`} className="text-white font-mono hover:text-amber-400">
                  {FOUNDER_INFO.email}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* PILLARS & CHARTER */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="p-8 rounded-2xl bg-[#090E1B] border border-white/10 space-y-4">
          <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
            {t('founder.visionTag', 'La Vision Africa Talent Football')}
          </span>
          <h2 className="text-xl font-black text-white">
            {t('founder.visionTitle', 'Un Corridor Éthique, Structuré & Sans Intermédiaires Opaques')}
          </h2>
          <p className="text-xs text-gray-300 leading-relaxed">
            {t('founder.visionDesc', 'La mission portée par Seydou Mario TRAORÉ consiste à remplacer le flou artistique des détections sauvages par un protocole technique rigoureux aux standards européens :')}
          </p>
          <ul className="space-y-2.5 text-xs text-gray-300 pt-2">
            <li className="flex items-start gap-2">
              <span className="text-amber-400 font-bold">✓</span>
              <span>{t('founder.pillar1', 'Audit Physique & Vitesse : Données précises (vitesse de pointe en km/h, volume aérobie, détente verticale).')}</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-amber-400 font-bold">✓</span>
              <span>{t('founder.pillar2', 'Vidéos de Matches Complets : Élimination des montages trompeurs au profit de séquences contextualisées de 90 minutes.')}</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-amber-400 font-bold">✓</span>
              <span>{t('founder.pillar3', 'Indice de Valeur Marchande : Modèle économique d\'estimation protégeant à la fois les clubs acquéreurs et les académies formatrices.')}</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-amber-400 font-bold">✓</span>
              <span>{t('founder.pillar4', 'Respect Strict FIFA Art. 19 : Protection totale des mineurs et accord préalable des tuteurs légaux.')}</span>
            </li>
          </ul>
        </div>

        <div className="p-8 rounded-2xl bg-[#090E1B] border border-white/10 space-y-4">
          <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
            {t('founder.coverageTag', 'Réseau de Détection sur le Terrain')}
          </span>
          <h2 className="text-xl font-black text-white">
            {t('founder.coverageTitle', 'Couverture Opérationnelle Ouest-Africaine')}
          </h2>
          <p className="text-xs text-gray-300 leading-relaxed">
            {t('founder.coverageDesc', 'Sous l\'égide de Seydou Mario TRAORÉ, Africa Talent Football supervise des missions régulières dans les principaux viviers de formation du continent :')}
          </p>
          <div className="grid grid-cols-2 gap-3 pt-2 text-xs">
            <div className="p-3.5 rounded bg-[#050810] border border-white/10">
              <span className="text-white font-bold block">🇨🇮 Côte d'Ivoire</span>
              <span className="text-gray-400 text-[11px]">Abidjan, San Pedro, Bouaké, Yamoussoukro</span>
            </div>
            <div className="p-3.5 rounded bg-[#050810] border border-white/10">
              <span className="text-white font-bold block">🇲🇱 Mali</span>
              <span className="text-gray-400 text-[11px]">Bamako, Sikasso, Mopti</span>
            </div>
            <div className="p-3.5 rounded bg-[#050810] border border-white/10">
              <span className="text-white font-bold block">🇸🇳 Sénégal</span>
              <span className="text-gray-400 text-[11px]">Dakar, Mbour, Saint-Louis</span>
            </div>
            <div className="p-3.5 rounded bg-[#050810] border border-white/10">
              <span className="text-white font-bold block">🇧🇫 Burkina Faso</span>
              <span className="text-gray-400 text-[11px]">Ouagadougou, Bobo-Dioulasso</span>
            </div>
          </div>
        </div>
      </div>

      {/* DIRECT INQUIRY DESK */}
      <div className="bg-[#050810] rounded-2xl border border-amber-500/40 p-6 sm:p-8 space-y-6">
        <div>
          <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
            {t('founder.inquiryTag', 'Sollicitation Institutionnelle & Clubs')}
          </span>
          <h2 className="text-2xl font-black text-white mt-1">
            {t('founder.inquiryTitle', 'Contacter le Desk de Seydou Mario TRAORÉ')}
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            {t('founder.inquiryDesc', 'Pour les cellules de recrutement professionnelles, directeurs sportifs ou académies souhaitant organiser un essai ou obtenir l\'accès aux vidéos complètes des joueurs.')}
          </p>
        </div>

        {sentSuccess ? (
          <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-600 text-emerald-300 text-xs">
            {t('founder.inquirySuccess', 'Votre demande a été acheminée avec succès vers le desk direct de Seydou Mario TRAORÉ. Une réponse vous parviendra sous 24h.')}
          </div>
        ) : (
          <form onSubmit={handleSubmitInquiry} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-[11px] font-bold text-gray-400 mb-1">
                  {t('founder.formName', 'Votre Nom & Prénom')}
                </label>
                <input
                  type="text"
                  required
                  value={inquiryName}
                  onChange={(e) => setInquiryName(e.target.value)}
                  placeholder="ex: Philippe Laurent"
                  className="w-full px-3 py-2.5 rounded bg-[#090E1B] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-gray-400 mb-1">
                  {t('founder.formOrg', 'Club / Agence / Média')}
                </label>
                <input
                  type="text"
                  required
                  value={inquiryOrg}
                  onChange={(e) => setInquiryOrg(e.target.value)}
                  placeholder="ex: RSC Anderlecht"
                  className="w-full px-3 py-2.5 rounded bg-[#090E1B] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-gray-400 mb-1">
                  {t('founder.formRole', 'Fonction')}
                </label>
                <select
                  value={inquiryRole}
                  onChange={(e) => setInquiryRole(e.target.value)}
                  className="w-full px-3 py-2.5 rounded bg-[#090E1B] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                >
                  <option value="Cellule de Recrutement Pro">Cellule de Recrutement Pro</option>
                  <option value="Directeur Sportif">Directeur Sportif</option>
                  <option value="Scout Mandaté">Scout Mandaté</option>
                  <option value="Académie Formatrice">Académie Formatrice</option>
                  <option value="Autre">Autre</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-400 mb-1">
                {t('founder.formSubject', 'Objet de la demande technique (Profil ciblé, vidéo 90 min, protocole d\'essai...)')}
              </label>
              <textarea
                rows={3}
                required
                value={inquiryMessage}
                onChange={(e) => setInquiryMessage(e.target.value)}
                placeholder="Indiquez les postes recherchés, tranche d'âge ou le nom du joueur ciblé..."
                className="w-full px-3 py-2.5 rounded bg-[#090E1B] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div className="flex gap-4">
              <button
                type="submit"
                className="px-7 py-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-lg shadow-amber-500/20"
              >
                {t('founder.formSubmit', 'Transmettre au Desk de Seydou Mario TRAORÉ via WhatsApp')}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
