import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { usePlayers } from '../../context/PlayerContext';
import { usePayment } from '../../context/PaymentContext';
import { useLanguage } from '../../context/LanguageContext';
import { FOUNDER_INFO, formatMarketValue } from '../../data/demoData';
import { RegisteredPlayer } from '../../types/database';

export type DashboardRoleKey =
  | 'CLUB_PRO'
  | 'PLAYER'
  | 'ACADEMY'
  | 'COACH'
  | 'SCOUT'
  | 'SPORTING_DIRECTOR'
  | 'FIFA_AGENT'
  | 'PRESIDENT'
  | 'RECRUITMENT_MANAGER';

interface RoleDefinition {
  key: DashboardRoleKey;
  label: string;
  icon: string;
  badge: string;
  shortDesc: string;
  category: 'Clubs & Dirigeants' | 'Terrain & Technique' | 'Représentation & Talents';
  color: string;
}

export const DASHBOARD_ROLES: RoleDefinition[] = [
  {
    key: 'CLUB_PRO',
    label: 'Clubs Professionnels',
    icon: '🏟️',
    badge: 'Pro Club Hub',
    shortDesc: 'Effectif pro, cibles mercato, gestion des essais et budgets',
    category: 'Clubs & Dirigeants',
    color: 'from-amber-500 to-amber-600',
  },
  {
    key: 'PLAYER',
    label: 'Joueurs & Talents',
    icon: '⚽',
    badge: 'Fiche Athlète',
    shortDesc: 'Vidéos de match, cotes marchandes, radar athlétique & détections',
    category: 'Représentation & Talents',
    color: 'from-emerald-500 to-emerald-600',
  },
  {
    key: 'ACADEMY',
    label: 'Académies de Football',
    icon: '🎓',
    badge: 'Centres de Formation',
    shortDesc: 'Effectifs U15-U21, suivi des anciens pensionnaires & partenariats',
    category: 'Représentation & Talents',
    color: 'from-blue-500 to-blue-600',
  },
  {
    key: 'COACH',
    label: 'Entraîneurs & Staff',
    icon: '📋',
    badge: 'Direction Tactique',
    shortDesc: 'Schémas tactiques, analyse vidéo de match & progression athlétique',
    category: 'Terrain & Technique',
    color: 'from-purple-500 to-purple-600',
  },
  {
    key: 'SCOUT',
    label: 'Scouts & Superviseurs',
    icon: '🔍',
    badge: 'Scouting Terrain',
    shortDesc: 'Rapports certifiés Eyeball, vitesse GPS & missions régionales',
    category: 'Terrain & Technique',
    color: 'from-amber-400 to-orange-500',
  },
  {
    key: 'SPORTING_DIRECTOR',
    label: 'Directeurs Sportifs',
    icon: '👔',
    badge: 'Gestion Sportive',
    shortDesc: 'Matrice de doublure, roadmap contractuelle & balance mercato',
    category: 'Clubs & Dirigeants',
    color: 'from-cyan-500 to-blue-600',
  },
  {
    key: 'FIFA_AGENT',
    label: 'Agents Licenciés FIFA',
    icon: '💼',
    badge: 'Licence FIFA #2024',
    shortDesc: 'Portefeuille de mandats officiels, sollicitations clubs & transferts',
    category: 'Représentation & Talents',
    color: 'from-yellow-400 to-amber-500',
  },
  {
    key: 'PRESIDENT',
    label: 'Présidents de Club',
    icon: '🏛️',
    badge: 'Haute Gouvernance',
    shortDesc: 'Valorisation du club, accords institutionnels & arbitrage financier',
    category: 'Clubs & Dirigeants',
    color: 'from-red-500 to-rose-600',
  },
  {
    key: 'RECRUITMENT_MANAGER',
    label: 'Responsables Recrutement',
    icon: '🎯',
    badge: 'Head of Recruitment',
    shortDesc: 'Pipeline de recrutement Kanban, délégation de missions & validation',
    category: 'Terrain & Technique',
    color: 'from-indigo-500 to-violet-600',
  },
];

interface ProfessionalDashboardsProps {
  initialRole?: DashboardRoleKey;
  onNavigate: (view: string, payload?: any) => void;
  onOpenSharePlatform?: () => void;
  onExportPdf?: (player: RegisteredPlayer) => void;
}

export const ProfessionalDashboards: React.FC<ProfessionalDashboardsProps> = ({
  initialRole = 'CLUB_PRO',
  onNavigate,
  onOpenSharePlatform,
  onExportPdf,
}) => {
  const [activeRole, setActiveRole] = useState<DashboardRoleKey>(initialRole);
  const [pipelineFilter, setPipelineFilter] = useState<'ALL' | 'IDENTIFIED' | 'VIDEO' | 'SCOUTED' | 'TRIAL' | 'OFFER'>('ALL');
  const [actionNotice, setActionNotice] = useState<string | null>(null);
  const [showGlobalPublishModal, setShowGlobalPublishModal] = useState<boolean>(false);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState<boolean>(false);
  const [walletAmount, setWalletAmount] = useState<string>('500000');
  const [withdrawMethod, setWithdrawMethod] = useState<'ORANGE_MONEY' | 'WAVE' | 'MTN' | 'BANK'>('WAVE');
  const [walletBalanceFcfa, setWalletBalanceFcfa] = useState<number>(3450000);

  const { currentUser, logout, getAllRegisteredUsersCount } = useAuth();
  const { players, openVideoModal, totalMarketValue } = usePlayers();
  const { activeSubscription, openCheckout } = usePayment();
  const { t, tRole, tPosition, tFoot, tContract, formatDate, formatCurrency, formatNumber } = useLanguage();

  const registeredUsersCount = getAllRegisteredUsersCount();

  const currentRoleDef = DASHBOARD_ROLES.find((r) => r.key === activeRole) || DASHBOARD_ROLES[0];

  const showFeedback = (msg: string) => {
    setActionNotice(msg);
    setTimeout(() => setActionNotice(null), 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      {/* ACTION NOTICE TOAST */}
      {actionNotice && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#090E1B] border-2 border-amber-400 text-white px-5 py-3 rounded-xl shadow-2xl flex items-center gap-3 text-xs animate-in slide-in-from-bottom duration-200">
          <span className="text-amber-400 text-base">✓</span>
          <span className="font-bold">{actionNotice}</span>
          <button
            onClick={() => setActionNotice(null)}
            className="ml-2 text-gray-400 hover:text-white"
          >
            ✕
          </button>
        </div>
      )}

      {/* TOP HEADER & GLOBAL PUBLISHING ONLINE BANNER */}
      <div className="bg-gradient-to-r from-[#070B16] via-[#0D152A] to-[#070B16] rounded-2xl p-6 sm:p-8 border border-amber-500/30 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-black uppercase tracking-wider">
                Hub Multi-Rôles Professionnel
              </span>
              <span className="px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Plateforme Publiée & En Ligne Mondialement
              </span>
              <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-300 text-[10px] font-mono">
                FIFA / CAF / UEFA Network
              </span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              Tableaux de Bord Football Professionnel
            </h1>

            <p className="text-xs sm:text-sm text-gray-300 max-w-3xl leading-relaxed">
              Espaces de pilotage dédiés et certifiés pour les <strong>Clubs Professionnels</strong>, <strong>Joueurs</strong>, <strong>Académies</strong>, <strong>Entraîneurs</strong>, <strong>Scouts</strong>, <strong>Directeurs Sportifs</strong>, <strong>Agents FIFA</strong>, <strong>Présidents de Club</strong> et <strong>Responsables du Recrutement</strong>.
              Supervision technique directe : <strong>{FOUNDER_INFO.name}</strong>, {FOUNDER_INFO.officialTitle}.
            </p>
          </div>

          {/* Quick Hub Actions */}
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={() => setShowGlobalPublishModal(true)}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-emerald-500/20 flex items-center gap-2 cursor-pointer border border-emerald-300 active:scale-95"
            >
              <span>🌍</span>
              <span>Statut Mondial & Diffusion</span>
            </button>

            {onOpenSharePlatform && (
              <button
                onClick={onOpenSharePlatform}
                className="px-3.5 py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-sm"
              >
                <span>🔗</span>
                <span>Partager l'Accès</span>
              </button>
            )}

            {activeSubscription?.status === 'ACTIVE' ? (
              <span className="px-3 py-2 rounded-xl bg-amber-500/10 border border-amber-400 text-amber-300 text-xs font-mono font-bold flex items-center gap-1.5">
                <span>👑</span>
                <span>{activeSubscription.tier}</span>
              </span>
            ) : (
              <button
                onClick={() => onNavigate('pricing')}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/20 cursor-pointer border border-amber-300"
              >
                ★ Passer Premium
              </button>
            )}
          </div>
        </div>

        {/* WORLD VISIBILITY TICKER */}
        <div className="mt-6 pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-[11px] font-mono text-gray-400">
          <div className="flex items-center gap-2">
            <span className="text-amber-400 font-bold">Couverture Mondiale :</span>
            <span>Afrique (54 Fédérations CAF) · Europe (55 Associations UEFA) · Amériques (CONMEBOL/CONCACAF) · Asie (AFC)</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-gray-300">
              Cote Marchande Totale Référencée : <strong className="text-emerald-400">{formatMarketValue(totalMarketValue)}</strong>
            </span>
            <span className="text-gray-300">
              Profils Actifs : <strong className="text-amber-400">{players.length} Talents</strong>
            </span>
          </div>
        </div>
      </div>

      {/* EXECUTIVE PLATFORM METRICS & FINANCIAL WALLET OVERVIEW (DEMANDE UTILISATEUR) */}
      <div className="bg-[#080D1A] rounded-2xl border-2 border-amber-500/40 p-5 sm:p-6 shadow-2xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400">
                Audience Mondiale & Métriques Opérationnelles en Temps Réel
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Performances Plateforme & Portefeuille Financier
            </h2>
            <p className="text-xs text-gray-300">
              Supervision consolidée du trafic, de la communauté inscrite et du solde certifié Africa Talent Football.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsWalletModalOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-emerald-500/20 flex items-center gap-2 cursor-pointer border border-emerald-300 active:scale-95"
            >
              <span>💳</span>
              <span>Gérer mon Solde</span>
            </button>
            <button
              onClick={() => showFeedback('Statistiques actualisées en direct depuis les serveurs Edge ATF.')}
              className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-colors cursor-pointer"
              title="Actualiser les compteurs"
            >
              🔄
            </button>
          </div>
        </div>

        {/* 5 KEY METRIC TILES */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3.5">
          {/* 1. Nombres de vues de la plateforme */}
          <div className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-1.5 hover:border-amber-400/50 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase text-gray-400 font-bold">Vues Plateforme</span>
              <span className="text-xs">👁️</span>
            </div>
            <div className="text-2xl font-black text-white font-mono tracking-tight">
              284 920
            </div>
            <div className="flex items-center gap-1.5 text-[10px] text-emerald-400 font-mono">
              <span>↑ +14.2%</span>
              <span className="text-gray-400">ce mois-ci</span>
            </div>
          </div>

          {/* 2. Nombres de personnes inscrites */}
          <div className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-1.5 hover:border-amber-400/50 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase text-gray-400 font-bold">Inscrits Certifiés</span>
              <span className="text-xs">👥</span>
            </div>
            <div className="text-2xl font-black text-amber-400 font-mono tracking-tight">
              {registeredUsersCount + 420}
            </div>
            <div className="flex items-center gap-1.5 text-[10px] text-amber-300 font-mono">
              <span>● Registre actif</span>
              <span className="text-gray-400">({registeredUsersCount} locaux)</span>
            </div>
          </div>

          {/* 3. Statistiques de visionnage & fiches */}
          <div className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-1.5 hover:border-amber-400/50 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase text-gray-400 font-bold">Statistiques Clés</span>
              <span className="text-xs">📊</span>
            </div>
            <div className="text-2xl font-black text-blue-400 font-mono tracking-tight">
              8 940
            </div>
            <div className="flex items-center gap-1.5 text-[10px] text-gray-400 font-mono">
              <span className="text-white font-bold">{players.length}</span>
              <span>talents · 1 420 PDF</span>
            </div>
          </div>

          {/* 4. Nombres d'abonnés */}
          <div className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-1.5 hover:border-amber-400/50 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase text-gray-400 font-bold">Abonnés Réseau</span>
              <span className="text-xs">🔔</span>
            </div>
            <div className="text-2xl font-black text-purple-300 font-mono tracking-tight">
              2 340
            </div>
            <div className="flex items-center gap-1.5 text-[10px] text-purple-300 font-mono">
              <span>★ Abonnés B2B</span>
              <span className="text-gray-400">veille mercato</span>
            </div>
          </div>

          {/* 5. Solde financier du compte */}
          <div className="p-4 rounded-xl bg-gradient-to-b from-[#092218] to-[#05140F] border border-emerald-500/50 space-y-1.5 hover:border-emerald-400 transition-colors col-span-2 md:col-span-1">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase text-emerald-300 font-bold">Solde Disponible</span>
              <span className="text-xs">💰</span>
            </div>
            <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono tracking-tight">
              {walletBalanceFcfa.toLocaleString('fr-FR')} <span className="text-xs font-normal">FCFA</span>
            </div>
            <div className="flex items-center justify-between text-[10px] text-gray-300 font-mono">
              <span>≈ {(walletBalanceFcfa / 655.957).toFixed(0)} €</span>
              <button
                onClick={() => setIsWalletModalOpen(true)}
                className="text-emerald-400 hover:underline font-bold"
              >
                Retirer ➔
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* WALLET / SOLDE WITHDRAWAL & RECHARGE MODAL */}
      {isWalletModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg bg-[#09101E] rounded-3xl border-2 border-emerald-500/50 shadow-2xl p-6 sm:p-7 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-2xl">
                  💰
                </div>
                <div>
                  <h3 className="text-lg font-black text-white">Portefeuille & Solde ATF</h3>
                  <p className="text-xs text-gray-400 font-mono">Retraits Mobile Money & Virements Bancaires</p>
                </div>
              </div>
              <button
                onClick={() => setIsWalletModalOpen(false)}
                className="text-gray-400 hover:text-white p-1 rounded-lg text-lg"
              >
                ✕
              </button>
            </div>

            {/* Balance Card */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-[#061A12] via-[#092B1F] to-[#061A12] border border-emerald-500/60 space-y-2">
              <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-emerald-300">
                Solde Net Disponible
              </span>
              <div className="text-3xl font-black text-white font-mono">
                {walletBalanceFcfa.toLocaleString('fr-FR')} FCFA
                <span className="block text-xs text-emerald-400 font-normal font-sans mt-0.5">
                  Équivalent : {(walletBalanceFcfa / 655.957).toFixed(2)} EUR (Compte Professionnel Vérifié)
                </span>
              </div>
            </div>

            {/* Withdrawal form */}
            <div className="space-y-4 text-xs">
              <label className="block text-gray-300 font-bold uppercase font-mono text-[11px]">
                Mode de Retrait Immédiat :
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'WAVE', label: 'Wave', icon: '🌊' },
                  { id: 'ORANGE_MONEY', label: 'Orange Money', icon: '🟠' },
                  { id: 'MTN', label: 'MTN MoMo', icon: '🟡' },
                  { id: 'BANK', label: 'Virement', icon: '🏦' }
                ].map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setWithdrawMethod(m.id as any)}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer font-bold ${
                      withdrawMethod === m.id
                        ? 'bg-emerald-500/20 border-emerald-400 text-white shadow-md'
                        : 'bg-[#050810] border-white/10 text-gray-400 hover:text-white'
                    }`}
                  >
                    <div className="text-base mb-1">{m.icon}</div>
                    <div className="text-[11px]">{m.label}</div>
                  </button>
                ))}
              </div>

              <div>
                <label className="block text-gray-300 font-bold uppercase font-mono text-[11px] mb-1.5">
                  Montant à Retirer (FCFA) :
                </label>
                <input
                  type="number"
                  value={walletAmount}
                  onChange={(e) => setWalletAmount(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#050810] border border-white/10 text-white font-mono text-sm focus:border-emerald-400 focus:outline-none"
                  placeholder="500000"
                />
              </div>

              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-[11px] space-y-1">
                <span className="font-bold flex items-center gap-1.5">
                  <span>ℹ️</span>
                  <span>Garantie de Sécurité Financière ATF :</span>
                </span>
                <p className="text-gray-300 leading-relaxed">
                  Les retraits Mobile Money en Côte d'Ivoire et Afrique de l'Ouest sont traités en moins de 15 minutes. Tout ordre est sécurisé par le protocole de paiement de Seydou Mario TRAORÉ.
                </p>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  const val = parseInt(walletAmount, 10) || 0;
                  if (val > 0 && val <= walletBalanceFcfa) {
                    setWalletBalanceFcfa((prev) => prev - val);
                    setIsWalletModalOpen(false);
                    showFeedback(`Demande de retrait de ${val.toLocaleString('fr-FR')} FCFA via ${withdrawMethod} transmise avec succès.`);
                  } else {
                    alert('Montant invalide ou solde insuffisant.');
                  }
                }}
                className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-emerald-500/20 cursor-pointer"
              >
                Confirmer le Retrait ➔
              </button>
              <button
                type="button"
                onClick={() => setIsWalletModalOpen(false)}
                className="px-5 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase transition-colors cursor-pointer"
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ROLE SWITCHER TABS - 9 STAKEHOLDER CATEGORIES */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
            {t('dashboard.selectRole', 'Sélectionnez votre Métier / Tableau de Bord Dédié :')}
          </span>
          <span className="text-[11px] text-gray-400 font-mono hidden sm:inline">
            ATF Pro Stakeholders
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-9 gap-2">
          {DASHBOARD_ROLES.map((role) => {
            const isSelected = activeRole === role.key;
            return (
              <button
                key={role.key}
                onClick={() => {
                  setActiveRole(role.key);
                  showFeedback(`${tRole(role.key) || role.label}`);
                }}
                className={`p-3 rounded-xl text-left transition-all duration-200 cursor-pointer flex flex-col justify-between border relative overflow-hidden group ${
                  isSelected
                    ? 'bg-[#0E1527] border-amber-400 shadow-xl shadow-amber-500/10 ring-2 ring-amber-400/30'
                    : 'bg-[#080D1A] border-white/10 hover:border-amber-500/40 hover:bg-[#0C1222]'
                }`}
              >
                {isSelected && (
                  <div className="absolute top-0 right-0 w-8 h-8 bg-amber-400/10 rounded-bl-xl flex items-center justify-center">
                    <span className="text-amber-400 text-[10px] font-bold">✓</span>
                  </div>
                )}
                <div>
                  <div className="text-xl mb-1 group-hover:scale-110 transition-transform">
                    {role.icon}
                  </div>
                  <div className={`font-black text-xs leading-tight ${isSelected ? 'text-white' : 'text-gray-200'}`}>
                    {tRole(role.key) || role.label}
                  </div>
                </div>
                <div className="mt-2">
                  <span
                    className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded block truncate ${
                      isSelected
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-white/5 text-gray-400'
                    }`}
                  >
                    {role.badge}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ACTIVE DASHBOARD CONTAINER */}
      <div className="space-y-8">
        {/* ========================================================================= */}
        {/* 1. DASHBOARD: PROFESSIONAL CLUB (CLUBS PROFESSIONNELS) */}
        {/* ========================================================================= */}
        {activeRole === 'CLUB_PRO' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Top Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Budget Mercato Alloué</span>
                <div className="text-2xl font-black text-emerald-400 font-mono">8 500 000 €</div>
                <p className="text-[11px] text-gray-400">Capacité d'investissement 2026</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Effectif Professionnel</span>
                <div className="text-2xl font-black text-white font-mono">26 Joueurs</div>
                <p className="text-[11px] text-gray-400">8 Internationaux · 2 Places Extra-UE</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Cibles Détectées ATF</span>
                <div className="text-2xl font-black text-amber-400 font-mono">14 Talents</div>
                <p className="text-[11px] text-gray-400">Profils supervisés par Mario TRAORÉ</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Essais & Showcases</span>
                <div className="text-2xl font-black text-cyan-400 font-mono">3 Convocations</div>
                <p className="text-[11px] text-gray-400">Visas sportifs & tests médicaux validés</p>
              </div>
            </div>

            {/* Club Recruitment Priorities & Squad Depth Needs */}
            <div className="p-6 rounded-2xl bg-[#080D1A] border border-white/10 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-black text-white uppercase font-mono">
                    Postes Prioritaires en Recherche Active (Mercato)
                  </h3>
                  <p className="text-xs text-gray-400">
                    Besoins transmis à la direction technique Africa Talent Football pour sélection immédiate.
                  </p>
                </div>
                <button
                  onClick={() => {
                    const win = window.open(
                      `${FOUNDER_INFO.whatsappUrl}?text=Bonjour%20Seydou%20Mario%20TRAOR%C3%89%2C%20notre%20club%20professionnel%20souhaite%20d%C3%A9finir%20de%20nouveaux%20crit%C3%A8res%20de%20recrutement%20prioritaires%20sur%20Africa%20Talent%20Football.`,
                      '_blank'
                    );
                    if (!win) showFeedback('Ouverture WhatsApp impossible.');
                  }}
                  className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  + Transmettre un Besoin au Desk
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                <div className="p-4 rounded-xl bg-[#050810] border border-amber-500/30 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-xs font-mono font-bold">Priorité 1</span>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold">Budget : 1.2M€</span>
                  </div>
                  <h4 className="font-black text-white text-sm">Ailier Droit Percutant (Pied Gauche)</h4>
                  <p className="text-xs text-gray-400">Vitesse flashée &gt; 33.5 km/h, gros volume de un-contre-un, U21.</p>
                  <div className="pt-2">
                    <button
                      onClick={() => onNavigate('search')}
                      className="text-xs text-amber-400 hover:underline font-bold"
                    >
                      Explorer les correspondances ATF →
                    </button>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#050810] border border-blue-500/30 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 text-xs font-mono font-bold">Priorité 2</span>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold">Budget : 800K€</span>
                  </div>
                  <h4 className="font-black text-white text-sm">Milieu Box-to-Box Athlétique (N°8)</h4>
                  <p className="text-xs text-gray-400">Capacité de récupération, impact physique, transition rapide.</p>
                  <div className="pt-2">
                    <button
                      onClick={() => onNavigate('search')}
                      className="text-xs text-blue-400 hover:underline font-bold"
                    >
                      Explorer les correspondances ATF →
                    </button>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#050810] border border-purple-500/30 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 text-xs font-mono font-bold">Priorité 3</span>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold">Budget : 500K€</span>
                  </div>
                  <h4 className="font-black text-white text-sm">Latéral Gauche Moderne (U19)</h4>
                  <p className="text-xs text-gray-400">Centre précis, endurance aérobie élevée, éligible contrat aspirant.</p>
                  <div className="pt-2">
                    <button
                      onClick={() => onNavigate('search')}
                      className="text-xs text-purple-400 hover:underline font-bold"
                    >
                      Explorer les correspondances ATF →
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Targeted Players Watchlist */}
            <div className="p-6 rounded-2xl bg-[#080D1A] border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-white uppercase font-mono">
                  Sélection Recommandée par Mario TRAORÉ pour Clubs Professionnels
                </h3>
                <button
                  onClick={() => onNavigate('players')}
                  className="text-xs text-amber-400 hover:underline font-bold"
                >
                  Voir toute la base talents →
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {players.slice(0, 3).map((p) => (
                  <div key={p.id} className="p-4 rounded-xl bg-[#050810] border border-white/10 flex flex-col justify-between space-y-3 hover:border-amber-500/50 transition-colors">
                    <div className="flex items-center gap-3">
                      <img src={p.avatarUrl} alt={p.firstName} className="w-14 h-14 rounded-lg object-cover" />
                      <div>
                        <div className="font-black text-white text-sm">{p.firstName} {p.lastName}</div>
                        <div className="text-xs text-gray-400 font-mono">{p.primaryPosition} · {p.calculatedAge} ans · {p.nationality}</div>
                        <div className="text-xs font-mono text-emerald-400 font-bold">{p.marketValueDisplay}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-2 border-t border-white/10">
                      <button
                        onClick={() => openVideoModal(p)}
                        className="flex-1 py-1.5 rounded bg-[#0E1527] hover:bg-amber-500/20 text-amber-300 text-xs font-bold transition-colors cursor-pointer border border-amber-500/30"
                      >
                        ▶ Vidéo Eyeball
                      </button>
                      <button
                        onClick={() => onNavigate('player-detail', p)}
                        className="flex-1 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-black text-xs font-black transition-colors cursor-pointer"
                      >
                        Dossier Club
                      </button>
                      {onExportPdf && (
                        <button
                          onClick={() => onExportPdf(p)}
                          className="py-1.5 px-2 rounded bg-amber-500/20 hover:bg-amber-500 hover:text-black text-amber-300 text-xs font-bold transition-colors cursor-pointer"
                          title="Exporter en PDF"
                        >
                          📄 PDF
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 2. DASHBOARD: PLAYER & TALENT (JOUEURS & ATHLÈTES) */}
        {/* ========================================================================= */}
        {activeRole === 'PLAYER' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Player Profile Hero */}
            <div className="p-6 rounded-2xl bg-gradient-to-r from-[#0B1224] to-[#060A14] border border-emerald-500/40 shadow-xl grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
              <div className="flex items-center gap-4">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80"
                  alt="Amadou Diallo"
                  className="w-24 h-24 rounded-2xl object-cover border-2 border-emerald-400 shadow-lg"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold">
                      PROFIL JOUEUR CERTIFIÉ
                    </span>
                    <span className="text-emerald-400">✓</span>
                  </div>
                  <h2 className="text-xl font-black text-white mt-1">Amadou Diallo</h2>
                  <p className="text-xs text-gray-400">Ailier Droit (BU / AD) · 18 Ans · Côte d'Ivoire</p>
                  <p className="text-xs font-mono text-gray-400 mt-1">FIFA ID : <span className="text-amber-400">ATF-CI-2026-0941</span></p>
                </div>
              </div>

              <div className="space-y-2 p-4 rounded-xl bg-[#050810] border border-white/10 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-gray-400">Cote Marchande ATF :</span>
                  <span className="text-emerald-400 font-bold text-sm">280 000 € (↗ +25%)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Vitesse Flashée :</span>
                  <span className="text-white font-bold">34.2 km/h</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Club / Académie :</span>
                  <span className="text-amber-400 font-bold">Académie Mimosas Abidjan</span>
                </div>
              </div>

              <div className="space-y-2 flex flex-col justify-center">
                <button
                  onClick={() => {
                    const win = window.open(
                      `${FOUNDER_INFO.whatsappUrl}?text=Bonjour%20Seydou%20Mario%20TRAOR%C3%89%2C%20je%20souhaite%20mettre%20%C3%A0%20jour%20ma%20vid%C3%A9o%20de%20match%20ou%20demander%20une%20certification%20sur%20mon%20profil%20de%20joueur.`,
                      '_blank'
                    );
                    if (!win) showFeedback('Liaison ouverte.');
                  }}
                  className="w-full py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                >
                  Mettre à Jour mes Vidéos / Stats
                </button>
                <button
                  onClick={() => onNavigate('opportunities')}
                  className="w-full py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                >
                  Voir les Détections & Showcases
                </button>
                {onExportPdf && (
                  <button
                    onClick={() => {
                      const dialloPlayer = players.find(p => p.lastName.toLowerCase().includes('diallo')) || players[0];
                      if (dialloPlayer) onExportPdf(dialloPlayer);
                    }}
                    className="w-full py-2.5 rounded-lg bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/20 active:scale-95 cursor-pointer flex items-center justify-center gap-2 border border-amber-200"
                  >
                    <span>📄</span>
                    <span>Exporter ma Fiche en PDF (Certifiée)</span>
                  </button>
                )}
              </div>
            </div>

            {/* Scout Views & Match Clips */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-6 rounded-2xl bg-[#080D1A] border border-white/10 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black text-white uppercase font-mono">
                    Clubs & Scouts Ayant Consulté ce Profil (30 Derniers Jours)
                  </h3>
                  <span className="text-xs font-mono text-emerald-400 font-bold">37 Vues</span>
                </div>

                <div className="space-y-2.5">
                  {[
                    { club: 'Standard de Liège (Belgique)', time: 'Il y a 2 heures', type: 'Visionnage Vidéo 90 Min', flag: '🇧🇪' },
                    { club: 'RC Lens (Ligue 1 - France)', time: 'Hier à 16:30', type: 'Téléchargement Fiche Athlétique', flag: '🇫🇷' },
                    { club: 'Sporting CP (Portugal)', time: 'Il y a 3 jours', type: 'Consultation Radar GPS', flag: '🇵🇹' },
                    { club: 'Brighton & Hove Albion (Angleterre)', time: 'Il y a 5 jours', type: 'Demande Info Desk Mario TRAORÉ', flag: '🇬🇧' },
                  ].map((item, idx) => (
                    <div key={idx} className="p-3 rounded-xl bg-[#050810] border border-white/5 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span>{item.flag}</span>
                        <div>
                          <div className="font-bold text-white">{item.club}</div>
                          <div className="text-[10px] text-gray-400">{item.type}</div>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono text-gray-500">{item.time}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-6 rounded-2xl bg-[#080D1A] border border-white/10 space-y-4">
                <h3 className="text-sm font-black text-white uppercase font-mono">
                  Évaluation Athlétique & Technique (Seydou Mario TRAORÉ)
                </h3>
                <div className="space-y-2 text-xs">
                  {[
                    { metric: 'Vitesse & Accélération (Pace)', score: 91 },
                    { metric: 'Dribbles & Percussion (Dribble)', score: 86 },
                    { metric: 'Finition & Frappe (Shooting)', score: 82 },
                    { metric: 'Précision de Passe (Passing)', score: 79 },
                    { metric: 'Endurance & Volume de Jeu (Stamina)', score: 88 },
                    { metric: 'Impact & Puissance (Physicality)', score: 84 },
                  ].map((m, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between font-mono">
                        <span className="text-gray-300">{m.metric}</span>
                        <span className="text-amber-400 font-bold">{m.score}/100</span>
                      </div>
                      <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-gradient-to-r from-amber-500 to-emerald-400 h-full rounded-full" style={{ width: `${m.score}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 3. DASHBOARD: FOOTBALL ACADEMY (ACADÉMIES DE FOOTBALL) */}
        {/* ========================================================================= */}
        {activeRole === 'ACADEMY' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Academy KPI Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Effectif Pensionnaires</span>
                <div className="text-2xl font-black text-blue-400 font-mono">56 Joueurs</div>
                <p className="text-[11px] text-gray-400">U15 (18) · U17 (22) · U19 (16)</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Alumni & Pro en Europe</span>
                <div className="text-2xl font-black text-emerald-400 font-mono">12 Joueurs</div>
                <p className="text-[11px] text-gray-400">Belgique, France, Suisse, Portugal</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Indemnités FIFA Solidarité</span>
                <div className="text-2xl font-black text-amber-400 font-mono">420 000 €</div>
                <p className="text-[11px] text-gray-400">Passeport électronique généré</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Showcases Programmés</span>
                <div className="text-2xl font-black text-purple-400 font-mono">3 Tournois</div>
                <p className="text-[11px] text-gray-400">Supervision directe Seydou Mario TRAORÉ</p>
              </div>
            </div>

            {/* Academy Actions & Roster Registry */}
            <div className="p-6 rounded-2xl bg-[#080D1A] border border-white/10 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-black text-white uppercase font-mono">
                    Registre des Talents de l'Académie & Passeports FIFA
                  </h3>
                  <p className="text-xs text-gray-400">
                    Certification des conventions de formation, enregistrement des vidéos et protection des indemnités de formation.
                  </p>
                </div>
                <button
                  onClick={() => onNavigate('register')}
                  className="px-4 py-2 rounded-lg bg-blue-500 hover:bg-blue-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  + Enregistrer un Nouveau Pensionnaire
                </button>
              </div>

              {/* Roster table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-sans">
                  <thead>
                    <tr className="border-b border-white/10 text-gray-400 font-mono uppercase text-[10px]">
                      <th className="pb-3">Talent</th>
                      <th className="pb-3">Catégorie</th>
                      <th className="pb-3">Poste</th>
                      <th className="pb-3">Vitesse Max</th>
                      <th className="pb-3">Cote Estimée</th>
                      <th className="pb-3">Statut Convention</th>
                      <th className="pb-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {players.map((p) => (
                      <tr key={p.id} className="hover:bg-white/5 transition-colors">
                        <td className="py-3 font-bold text-white flex items-center gap-2">
                          <img src={p.avatarUrl} alt={p.firstName} className="w-8 h-8 rounded-full object-cover" />
                          <span>{p.firstName} {p.lastName}</span>
                        </td>
                        <td className="py-3 font-mono text-gray-300">
                          {p.calculatedAge <= 17 ? 'U17' : p.calculatedAge <= 19 ? 'U19' : 'U21'}
                        </td>
                        <td className="py-3 font-mono text-amber-400 font-bold">{p.primaryPosition}</td>
                        <td className="py-3 font-mono text-emerald-400">{p.stats.topSpeedKmh} km/h</td>
                        <td className="py-3 font-mono font-bold text-white">{p.marketValueDisplay}</td>
                        <td className="py-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                            Convention Enregistrée
                          </span>
                        </td>
                        <td className="py-3 text-right">
                          <button
                            onClick={() => onNavigate('player-detail', p)}
                            className="px-2.5 py-1 rounded bg-white/10 hover:bg-amber-500 hover:text-black font-bold text-[10px] uppercase transition-colors"
                          >
                            Gérer Fiche
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 4. DASHBOARD: HEAD COACH & TECHNICAL STAFF (ENTRAÎNEURS) */}
        {/* ========================================================================= */}
        {activeRole === 'COACH' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Système Tactique Privilégié</span>
                <div className="text-2xl font-black text-purple-400 font-mono">4-3-3 Offensif</div>
                <p className="text-[11px] text-gray-400">Bloc médian haut & contre-pressing</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Séquences Vidéo Analysées</span>
                <div className="text-2xl font-black text-emerald-400 font-mono">42 Clips Eyeball</div>
                <p className="text-[11px] text-gray-400">Transitions, CPA & duels 1v1</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Indice de Progression Athlétique</span>
                <div className="text-2xl font-black text-amber-400 font-mono">+14.2%</div>
                <p className="text-[11px] text-gray-400">Gain moyen VMA et sprints répétés</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Fiches d'Entraînement Validées</span>
                <div className="text-2xl font-black text-cyan-400 font-mono">68 Séances</div>
                <p className="text-[11px] text-gray-400">Méthodologie certifiée ATF</p>
              </div>
            </div>

            {/* Tactical Room */}
            <div className="p-6 rounded-2xl bg-[#080D1A] border border-white/10 space-y-4">
              <h3 className="text-base font-black text-white uppercase font-mono">
                Salle d'Analyse Tactique & Découpage Vidéo
              </h3>
              <p className="text-xs text-gray-400">
                Visualisez les matchs complets 90 minutes pour analyser l'occupation des couloirs, le replacement défensif et la vitesse de transition.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                {players.slice(0, 3).map((p) => (
                  <div key={p.id} className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-3">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-mono text-amber-400 font-bold">{p.primaryPosition}</span>
                      <span className="text-[10px] font-mono text-emerald-400">{p.stats.topSpeedKmh} km/h max</span>
                    </div>
                    <div className="font-bold text-white text-sm">{p.firstName} {p.lastName}</div>
                    <p className="text-xs text-gray-400 line-clamp-2">{p.bio}</p>
                    <button
                      onClick={() => openVideoModal(p)}
                      className="w-full py-2 rounded bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 text-xs font-bold transition-colors cursor-pointer"
                    >
                      ▶ Lancer Découpage Vidéo
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 5. DASHBOARD: SCOUT (SCOUTS & SUPERVISEURS TERRAIN) */}
        {/* ========================================================================= */}
        {activeRole === 'SCOUT' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Rapports d'Audit Certifiés</span>
                <div className="text-2xl font-black text-amber-400 font-mono">89 Fiches</div>
                <p className="text-[11px] text-gray-400">Validées sous Seydou Mario TRAORÉ</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Shortlist Prioritaire</span>
                <div className="text-2xl font-black text-emerald-400 font-mono">14 Joueurs</div>
                <p className="text-[11px] text-gray-400">Grade A (Potentiel Première Ligue)</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Vitesse Moyenne Cibles</span>
                <div className="text-2xl font-black text-white font-mono">33.8 km/h</div>
                <p className="text-[11px] text-gray-400">Mesure radar GPS certifiée</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Missions Régionales</span>
                <div className="text-2xl font-black text-cyan-400 font-mono">6 Territoires</div>
                <p className="text-[11px] text-gray-400">Abidjan, Dakar, Bamako, Accra, Douala</p>
              </div>
            </div>

            {/* Field missions & certified scout notes */}
            <div className="p-6 rounded-2xl bg-[#080D1A] border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-white uppercase font-mono">
                  Derniers Rapports d'Observation Eyeball (Mario TRAORÉ)
                </h3>
                <button
                  onClick={() => {
                    const win = window.open(
                      `${FOUNDER_INFO.whatsappUrl}?text=Bonjour%20Seydou%20Mario%20TRAOR%C3%89%2C%20je%20souhaite%20obtenir%20le%20rapport%20d%27audit%20complet%20au%20format%20PDF%20pour%20les%20derniers%20joueurs%20scout%C3%A9s.`,
                      '_blank'
                    );
                    if (!win) showFeedback('WhatsApp déclenché.');
                  }}
                  className="px-3.5 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-black text-xs font-black uppercase transition-colors cursor-pointer"
                >
                  Télécharger Rapport PDF Complet
                </button>
              </div>

              <div className="space-y-3">
                {players.slice(0, 3).map((p) => {
                  const report = p.scoutingReports[0];
                  return (
                    <div key={p.id} className="p-4 rounded-xl bg-[#050810] border border-white/5 space-y-2">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">{p.firstName} {p.lastName}</span>
                          <span className="text-xs font-mono text-amber-400">({p.primaryPosition})</span>
                          <span className="text-xs text-gray-500">· {p.academy}</span>
                        </div>
                        <span className="text-xs font-mono text-emerald-400 font-bold">
                          Note Potentiel : {report ? report.potentialRating : 88}/100
                        </span>
                      </div>
                      <p className="text-xs text-gray-300 italic">
                        "{report ? report.summary : 'Joueur à fort potentiel de vitesse et de transition offensive.'}"
                      </p>
                      <div className="flex items-center justify-between pt-2 border-t border-white/5 text-[11px]">
                        <span className="text-gray-400 font-mono">Superviseur : {report ? report.scoutName : FOUNDER_INFO.name}</span>
                        <button
                          onClick={() => onNavigate('player-detail', p)}
                          className="text-amber-400 hover:underline font-bold"
                        >
                          Consulter la fiche complète →
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 6. DASHBOARD: SPORTING DIRECTOR (DIRECTEURS SPORTIFS) */}
        {/* ========================================================================= */}
        {activeRole === 'SPORTING_DIRECTOR' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Valorisation Globale d'Effectif</span>
                <div className="text-2xl font-black text-cyan-400 font-mono">48 500 000 €</div>
                <p className="text-[11px] text-gray-400">26 Joueurs sous contrat pro</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Balance Transferts Nette</span>
                <div className="text-2xl font-black text-emerald-400 font-mono">+6 200 000 €</div>
                <p className="text-[11px] text-gray-400">Plus-values sur reventes réalisées</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Échéances Contrats &lt; 12 Mois</span>
                <div className="text-2xl font-black text-amber-400 font-mono">5 Dossiers</div>
                <p className="text-[11px] text-gray-400">Prolongations ou cessions d'urgence</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Réseau Partenariats Clubs</span>
                <div className="text-2xl font-black text-purple-400 font-mono">8 Accords</div>
                <p className="text-[11px] text-gray-400">Conventions bilatérales actives</p>
              </div>
            </div>

            {/* Depth Chart & Succession Planning */}
            <div className="p-6 rounded-2xl bg-[#080D1A] border border-white/10 space-y-4">
              <h3 className="text-base font-black text-white uppercase font-mono">
                Planification des Doublures & Remplacement Poste par Poste
              </h3>
              <p className="text-xs text-gray-400">
                Assurez la pérennité sportive en identifiant les futurs titulaires dès maintenant via le réseau Africa Talent Football.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white text-xs">Attaque : Avant-Centre Titulaire</span>
                    <span className="text-[10px] font-mono text-amber-400">Contrat fin 2026</span>
                  </div>
                  <div className="p-2.5 rounded bg-white/5 text-xs flex justify-between items-center">
                    <div>
                      <div className="font-semibold text-gray-200">Titulaire Actuel (29 ans)</div>
                      <div className="text-[10px] text-gray-500">Valeur : 4.5M€</div>
                    </div>
                    <span className="text-gray-400 text-xs">Cession préconisée</span>
                  </div>
                  <div className="p-2.5 rounded bg-amber-500/10 border border-amber-500/30 text-xs flex justify-between items-center">
                    <div>
                      <div className="font-bold text-amber-300">Successeur Recommandé ATF (18 ans)</div>
                      <div className="text-[10px] text-gray-400">Amadou Diallo (Cote: 280K€)</div>
                    </div>
                    <button
                      onClick={() => onNavigate('search')}
                      className="px-2 py-1 rounded bg-amber-500 text-black font-black text-[10px] uppercase"
                    >
                      Dossier
                    </button>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white text-xs">Milieu : Récupérateur / Relanceur</span>
                    <span className="text-[10px] font-mono text-emerald-400">Sous contrat 2028</span>
                  </div>
                  <div className="p-2.5 rounded bg-white/5 text-xs flex justify-between items-center">
                    <div>
                      <div className="font-semibold text-gray-200">Titulaire Actuel (24 ans)</div>
                      <div className="text-[10px] text-gray-500">Valeur : 8.0M€</div>
                    </div>
                    <span className="text-emerald-400 text-xs">Courtisé Bundesliga</span>
                  </div>
                  <div className="p-2.5 rounded bg-blue-500/10 border border-blue-500/30 text-xs flex justify-between items-center">
                    <div>
                      <div className="font-bold text-blue-300">Doublure Africaine Recommandée (19 ans)</div>
                      <div className="text-[10px] text-gray-400">Profils ATF U20 certifiés</div>
                    </div>
                    <button
                      onClick={() => onNavigate('players')}
                      className="px-2 py-1 rounded bg-blue-500 text-black font-black text-[10px] uppercase"
                    >
                      Dossier
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 7. DASHBOARD: FIFA LICENSED AGENT (AGENTS FIFA LICENCIÉS) */}
        {/* ========================================================================= */}
        {activeRole === 'FIFA_AGENT' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Mandats Joueurs Actifs</span>
                <div className="text-2xl font-black text-amber-400 font-mono">18 Mandats</div>
                <p className="text-[11px] text-gray-400">Conformes règlement FIFA FFAR</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Licence FIFA Internationale</span>
                <div className="text-2xl font-black text-emerald-400 font-mono">#2024-8842</div>
                <p className="text-[11px] text-gray-400">Vérifiée auprès de Zurich</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Négociations Mercato Ouvertes</span>
                <div className="text-2xl font-black text-white font-mono">6 Dossiers</div>
                <p className="text-[11px] text-gray-400">Clubs européens et moyen-orientaux</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Protection Mineurs (Art. 19)</span>
                <div className="text-2xl font-black text-cyan-400 font-mono">100% Conforme</div>
                <p className="text-[11px] text-gray-400">Encadrement tuteurs légaux validé</p>
              </div>
            </div>

            {/* Agent Mandates Portfolio */}
            <div className="p-6 rounded-2xl bg-[#080D1A] border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-white uppercase font-mono">
                  Portefeuille de Mandats de Joueurs & Demandes de Transfert
                </h3>
                <button
                  onClick={() => {
                    const win = window.open(
                      `${FOUNDER_INFO.whatsappUrl}?text=Bonjour%20Seydou%20Mario%20TRAOR%C3%89%2C%20en%20tant%20qu%27Agent%20FIFA%2C%20je%20souhaite%20proposer%20un%20joueur%20ou%20obtenir%20un%20mandat%20exclusif%20de%20placement%20pour%20le%20march%C3%A9%20europ%C3%A9en.`,
                      '_blank'
                    );
                    if (!win) showFeedback('WhatsApp ouvert.');
                  }}
                  className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  + Proposer un Joueur au Réseau Pro
                </button>
              </div>

              <div className="space-y-3">
                {players.slice(0, 3).map((p) => (
                  <div key={p.id} className="p-4 rounded-xl bg-[#050810] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <img src={p.avatarUrl} alt={p.firstName} className="w-12 h-12 rounded-lg object-cover" />
                      <div>
                        <div className="font-bold text-white text-sm">{p.firstName} {p.lastName}</div>
                        <div className="text-xs text-gray-400 font-mono">{p.primaryPosition} · {p.calculatedAge} ans · {p.academy}</div>
                        <div className="text-xs text-emerald-400 font-mono font-bold">Cote ATF : {p.marketValueDisplay}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openVideoModal(p)}
                        className="px-3 py-1.5 rounded bg-white/10 hover:bg-white/20 text-white font-bold text-xs"
                      >
                        ▶ Vidéo
                      </button>
                      <button
                        onClick={() => {
                          const win = window.open(
                            `${FOUNDER_INFO.whatsappUrl}?text=Demande%20de%20mandat%20exclusif%20pour%20${encodeURIComponent(p.firstName + ' ' + p.lastName)}%20sur%20Africa%20Talent%20Football.`,
                            '_blank'
                          );
                          if (!win) showFeedback('Liaison ouverte.');
                        }}
                        className="px-3 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase"
                      >
                        Émettre Mandat Club
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 8. DASHBOARD: CLUB PRESIDENT (PRÉSIDENTS DE CLUB) */}
        {/* ========================================================================= */}
        {activeRole === 'PRESIDENT' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Valorisation Institutionnelle</span>
                <div className="text-2xl font-black text-red-400 font-mono">35 000 000 €</div>
                <p className="text-[11px] text-gray-400">Actifs club, infrastructures & droits TV</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Ratio Masse Salariale</span>
                <div className="text-2xl font-black text-emerald-400 font-mono">58%</div>
                <p className="text-[11px] text-gray-400">Conformité DNCG / FFP européen</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Arbitrages Mercato en Attente</span>
                <div className="text-2xl font-black text-amber-400 font-mono">3 Validations</div>
                <p className="text-[11px] text-gray-400">Offres de transfert et primes à la signature</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Partenariats Stratégiques</span>
                <div className="text-2xl font-black text-purple-400 font-mono">8 Accords</div>
                <p className="text-[11px] text-gray-400">Clubs satellites et académies partenaires</p>
              </div>
            </div>

            {/* President Governance Cockpit */}
            <div className="p-6 rounded-2xl bg-[#080D1A] border border-white/10 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-black text-white uppercase font-mono">
                    Cockpit de Décision Stratégique & Arbitrage Financier
                  </h3>
                  <p className="text-xs text-gray-400">
                    Validation des conventions de partenariats, validation des transferts majeurs et liaison de gouvernance avec Seydou Mario TRAORÉ.
                  </p>
                </div>
                <button
                  onClick={() => {
                    const win = window.open(
                      `${FOUNDER_INFO.whatsappUrl}?text=Bonjour%20Monsieur%20TRAOR%C3%89%2C%20le%20Pr%C3%A9sident%20du%20club%20souhaite%20un%20entretien%20strat%C3%A9gique%20concernant%20des%20accords%20de%20partenariats%20internationaux%20et%20des%20dossiers%20mercato%20prioritaires.`,
                      '_blank'
                    );
                    if (!win) showFeedback('Liaison ouverte.');
                  }}
                  className="px-4 py-2.5 rounded-lg bg-red-500 hover:bg-red-400 text-white font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Ligne Directe Président (WhatsApp Mario TRAORÉ)
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                <div className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-2">
                  <span className="text-[10px] font-mono text-amber-400 uppercase font-bold">Décision 1 : Transfert Sortant</span>
                  <h4 className="font-bold text-white text-sm">Offre Ferme Reçue de Bundesliga (6.5M€)</h4>
                  <p className="text-xs text-gray-400">Plus-value nette estimée : +4.8M€. Réinvestissement académie prévu : 20%.</p>
                  <div className="pt-2 flex gap-2">
                    <button
                      onClick={() => showFeedback('Validation présidentielle enregistrée.')}
                      className="px-3 py-1 rounded bg-emerald-500 text-black font-black text-xs"
                    >
                      Approuver
                    </button>
                    <button
                      onClick={() => showFeedback('Négociation relancée pour 7.5M€.')}
                      className="px-3 py-1 rounded bg-white/10 text-white font-bold text-xs"
                    >
                      Contre-Offre
                    </button>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-2">
                  <span className="text-[10px] font-mono text-blue-400 uppercase font-bold">Décision 2 : Accord Académie</span>
                  <h4 className="font-bold text-white text-sm">Partenariat Exclusif Académie Mimosas</h4>
                  <p className="text-xs text-gray-400">Droit de premier refus sur les 3 meilleurs talents U19 de chaque promotion.</p>
                  <div className="pt-2 flex gap-2">
                    <button
                      onClick={() => showFeedback('Convention de partenariat signée électroniquement.')}
                      className="px-3 py-1 rounded bg-blue-500 text-black font-black text-xs"
                    >
                      Signer Convention
                    </button>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-2">
                  <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">Décision 3 : Infrastructures</span>
                  <h4 className="font-bold text-white text-sm">Implantation Centre de Détection ATF</h4>
                  <p className="text-xs text-gray-400">Installation de caméras automatiques 4K pour captation vidéo 90 min en continu.</p>
                  <div className="pt-2 flex gap-2">
                    <button
                      onClick={() => showFeedback('Projet d\'infrastructure validé.')}
                      className="px-3 py-1 rounded bg-purple-500 text-black font-black text-xs"
                    >
                      Allouer Budget
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 9. DASHBOARD: HEAD OF RECRUITMENT (RESPONSABLES DU RECRUTEMENT) */}
        {/* ========================================================================= */}
        {activeRole === 'RECRUITMENT_MANAGER' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Pipeline Global Suivi</span>
                <div className="text-2xl font-black text-indigo-400 font-mono">40 Talents</div>
                <p className="text-[11px] text-gray-400">Répartis sur les 5 étapes de recrutement</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Vidéos de Match Traitées</span>
                <div className="text-2xl font-black text-emerald-400 font-mono">115 Matchs</div>
                <p className="text-[11px] text-gray-400">Analysées et annotées par les scouts</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Essais Programmés ce Mois</span>
                <div className="text-2xl font-black text-amber-400 font-mono">4 Invitations</div>
                <p className="text-[11px] text-gray-400">Détections en Europe & en Afrique</p>
              </div>
              <div className="p-5 rounded-2xl bg-[#080D1A] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Budget Détection Dédié</span>
                <div className="text-2xl font-black text-white font-mono">120 000 €</div>
                <p className="text-[11px] text-gray-400">Frais de déplacement et visas sportifs</p>
              </div>
            </div>

            {/* Kanban Recruitment Pipeline Board */}
            <div className="p-6 rounded-2xl bg-[#080D1A] border border-white/10 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-black text-white uppercase font-mono">
                    Pipeline de Recrutement Interactif (Kanban Scouting)
                  </h3>
                  <p className="text-xs text-gray-400">
                    Du repérage initial jusqu'à la signature du contrat professionnel.
                  </p>
                </div>

                {/* Filter buttons */}
                <div className="flex items-center gap-1.5 overflow-x-auto text-[10px] font-mono">
                  {(['ALL', 'IDENTIFIED', 'VIDEO', 'SCOUTED', 'TRIAL', 'OFFER'] as const).map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setPipelineFilter(filter)}
                      className={`px-2.5 py-1 rounded font-bold uppercase transition-colors whitespace-nowrap cursor-pointer ${
                        pipelineFilter === filter
                          ? 'bg-amber-500 text-black'
                          : 'bg-white/5 text-gray-400 hover:text-white'
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </div>
              </div>

              {/* Pipeline Columns */}
              <div className="grid grid-cols-1 md:grid-cols-5 gap-3 pt-2">
                {/* Column 1: Identified */}
                <div className="p-3.5 rounded-xl bg-[#050810] border border-white/10 space-y-2.5">
                  <div className="flex justify-between items-center text-xs border-b border-white/5 pb-2">
                    <span className="font-bold text-gray-300 font-mono uppercase text-[10px]">1. Identifié</span>
                    <span className="px-1.5 py-0.5 rounded bg-white/10 text-gray-400 font-mono text-[10px]">18</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#0E1527] border border-white/5 text-xs space-y-1">
                    <div className="font-bold text-white">Ibrahim Traoré</div>
                    <div className="text-[10px] text-gray-400 font-mono">MOC · 17 ans · Mali</div>
                    <button
                      onClick={() => showFeedback('Fiche transmise en étape 2 : Vidéo.')}
                      className="mt-1 text-[10px] text-amber-400 hover:underline block"
                    >
                      Passer à Vidéo →
                    </button>
                  </div>
                </div>

                {/* Column 2: Video Screened */}
                <div className="p-3.5 rounded-xl bg-[#050810] border border-white/10 space-y-2.5">
                  <div className="flex justify-between items-center text-xs border-b border-white/5 pb-2">
                    <span className="font-bold text-blue-400 font-mono uppercase text-[10px]">2. Vidéo Eyeball</span>
                    <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 font-mono text-[10px]">11</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#0E1527] border border-blue-500/20 text-xs space-y-1">
                    <div className="font-bold text-white">Youssouf Koné</div>
                    <div className="text-[10px] text-gray-400 font-mono">BU · 19 ans · Sénégal</div>
                    <button
                      onClick={() => showFeedback('Supervision terrain commandée pour Youssouf Koné.')}
                      className="mt-1 text-[10px] text-blue-400 hover:underline block"
                    >
                      Commander Audit Terrain →
                    </button>
                  </div>
                </div>

                {/* Column 3: Live Scouted */}
                <div className="p-3.5 rounded-xl bg-[#050810] border border-white/10 space-y-2.5">
                  <div className="flex justify-between items-center text-xs border-b border-white/5 pb-2">
                    <span className="font-bold text-purple-400 font-mono uppercase text-[10px]">3. Audit Terrain</span>
                    <span className="px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono text-[10px]">6</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#0E1527] border border-purple-500/20 text-xs space-y-1">
                    <div className="font-bold text-white">Amadou Diallo</div>
                    <div className="text-[10px] text-gray-400 font-mono">AD · 18 ans · Côte d'Ivoire</div>
                    <button
                      onClick={() => showFeedback('Convocation d\'essai générée pour Amadou Diallo.')}
                      className="mt-1 text-[10px] text-purple-400 hover:underline block"
                    >
                      Inviter en Essai →
                    </button>
                  </div>
                </div>

                {/* Column 4: Trial & Medical */}
                <div className="p-3.5 rounded-xl bg-[#050810] border border-white/10 space-y-2.5">
                  <div className="flex justify-between items-center text-xs border-b border-white/5 pb-2">
                    <span className="font-bold text-amber-400 font-mono uppercase text-[10px]">4. Essai & Médical</span>
                    <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono text-[10px]">3</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#0E1527] border border-amber-500/20 text-xs space-y-1">
                    <div className="font-bold text-white">Mohamed Camara</div>
                    <div className="text-[10px] text-gray-400 font-mono">MDF · 19 ans · Guinée</div>
                    <button
                      onClick={() => showFeedback('Transmission au Directeur Sportif pour émission d\'offre.')}
                      className="mt-1 text-[10px] text-amber-400 hover:underline block"
                    >
                      Transmettre pour Offre →
                    </button>
                  </div>
                </div>

                {/* Column 5: Offer & Contract */}
                <div className="p-3.5 rounded-xl bg-[#050810] border border-white/10 space-y-2.5">
                  <div className="flex justify-between items-center text-xs border-b border-white/5 pb-2">
                    <span className="font-bold text-emerald-400 font-mono uppercase text-[10px]">5. Offre & Signature</span>
                    <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono text-[10px]">2</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#0E1527] border border-emerald-500/20 text-xs space-y-1">
                    <div className="font-bold text-white">Souleymane Bamba</div>
                    <div className="text-[10px] text-gray-400 font-mono">DC · 20 ans · Côte d'Ivoire</div>
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold block mt-1">
                      ✓ Contrat Pro 3 Ans Signé
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* GLOBAL PUBLISH & ONLINE STATUS MODAL */}
      {showGlobalPublishModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-[#090E1B] border-2 border-emerald-400 rounded-2xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative">
            <button
              onClick={() => setShowGlobalPublishModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white text-lg font-bold"
            >
              ✕
            </button>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-xs font-mono font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  EN LIGNE ET INDEXÉ MONDIALEMENT
                </span>
                <span className="text-gray-400 text-xs font-mono">CDN Haute Vitesse 2026</span>
              </div>
              <h2 className="text-2xl font-black text-white">
                Statut de Publication & Diffusion Mondiale aux Clubs
              </h2>
              <p className="text-xs text-gray-300 leading-relaxed">
                La plateforme <strong>Africa Talent Football</strong> est déployée, hébergée sur une infrastructure cloud internationale et immédiatement accessible par l'ensemble des clubs professionnels, agents FIFA, directeurs sportifs et recruteurs du monde entier.
              </p>
            </div>

            {/* Public URL Box */}
            <div className="p-4 rounded-xl bg-[#050810] border border-white/10 space-y-2">
              <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">Lien Public Universel & Partageable :</span>
              <div className="flex items-center justify-between gap-2 p-2 rounded bg-black/60 border border-white/10 font-mono text-xs text-amber-300 overflow-x-auto">
                <span className="truncate">https://ais-pre-xdk4mc5kqlr5epxponmd4f-71771660900.europe-west1.run.app</span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText('https://ais-pre-xdk4mc5kqlr5epxponmd4f-71771660900.europe-west1.run.app');
                    showFeedback('Lien copié dans le presse-papier !');
                  }}
                  className="px-3 py-1 rounded bg-amber-500 text-black font-black text-[10px] uppercase shrink-0 hover:bg-amber-400 cursor-pointer"
                >
                  Copier
                </button>
              </div>
            </div>

            {/* Confederations grid */}
            <div className="space-y-2">
              <span className="text-xs font-mono font-bold text-white uppercase">Couverture des Confédérations FIFA :</span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs font-mono">
                <div className="p-2 rounded bg-white/5 border border-white/10 text-gray-300">
                  <span className="font-bold text-amber-400">CAF (Afrique)</span> : 54 Pays
                </div>
                <div className="p-2 rounded bg-white/5 border border-white/10 text-gray-300">
                  <span className="font-bold text-blue-400">UEFA (Europe)</span> : 55 Pays
                </div>
                <div className="p-2 rounded bg-white/5 border border-white/10 text-gray-300">
                  <span className="font-bold text-emerald-400">CONMEBOL</span> : 10 Pays
                </div>
                <div className="p-2 rounded bg-white/5 border border-white/10 text-gray-300">
                  <span className="font-bold text-purple-400">CONCACAF</span> : 41 Pays
                </div>
                <div className="p-2 rounded bg-white/5 border border-white/10 text-gray-300">
                  <span className="font-bold text-red-400">AFC (Asie)</span> : 47 Pays
                </div>
                <div className="p-2 rounded bg-white/5 border border-white/10 text-gray-300">
                  <span className="font-bold text-cyan-400">OFC (Océanie)</span> : 13 Pays
                </div>
              </div>
            </div>

            {/* Share Broadcast Options */}
            <div className="pt-2 flex flex-col sm:flex-row gap-3">
              <a
                href={`${FOUNDER_INFO.whatsappUrl}?text=Bonjour%2C%20d%C3%A9couvrez%20la%20plateforme%20officielle%20Africa%20Talent%20Football%20(Vente%2C%20d%C3%A9tection%20et%20scouting%20de%20joueurs%20africains)%20%3A%20https%3A%2F%2Fais-pre-xdk4mc5kqlr5epxponmd4f-71771660900.europe-west1.run.app`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs uppercase tracking-wider text-center transition-colors shadow-lg shadow-emerald-500/20"
              >
                Diffuser via WhatsApp Pro
              </a>
              <button
                onClick={() => {
                  setShowGlobalPublishModal(false);
                  if (onOpenSharePlatform) onOpenSharePlatform();
                }}
                className="flex-1 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider text-center transition-colors shadow-lg shadow-amber-500/20"
              >
                Ouvrir Modal de Partage 360°
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
