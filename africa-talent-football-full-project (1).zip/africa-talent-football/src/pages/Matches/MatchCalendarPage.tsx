import React, { useState, useMemo, useEffect } from 'react';
import { FootballMatchFixture, WorldwideNewsArticle, ConfederationCode, FootballClub } from '../../types/database';
import { WORLDWIDE_MATCH_FIXTURES, WORLDWIDE_NEWS_FEED } from '../../data/calendarAndNewsData';
import { COMPREHENSIVE_WORLD_CLUBS } from '../../data/clubsData';
import { ClubDossierModal } from '../../components/common/ClubDossierModal';
import { FOUNDER_INFO } from '../../data/demoData';
import { useLanguage } from '../../context/LanguageContext';

interface MatchCalendarPageProps {
  onNavigate: (view: string, payload?: any) => void;
  initialTab?: 'CALENDAR' | 'NEWS';
}

export const MatchCalendarPage: React.FC<MatchCalendarPageProps> = ({ onNavigate, initialTab = 'CALENDAR' }) => {
  const { t, formatDate } = useLanguage();
  const [activeMainTab, setActiveMainTab] = useState<'CALENDAR' | 'NEWS'>(initialTab);
  const [selectedConfederation, setSelectedConfederation] = useState<string>('ALL');
  const [selectedMatchStatus, setSelectedMatchStatus] = useState<string>('ALL');
  const [selectedDateFilter, setSelectedDateFilter] = useState<string>('ALL');
  const [selectedNewsCategory, setSelectedNewsCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Real-time ticker and live refresh simulation
  const [tickerIndex, setTickerIndex] = useState(0);
  const [lastSyncTime, setLastSyncTime] = useState<string>('En direct');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Selected modals
  const [selectedClubForModal, setSelectedClubForModal] = useState<FootballClub | null>(null);
  const [activePlayingMatch, setActivePlayingMatch] = useState<FootballMatchFixture | null>(null);
  const [selectedMatchForDetail, setSelectedMatchForDetail] = useState<FootballMatchFixture | null>(null);
  const [selectedArticleForRead, setSelectedArticleForRead] = useState<WorldwideNewsArticle | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  // Rotate breaking ticker automatically
  const breakingNews = useMemo(() => {
    return WORLDWIDE_NEWS_FEED.filter(n => n.isBreaking || n.category === 'MERCATO');
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTickerIndex(prev => (prev + 1) % (breakingNews.length || 1));
    }, 6000);
    return () => clearInterval(timer);
  }, [breakingNews.length]);

  const handleManualRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      const now = new Date();
      setLastSyncTime(`${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')} GMT`);
      setIsRefreshing(false);
    }, 600);
  };

  // Filtered match fixtures
  const filteredMatches = useMemo(() => {
    return WORLDWIDE_MATCH_FIXTURES.filter((m) => {
      // Search query
      const searchBlob = `${m.competition} ${m.round || ''} ${m.homeTeam.name} ${m.awayTeam.name} ${m.city} ${m.stadium} ${m.country} ${m.scoutNotes || ''} ${(m.monitoredTalents || []).join(' ')}`.toLowerCase();
      const matchesSearch = !searchQuery || searchBlob.includes(searchQuery.toLowerCase());

      // Confederation / continent filter
      const matchesConfed = selectedConfederation === 'ALL' || m.confederation === selectedConfederation;

      // Status filter
      const matchesStatus =
        selectedMatchStatus === 'ALL' ||
        (selectedMatchStatus === 'LIVE' && m.status === 'LIVE') ||
        (selectedMatchStatus === 'TODAY' && (m.date.includes('Aujourd’hui') || m.date.includes('Ce Soir'))) ||
        (selectedMatchStatus === 'UPCOMING' && m.status === 'UPCOMING') ||
        (selectedMatchStatus === 'FINISHED' && m.status === 'FINISHED');

      // Date ribbon filter
      const matchesDate =
        selectedDateFilter === 'ALL' ||
        (selectedDateFilter === 'TODAY' && (m.date.includes('Aujourd’hui') || m.date.includes('Ce Soir'))) ||
        (selectedDateFilter === 'TOMORROW' && m.date.includes('Demain')) ||
        (selectedDateFilter === 'WEEKEND' && (m.date.includes('Samedi') || m.date.includes('Dimanche'))) ||
        (selectedDateFilter === 'FINISHED' && m.status === 'FINISHED');

      return matchesSearch && matchesConfed && matchesStatus && matchesDate;
    });
  }, [searchQuery, selectedConfederation, selectedMatchStatus, selectedDateFilter]);

  // Filtered news feed
  const filteredNews = useMemo(() => {
    return WORLDWIDE_NEWS_FEED.filter((n) => {
      const searchBlob = `${n.title} ${n.summary} ${n.source} ${n.category} ${n.country || ''} ${(n.tags || []).join(' ')} ${n.keyHighlight || ''}`.toLowerCase();
      const matchesSearch = !searchQuery || searchBlob.includes(searchQuery.toLowerCase());

      const matchesConfed = selectedConfederation === 'ALL' || n.confederation === selectedConfederation || n.confederation === 'GLOBAL';

      const matchesCat = selectedNewsCategory === 'ALL' || n.category === selectedNewsCategory;

      return matchesSearch && matchesConfed && matchesCat;
    });
  }, [searchQuery, selectedConfederation, selectedNewsCategory]);

  // Counts per confederation
  const confederationCounts = useMemo(() => {
    const counts: Record<string, { matches: number; news: number }> = {
      ALL: { matches: WORLDWIDE_MATCH_FIXTURES.length, news: WORLDWIDE_NEWS_FEED.length },
      CAF: { matches: 0, news: 0 },
      UEFA: { matches: 0, news: 0 },
      CONMEBOL: { matches: 0, news: 0 },
      CONCACAF: { matches: 0, news: 0 },
      AFC: { matches: 0, news: 0 },
      OFC: { matches: 0, news: 0 },
      ATF_SHOWCASE: { matches: 0, news: 0 }
    };

    WORLDWIDE_MATCH_FIXTURES.forEach(m => {
      if (counts[m.confederation]) {
        counts[m.confederation].matches += 1;
      }
    });

    WORLDWIDE_NEWS_FEED.forEach(n => {
      if (counts[n.confederation]) {
        counts[n.confederation].news += 1;
      }
    });

    return counts;
  }, []);

  const handleOpenClubByName = (clubName: string) => {
    const found = COMPREHENSIVE_WORLD_CLUBS.find(
      (c) => c.name.toLowerCase() === clubName.toLowerCase() || clubName.toLowerCase().includes(c.name.toLowerCase())
    );
    if (found) {
      setSelectedClubForModal(found);
    }
  };

  const handleWhatsAppMatchInquiry = (match: FootballMatchFixture) => {
    const text = `Bonjour Seydou Mario TRAORÉ,\nJe vous contacte concernant le match "${match.homeTeam.name} vs ${match.awayTeam.name}" (${match.competition}) sur Africa Talent Football :\n\n- Date & Heure : ${match.date} à ${match.time}\n- Stade : ${match.stadium} (${match.city})\n- Talents ciblés : ${(match.monitoredTalents || []).join(', ') || 'Supervision générale'}\n\nMerci de me communiquer les fiches techniques certifiées et les séquences vidéo des joueurs surveillés.`;
    window.open(`${FOUNDER_INFO.whatsappUrl}?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleWhatsAppNewsShare = (article: WorldwideNewsArticle) => {
    const text = `Bonjour Seydou Mario TRAORÉ,\nJe souhaite échanger avec votre desk concernant l'actualité officielle suivante sur Africa Talent Football :\n\n"${article.title}" (${article.publishedAt})\nSource : ${article.source}\n\nMerci de m'éclairer sur les retombées et opportunités pour nos talents et clubs partenaires.`;
    window.open(`${FOUNDER_INFO.whatsappUrl}?text=${encodeURIComponent(text)}`, '_blank');
  };

  const getConfederationBadge = (conf?: string) => {
    switch (conf) {
      case 'CAF':
        return <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-mono font-bold">🌍 CAF Afrique</span>;
      case 'UEFA':
        return <span className="px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/40 text-[10px] font-mono font-bold">🇪🇺 UEFA Europe</span>;
      case 'CONMEBOL':
        return <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 text-[10px] font-mono font-bold">🌎 CONMEBOL Am. Sud</span>;
      case 'CONCACAF':
        return <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 text-[10px] font-mono font-bold">🌎 CONCACAF Am. Nord</span>;
      case 'AFC':
        return <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/40 text-[10px] font-mono font-bold">🌏 AFC Asie & Golfe</span>;
      case 'OFC':
        return <span className="px-2.5 py-0.5 rounded-full bg-teal-500/20 text-teal-400 border border-teal-500/40 text-[10px] font-mono font-bold">🌊 OFC Océanie</span>;
      case 'ATF_SHOWCASE':
        return <span className="px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-500/30 to-amber-600/30 text-amber-300 border border-amber-500/50 text-[10px] font-mono font-bold animate-pulse">⭐ Showcase ATF</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full bg-white/10 text-gray-300 text-[10px] font-mono font-bold">🌐 Mondial</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-left">
      {/* BREAKING NEWS TICKER BANNER (ROTATING & INTERACTIVE) */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-[#1A0B0B] via-[#2A101A] to-[#0A142A] border-2 border-red-500/40 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="flex items-center gap-2 shrink-0">
            <span className="px-2.5 py-1 rounded-xl bg-red-600 text-white font-black text-[10px] font-mono uppercase tracking-wider flex items-center gap-1.5 animate-pulse">
              <span className="w-2 h-2 rounded-full bg-white" />
              Flash Direct
            </span>
          </div>

          {breakingNews.length > 0 && (
            <div className="overflow-hidden">
              <p className="text-xs text-gray-200 font-mono truncate transition-all duration-300">
                <strong className="text-amber-400">{breakingNews[tickerIndex]?.category} :</strong> {breakingNews[tickerIndex]?.title}
              </p>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2 shrink-0 self-end md:self-auto">
          <button
            onClick={() => setTickerIndex((prev) => (prev - 1 + breakingNews.length) % breakingNews.length)}
            className="p-1 rounded bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white text-xs"
            title="Précédent"
          >
            ◀
          </button>
          <button
            onClick={() => setTickerIndex((prev) => (prev + 1) % breakingNews.length)}
            className="p-1 rounded bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white text-xs"
            title="Suivant"
          >
            ▶
          </button>
          <button
            onClick={() => {
              setActiveMainTab('NEWS');
              if (breakingNews[tickerIndex]) {
                setSelectedArticleForRead(breakingNews[tickerIndex]);
              }
            }}
            className="text-xs font-mono font-bold text-amber-400 hover:text-amber-300 shrink-0 flex items-center gap-1 cursor-pointer transition-colors ml-2"
          >
            <span>Lire l'Article</span>
            <span>→</span>
          </button>
        </div>
      </div>

      {/* HEADER SECTION & LIVE SYNC TELEMETRY */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-5 border-b border-white/10 pb-6">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
              Centre de Matchs & Hub d'Information Mondial
            </span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono text-[10px] font-bold border border-emerald-500/40">
              6 Continents FIFA Couverts
            </span>
            <span className="text-gray-500 text-xs">|</span>
            <span className="text-xs font-mono text-gray-400 flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${isRefreshing ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`} />
              Dernière mise à jour : <strong className="text-white">{lastSyncTime}</strong>
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white mt-1">
            Calendriers des Matchs & Flux d'Actualités Mondiales
          </h1>
          <p className="text-xs sm:text-sm text-gray-300 mt-1 max-w-3xl leading-relaxed">
            Calendriers officiels, scores en direct, chaînes de diffusion TV et fiches de détection pour les compétitions de la <strong>CAF (Afrique)</strong>, <strong>UEFA (Europe)</strong>, <strong>CONMEBOL (Amérique du Sud)</strong>, <strong>CONCACAF (Amérique du Nord)</strong>, <strong>AFC (Asie & Golfe)</strong>, <strong>OFC (Océanie)</strong> et les <strong>Showcases Détection ATF</strong>.
          </p>
        </div>

        {/* Global Search Bar & Live Sync Button */}
        <div className="flex items-center gap-2.5 w-full md:w-auto shrink-0">
          <div className="relative flex-grow md:w-72">
            <input
              type="text"
              placeholder="Rechercher club, joueur, stade, actu..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-8 py-2.5 rounded-xl bg-[#090E1B] border border-white/10 text-white placeholder-gray-500 text-xs font-mono focus:border-amber-500 outline-none transition-colors"
            />
            <span className="absolute left-3 top-2.5 text-gray-400 text-sm">🔍</span>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-gray-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            )}
          </div>

          <button
            onClick={handleManualRefresh}
            disabled={isRefreshing}
            className="px-3.5 py-2.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-mono font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0"
            title="Rafraîchir les scores et actualités en direct"
          >
            <span className={isRefreshing ? 'animate-spin' : ''}>🔄</span>
            <span className="hidden sm:inline">Actualiser</span>
          </button>
        </div>
      </div>

      {/* MAIN VIEW TOGGLE TABS (CALENDRIER MATCHS vs FLUX D'ACTUALITÉS) */}
      <div className="flex border-b border-white/10 gap-6 text-sm font-mono font-bold overflow-x-auto">
        <button
          onClick={() => setActiveMainTab('CALENDAR')}
          className={`pb-3 border-b-2 transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
            activeMainTab === 'CALENDAR'
              ? 'border-amber-500 text-amber-400 font-black'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <span>📅 Calendrier des Matchs & Résultats</span>
          <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-xs">
            {filteredMatches.length}
          </span>
        </button>

        <button
          onClick={() => setActiveMainTab('NEWS')}
          className={`pb-3 border-b-2 transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
            activeMainTab === 'NEWS'
              ? 'border-amber-500 text-amber-400 font-black'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <span>📰 Flux d'Actualités & Veille Internationale</span>
          <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-xs">
            {filteredNews.length}
          </span>
        </button>
      </div>

      {/* CONTINENT / CONFEDERATION FILTER BAR (KEY REQUIREMENT: FILTER BY CONTINENT) */}
      <div className="space-y-2.5 p-4 rounded-2xl bg-[#070D1B] border border-white/10 shadow-lg">
        <div className="flex items-center justify-between text-xs font-mono text-gray-400">
          <span className="font-bold uppercase text-white flex items-center gap-2">
            <span>🌍</span>
            <span>Filtrer par Continent / Confédération FIFA :</span>
          </span>
          <button
            onClick={() => {
              setSelectedConfederation('ALL');
              setSelectedMatchStatus('ALL');
              setSelectedDateFilter('ALL');
              setSelectedNewsCategory('ALL');
              setSearchQuery('');
            }}
            className="text-amber-400 hover:underline cursor-pointer text-[11px] font-bold"
          >
            Réinitialiser tous les filtres
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: 'ALL', label: '🌍 Tous les Continents' },
            { id: 'CAF', label: '🌍 CAF · Afrique' },
            { id: 'UEFA', label: '🇪🇺 UEFA · Europe' },
            { id: 'CONMEBOL', label: '🌎 CONMEBOL · Am. Sud' },
            { id: 'CONCACAF', label: '🌎 CONCACAF · Am. Nord' },
            { id: 'AFC', label: '🌏 AFC · Asie & Golfe' },
            { id: 'OFC', label: '🌊 OFC · Océanie' },
            { id: 'ATF_SHOWCASE', label: '⭐ Showcases Détection ATF' }
          ].map((conf) => {
            const isSelected = selectedConfederation === conf.id;
            const count = activeMainTab === 'CALENDAR' 
              ? confederationCounts[conf.id]?.matches ?? 0
              : confederationCounts[conf.id]?.news ?? 0;

            return (
              <button
                key={conf.id}
                onClick={() => setSelectedConfederation(conf.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer border flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-amber-500 text-black border-amber-400 shadow-md shadow-amber-500/20'
                    : 'bg-[#0A1224] text-gray-300 border-white/10 hover:border-white/30 hover:text-white'
                }`}
              >
                <span>{conf.label}</span>
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${isSelected ? 'bg-black/30 text-black font-black' : 'bg-white/10 text-gray-400'}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ========================================================= */}
      {/* VUE 1 : CALENDRIER DES MATCHS, SCORES EN DIRECT & TACTIQUE */}
      {/* ========================================================= */}
      {activeMainTab === 'CALENDAR' && (
        <div className="space-y-6">
          {/* Sub-bar: Date Selector Ribbon & Match Status Filters */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 p-3.5 rounded-2xl bg-[#090E1B] border border-white/10 text-xs font-mono">
            {/* Status filters */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-gray-400 font-bold uppercase text-[11px] mr-1">Statut :</span>
              {[
                { id: 'ALL', label: 'Tous' },
                { id: 'LIVE', label: '🔴 En Direct' },
                { id: 'TODAY', label: '📅 Aujourd’hui' },
                { id: 'UPCOMING', label: '📆 À Venir' },
                { id: 'FINISHED', label: '✅ Terminés (Scores)' }
              ].map((st) => (
                <button
                  key={st.id}
                  onClick={() => setSelectedMatchStatus(st.id)}
                  className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                    selectedMatchStatus === st.id
                      ? 'bg-amber-500 text-black font-black'
                      : 'text-gray-300 bg-white/5 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {st.label}
                </button>
              ))}
            </div>

            {/* Date Ribbon */}
            <div className="flex flex-wrap items-center gap-1.5 pt-2 lg:pt-0 border-t lg:border-t-0 border-white/5">
              <span className="text-gray-400 font-bold uppercase text-[11px] mr-1">Période :</span>
              {[
                { id: 'ALL', label: 'Toutes les Dates' },
                { id: 'TODAY', label: 'Aujourd\'hui' },
                { id: 'TOMORROW', label: 'Demain' },
                { id: 'WEEKEND', label: 'Ce Week-End' }
              ].map((dt) => (
                <button
                  key={dt.id}
                  onClick={() => setSelectedDateFilter(dt.id)}
                  className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer text-[11px] ${
                    selectedDateFilter === dt.id
                      ? 'bg-white/20 text-white font-bold border border-white/30'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {dt.label}
                </button>
              ))}
              <span className="text-gray-500 ml-2">({filteredMatches.length} affichés)</span>
            </div>
          </div>

          {/* Active Highlight Video Player if triggered */}
          {activePlayingMatch && activePlayingMatch.tacticalHighlightsUrl && (
            <div className="p-4 sm:p-5 rounded-2xl bg-[#050914] border-2 border-amber-500/50 space-y-3 shadow-2xl animate-in zoom-in duration-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-mono font-bold uppercase text-amber-400">
                    Séquences Tactiques & Résumé Vidéo Officiel
                  </span>
                </div>
                <button
                  onClick={() => setActivePlayingMatch(null)}
                  className="text-gray-400 hover:text-white text-xs font-bold px-2 py-1 rounded bg-white/10"
                >
                  ✕ Fermer Lecteur
                </button>
              </div>

              <div className="relative aspect-video rounded-xl overflow-hidden bg-black border border-white/10">
                <video
                  controls
                  autoPlay
                  className="w-full h-full object-cover"
                >
                  <source src={activePlayingMatch.tacticalHighlightsUrl} type="video/mp4" />
                </video>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono text-gray-300">
                <span>{activePlayingMatch.competition} : {activePlayingMatch.homeTeam.name} vs {activePlayingMatch.awayTeam.name}</span>
                <span className="text-amber-400">Stade : {activePlayingMatch.stadium} ({activePlayingMatch.city})</span>
              </div>
            </div>
          )}

          {/* Matches Grid */}
          {filteredMatches.length === 0 ? (
            <div className="py-16 text-center space-y-3 bg-[#090E1B] rounded-2xl border border-white/10 p-6">
              <span className="text-4xl block">⚽</span>
              <h3 className="text-base font-bold text-white">Aucun match ne correspond à ces critères de filtrage</h3>
              <p className="text-xs text-gray-400 max-w-md mx-auto">
                Essayez d'élargir votre recherche, de sélectionner « Tous les Continents » ou de réinitialiser les filtres de date.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {filteredMatches.map((m) => {
                const isLive = m.status === 'LIVE';
                const isFinished = m.status === 'FINISHED';

                return (
                  <div
                    key={m.id}
                    className="p-5 sm:p-6 rounded-2xl bg-[#090E1B] border border-white/10 hover:border-amber-500/50 transition-all space-y-4 shadow-xl flex flex-col justify-between group"
                  >
                    {/* Top Competition & Confederation Stripe */}
                    <div className="space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          {getConfederationBadge(m.confederation)}
                          <span className="text-xs font-mono font-bold text-gray-300">
                            {m.competition} {m.round ? `· ${m.round}` : ''}
                          </span>
                        </div>

                        {/* Status Badge */}
                        <div>
                          {isLive && (
                            <span className="px-2.5 py-0.5 rounded-full bg-red-600/30 text-red-300 border border-red-500/50 text-[10px] font-mono font-black flex items-center gap-1.5 animate-pulse">
                              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                              EN DIRECT ({m.liveMinute || '70\''})
                            </span>
                          )}
                          {isFinished && (
                            <span className="px-2.5 py-0.5 rounded-full bg-gray-700/40 text-gray-300 border border-white/10 text-[10px] font-mono font-bold">
                              ✓ TERMINÉ
                            </span>
                          )}
                          {!isLive && !isFinished && (
                            <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold">
                              ⏰ {m.date} · {m.time}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Stadium & City & Referee */}
                      <div className="flex flex-wrap items-center justify-between text-[11px] font-mono text-gray-400 gap-2">
                        <span className="flex items-center gap-1">
                          <span>🏟️</span>
                          <span>{m.stadium} ({m.city}, {m.country})</span>
                        </span>
                        {m.referee && (
                          <span className="text-gray-500">
                            Arbitre : {m.referee}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Match Scoreboard Display */}
                    <div className="p-4 rounded-xl bg-[#050810] border border-white/5 flex items-center justify-between gap-3">
                      {/* Home Team */}
                      <div
                        onClick={() => handleOpenClubByName(m.homeTeam.name)}
                        className="flex-1 flex items-center gap-3 cursor-pointer group/team"
                        title="Consulter le dossier du club"
                      >
                        <img
                          src={m.homeTeam.logoUrl}
                          alt={m.homeTeam.name}
                          className="w-12 h-12 rounded-xl object-cover border border-white/10 shadow-md group-hover/team:scale-105 transition-transform shrink-0"
                        />
                        <div className="space-y-0.5">
                          <span className="text-xs sm:text-sm font-black text-white group-hover/team:text-amber-400 transition-colors line-clamp-1">
                            {m.homeTeam.name}
                          </span>
                          <span className="text-[10px] font-mono text-gray-400 block">
                            {m.homeTeam.countryFlag} Domicile
                          </span>
                        </div>
                      </div>

                      {/* Middle Score / Time */}
                      <div className="text-center px-3 py-1.5 rounded-lg bg-black/60 border border-white/10 shrink-0 min-w-[70px]">
                        {isLive || isFinished ? (
                          <div className="text-lg sm:text-xl font-black font-mono text-amber-400">
                            {m.homeTeam.score ?? 0} - {m.awayTeam.score ?? 0}
                          </div>
                        ) : (
                          <div className="text-xs font-mono font-bold text-gray-400">
                            VS
                          </div>
                        )}
                        <span className="text-[9px] font-mono text-gray-500 uppercase block">
                          {isLive ? 'En cours' : isFinished ? 'Score Final' : m.time}
                        </span>
                      </div>

                      {/* Away Team */}
                      <div
                        onClick={() => handleOpenClubByName(m.awayTeam.name)}
                        className="flex-1 flex items-center justify-end gap-3 text-right cursor-pointer group/team"
                        title="Consulter le dossier du club"
                      >
                        <div className="space-y-0.5">
                          <span className="text-xs sm:text-sm font-black text-white group-hover/team:text-amber-400 transition-colors line-clamp-1">
                            {m.awayTeam.name}
                          </span>
                          <span className="text-[10px] font-mono text-gray-400 block">
                            {m.awayTeam.countryFlag} Extérieur
                          </span>
                        </div>
                        <img
                          src={m.awayTeam.logoUrl}
                          alt={m.awayTeam.name}
                          className="w-12 h-12 rounded-xl object-cover border border-white/10 shadow-md group-hover/team:scale-105 transition-transform shrink-0"
                        />
                      </div>
                    </div>

                    {/* Possession percentage bar if available */}
                    {m.possessionPct && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] font-mono text-gray-400">
                          <span>Possession {m.possessionPct.home}%</span>
                          <span>{m.possessionPct.away}%</span>
                        </div>
                        <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden flex">
                          <div className="bg-amber-400 h-full" style={{ width: `${m.possessionPct.home}%` }} />
                          <div className="bg-blue-400 h-full" style={{ width: `${m.possessionPct.away}%` }} />
                        </div>
                      </div>
                    )}

                    {/* Scorers if live or finished */}
                    {m.scorers && m.scorers.length > 0 && (
                      <div className="p-2 rounded-lg bg-black/40 text-[11px] font-mono text-gray-300 space-y-0.5">
                        <span className="text-[10px] text-gray-500 uppercase font-bold">Buteurs :</span>
                        <div className="flex flex-wrap gap-x-3 gap-y-0.5">
                          {m.scorers.map((sc, i) => (
                            <span key={i} className="text-gray-300">
                              ⚽ {sc.player} ({sc.minute})
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Broadcast Channel & Scout Highlights */}
                    <div className="space-y-2 text-xs">
                      {m.broadcastChannel && (
                        <div className="flex items-center justify-between text-[11px] font-mono text-gray-400 bg-white/5 p-2 rounded-lg">
                          <span className="flex items-center gap-1.5">
                            <span>📺 Diffusion TV :</span>
                            <strong className="text-white">{m.broadcastChannel}</strong>
                          </span>
                        </div>
                      )}

                      {m.scoutNotes && (
                        <div className="p-2.5 rounded-xl bg-[#0B1428] border border-amber-500/20 text-[11px] text-gray-300 space-y-1">
                          <span className="text-[10px] font-mono font-bold text-amber-400 uppercase block">
                            🎯 Veille & Notes de Scouting ATF :
                          </span>
                          <p>{m.scoutNotes}</p>
                          {m.monitoredTalents && m.monitoredTalents.length > 0 && (
                            <div className="flex flex-wrap gap-1 pt-1">
                              {m.monitoredTalents.map((t, idx) => (
                                <span key={idx} className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 font-mono text-[10px] border border-amber-500/30">
                                  ★ {t}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/5">
                      <div className="flex items-center gap-2">
                        {m.tacticalHighlightsUrl && (
                          <button
                            onClick={() => setActivePlayingMatch(m)}
                            className="px-3 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 text-xs font-mono font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                          >
                            <span>▶ Vidéo Résumé</span>
                          </button>
                        )}
                        <button
                          onClick={() => setSelectedMatchForDetail(m)}
                          className="px-2.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 text-xs font-mono transition-colors cursor-pointer"
                        >
                          📋 Détails & Compo
                        </button>
                      </div>

                      <button
                        onClick={() => handleWhatsAppMatchInquiry(m)}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/40 text-xs font-mono font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                        title="Échanger directement avec Seydou Mario TRAORÉ sur cette rencontre"
                      >
                        <span>📱 Desk Mario Traoré</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* VUE 2 : FLUX D'ACTUALITÉS & VEILLE INTERNATIONALE EN DIRECT */}
      {/* ========================================================= */}
      {activeMainTab === 'NEWS' && (
        <div className="space-y-6">
          {/* Sub-category filter pills */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-[#090E1B] border border-white/10 text-xs font-mono">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-gray-400 font-bold uppercase text-[11px] mr-1">Rubrique :</span>
              {[
                { id: 'ALL', label: 'Toutes les Actualités' },
                { id: 'MERCATO', label: '🎯 Mercato & Transferts' },
                { id: 'MATCH', label: '⚽ Matchs & Résultats' },
                { id: 'SCOUTING', label: '🔍 Détection & Pépites' },
                { id: 'ACADEMY', label: '🎓 Académies & Bourses' },
                { id: 'OFFICIAL', label: '📢 Communiqués Officiels' },
                { id: 'TACTICAL', label: '📐 Analyses Tactiques' }
              ].map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedNewsCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                    selectedNewsCategory === cat.id
                      ? 'bg-amber-500 text-black font-black'
                      : 'text-gray-300 bg-white/5 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            <div className="text-gray-400 text-[11px]">
              {filteredNews.length} article{filteredNews.length > 1 ? 's' : ''} disponible{filteredNews.length > 1 ? 's' : ''}
            </div>
          </div>

          {/* News Feed Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredNews.map((art) => (
              <div
                key={art.id}
                className="p-5 sm:p-6 rounded-2xl bg-[#090E1B] border border-white/10 hover:border-amber-500/50 transition-all space-y-4 shadow-xl flex flex-col justify-between group"
              >
                <div className="space-y-3">
                  {/* Article Image Banner */}
                  <div
                    onClick={() => setSelectedArticleForRead(art)}
                    className="relative aspect-video rounded-xl overflow-hidden bg-black cursor-pointer"
                  >
                    <img
                      src={art.imageUrl}
                      alt={art.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5">
                      {getConfederationBadge(art.confederation)}
                      <span className="px-2.5 py-0.5 rounded-full bg-black/80 text-amber-400 text-[10px] font-mono font-bold uppercase border border-amber-500/40">
                        {art.category}
                      </span>
                    </div>

                    {art.isBreaking && (
                      <span className="absolute bottom-3 left-3 px-2 py-0.5 rounded bg-red-600 text-white text-[10px] font-mono font-black uppercase tracking-wider animate-pulse">
                        ● Urgent
                      </span>
                    )}

                    {art.readTimeMinutes && (
                      <span className="absolute bottom-3 right-3 px-2 py-0.5 rounded bg-black/80 text-gray-300 text-[10px] font-mono">
                        ⏱️ {art.readTimeMinutes} min de lecture
                      </span>
                    )}
                  </div>

                  {/* Header info */}
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono text-gray-400">
                    <span className="text-emerald-400 font-bold">📅 {art.publishedAt}</span>
                    <span className="bg-white/5 px-2 py-0.5 rounded border border-white/10">
                      Source : {art.source}
                    </span>
                  </div>

                  {/* Title & Summary */}
                  <h3
                    onClick={() => setSelectedArticleForRead(art)}
                    className="text-base sm:text-lg font-black text-white group-hover:text-amber-400 transition-colors leading-snug cursor-pointer"
                  >
                    {art.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
                    {art.summary}
                  </p>

                  {/* Tags */}
                  {art.tags && art.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {art.tags.map((t, idx) => (
                        <span key={idx} className="px-2 py-0.5 rounded bg-white/5 text-gray-400 text-[10px] font-mono">
                          #{t}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Key highlight quote box */}
                  {art.keyHighlight && (
                    <div className="p-3 rounded-xl bg-[#070D1B] border-l-4 border-amber-500 text-xs text-amber-300 font-mono">
                      <strong>Point Clé :</strong> {art.keyHighlight}
                    </div>
                  )}

                  {/* Related Club Tag if any */}
                  {art.relatedClubName && (
                    <div className="pt-1">
                      <button
                        onClick={() => handleOpenClubByName(art.relatedClubName!)}
                        className="text-xs font-mono font-bold text-gray-300 hover:text-white bg-white/5 hover:bg-white/10 px-2.5 py-1 rounded-lg border border-white/10 transition-colors cursor-pointer inline-flex items-center gap-1.5"
                      >
                        <span>🏟️ Consulter Fiche :</span>
                        <span className="text-amber-400">{art.relatedClubName}</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Footer sharing & contact */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-white/5">
                  <button
                    onClick={() => setSelectedArticleForRead(art)}
                    className="text-xs font-mono font-bold text-amber-400 hover:underline cursor-pointer flex items-center gap-1"
                  >
                    <span>Lire le rapport complet</span>
                    <span>→</span>
                  </button>

                  <button
                    onClick={() => handleWhatsAppNewsShare(art)}
                    className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-mono font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <span>💬 Consulter le Desk</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL 1 : FEUILLE DE MATCH COMPLÈTE & RAPPORT DE DÉTECTION */}
      {/* ========================================================= */}
      {selectedMatchForDetail && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-[#090E1B] border-2 border-amber-500/50 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl my-8 text-left">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                {getConfederationBadge(selectedMatchForDetail.confederation)}
                <span className="text-xs font-mono text-gray-400 font-bold">
                  {selectedMatchForDetail.competition} · Feuille Officielle
                </span>
              </div>
              <button
                onClick={() => setSelectedMatchForDetail(null)}
                className="text-gray-400 hover:text-white text-sm font-bold p-1 rounded hover:bg-white/10"
              >
                ✕ Fermer
              </button>
            </div>

            {/* Score banner */}
            <div className="p-5 rounded-2xl bg-[#050812] border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={selectedMatchForDetail.homeTeam.logoUrl}
                  alt={selectedMatchForDetail.homeTeam.name}
                  className="w-14 h-14 rounded-2xl object-cover border border-white/10"
                />
                <div>
                  <h3 className="font-black text-white text-base sm:text-lg">
                    {selectedMatchForDetail.homeTeam.name}
                  </h3>
                  <span className="text-xs text-gray-400 font-mono">
                    {selectedMatchForDetail.homeTeam.countryFlag} Domicile
                  </span>
                </div>
              </div>

              <div className="text-center px-4 py-2 rounded-xl bg-black border border-white/10">
                <span className="text-2xl font-black font-mono text-amber-400">
                  {selectedMatchForDetail.homeTeam.score ?? '-'} : {selectedMatchForDetail.awayTeam.score ?? '-'}
                </span>
                <span className="block text-[10px] font-mono text-gray-400 uppercase mt-0.5">
                  {selectedMatchForDetail.status === 'LIVE' ? 'En Direct' : selectedMatchForDetail.status === 'FINISHED' ? 'Terminé' : selectedMatchForDetail.time}
                </span>
              </div>

              <div className="flex items-center gap-3 text-right">
                <div>
                  <h3 className="font-black text-white text-base sm:text-lg">
                    {selectedMatchForDetail.awayTeam.name}
                  </h3>
                  <span className="text-xs text-gray-400 font-mono">
                    {selectedMatchForDetail.awayTeam.countryFlag} Extérieur
                  </span>
                </div>
                <img
                  src={selectedMatchForDetail.awayTeam.logoUrl}
                  alt={selectedMatchForDetail.awayTeam.name}
                  className="w-14 h-14 rounded-2xl object-cover border border-white/10"
                />
              </div>
            </div>

            {/* Match info grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs font-mono">
              <div className="p-3 rounded-xl bg-[#070D1B] border border-white/5">
                <span className="text-gray-500 block text-[10px]">STADE</span>
                <span className="text-white font-bold">{selectedMatchForDetail.stadium}</span>
              </div>
              <div className="p-3 rounded-xl bg-[#070D1B] border border-white/5">
                <span className="text-gray-500 block text-[10px]">VILLE & PAYS</span>
                <span className="text-white font-bold">{selectedMatchForDetail.city}, {selectedMatchForDetail.country}</span>
              </div>
              <div className="p-3 rounded-xl bg-[#070D1B] border border-white/5">
                <span className="text-gray-500 block text-[10px]">CHAÎNE TV</span>
                <span className="text-amber-400 font-bold">{selectedMatchForDetail.broadcastChannel || 'Non communiqué'}</span>
              </div>
            </div>

            {/* Scout notes */}
            {selectedMatchForDetail.scoutNotes && (
              <div className="p-4 rounded-xl bg-[#0C152B] border border-amber-500/30 space-y-2 text-xs">
                <span className="font-mono font-bold text-amber-400 uppercase block">
                  🎯 Notes d'Analyse Tactique & Télémétrie ATF :
                </span>
                <p className="text-gray-200 leading-relaxed">
                  {selectedMatchForDetail.scoutNotes}
                </p>
                {selectedMatchForDetail.monitoredTalents && (
                  <div className="pt-2">
                    <span className="text-[10px] text-gray-400 font-mono block mb-1">Pépites sous observation active :</span>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedMatchForDetail.monitoredTalents.map((t, idx) => (
                        <span key={idx} className="px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 font-mono font-bold text-xs border border-amber-500/40">
                          ★ {t}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-white/10">
              <button
                onClick={() => setSelectedMatchForDetail(null)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-gray-300 font-mono text-xs cursor-pointer"
              >
                Fermer
              </button>

              <button
                onClick={() => handleWhatsAppMatchInquiry(selectedMatchForDetail)}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-mono font-bold text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-600/30"
              >
                <span>📱 Demander Fiche Recruteur WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL 2 : LECTURE COMPLÈTE DE L'ARTICLE DE PRESSE */}
      {/* ========================================================= */}
      {selectedArticleForRead && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-[#090E1B] border-2 border-amber-500/50 rounded-3xl max-w-3xl w-full p-6 sm:p-8 space-y-6 shadow-2xl my-8 text-left max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                {getConfederationBadge(selectedArticleForRead.confederation)}
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-[10px] font-mono font-bold uppercase">
                  {selectedArticleForRead.category}
                </span>
              </div>
              <button
                onClick={() => {
                  setSelectedArticleForRead(null);
                  setIsPlayingAudio(false);
                }}
                className="text-gray-400 hover:text-white text-sm font-bold p-1 rounded hover:bg-white/10"
              >
                ✕ Fermer
              </button>
            </div>

            {/* Article Image Banner */}
            <div className="relative aspect-video rounded-2xl overflow-hidden bg-black">
              <img
                src={selectedArticleForRead.imageUrl}
                alt={selectedArticleForRead.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-3 left-3 bg-black/80 px-3 py-1 rounded-lg text-xs font-mono text-gray-300">
                Source : {selectedArticleForRead.source} · {selectedArticleForRead.publishedAt}
              </div>
            </div>

            {/* Audio Reader Simulation Bar */}
            <div className="p-3.5 rounded-xl bg-[#060B18] border border-amber-500/30 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setIsPlayingAudio(!isPlayingAudio)}
                  className="w-9 h-9 rounded-full bg-amber-500 text-black flex items-center justify-center font-bold text-sm cursor-pointer shadow-md hover:bg-amber-400 transition-transform active:scale-95"
                >
                  {isPlayingAudio ? '⏸' : '▶'}
                </button>
                <div>
                  <span className="text-xs font-mono font-bold text-white block">
                    {isPlayingAudio ? 'Lecture audio en cours (Synthèse vocale IA)...' : 'Écouter le briefing audio de l\'article'}
                  </span>
                  <span className="text-[10px] font-mono text-gray-400">
                    Durée estimée : {selectedArticleForRead.readTimeMinutes || 3} min
                  </span>
                </div>
              </div>

              {isPlayingAudio && (
                <div className="flex items-center gap-1">
                  <span className="w-1 h-4 bg-amber-400 animate-pulse" />
                  <span className="w-1 h-6 bg-amber-400 animate-pulse delay-75" />
                  <span className="w-1 h-3 bg-amber-400 animate-pulse delay-150" />
                </div>
              )}
            </div>

            {/* Title & Author */}
            <div className="space-y-2">
              <h2 className="text-xl sm:text-2xl font-black text-white leading-tight">
                {selectedArticleForRead.title}
              </h2>
              <div className="flex flex-wrap items-center gap-3 text-xs font-mono text-gray-400">
                {selectedArticleForRead.author && (
                  <span className="text-amber-400 font-bold">
                    ✍ Par {selectedArticleForRead.author} {selectedArticleForRead.authorRole ? `(${selectedArticleForRead.authorRole})` : ''}
                  </span>
                )}
                <span>●</span>
                <span>Certifié par la Cellule de Veille ATF</span>
              </div>
            </div>

            {/* Full Story Paragraphs */}
            <div className="space-y-4 text-sm text-gray-200 leading-relaxed font-sans">
              {selectedArticleForRead.fullStory ? (
                selectedArticleForRead.fullStory.map((para, i) => (
                  <p key={i}>{para}</p>
                ))
              ) : (
                <p>{selectedArticleForRead.content || selectedArticleForRead.summary}</p>
              )}
            </div>

            {/* Key Highlight quote */}
            {selectedArticleForRead.keyHighlight && (
              <div className="p-4 rounded-xl bg-[#081226] border-l-4 border-amber-500 text-xs sm:text-sm text-amber-300 font-mono">
                <strong>Point Clé du Desk :</strong> {selectedArticleForRead.keyHighlight}
              </div>
            )}

            {/* Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-white/10">
              <button
                onClick={() => {
                  setSelectedArticleForRead(null);
                  setIsPlayingAudio(false);
                }}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-gray-300 font-mono text-xs cursor-pointer"
              >
                Fermer l'article
              </button>

              <button
                onClick={() => handleWhatsAppNewsShare(selectedArticleForRead)}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-600/30"
              >
                <span>💬 Partager / Échanger avec Seydou Mario TRAORÉ</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CLUB DOSSIER MODAL */}
      <ClubDossierModal
        club={selectedClubForModal}
        isOpen={Boolean(selectedClubForModal)}
        onClose={() => setSelectedClubForModal(null)}
      />
    </div>
  );
};
