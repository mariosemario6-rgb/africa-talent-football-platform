import React, { useState, useMemo } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { usePlayers } from '../context/PlayerContext';
import { ASSETS, FOUNDER_INFO, DEMO_OPPORTUNITIES, OFFICIAL_PLATFORM_CONFIG, formatMarketValue } from '../data/demoData';
import { RegisteredPlayer } from '../types/database';
import { WORLDWIDE_MATCH_FIXTURES, WORLDWIDE_NEWS_FEED } from '../data/calendarAndNewsData';
import { getOptimizedImageUrl, lazyImageProps } from '../utils/imageOptimizer';

interface HomeProps {
  onNavigate: (view: string, payload?: any) => void;
  onOpenSearch?: () => void;
  onOpenSharePlatform?: () => void;
  onExportPdf?: (player: RegisteredPlayer) => void;
}

export const Home: React.FC<HomeProps> = ({ onNavigate, onOpenSearch, onOpenSharePlatform, onExportPdf }) => {
  const { language, t } = useLanguage();
  const {
    players,
    openVideoModal,
    totalMarketValue,
    favorites,
    toggleFavorite,
    isFavorite,
    setIsFavoritesModalOpen,
    comparisonIds,
    toggleComparison,
    isInComparison,
    setIsComparisonModalOpen,
  } = usePlayers();
  const [activePositionFilter, setActivePositionFilter] = useState<string>('ALL');
  const [displayMode, setDisplayMode] = useState<'CARDS' | 'TABLE'>('CARDS');
  const [homeContinentFilter, setHomeContinentFilter] = useState<string>('ALL');
  const [visibleHomePlayersLimit, setVisibleHomePlayersLimit] = useState<number>(6);

  const homePreviewMatches = useMemo(() => {
    return WORLDWIDE_MATCH_FIXTURES.filter(
      (m) => homeContinentFilter === 'ALL' || m.confederation === homeContinentFilter
    ).slice(0, 4);
  }, [homeContinentFilter]);

  const homePreviewNews = useMemo(() => {
    return WORLDWIDE_NEWS_FEED.filter(
      (n) => homeContinentFilter === 'ALL' || n.confederation === homeContinentFilter || n.confederation === 'GLOBAL'
    ).slice(0, 3);
  }, [homeContinentFilter]);

  const filteredPlayers = useMemo(() => {
    return players.filter((player) => {
      if (activePositionFilter === 'ALL') return true;
      if (activePositionFilter === 'ATT') return ['BU', 'AG', 'AD'].includes(player.primaryPosition);
      if (activePositionFilter === 'MID') return ['MC', 'MOC', 'MDF'].includes(player.primaryPosition);
      if (activePositionFilter === 'DEF') return ['DC', 'DL'].includes(player.primaryPosition);
      if (activePositionFilter === 'GK') return player.primaryPosition === 'GB';
      return true;
    });
  }, [players, activePositionFilter]);

  const displayedHomePlayers = useMemo(() => {
    return filteredPlayers.slice(0, visibleHomePlayersLimit);
  }, [filteredPlayers, visibleHomePlayersLimit]);

  return (
    <div className="space-y-16 pb-16">
      {/* HERO SECTION */}
      <section className="relative min-h-[620px] flex items-center justify-center overflow-hidden border-b border-white/10">
        {/* Background Image with Dark Gradient Scrim */}
        <div className="absolute inset-0 z-0">
          <img
            src={ASSETS.heroPitch}
            alt="Africa Talent Football Grounds"
            className="w-full h-full object-cover object-center brightness-60"
            loading="eager"
            fetchPriority="high"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#040711] via-[#040711]/80 to-[#040711]/50" />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center space-y-6">
          <div className="flex flex-wrap items-center justify-center gap-2">
            <div className="inline-flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-widest text-amber-300 bg-black/60 border border-amber-500/40 px-3.5 py-1 rounded shadow-lg">
              <span>★</span>
              <span>{FOUNDER_INFO.officialTitle}</span>
            </div>
            <div
              className="inline-flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-wider text-emerald-300 bg-emerald-950/70 border border-emerald-500/50 px-3.5 py-1 rounded shadow-lg"
              title={t('home.officialPlatformCertified', 'Plateforme Officielle En Ligne')}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{t('home.officialPlatformCertified', 'Plateforme Officielle En Ligne')}</span>
            </div>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-tight">
            Africa Talent Football
            <span className="block text-amber-400 font-extrabold text-2xl sm:text-3xl lg:text-4xl mt-2 tracking-normal font-sans">
              {t('home.certifiedStats', 'Statistiques Certifiées, Vidéos & Valeurs Marchandes')}
            </span>
          </h1>

          <p className="max-w-2xl mx-auto text-sm sm:text-base text-gray-300 leading-relaxed font-normal">
            {t('hero.subtitle')}
          </p>

          <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => onNavigate('feed')}
              className="px-6 py-3.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-amber-500/20 active:scale-95 cursor-pointer flex items-center gap-2"
            >
              <span>📰 Fil Réseau & Posts (LinkedIn)</span>
            </button>

            <button
              onClick={() => onNavigate('players')}
              className="px-6 py-3.5 rounded-lg bg-[#0E1527] hover:bg-white/10 text-white border border-amber-500/40 hover:border-amber-400 font-bold text-xs uppercase tracking-wider transition-all shadow-lg cursor-pointer flex items-center gap-2"
            >
              <span>📹 {t('hero.cta_explore')}</span>
            </button>

            {onOpenSearch && (
              <button
                onClick={onOpenSearch}
                className="px-6 py-3.5 rounded-lg bg-white/5 hover:bg-white/10 text-white border border-white/20 hover:border-amber-400 font-bold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 shadow-lg"
              >
                <span>🔍 {t('nav.search')}</span>
              </button>
            )}

            <button
              onClick={() => onNavigate('register')}
              className="px-6 py-3.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-lg shadow-emerald-900/30"
            >
              Inscription Gratuite ➔
            </button>
          </div>

          {/* Key Metrics Strip (Transfermarkt-style telemetry) */}
          <div className="pt-8 grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 text-left max-w-4xl mx-auto">
            <div className="p-4 rounded-xl bg-[#090E1B]/90 backdrop-blur-md border border-white/10 shadow-xl">
              <div className="text-2xl sm:text-3xl font-black text-amber-400 font-mono tabular-nums">
                {players.length}
              </div>
              <div className="text-xs text-gray-400 font-medium">{t('stats.players')}</div>
            </div>

            <div className="p-4 rounded-xl bg-[#090E1B]/90 backdrop-blur-md border border-white/10 shadow-xl">
              <div className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono tabular-nums">
                {formatMarketValue(totalMarketValue)}
              </div>
              <div className="text-xs text-gray-400 font-medium">{t('stats.market_value')}</div>
            </div>

            <div className="p-4 rounded-xl bg-[#090E1B]/90 backdrop-blur-md border border-white/10 shadow-xl">
              <div className="text-2xl sm:text-3xl font-black text-white font-mono tabular-nums">
                100%
              </div>
              <div className="text-xs text-gray-400 font-medium">{t('stats.verified_videos')}</div>
            </div>

            <div className="p-4 rounded-xl bg-[#090E1B]/90 backdrop-blur-md border border-white/10 shadow-xl">
              <div className="text-2xl sm:text-3xl font-black text-amber-400 font-mono tabular-nums">
                Direct
              </div>
              <div className="text-xs text-gray-400 font-medium">{t('stats.direct_desk')}</div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION SITE OFFICIEL & DISPONIBILITÉ SUR TOUTES LES PLATEFORMES DE TÉLÉCHARGEMENT MONDIALES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-[#070D1B] via-[#0A142A] to-[#070D1B] rounded-3xl p-6 sm:p-8 border-2 border-amber-500/50 shadow-2xl space-y-6">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 border-b border-white/10 pb-6">
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-mono font-bold uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  {t('home.officialSiteBadge', 'Site Officiel En Ligne Mondialement')}
                </span>
                <span className="px-2.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-bold uppercase">
                  {t('home.countriesCovered', '190+ Pays Couverts')}
                </span>
                <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/30 text-[10px] font-mono font-bold">
                  {t('home.fifaConfederations', '6 Confédérations FIFA')}
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                Africa Talent Football · Web & Mobile
              </h2>

              <p className="text-xs sm:text-sm text-gray-300 max-w-3xl leading-relaxed">
                {t('home.officialPlatformDesc', 'Retrouvez la plateforme officielle sur le web et sur l\'ensemble des stores d\'applications mondiaux pour smartphones, tablettes et ordinateurs de travail.')}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => onNavigate('download')}
                className="px-5 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-amber-500/25 active:scale-95 cursor-pointer border border-amber-200 flex items-center gap-2"
              >
                <span>📲</span>
                <span>{t('home.downloadPhone', 'Télécharger sur mon Téléphone')}</span>
              </button>

              <button
                onClick={() => onOpenSharePlatform && onOpenSharePlatform()}
                className="px-4 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase transition-colors flex items-center gap-2 cursor-pointer border border-white/15"
              >
                <span>🔗</span>
                <span>{t('common.sharePlatform', 'Partager la Plateforme')}</span>
              </button>
            </div>
          </div>

          {/* Platforms Grid in 7 Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
            {OFFICIAL_PLATFORM_CONFIG.downloadPlatformsWorldwide.map((platform) => (
              <button
                key={platform.id}
                onClick={() => onNavigate('download')}
                className="p-3.5 rounded-2xl bg-[#050914] border border-white/10 hover:border-amber-400/60 transition-all text-left flex flex-col justify-between space-y-2 group cursor-pointer hover:bg-[#070D1F]"
              >
                <div className="flex items-center justify-between">
                  <span className="text-2xl group-hover:scale-110 transition-transform">{platform.icon}</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                </div>
                <div>
                  <div className="font-bold text-white text-xs group-hover:text-amber-400 transition-colors line-clamp-1">
                    {platform.name}
                  </div>
                  <div className="text-[10px] text-gray-400 font-mono mt-0.5 line-clamp-1">
                    {platform.availability}
                  </div>
                </div>
                <div className="text-[9px] font-mono text-amber-400 font-bold uppercase tracking-wider pt-1 border-t border-white/5">
                  {t('home.available', 'Disponible')} ➔
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION CALENDRIERS DES MATCHS & FLUX D'ACTUALITÉS MONDIALES (FILTRE PAR CONTINENT) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-b from-[#080E1E] to-[#040814] rounded-3xl p-6 sm:p-8 border-2 border-amber-500/40 shadow-2xl space-y-6">
          {/* Header row */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/10 pb-6">
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-bold uppercase tracking-wider">
                  Centre de Matchs & Actualités
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-mono font-bold flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  6 Continents en Direct
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white">
                Calendriers des Matchs & Flux d'Actualités Mondiales
              </h2>
              <p className="text-xs sm:text-sm text-gray-300 max-w-2xl leading-relaxed">
                Suivez les rencontres phares, scores en direct, chaînes TV et dépêches certifiées de la <strong>CAF</strong>, <strong>UEFA</strong>, <strong>CONMEBOL</strong>, <strong>CONCACAF</strong>, <strong>AFC</strong>, <strong>OFC</strong> et des <strong>Showcases Détection ATF</strong>.
              </p>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <button
                onClick={() => onNavigate('matches')}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/20 cursor-pointer border border-amber-300 flex items-center gap-2"
              >
                <span>📅 Calendrier Complet</span>
                <span>→</span>
              </button>
            </div>
          </div>

          {/* Continent Filter Chips */}
          <div className="space-y-2">
            <div className="text-xs font-mono text-gray-400 flex items-center justify-between">
              <span className="font-bold text-white uppercase flex items-center gap-1.5">
                <span>🌍</span>
                <span>Filtrer par Continent / Confédération FIFA :</span>
              </span>
              <button
                onClick={() => setHomeContinentFilter('ALL')}
                className="text-amber-400 hover:underline cursor-pointer text-[11px]"
              >
                Tous les continents
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {[
                { id: 'ALL', label: '🌍 Tous' },
                { id: 'CAF', label: '🌍 CAF (Afrique)' },
                { id: 'UEFA', label: '🇪🇺 UEFA (Europe)' },
                { id: 'CONMEBOL', label: '🌎 CONMEBOL (Am. Sud)' },
                { id: 'CONCACAF', label: '🌎 CONCACAF (Am. Nord)' },
                { id: 'AFC', label: '🌏 AFC (Asie & Golfe)' },
                { id: 'OFC', label: '🌊 OFC (Océanie)' },
                { id: 'ATF_SHOWCASE', label: '⭐ Showcases ATF' }
              ].map((c) => (
                <button
                  key={c.id}
                  onClick={() => setHomeContinentFilter(c.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer border ${
                    homeContinentFilter === c.id
                      ? 'bg-amber-500 text-black border-amber-400 shadow-md shadow-amber-500/25'
                      : 'bg-[#050914] text-gray-300 border-white/10 hover:border-white/30 hover:text-white'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* 2-Column Content: Match Fixtures + Breaking News Preview */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
            {/* Column 1: Live & Upcoming Matches (7 cols) */}
            <div className="lg:col-span-7 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-mono font-black text-amber-400 uppercase tracking-wider flex items-center gap-2">
                  <span>⚽ Rencontres & Calendrier</span>
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px]">
                    {homePreviewMatches.length} affichés
                  </span>
                </h3>

                <button
                  onClick={() => onNavigate('matches')}
                  className="text-xs font-mono text-gray-400 hover:text-white cursor-pointer"
                >
                  Voir tous les matchs ➔
                </button>
              </div>

              <div className="space-y-3">
                {homePreviewMatches.map((m) => (
                  <div
                    key={m.id}
                    onClick={() => onNavigate('matches')}
                    className="p-4 rounded-2xl bg-[#060B18] border border-white/10 hover:border-amber-400/50 transition-all cursor-pointer space-y-3 group"
                  >
                    <div className="flex items-center justify-between text-[11px] font-mono">
                      <span className="text-gray-400 font-bold truncate">
                        {m.competition} {m.round ? `· ${m.round}` : ''}
                      </span>
                      {m.status === 'LIVE' ? (
                        <span className="px-2 py-0.5 rounded-full bg-red-600/30 text-red-300 border border-red-500/50 font-black animate-pulse flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                          DIRECT ({m.liveMinute || '65\''})
                        </span>
                      ) : m.status === 'FINISHED' ? (
                        <span className="px-2 py-0.5 rounded-full bg-gray-700/40 text-gray-300 border border-white/10">
                          TERMINÉ
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30">
                          {m.date} · {m.time}
                        </span>
                      )}
                    </div>

                    {/* Teams row */}
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 flex-1 min-w-0">
                        <img
                          src={m.homeTeam.logoUrl}
                          alt={m.homeTeam.name}
                          className="w-8 h-8 rounded-lg object-cover border border-white/10 shrink-0"
                        />
                        <span className="text-xs sm:text-sm font-black text-white truncate group-hover:text-amber-400 transition-colors">
                          {m.homeTeam.name}
                        </span>
                      </div>

                      <div className="text-center px-3 py-1 rounded bg-black/60 border border-white/10 shrink-0 font-mono font-bold text-amber-400 text-xs sm:text-sm">
                        {m.status === 'LIVE' || m.status === 'FINISHED'
                          ? `${m.homeTeam.score ?? 0} - ${m.awayTeam.score ?? 0}`
                          : 'VS'}
                      </div>

                      <div className="flex items-center justify-end gap-2.5 flex-1 min-w-0 text-right">
                        <span className="text-xs sm:text-sm font-black text-white truncate group-hover:text-amber-400 transition-colors">
                          {m.awayTeam.name}
                        </span>
                        <img
                          src={m.awayTeam.logoUrl}
                          alt={m.awayTeam.name}
                          className="w-8 h-8 rounded-lg object-cover border border-white/10 shrink-0"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[10px] font-mono text-gray-400 pt-1 border-t border-white/5">
                      <span className="truncate">🏟️ {m.stadium}</span>
                      {m.broadcastChannel && (
                        <span className="text-amber-400 truncate ml-2">📺 {m.broadcastChannel}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Column 2: Breaking News Feed (5 cols) */}
            <div className="lg:col-span-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-mono font-black text-blue-400 uppercase tracking-wider flex items-center gap-2">
                  <span>📰 Flux d'Actualités Certifié</span>
                </h3>

                <button
                  onClick={() => onNavigate('matches')}
                  className="text-xs font-mono text-gray-400 hover:text-white cursor-pointer"
                >
                  Voir toute l'actualité ➔
                </button>
              </div>

              <div className="space-y-3">
                {homePreviewNews.map((n) => (
                  <div
                    key={n.id}
                    onClick={() => onNavigate('matches')}
                    className="p-3.5 rounded-2xl bg-[#060B18] border border-white/10 hover:border-blue-400/50 transition-all cursor-pointer flex gap-3 group"
                  >
                    <img
                      src={n.imageUrl}
                      alt={n.title}
                      className="w-20 h-20 rounded-xl object-cover border border-white/10 shrink-0 group-hover:scale-105 transition-transform"
                    />

                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 text-[9px] font-mono">
                        <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-bold uppercase">
                          {n.category}
                        </span>
                        <span className="text-gray-400">· {n.publishedAt}</span>
                      </div>

                      <h4 className="text-xs font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-2 leading-snug">
                        {n.title}
                      </h4>

                      <p className="text-[10px] text-gray-400 font-mono truncate">
                        Source : {n.source}
                      </p>
                    </div>
                  </div>
                ))}

                <button
                  onClick={() => onNavigate('matches')}
                  className="w-full py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white text-xs font-mono font-bold transition-colors border border-white/10 text-center block cursor-pointer"
                >
                  Ouvrir le flux complet & écouter les briefings ➔
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION TABLEAUX DE BORD MÉTIERS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#080D1A] rounded-2xl p-6 sm:p-8 border border-amber-500/30 shadow-2xl space-y-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-bold uppercase tracking-wider">
                  {t('home.proGlobalAccess', 'Accès Professionnel Mondial')}
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-bold">
                  {t('home.online247', 'En Ligne 24/7')}
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white">
                {t('home.dashboardsByRole', 'Tableaux de Bord par Métier du Football Mondial')}
              </h2>
              <p className="text-xs sm:text-sm text-gray-400 max-w-2xl leading-relaxed">
                {t('home.dashboardsDesc', 'Des espaces de travail sur-mesure conçus pour les besoins spécifiques des Clubs Professionnels, Présidents, Directeurs Sportifs, Scouts, Agents FIFA, Académies et Joueurs.')}
              </p>
            </div>

            <button
              onClick={() => onNavigate('dashboard')}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/20 shrink-0 cursor-pointer border border-amber-300"
            >
              {t('home.openDashboardsHub', 'Ouvrir le Hub des Tableaux de Bord')} →
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 pt-2">
            {[
              {
                role: 'CLUB_PRO',
                icon: '🏟️',
                title: t('role.clubPro.title', 'Clubs Professionnels'),
                badge: t('role.clubPro.badge', 'Pro Club Hub'),
                desc: t('role.clubPro.desc', 'Effectif pro, budget mercato alloué, cibles prioritaires et demandes d\'essai directes.'),
                action: t('role.clubPro.action', 'Ouvrir Espace Club'),
              },
              {
                role: 'PLAYER',
                icon: '⚽',
                title: t('role.player.title', 'Joueurs & Talents'),
                badge: t('role.player.badge', 'Fiche Athlète'),
                desc: t('role.player.desc', 'Vidéos de match 90 min, radar athlétique, cotes marchandes et suivi des vues de clubs.'),
                action: t('role.player.action', 'Ouvrir Espace Joueur'),
              },
              {
                role: 'ACADEMY',
                icon: '🎓',
                title: t('role.academy.title', 'Académies de Football'),
                badge: t('role.academy.badge', 'Centres de Formation'),
                desc: t('role.academy.desc', 'Registre des pensionnaires U15-U21, convention de formation & passeport FIFA électronique.'),
                action: t('role.academy.action', 'Ouvrir Espace Académie'),
              },
              {
                role: 'COACH',
                icon: '📋',
                title: t('role.coach.title', 'Entraîneurs & Staff'),
                badge: t('role.coach.badge', 'Direction Tactique'),
                desc: t('role.coach.desc', 'Systèmes tactiques 4-3-3, analyse vidéo des séquences de match et progression athlétique.'),
                action: t('role.coach.action', 'Ouvrir Espace Coach'),
              },
              {
                role: 'SCOUT',
                icon: '🔍',
                title: t('role.scout.title', 'Scouts & Superviseurs'),
                badge: t('role.scout.badge', 'Scouting Terrain'),
                desc: t('role.scout.desc', 'Rapports d\'audit certifiés Eyeball, radar GPS, vitesse de pointe et missions régionales.'),
                action: t('role.scout.action', 'Ouvrir Espace Scout'),
              },
              {
                role: 'SPORTING_DIRECTOR',
                icon: '👔',
                title: t('role.sportingDirector.title', 'Directeurs Sportifs'),
                badge: t('role.sportingDirector.badge', 'Gestion Sportive'),
                desc: t('role.sportingDirector.desc', 'Valorisation globale d\'effectif, matrice de doublure poste par poste et balance mercato.'),
                action: t('role.sportingDirector.action', 'Ouvrir Espace Dir. Sportif'),
              },
              {
                role: 'FIFA_AGENT',
                icon: '💼',
                title: t('role.fifaAgent.title', 'Agents Licenciés FIFA'),
                badge: t('role.fifaAgent.badge', 'Licence FIFA #2024'),
                desc: t('role.fifaAgent.desc', 'Portefeuille de mandats exclusifs, conformité FFAR, sollicitations et transfert direct.'),
                action: t('role.fifaAgent.action', 'Ouvrir Espace Agent FIFA'),
              },
              {
                role: 'PRESIDENT',
                icon: '🏛️',
                title: t('role.president.title', 'Présidents de Club'),
                badge: t('role.president.badge', 'Haute Gouvernance'),
                desc: t('role.president.desc', 'Cockpit de décision institutionnelle, valorisation du club et partenariats internationaux.'),
                action: t('role.president.action', 'Ouvrir Espace Président'),
              },
              {
                role: 'RECRUITMENT_MANAGER',
                icon: '🎯',
                title: t('role.recruitment.title', 'Responsables Recrutement'),
                badge: t('role.recruitment.badge', 'Head of Recruitment'),
                desc: t('role.recruitment.desc', 'Pipeline de recrutement Kanban, délégation de missions terrain et validation d\'offres.'),
                action: t('role.recruitment.action', 'Ouvrir Espace Recrutement'),
              },
            ].map((item) => (
              <div
                key={item.role}
                className="p-4 rounded-xl bg-[#050810] border border-white/10 hover:border-amber-500/50 transition-all flex flex-col justify-between space-y-3 group"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl group-hover:scale-110 transition-transform">{item.icon}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30 font-bold">
                      {item.badge}
                    </span>
                  </div>
                  <h3 className="font-black text-white text-sm group-hover:text-amber-400 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    {item.desc}
                  </p>
                </div>

                <div className="pt-2 border-t border-white/5">
                  <button
                    onClick={() => onNavigate('dashboard', { role: item.role })}
                    className="w-full py-1.5 rounded-lg bg-white/5 hover:bg-amber-500 hover:text-black text-gray-300 font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                  >
                    {item.action} →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* METHODOLOGY: The 4 Pillars of Africa Talent Football */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
          <div className="inline-block text-[11px] font-mono font-bold uppercase text-amber-400 tracking-wider">
            {t('home.technicalDirection', 'Direction Technique Seydou Mario TRAORÉ')}
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            {t('method.title')}
          </h2>
          <p className="text-xs sm:text-sm text-gray-400 leading-relaxed">
            {t('method.subtitle')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 rounded-xl bg-[#080E1B] border border-white/10 hover:border-amber-500/50 transition-colors space-y-3">
            <div className="w-10 h-10 rounded bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-black text-sm">
              01
            </div>
            <h3 className="font-bold text-white text-sm">{t('method.pillar1_title')}</h3>
            <p className="text-xs text-gray-400 leading-relaxed">{t('method.pillar1_desc')}</p>
          </div>

          <div className="p-6 rounded-xl bg-[#080E1B] border border-white/10 hover:border-amber-500/50 transition-colors space-y-3">
            <div className="w-10 h-10 rounded bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-black text-sm">
              02
            </div>
            <h3 className="font-bold text-white text-sm">{t('method.pillar2_title')}</h3>
            <p className="text-xs text-gray-400 leading-relaxed">{t('method.pillar2_desc')}</p>
          </div>

          <div className="p-6 rounded-xl bg-[#080E1B] border border-white/10 hover:border-amber-500/50 transition-colors space-y-3">
            <div className="w-10 h-10 rounded bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-black text-sm">
              03
            </div>
            <h3 className="font-bold text-white text-sm">{t('method.pillar3_title')}</h3>
            <p className="text-xs text-gray-400 leading-relaxed">{t('method.pillar3_desc')}</p>
          </div>

          <div className="p-6 rounded-xl bg-[#080E1B] border border-white/10 hover:border-amber-500/50 transition-colors space-y-3">
            <div className="w-10 h-10 rounded bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-black text-sm">
              04
            </div>
            <h3 className="font-bold text-white text-sm">{t('method.pillar4_title')}</h3>
            <p className="text-xs text-gray-400 leading-relaxed">{t('method.pillar4_desc')}</p>
          </div>
        </div>
      </section>

      {/* TALENT SPOTLIGHT: CARDS & WYSCOUT TABULAR VIEW */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
              {t('home.databaseTitle', 'Base de Données Athlétique & Vidéo')}
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">
              {t('home.databaseSubtitle', 'Joueurs Enregistrés sur Africa Talent Football')}
            </h2>
            <p className="text-xs text-gray-400 mt-1">
              {t('home.databaseDesc', 'Chaque profil dispose de ses statistiques de saison, de sa valeur marchande estimée et de sa vidéo de match.')}
            </p>
          </div>

          {/* Controls: Position Filter Tabs + Display Mode Toggle */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Position filter */}
            <div className="flex items-center gap-1 p-1 bg-[#090E1B] rounded-lg border border-white/10">
              {[
                { id: 'ALL', label: t('catalog.all') },
                { id: 'ATT', label: t('catalog.forwards') },
                { id: 'MID', label: t('catalog.midfielders') },
                { id: 'DEF', label: t('catalog.defenders') },
                { id: 'GK', label: t('catalog.goalkeepers') },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActivePositionFilter(tab.id)}
                  className={`px-3 py-1.5 rounded text-xs font-bold transition-colors cursor-pointer ${
                    activePositionFilter === tab.id
                      ? 'bg-amber-500 text-black font-black'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Display toggle & Quick Actions */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center bg-[#090E1B] border border-white/10 rounded-lg p-1 text-xs">
                <button
                  onClick={() => setDisplayMode('CARDS')}
                  className={`px-3 py-1 rounded font-bold transition-colors ${
                    displayMode === 'CARDS' ? 'bg-white/15 text-white' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {t('home.viewCards', 'Cartes & Vidéo')}
                </button>
                <button
                  onClick={() => setDisplayMode('TABLE')}
                  className={`px-3 py-1 rounded font-bold transition-colors ${
                    displayMode === 'TABLE' ? 'bg-white/15 text-white' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {t('home.viewTable', 'Tableau Cote (Wyscout)')}
                </button>
              </div>

              {/* Quick Shortlist & Compare Buttons */}
              <button
                onClick={() => setIsFavoritesModalOpen(true)}
                className={`px-3 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95 ${
                  favorites.length > 0
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/60 hover:bg-amber-500/30'
                    : 'bg-[#090E1B] text-gray-400 border-white/10 hover:text-white'
                }`}
                title="Consulter ma sélection scouting"
              >
                <span className="text-amber-400">★</span>
                <span>Shortlist ({favorites.length})</span>
              </button>

              <button
                onClick={() => setIsComparisonModalOpen(true)}
                className={`px-3 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95 ${
                  comparisonIds.length > 0
                    ? 'bg-purple-600/25 text-purple-300 border-purple-500/60 hover:bg-purple-600/35'
                    : 'bg-[#090E1B] text-gray-400 border-white/10 hover:text-white'
                }`}
                title="Ouvrir le Face-à-Face Comparateur"
              >
                <span>⇄</span>
                <span>Face-à-Face ({comparisonIds.length})</span>
              </button>
            </div>
          </div>
        </div>

        {/* MODE 1: VISUAL CARDS & VIDEO TRIGGERS */}
        {displayMode === 'CARDS' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {displayedHomePlayers.map((player: RegisteredPlayer) => (
                <div
                  key={player.id}
                  className="bg-[#090E1B] rounded-xl border border-white/10 hover:border-amber-500/50 transition-all flex flex-col justify-between overflow-hidden shadow-xl group"
                >
                  <div>
                    {/* Photo Header with Position and Market Value Badges */}
                    <div className="relative h-60 bg-gray-950 overflow-hidden">
                      <img
                        src={getOptimizedImageUrl(player.avatarUrl, 'card')}
                        alt={`${player.firstName} ${player.lastName}`}
                        className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                        {...lazyImageProps}
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#090E1B] via-transparent to-transparent" />

                      {/* Position */}
                      <div className="absolute top-3 left-3 bg-black/85 border border-amber-500/60 px-2.5 py-1 rounded text-xs font-black text-amber-400 font-mono">
                        {player.primaryPosition}
                      </div>

                      {/* AI Certification badge on card photo */}
                      {player.aiCertification?.isCertified && (
                        <div className="absolute top-12 left-3 bg-emerald-950/90 border border-emerald-500/70 text-emerald-300 px-2 py-0.5 rounded text-[10px] font-bold font-mono flex items-center gap-1 shadow-md">
                          <span>🤖</span>
                          <span>Certifié IA</span>
                        </div>
                      )}

                    {/* Favorite Button on Card Photo */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(player.id);
                      }}
                      className={`absolute top-3 left-14 w-7 h-7 rounded-lg flex items-center justify-center text-xs transition-all shadow-md active:scale-90 cursor-pointer ${
                        isFavorite(player.id)
                          ? 'bg-amber-500 text-black border border-amber-300 shadow-amber-500/40 font-black'
                          : 'bg-black/75 text-gray-300 border border-white/20 hover:text-amber-300'
                      }`}
                      title={isFavorite(player.id) ? 'Retirer des favoris' : 'Ajouter à la shortlist'}
                    >
                      ★
                    </button>

                    {/* Market Value Tag */}
                    <div className="absolute top-3 right-3 bg-black/85 border border-emerald-500/60 px-3 py-1 rounded text-xs font-black text-emerald-400 font-mono shadow-md">
                      {player.marketValueDisplay}
                    </div>

                    {/* Direct Video Trigger button on photo */}
                    <button
                      onClick={() => openVideoModal(player)}
                      className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-amber-500/90 hover:bg-amber-400 text-black flex items-center justify-center font-black text-sm shadow-xl transition-transform hover:scale-110 active:scale-95 cursor-pointer"
                      title={t('home.watchVideo', 'Visionner les séquences vidéo')}
                    >
                      ▶
                    </button>

                    {player.isMinor && (
                      <div className="absolute bottom-3 left-3 bg-red-950/90 text-red-200 border border-red-700/60 px-2 py-0.5 rounded text-[10px] font-bold">
                        {t('player.fifaProtection', 'Mineur (Directive FIFA Art. 19)')}
                      </div>
                    )}
                  </div>

                  {/* Body Content */}
                  <div className="p-5 space-y-4">
                    <div>
                      <h3 className="text-lg font-black text-white group-hover:text-amber-400 transition-colors">
                        {player.firstName} {player.lastName}
                      </h3>
                      <div className="text-xs text-gray-400 flex items-center gap-1.5 mt-0.5 font-mono">
                        <span>{player.countryFlag} {player.nationality}</span>
                        <span aria-hidden="true">·</span>
                        <span>{player.calculatedAge} {t('player.age', 'ans')}</span>
                        <span aria-hidden="true">·</span>
                        <span>{player.heightCm} cm</span>
                        <span aria-hidden="true">·</span>
                        <span>{player.preferredFoot}</span>
                      </div>
                      <div className="text-xs text-gray-300 font-medium truncate mt-1">
                        {player.currentClub} ({player.academy})
                      </div>
                    </div>

                    {/* Statistics Matrix */}
                    <div className="grid grid-cols-4 gap-1.5 text-center text-xs bg-[#050810] p-2.5 rounded-lg border border-white/5">
                      <div>
                        <div className="text-white font-mono font-bold">{player.stats.matches}</div>
                        <div className="text-[9px] text-gray-500 uppercase">{t('stats.matches', 'Matchs')}</div>
                      </div>
                      <div>
                        <div className="text-white font-mono font-bold">{player.stats.minutes}'</div>
                        <div className="text-[9px] text-gray-500 uppercase">{t('stats.minutes', 'Min')}</div>
                      </div>
                      <div>
                        <div className="text-amber-400 font-mono font-bold">
                          {player.primaryPosition === 'GB' ? (player.stats.cleanSheets ?? 0) : player.stats.goals}
                        </div>
                        <div className="text-[9px] text-gray-500 uppercase">
                          {player.primaryPosition === 'GB' ? 'CS' : t('stats.goals', 'Buts')}
                        </div>
                      </div>
                      <div>
                        <div className="text-emerald-400 font-mono font-bold">
                          {player.stats.topSpeedKmh}
                        </div>
                        <div className="text-[9px] text-gray-500 uppercase">km/h</div>
                      </div>
                    </div>

                    {/* Scouting verdict quote */}
                    {player.scoutingReports.length > 0 && (
                      <div className="border-l-2 border-amber-500/60 pl-2.5 text-[11px] text-gray-300 italic line-clamp-2">
                        "{player.scoutingReports[0].summary}"
                      </div>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="p-5 pt-0 space-y-2">
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => openVideoModal(player)}
                      className="py-2.5 rounded-lg bg-[#0E1527] hover:bg-white/10 border border-amber-500/40 text-amber-300 hover:text-white font-black text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <span>▶ {t('home.watchVideo', 'Vidéo')}</span>
                    </button>
                    <button
                      onClick={() => onNavigate('player-detail', player)}
                      className="py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                    >
                      {t('home.fullProfile', 'Fiche')}
                    </button>
                    <button
                      onClick={() => toggleComparison(player.id)}
                      className={`py-2.5 rounded-lg border font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer active:scale-95 ${
                        isInComparison(player.id)
                          ? 'bg-purple-600 text-white border-purple-400 shadow-md shadow-purple-500/30'
                          : 'bg-[#0E1527] text-purple-300 border-purple-500/40 hover:bg-purple-600/20'
                      }`}
                      title={isInComparison(player.id) ? 'Retirer du comparateur' : 'Comparer ce joueur'}
                    >
                      <span>⇄</span>
                      <span>{isInComparison(player.id) ? 'Prêt' : 'Radar'}</span>
                    </button>
                  </div>

                  {onExportPdf && (
                    <button
                      onClick={() => onExportPdf(player)}
                      className="w-full py-2 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 hover:text-amber-200 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95"
                      title={t('home.exportPdf', 'Exporter en PDF')}
                    >
                      <span>📄</span>
                      <span>{t('home.exportPdf', 'Exporter en PDF')}</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
            </div>

            {filteredPlayers.length > visibleHomePlayersLimit && (
              <div className="pt-2 text-center">
                <button
                  onClick={() => setVisibleHomePlayersLimit((prev) => prev + 6)}
                  className="px-6 py-3 rounded-xl bg-[#0E1527] hover:bg-amber-500 hover:text-black border border-amber-500/40 text-amber-300 font-bold text-xs uppercase tracking-wider transition-all cursor-pointer shadow-lg active:scale-95"
                >
                  Afficher plus de talents ({filteredPlayers.length - visibleHomePlayersLimit} restants) ↓
                </button>
              </div>
            )}
          </div>
        )}

        {/* MODE 2: WYSCOUT / TRANSFERMARKT HIGH DENSITY DATA TABLE */}
        {displayMode === 'TABLE' && (
          <div className="bg-[#090E1B] rounded-xl border border-white/10 overflow-x-auto shadow-2xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#050810] border-b border-white/10 text-gray-400 font-mono uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">{t('home.tablePlayer', 'Joueur')} / {t('home.tablePos', 'Poste')}</th>
                  <th className="py-3 px-4">{t('home.tableAge', 'Âge')}</th>
                  <th className="py-3 px-4">{t('home.tableClub', 'Club / Académie')}</th>
                  <th className="py-3 px-4 text-center">{t('stats.matches', 'Matchs')}</th>
                  <th className="py-3 px-4 text-center">{t('stats.goals', 'Buts')} / CS</th>
                  <th className="py-3 px-4 text-center">{t('stats.assists', 'Passes')}</th>
                  <th className="py-3 px-4 text-center">{t('stats.passAccuracy', 'Précision')}</th>
                  <th className="py-3 px-4 text-center">{t('home.tableSpeed', 'Vitesse Max')}</th>
                  <th className="py-3 px-4 text-right">{t('home.tableValue', 'Valeur Marchande')}</th>
                  <th className="py-3 px-4 text-center">{t('home.tableActions', 'Actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-sans">
                {filteredPlayers.map((player) => (
                  <tr key={player.id} className="hover:bg-white/5 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={player.avatarUrl}
                          alt={player.firstName}
                          className="w-8 h-8 rounded object-cover"
                        />
                        <div>
                          <div className="font-bold text-white">
                            {player.firstName} {player.lastName}
                          </div>
                          <span className="text-[10px] text-amber-400 font-mono font-bold">
                            {player.primaryPosition} · {player.countryFlag}
                          </span>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-gray-300">{player.calculatedAge} {t('player.age', 'ans')}</td>
                    <td className="py-3 px-4 text-gray-300">{player.currentClub}</td>
                    <td className="py-3 px-4 text-center font-mono tabular-nums text-white">
                      {player.stats.matches}
                    </td>
                    <td className="py-3 px-4 text-center font-mono tabular-nums text-amber-400 font-bold">
                      {player.primaryPosition === 'GB' ? (player.stats.cleanSheets ?? 0) : player.stats.goals}
                    </td>
                    <td className="py-3 px-4 text-center font-mono tabular-nums text-white">
                      {player.stats.assists}
                    </td>
                    <td className="py-3 px-4 text-center font-mono tabular-nums text-gray-300">
                      {player.stats.passAccuracyPct}%
                    </td>
                    <td className="py-3 px-4 text-center font-mono tabular-nums text-emerald-400 font-bold">
                      {player.stats.topSpeedKmh} km/h
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-black text-emerald-400 text-sm">
                      {player.marketValueDisplay}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        {/* Favorite button */}
                        <button
                          onClick={() => toggleFavorite(player.id)}
                          className={`p-1 rounded text-xs transition-colors cursor-pointer ${
                            isFavorite(player.id)
                              ? 'text-amber-400 bg-amber-500/20'
                              : 'text-gray-500 hover:text-amber-400'
                          }`}
                          title={isFavorite(player.id) ? 'Retirer des favoris' : 'Ajouter à la shortlist'}
                        >
                          ★
                        </button>

                        {/* Compare button */}
                        <button
                          onClick={() => toggleComparison(player.id)}
                          className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold transition-colors cursor-pointer border ${
                            isInComparison(player.id)
                              ? 'bg-purple-600 text-white border-purple-400'
                              : 'text-purple-300 border-purple-500/40 hover:bg-purple-600/20'
                          }`}
                          title="Comparer"
                        >
                          ⇄
                        </button>

                        <button
                          onClick={() => openVideoModal(player)}
                          className="px-2 py-1 rounded bg-[#0E1527] hover:bg-amber-500 hover:text-black text-amber-300 font-bold text-[10px] uppercase transition-colors"
                        >
                          ▶ {t('home.watchVideo', 'Vidéo')}
                        </button>
                        <button
                          onClick={() => onNavigate('player-detail', player)}
                          className="px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-white font-bold text-[10px] uppercase transition-colors"
                        >
                          {t('home.fullProfile', 'Fiche')}
                        </button>
                        {onExportPdf && (
                          <button
                            onClick={() => onExportPdf(player)}
                            className="px-2 py-1 rounded bg-amber-500/20 hover:bg-amber-500 hover:text-black text-amber-300 font-bold text-[10px] uppercase transition-colors"
                            title={t('home.exportPdf', 'Exporter en PDF')}
                          >
                            📄 PDF
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="text-center mt-10">
          <button
            onClick={() => onNavigate('players')}
            className="px-7 py-3 rounded-lg bg-[#090E1B] hover:bg-white/10 border border-white/20 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
          >
            {t('home.viewAllDatabase', 'Consulter toute la base de données & vidéos →')}
          </button>
        </div>
      </section>

      {/* FOUNDER & SCOUT AGENT PROFILE: SEYDOU MARIO TRAORÉ */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#090E1B] rounded-2xl border border-amber-500/30 overflow-hidden p-6 sm:p-10 shadow-2xl relative">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
            <div className="space-y-4 text-center md:text-left">
              <div className="w-52 h-52 sm:w-60 sm:h-60 mx-auto md:mx-0 rounded-2xl overflow-hidden border-2 border-amber-500/50 shadow-2xl bg-black">
                <img
                  src={(typeof window !== 'undefined' ? localStorage.getItem('atf_founder_custom_photo') : null) || '/founder_africa_talent.jpg'}
                  alt={FOUNDER_INFO.name}
                  className="w-full h-full object-cover object-[50%_20%]"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (target.src !== ASSETS.founder) {
                      target.src = ASSETS.founder;
                    }
                  }}
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

            <div className="md:col-span-2 space-y-4">
              <div className="inline-block text-[11px] font-mono font-bold uppercase tracking-widest text-amber-400 bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded">
                {t('home.founderSupervision', 'Direction & Supervision Technique')}
              </div>

              <h2 className="text-3xl sm:text-4xl font-black text-white">
                {FOUNDER_INFO.name}
              </h2>
              <div className="text-sm font-bold text-amber-400 font-mono">
                {FOUNDER_INFO.officialTitle}
              </div>

              <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
                {t('home.founderQuote')}
              </p>

              <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded bg-[#050810] border border-white/10">
                  <span className="text-gray-500 block text-[10px] uppercase font-bold">{t('home.whatsappDesk', 'Desk Direct WhatsApp')}</span>
                  <a href={FOUNDER_INFO.whatsappUrl} target="_blank" rel="noopener noreferrer" className="text-amber-400 font-bold hover:underline font-mono">
                    {FOUNDER_INFO.phone}
                  </a>
                </div>
                <div className="p-3 rounded bg-[#050810] border border-white/10">
                  <span className="text-gray-500 block text-[10px] uppercase font-bold">{t('home.officialEmail', 'Courriel Officiel')}</span>
                  <a href={`mailto:${FOUNDER_INFO.email}`} className="text-white font-mono hover:text-amber-400">
                    {FOUNDER_INFO.email}
                  </a>
                </div>
              </div>

              <div className="pt-4 flex flex-wrap gap-3">
                <button
                  onClick={() => onNavigate('founder')}
                  className="px-6 py-2.5 rounded bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  {t('home.viewTechnicalDossier', 'Consulter le Dossier Technique')}
                </button>
                <a
                  href={`${FOUNDER_INFO.whatsappUrl}?text=Bonjour%20M.%20Seydou%20Mario%20TRAOR%C3%A9%2C%20je%20vous%20contacte%20depuis%20Africa%20Talent%20Football.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-2.5 rounded bg-[#050810] hover:bg-white/10 border border-amber-500/40 text-amber-300 font-bold text-xs uppercase tracking-wider transition-colors"
                >
                  {t('home.contactWhatsApp', 'Contacter via WhatsApp')}
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* UPCOMING SHOWCASES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
              {t('home.upcomingShowcases', 'Agenda Détections & Essais')}
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">
              {t('home.upcomingTitle', 'Sessions de Détection Supervisées')}
            </h2>
            <p className="text-xs text-gray-400 mt-1">
              {t('home.upcomingSubtitle', 'Tournois et showcases officiels sous supervision de Seydou Mario TRAORÉ.')}
            </p>
          </div>

          <button
            onClick={() => onNavigate('opportunities')}
            className="text-xs font-bold text-amber-400 hover:underline cursor-pointer"
          >
            {t('home.viewAllEvents', 'Voir tous les événements →')}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {DEMO_OPPORTUNITIES.map((opp) => (
            <div
              key={opp.id}
              className="p-6 rounded-xl bg-[#090E1B] border border-white/10 flex flex-col justify-between space-y-4 hover:border-amber-500/50 transition-colors shadow-lg"
            >
              <div className="space-y-3">
                <div className="flex justify-between items-start">
                  <span className="text-xs font-mono font-bold text-amber-400">{opp.category}</span>
                  <span className="text-[10px] font-black px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                    {opp.status.replace('_', ' ')}
                  </span>
                </div>

                <h3 className="font-bold text-white text-base">{opp.title}</h3>
                <p className="text-xs text-gray-400 leading-relaxed">{opp.description}</p>

                <div className="text-[11px] text-gray-400 space-y-1 pt-2 border-t border-white/10">
                  <div className="flex justify-between">
                    <span className="text-gray-500">{t('home.location', 'Lieu')} :</span>
                    <span className="font-semibold text-white">{opp.location}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">{t('home.dates', 'Dates')} :</span>
                    <span className="font-semibold text-white">{opp.date}</span>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => onNavigate('register')}
                  className="w-full py-2.5 rounded bg-[#050810] hover:bg-amber-500 hover:text-black border border-amber-500/40 text-amber-300 text-xs font-black uppercase tracking-wider transition-colors cursor-pointer"
                >
                  {t('home.applyShowcase', 'Candidater à cette détection')}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
