import React, { useState } from 'react';
import { usePayment, PRICING_PLANS, CURRENCY_RATES } from '../../context/PaymentContext';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { CurrencyCode, BillingInterval } from '../../types/database';
import { FOUNDER_INFO } from '../../data/demoData';

interface PricingPageProps {
  onNavigate: (view: string, payload?: any) => void;
}

export const PricingPage: React.FC<PricingPageProps> = ({ onNavigate }) => {
  const { currentUser, isPremium, toggleSimulatePremium, upgradeToPremium } = useAuth();
  const {
    currency,
    setCurrency,
    formatPrice,
    openCheckout,
    activeSubscription,
    cancelSubscription
  } = usePayment();
  const { t } = useLanguage();

  const [interval, setInterval] = useState<BillingInterval>('ANNUAL');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* HEADER & VALUE PROPOSITION */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-widest text-amber-400 bg-amber-500/10 border border-amber-500/30 px-3.5 py-1 rounded">
          {t('pricing.badge', '★ Modèle de Monétisation B2B & Abonnements Internationaux')}
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
          {t('pricing.title', 'Passez au Niveau Supérieur sur Africa Talent Football')}
        </h1>

        <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
          {t('pricing.subtitle', `Accédez aux vidéos complètes de match, aux données athlétiques GPS certifiées et connectez-vous directement avec les cellules de recrutement professionnelles sous la supervision de ${FOUNDER_INFO.name}.`)}
        </p>

        {/* Global Currency & Billing Interval Controls */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
          {/* Currency selector */}
          <div className="flex items-center gap-2 bg-[#090E1B] border border-white/10 px-3 py-1.5 rounded-xl">
            <span className="text-[11px] text-gray-400 font-mono">{t('pricing.currency', 'Devise :')}</span>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
              className="bg-transparent text-amber-400 font-mono font-bold text-xs focus:outline-none cursor-pointer"
            >
              {Object.entries(CURRENCY_RATES).map(([code, info]) => (
                <option key={code} value={code} className="bg-[#050810] text-white">
                  {info.symbol} - {code}
                </option>
              ))}
            </select>
          </div>

          {/* Monthly / Annual Toggle */}
          <div className="flex items-center bg-[#090E1B] border border-white/10 p-1 rounded-xl text-xs">
            <button
              onClick={() => setInterval('MONTHLY')}
              className={`px-4 py-1.5 rounded-lg font-bold transition-colors cursor-pointer ${
                interval === 'MONTHLY' ? 'bg-amber-500 text-black' : 'text-gray-400 hover:text-white'
              }`}
            >
              {t('pricing.monthly', 'Mensuel')}
            </button>
            <button
              onClick={() => setInterval('ANNUAL')}
              className={`px-4 py-1.5 rounded-lg font-bold transition-colors flex items-center gap-1.5 cursor-pointer ${
                interval === 'ANNUAL' ? 'bg-amber-500 text-black' : 'text-gray-400 hover:text-white'
              }`}
            >
              <span>{t('pricing.annual', 'Annuel')}</span>
              <span className="px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 text-[10px] border border-emerald-800 font-mono">
                {t('pricing.discount20', '-20%')}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* VOLUNTARY MEMBERSHIP & PREMIUM COMPARISON BANNER */}
      <div className="max-w-4xl mx-auto p-6 rounded-3xl bg-gradient-to-r from-[#0C152B] via-[#091022] to-[#0A1A2E] border-2 border-amber-500/40 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl">🤝</span>
              <h2 className="text-base sm:text-lg font-black text-white">Principe Fondamental : Inscription Gratuite & Volontaire</h2>
            </div>
            <p className="text-xs text-gray-300 mt-1">
              Sur Africa Talent Football, l'inscription est 100% libre et gratuite pour tous (joueurs, académies, clubs, agents, scouts). 
              L'abonnement Premium est entièrement <strong>volontaire</strong> et réservé aux membres souhaitant un accès direct prioritaire avec la direction de la plateforme et les membres VIP.
            </p>
          </div>
          <button
            onClick={() => toggleSimulatePremium()}
            className="shrink-0 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md"
          >
            {isPremium ? '👑 Mode VIP Actif (Tester Gratuit)' : '★ Tester le Statut Premium'}
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
          <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white uppercase">🟢 Inscription Gratuite (0 €)</span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px]">Pour Tous</span>
            </div>
            <ul className="text-gray-300 space-y-1 text-[11px]">
              <li>✓ Création et gestion complète de profil officiel</li>
              <li>✓ Publication de posts, actualités et vidéos sur le fil réseau</li>
              <li>✓ Recommandations et commentaires sur les publications</li>
              <li>✓ Consultation de l'annuaire mondial et fiches talents</li>
            </ul>
          </div>

          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-400/50 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-amber-300 uppercase">👑 Abonnement Premium VIP</span>
              <span className="px-2 py-0.5 rounded bg-amber-500 text-black text-[10px] font-bold">Volontaire</span>
            </div>
            <ul className="text-amber-100 space-y-1 text-[11px]">
              <li>★ <strong>Ligne directe avec la plateforme</strong> (Seydou Mario TRAORÉ au {FOUNDER_INFO.phone})</li>
              <li>★ <strong>Contact direct B2B</strong> avec les membres Premium et clubs pros</li>
              <li>★ <strong>Badge VIP Doré Vérifié</strong> sur vos posts et fiches</li>
              <li>★ <strong>Audit technique prioritaire</strong> sous 48 heures ouvrées</li>
            </ul>
          </div>
        </div>
      </div>

      {/* ACTIVE SUBSCRIPTION ALERT IF ANY */}
      {activeSubscription && activeSubscription.status === 'ACTIVE' && (
        <div className="max-w-3xl mx-auto p-4 rounded-xl bg-gradient-to-r from-emerald-950/80 via-black to-[#090E1B] border border-emerald-500/60 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🎖️</span>
            <div>
              <div className="font-bold text-white text-sm">
                {t('pricing.activePlanAlert', 'Vous disposez d\'un abonnement actif :')} <span className="text-emerald-400">{activeSubscription.tier}</span>
              </div>
              <p className="text-[11px] text-gray-400 font-mono">
                Facture #{activeSubscription.invoiceId} · Valide jusqu'au {activeSubscription.expiresAt} ({activeSubscription.paymentMethod.details})
              </p>
            </div>
          </div>
          <button
            onClick={cancelSubscription}
            className="text-[11px] text-red-400 hover:text-red-300 underline font-mono cursor-pointer"
          >
            {t('pricing.cancelSub', 'Résilier l\'abonnement')}
          </button>
        </div>
      )}

      {/* 4 WORLDWIDE PRICING TIERS */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {PRICING_PLANS.map((plan) => {
          const priceEur = interval === 'ANNUAL' ? plan.annualEur : plan.monthlyEur;
          const isCurrent = activeSubscription?.tier === plan.id && activeSubscription.status === 'ACTIVE';

          return (
            <div
              key={plan.id}
              className={`rounded-2xl border flex flex-col justify-between p-6 transition-all shadow-2xl relative ${
                plan.highlight
                  ? 'bg-[#0E1528] border-amber-500 shadow-amber-500/10 ring-1 ring-amber-500'
                  : 'bg-[#090E1B] border-white/10 hover:border-white/20'
              }`}
            >
              {plan.badge && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-amber-500 text-black font-black text-[9px] uppercase tracking-wider shadow-md whitespace-nowrap">
                  {plan.badge}
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <h3 className="font-black text-white text-lg">{plan.title}</h3>
                  <p className="text-[11px] text-gray-400 leading-tight mt-1 min-h-[32px]">
                    {plan.targetAudience}
                  </p>
                </div>

                {/* Price Display */}
                <div className="pt-2 border-t border-white/10">
                  <div className="text-2xl sm:text-3xl font-black text-white font-mono">
                    {formatPrice(priceEur, interval)}
                  </div>
                  <span className="text-[10px] text-gray-500 font-mono">
                    {interval === 'ANNUAL' ? t('pricing.billedOnce', 'Facturé en 1 fois (économie 20%)') : t('pricing.billedNoCommitment', 'Facturation sans engagement')}
                  </span>
                </div>

                {/* Concrete Deliverables Matrix */}
                <div className="p-3 rounded-xl bg-[#050810] border border-white/5 text-[10px] space-y-1.5 font-mono">
                  <div className="flex justify-between">
                    <span className="text-gray-500">{t('pricing.videoLibrary', 'Vidéothèque :')}</span>
                    <span className="text-amber-300 font-bold">{plan.deliverables.videoUploadLimit}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">{t('pricing.scoutAudit', 'Audit Scout :')}</span>
                    <span className="text-white font-medium">{plan.deliverables.scoutingAudit}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">{t('pricing.deskLine', 'Ligne Desk :')}</span>
                    <span className="text-emerald-400 font-bold">{plan.deliverables.directDeskAccess}</span>
                  </div>
                </div>

                {/* Features List */}
                <ul className="space-y-2 text-xs text-gray-300 pt-2 border-t border-white/5">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-amber-400 font-bold shrink-0">✓</span>
                      <span className="leading-snug text-[11px]">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Button */}
              <div className="pt-6">
                {isCurrent ? (
                  <button
                    disabled
                    className="w-full py-3 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold text-xs uppercase"
                  >
                    {t('pricing.currentActiveBadge', 'Formule Active ✓')}
                  </button>
                ) : (
                  <button
                    onClick={() => openCheckout(plan.id)}
                    className={`w-full py-3 rounded-lg font-black text-xs uppercase tracking-wider transition-all cursor-pointer shadow-lg ${
                      plan.highlight
                        ? 'bg-amber-500 hover:bg-amber-400 text-black shadow-amber-500/20'
                        : 'bg-white/10 hover:bg-white/20 text-white'
                    }`}
                  >
                    {t('pricing.subscribeNow', 'Souscrire Maintenant')}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* WORLDWIDE PAYMENT METHODS GUARANTEE */}
      <div className="p-8 rounded-2xl bg-[#090E1B] border border-white/10 shadow-xl space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-1">
          <span className="text-xs font-mono font-bold uppercase text-amber-400">
            {t('pricing.gatewaysTag', 'Disponibilité Mondiale & Passerelles Certifiées')}
          </span>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            {t('pricing.gatewaysTitle', 'Payez en Toute Sécurité Depuis N’importe Quel Pays')}
          </h2>
          <p className="text-xs text-gray-400">
            {t('pricing.gatewaysDesc', 'Africa Talent Football accepte l’ensemble des moyens de paiement internationaux et régionaux pour faciliter l\'accès des athlètes et des clubs.')}
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          <div className="p-4 rounded-xl bg-[#050810] border border-white/5 space-y-1.5">
            <div className="text-2xl">💳</div>
            <div className="font-bold text-white text-xs">{t('pricing.intlCards', 'Cartes Internationales')}</div>
            <p className="text-[10px] text-gray-400">{t('pricing.intlCardsDesc', 'Visa, Mastercard, American Express (Monde entier)')}</p>
          </div>

          <div className="p-4 rounded-xl bg-[#050810] border border-white/5 space-y-1.5">
            <div className="text-2xl">📱</div>
            <div className="font-bold text-white text-xs">{t('pricing.mobileMoney', 'Mobile Money Africain')}</div>
            <p className="text-[10px] text-gray-400">{t('pricing.mobileMoneyDesc', 'Wave, Orange Money, MTN MoMo, Moov (UEMOA / CEMAC)')}</p>
          </div>

          <div className="p-4 rounded-xl bg-[#050810] border border-white/5 space-y-1.5">
            <div className="text-2xl">🅿️</div>
            <div className="font-bold text-white text-xs">{t('pricing.paypalApple', 'PayPal & Apple Pay')}</div>
            <p className="text-[10px] text-gray-400">{t('pricing.paypalAppleDesc', 'Paiement express 1-clic mondial')}</p>
          </div>

          <div className="p-4 rounded-xl bg-[#050810] border border-white/5 space-y-1.5">
            <div className="text-2xl">🏦</div>
            <div className="font-bold text-white text-xs">{t('pricing.b2bTransfer', 'Virements B2B SEPA & SWIFT')}</div>
            <p className="text-[10px] text-gray-400">{t('pricing.b2bTransferDesc', 'Pour clubs professionnels, avec facturation pro-forma')}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
