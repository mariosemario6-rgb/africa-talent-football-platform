import React, { useState, useMemo } from 'react';
import { usePlayers } from '../../context/PlayerContext';
import { useNetwork } from '../../context/NetworkContext';
import { RegisteredPlayer, FootballClub, FootballProfessional, FootballCompany } from '../../types/database';
import { formatMarketValue, FOUNDER_INFO } from '../../data/demoData';
import { matchesQuery } from '../../utils/searchEngine';
import { useLanguage } from '../../context/LanguageContext';

interface SearchPageProps {
  onNavigate: (view: string, payload?: any) => void;
  initialQuery?: string;
  onExportPdf?: (player: RegisteredPlayer) => void;
}

type SearchCategory = 'ALL' | 'CLUBS' | 'PRESIDENTS' | 'DIRECTORS' | 'COACHES' | 'PLAYERS' | 'COMPANIES';

export const SearchPage: React.FC<SearchPageProps> = ({ onNavigate, initialQuery = '', onExportPdf }) => {
  const { t, tPosition, tFoot, tRole, formatNumber } = useLanguage();
  const { players, openVideoModal, favorites, toggleFavorite, isFavorite, comparisonIds, toggleComparison, isInComparison } = usePlayers();
  const { clubs, professionals, companies, createDirectConversation, globalSearch, setGlobalSearch } = useNetwork();

  const [activeCategory, setActiveCategory] = useState<SearchCategory>('ALL');
  const [selectedCountry, setSelectedCountry] = useState<string>('ALL');

  // Query is synced with globalSearch
  const query = globalSearch || initialQuery;

  const handleQueryChange = (val: string) => {
    setGlobalSearch(val);
  };

  // Filtered Players
  const matchedPlayers = useMemo(() => {
    return players.filter((p) => {
      const searchBlob = `${p.firstName} ${p.lastName} ${p.primaryPosition} ${p.secondaryPosition || ''} ${p.academy} ${p.currentClub || ''} ${p.nationality} ${p.preferredFoot} ${p.bio} ${p.contractStatus}`;
      const matchesText = matchesQuery(searchBlob, query);
      const matchesCountry = selectedCountry === 'ALL' || p.nationality === selectedCountry;
      return matchesText && matchesCountry;
    });
  }, [players, query, selectedCountry]);

  // Filtered Clubs
  const matchedClubs = useMemo(() => {
    return clubs.filter((c) => {
      const searchBlob = `${c.name} ${c.league} ${c.division} ${c.country} ${c.city} ${c.president} ${c.sportingDirector} ${c.headCoach} ${c.headOfRecruitment || ''} ${c.openNeeds.join(' ')} ${c.description}`;
      const matchesText = matchesQuery(searchBlob, query);
      const matchesCountry = selectedCountry === 'ALL' || c.country === selectedCountry;
      return matchesText && matchesCountry;
    });
  }, [clubs, query, selectedCountry]);

  // Filtered Presidents
  const matchedPresidents = useMemo(() => {
    const list = professionals.filter((p) => p.role === 'PRESIDENT');
    return list.filter((p) => {
      const searchBlob = `${p.name} ${p.title} ${p.clubOrOrg} ${p.country} ${p.bio}`;
      const matchesText = matchesQuery(searchBlob, query);
      const matchesCountry = selectedCountry === 'ALL' || p.country === selectedCountry;
      return matchesText && matchesCountry;
    });
  }, [professionals, query, selectedCountry]);

  // Filtered Directors
  const matchedDirectors = useMemo(() => {
    const list = professionals.filter((p) => p.role === 'SPORTING_DIRECTOR' || p.role === 'CHIEF_SCOUT' || p.role === 'SCOUT_AGENT');
    return list.filter((p) => {
      const searchBlob = `${p.name} ${p.title} ${p.clubOrOrg} ${p.country} ${p.bio}`;
      const matchesText = matchesQuery(searchBlob, query);
      const matchesCountry = selectedCountry === 'ALL' || p.country === selectedCountry;
      return matchesText && matchesCountry;
    });
  }, [professionals, query, selectedCountry]);

  // Filtered Coaches
  const matchedCoaches = useMemo(() => {
    const list = professionals.filter((p) => p.role === 'HEAD_COACH');
    return list.filter((p) => {
      const searchBlob = `${p.name} ${p.title} ${p.clubOrOrg} ${p.country} ${p.bio}`;
      const matchesText = matchesQuery(searchBlob, query);
      const matchesCountry = selectedCountry === 'ALL' || p.country === selectedCountry;
      return matchesText && matchesCountry;
    });
  }, [professionals, query, selectedCountry]);

  // Filtered Companies
  const matchedCompanies = useMemo(() => {
    return companies.filter((c) => {
      const searchBlob = `${c.name} ${c.category} ${c.country} ${c.contactPerson} ${c.description} ${c.partnershipOpportunities.join(' ')}`;
      const matchesText = matchesQuery(searchBlob, query);
      const matchesCountry = selectedCountry === 'ALL' || c.country.includes(selectedCountry);
      return matchesText && matchesCountry;
    });
  }, [companies, query, selectedCountry]);

  const totalResultsCount =
    (activeCategory === 'ALL' || activeCategory === 'PLAYERS' ? matchedPlayers.length : 0) +
    (activeCategory === 'ALL' || activeCategory === 'CLUBS' ? matchedClubs.length : 0) +
    (activeCategory === 'ALL' || activeCategory === 'PRESIDENTS' ? matchedPresidents.length : 0) +
    (activeCategory === 'ALL' || activeCategory === 'DIRECTORS' ? matchedDirectors.length : 0) +
    (activeCategory === 'ALL' || activeCategory === 'COACHES' ? matchedCoaches.length : 0) +
    (activeCategory === 'ALL' || activeCategory === 'COMPANIES' ? matchedCompanies.length : 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-left">
      {/* HEADER */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
            {t('search.indexSystem', "Système d'Indexation Mondiale")}
          </span>
          <h1 className="text-3xl font-black text-white mt-1">
            {t('search.officialTitle', 'Moteur de Recherche Officiel Africa Talent Football')}
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            {t('search.subtitle', "Recherchez instantanément parmi l'ensemble des clubs mondiaux, présidents, directeurs sportifs, entraîneurs, talents africains et entreprises partenaires.")}
          </p>
        </div>

        <button
          onClick={() => onNavigate('pricing')}
          className="px-4 py-2 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer self-start md:self-auto"
        >
          ★ {t('pricing.upgradePremium', 'Passer Premium Pro')}
        </button>
      </div>

      {/* SEARCH CONTROL BAR */}
      <div className="p-5 rounded-2xl bg-[#090E1B] border border-white/10 space-y-4 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Main search input */}
          <div className="relative md:col-span-2">
            <input
              type="text"
              value={query}
              onChange={(e) => handleQueryChange(e.target.value)}
              placeholder={t('search.placeholder', 'Rechercher un club, président, directeur sportif, entraîneur, joueur ou marque...')}
              className="w-full px-4 py-3 pl-11 rounded-xl bg-[#050810] border border-white/15 text-white text-sm focus:border-amber-500 focus:outline-none placeholder:text-gray-500 shadow-inner"
              autoFocus
            />
            <span className="absolute left-3.5 top-3.5 text-gray-400 text-base">🔍</span>
            {query && (
              <button
                onClick={() => handleQueryChange('')}
                className="absolute right-3.5 top-3 text-gray-400 hover:text-white p-1 text-xs rounded-full hover:bg-white/10"
                title={t('common.cancel', 'Effacer')}
              >
                ✕
              </button>
            )}

            {/* SEARCH BUTTON PLACED JUST BELOW SEARCH ENGINE */}
            <div className="flex flex-wrap items-center gap-2 mt-2.5">
              <button
                type="button"
                className="px-4 py-2 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-md shadow-amber-500/20 active:scale-95 transition-all cursor-pointer border border-amber-300"
                title={t('common.search', 'Lancer la recherche')}
              >
                <span>🔍</span>
                <span>{t('common.search', 'Rechercher')} ({formatNumber(totalResultsCount)})</span>
              </button>
              {query && (
                <button
                  type="button"
                  onClick={() => handleQueryChange('')}
                  className="px-3 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white text-xs font-mono transition-colors cursor-pointer"
                >
                  ✕ {t('search.clearFilters', 'Réinitialiser')}
                </button>
              )}
              <span className="text-[11px] text-gray-400 font-mono hidden sm:inline">
                {formatNumber(clubs.length)} {t('search.catClubs', 'Clubs')} · {formatNumber(players.length)} {t('search.catPlayers', 'Talents')}
              </span>
            </div>
          </div>

          {/* Country Selector */}
          <div>
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-[#050810] border border-white/15 text-white text-xs focus:border-amber-500 focus:outline-none"
            >
              <option value="ALL">{t('common.allCountries', 'Tous les Pays & Confédérations')}</option>
              <option value="Belgique">🇧🇪 Belgique</option>
              <option value="France">🇫🇷 France</option>
              <option value="Angleterre">🇬🇧 Angleterre</option>
              <option value="Portugal">🇵🇹 Portugal</option>
              <option value="Espagne">🇪🇸 Espagne</option>
              <option value="Suisse">🇨🇭 Suisse</option>
              <option value="Côte d'Ivoire">🇨🇮 Côte d'Ivoire</option>
              <option value="Égypte">🇪🇬 Égypte</option>
              <option value="RD Congo">🇨🇩 RD Congo</option>
              <option value="Mali">🇲🇱 Mali</option>
            </select>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          {[
            { id: 'ALL', label: `${t('search.catAll', 'Tout')} (${formatNumber(totalResultsCount)})` },
            { id: 'CLUBS', label: `${t('search.catClubs', 'Clubs')} (${formatNumber(matchedClubs.length)})` },
            { id: 'PRESIDENTS', label: `${t('search.catPresidents', 'Présidents')} (${formatNumber(matchedPresidents.length)})` },
            { id: 'DIRECTORS', label: `${t('search.catDirectors', 'Directeurs')} (${formatNumber(matchedDirectors.length)})` },
            { id: 'COACHES', label: `${t('search.catCoaches', 'Entraîneurs')} (${formatNumber(matchedCoaches.length)})` },
            { id: 'PLAYERS', label: `${t('search.catPlayers', 'Talents')} (${formatNumber(matchedPlayers.length)})` },
            { id: 'COMPANIES', label: `${t('search.catCompanies', 'Entreprises')} (${formatNumber(matchedCompanies.length)})` },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveCategory(tab.id as SearchCategory)}
              className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-colors cursor-pointer text-xs ${
                activeCategory === tab.id
                  ? 'bg-amber-500 text-black font-black shadow-md shadow-amber-500/20'
                  : 'bg-[#050810] text-gray-400 hover:text-white border border-white/5'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Suggested Queries */}
        <div className="flex flex-wrap items-center gap-2 pt-2 text-xs text-gray-400">
          <span className="text-[11px] font-mono text-amber-400 font-bold uppercase">Recherches Populaires :</span>
          {[
            'Standard de Liège',
            'Stade Rennais',
            'Brighton',
            'ASEC Mimosas',
            'Al Ahly',
            'Will Still',
            'Dimitri de Condé',
            'Attaquant U19',
            'Wyscout',
            'Seydou Mario TRAORÉ',
          ].map((tag) => (
            <button
              key={tag}
              onClick={() => handleQueryChange(tag)}
              className="px-2.5 py-1 rounded-full bg-white/5 hover:bg-amber-500/20 hover:text-amber-300 border border-white/5 hover:border-amber-500/30 transition-colors cursor-pointer text-[11px]"
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      {/* RESULTS COUNT BANNER */}
      <div className="flex items-center justify-between text-xs text-gray-400 px-1 font-mono">
        <span>
          {totalResultsCount} résultat(s) trouvé(s) {query ? `pour « ${query} »` : 'au total'}
        </span>
        {query && (
          <button
            onClick={() => handleQueryChange('')}
            className="text-amber-400 hover:underline cursor-pointer"
          >
            Réinitialiser la recherche
          </button>
        )}
      </div>

      {/* RESULTS SECTIONS */}
      {totalResultsCount === 0 && (
        <div className="p-16 rounded-3xl bg-[#090E1B] border border-white/10 text-center space-y-4">
          <span className="text-5xl block">🔎</span>
          <h2 className="text-xl font-bold text-white">Aucun résultat trouvé pour cette recherche</h2>
          <p className="text-xs text-gray-400 max-w-md mx-auto">
            Vérifiez l'orthographe ou essayez un mot-clé plus générique tel que « Belgique », « France », « Buteur », « Entraîneur » ou « Wyscout ».
          </p>
          <button
            onClick={() => handleQueryChange('')}
            className="px-5 py-2 rounded-lg bg-amber-500 text-black font-bold text-xs uppercase cursor-pointer"
          >
            Afficher Tous les Éléments
          </button>
        </div>
      )}

      {/* 1. CLUBS SECTION */}
      {(activeCategory === 'ALL' || activeCategory === 'CLUBS') && matchedClubs.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-white uppercase font-mono flex items-center gap-2">
              <span>🏟️ Clubs Professionnels ({matchedClubs.length})</span>
            </h2>
            <button
              onClick={() => onNavigate('directory')}
              className="text-xs text-amber-400 hover:underline"
            >
              Voir dans l'Annuaire →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {matchedClubs.map((club: FootballClub) => (
              <div
                key={club.id}
                className="bg-[#090E1B] rounded-2xl border border-white/10 p-5 flex flex-col justify-between space-y-4 hover:border-amber-500/50 transition-all shadow-xl group"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{club.countryFlag}</span>
                      <div>
                        <h3 className="font-black text-white text-base group-hover:text-amber-400 transition-colors">
                          {club.name}
                        </h3>
                        <p className="text-xs text-gray-400 font-mono">
                          {club.city}, {club.country} · {club.league}
                        </p>
                      </div>
                    </div>
                    {club.verified && (
                      <span className="text-xs text-amber-400 font-bold" title="Club Vérifié">
                        ★ Vérifié
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-gray-300 line-clamp-2 leading-relaxed">
                    {club.description}
                  </p>

                  <div className="p-3 rounded-xl bg-[#050810] border border-white/5 space-y-1.5 text-xs">
                    <div className="text-gray-300">
                      <span className="text-gray-500">Président :</span> <strong>{club.president}</strong>
                    </div>
                    <div className="text-gray-300">
                      <span className="text-gray-500">Dir. Sportif :</span> <strong>{club.sportingDirector}</strong>
                    </div>
                    <div className="text-gray-300">
                      <span className="text-gray-500">Entraîneur :</span> <strong>{club.headCoach}</strong>
                    </div>
                  </div>

                  {club.openNeeds.length > 0 && (
                    <div className="space-y-1">
                      <span className="text-[10px] font-mono text-amber-400/80 uppercase">
                        Besoins Actuels Déclarés :
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {club.openNeeds.map((need, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[10px] font-medium"
                          >
                            {need}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                  <button
                    onClick={() => {
                      createDirectConversation({
                        id: club.id,
                        name: club.sportingDirector || club.president,
                        title: `Cellule Recrutement · ${club.name}`,
                        avatar: club.logoUrl,
                        org: club.name,
                        role: 'CLUB',
                      });
                      onNavigate('messages');
                    }}
                    className="flex-1 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                  >
                    💬 Contacter Recrutement
                  </button>
                  <button
                    onClick={() => onNavigate('directory')}
                    className="px-3 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-white font-bold text-xs transition-colors"
                  >
                    Détails
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 2. PLAYERS & TALENTS SECTION */}
      {(activeCategory === 'ALL' || activeCategory === 'PLAYERS') && matchedPlayers.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-white uppercase font-mono flex items-center gap-2">
              <span>⚽ Talents, Vidéos & Cotations Marchandes ({matchedPlayers.length})</span>
            </h2>
            <button
              onClick={() => onNavigate('players')}
              className="text-xs text-emerald-400 hover:underline"
            >
              Voir le Catalogue Complet →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {matchedPlayers.map((player: RegisteredPlayer) => (
              <div
                key={player.id}
                className="bg-[#090E1B] rounded-2xl border border-white/10 p-5 flex flex-col justify-between space-y-4 hover:border-emerald-500/50 transition-all shadow-xl group"
              >
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={player.avatarUrl}
                      alt={player.firstName}
                      className="w-16 h-16 rounded-xl object-cover border border-white/10 shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm">{player.countryFlag}</span>
                        <h3 className="font-black text-white text-base group-hover:text-emerald-400 transition-colors">
                          {player.firstName} {player.lastName}
                        </h3>
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] font-mono font-black px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                          {player.primaryPosition}
                        </span>
                        <span className="text-xs text-gray-400 font-mono">
                          {player.calculatedAge} ans · {player.heightCm} cm
                        </span>
                      </div>
                      <div className="text-xs font-mono font-bold text-amber-400 mt-1">
                        Cote : {formatMarketValue(player.marketValueEur)}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-gray-400 line-clamp-2 leading-relaxed">
                    {player.bio}
                  </p>

                  <div className="grid grid-cols-3 gap-2 text-center text-xs p-2 rounded-lg bg-[#050810] border border-white/5">
                    <div>
                      <span className="text-gray-500 block text-[10px]">Vitesse</span>
                      <strong className="text-white">{player.stats.topSpeedKmh} km/h</strong>
                    </div>
                    <div>
                      <span className="text-gray-500 block text-[10px]">Buts</span>
                      <strong className="text-amber-400">{player.stats.goals}</strong>
                    </div>
                    <div>
                      <span className="text-gray-500 block text-[10px]">Duels Gagnés</span>
                      <strong className="text-emerald-400">{player.stats.duelsWonPct}%</strong>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 pt-2 border-t border-white/5">
                  {/* Favorite button */}
                  <button
                    onClick={() => toggleFavorite(player.id)}
                    className={`p-2 rounded-lg text-xs transition-colors cursor-pointer border ${
                      isFavorite(player.id)
                        ? 'text-amber-400 bg-amber-500/20 border-amber-500/50'
                        : 'text-gray-400 bg-white/5 border-white/10 hover:text-amber-300'
                    }`}
                    title={isFavorite(player.id) ? 'Retirer des favoris' : 'Ajouter à la shortlist'}
                  >
                    ★
                  </button>

                  {/* Compare button */}
                  <button
                    onClick={() => toggleComparison(player.id)}
                    className={`px-2 py-1.5 rounded-lg text-xs font-mono font-bold transition-colors cursor-pointer border ${
                      isInComparison(player.id)
                        ? 'bg-purple-600 text-white border-purple-400 shadow-sm'
                        : 'text-purple-300 bg-white/5 border-purple-500/40 hover:bg-purple-600/20'
                    }`}
                    title="Face-à-Face Comparateur"
                  >
                    ⇄
                  </button>

                  <button
                    onClick={() => onNavigate('player-detail', player)}
                    className="flex-1 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                  >
                    Fiche
                  </button>
                  {onExportPdf && (
                    <button
                      onClick={() => onExportPdf(player)}
                      className="py-2 px-2.5 rounded-lg bg-amber-500/20 hover:bg-amber-500 hover:text-black text-amber-300 font-bold text-xs transition-colors cursor-pointer flex items-center gap-1"
                      title="Exporter en PDF"
                    >
                      <span>📄 PDF</span>
                    </button>
                  )}
                  {player.videoUrl && (
                    <button
                      onClick={() => openVideoModal(player)}
                      className="py-2 px-2.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1"
                    >
                      <span>▶ Vidéo</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 3. PRESIDENTS, DIRECTORS & COACHES SECTION */}
      {(activeCategory === 'ALL' || activeCategory === 'PRESIDENTS' || activeCategory === 'DIRECTORS' || activeCategory === 'COACHES') && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-white uppercase font-mono flex items-center gap-2">
              <span>👔 Dirigeants, Présidents & Entraîneurs</span>
            </h2>
            <button
              onClick={() => onNavigate('directory')}
              className="text-xs text-blue-400 hover:underline"
            >
              Consulter l'Annuaire Pro →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {[
              ...(activeCategory === 'ALL' || activeCategory === 'PRESIDENTS' ? matchedPresidents : []),
              ...(activeCategory === 'ALL' || activeCategory === 'DIRECTORS' ? matchedDirectors : []),
              ...(activeCategory === 'ALL' || activeCategory === 'COACHES' ? matchedCoaches : []),
            ].map((pro: FootballProfessional) => (
              <div
                key={pro.id}
                className="bg-[#090E1B] rounded-2xl border border-white/10 p-5 flex flex-col justify-between space-y-4 hover:border-blue-500/50 transition-all shadow-xl"
              >
                <div className="flex items-start gap-3">
                  <img
                    src={pro.avatarUrl}
                    alt={pro.name}
                    className="w-14 h-14 rounded-full object-cover border border-white/10 shrink-0"
                  />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm">{pro.countryFlag}</span>
                      <h3 className="font-bold text-white text-base">
                        {pro.name}
                      </h3>
                      {pro.verified && <span className="text-blue-400 text-xs">☑</span>}
                    </div>
                    <p className="text-xs text-gray-300 font-semibold mt-0.5">
                      {pro.title}
                    </p>
                    <p className="text-xs text-gray-400 font-mono">
                      {pro.clubOrOrg}
                    </p>
                    <p className="text-xs text-gray-400 mt-2 line-clamp-2">
                      {pro.bio}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                  <button
                    onClick={() => {
                      createDirectConversation({
                        id: pro.id,
                        name: pro.name,
                        title: pro.title,
                        avatar: pro.avatarUrl,
                        org: pro.clubOrOrg,
                        role: pro.role,
                      });
                      onNavigate('messages');
                    }}
                    className="flex-1 py-2 rounded-lg bg-blue-500 hover:bg-blue-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                  >
                    💬 Envoyer Message B2B
                  </button>
                  <a
                    href={FOUNDER_INFO.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-white font-bold text-xs"
                    title="Mise en relation via Desk Seydou Mario TRAORÉ"
                  >
                    Liaison
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 4. COMPANIES & SPONSORS SECTION */}
      {(activeCategory === 'ALL' || activeCategory === 'COMPANIES') && matchedCompanies.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-white uppercase font-mono flex items-center gap-2">
              <span>🏢 Entreprises, Équipementiers & Sponsors ({matchedCompanies.length})</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {matchedCompanies.map((comp: FootballCompany) => (
              <div
                key={comp.id}
                className="bg-[#090E1B] rounded-2xl border border-white/10 p-5 flex flex-col justify-between space-y-4 hover:border-purple-500/50 transition-all shadow-xl"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-white text-base">{comp.name}</h3>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">
                      {comp.category}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 mt-2 line-clamp-3">
                    {comp.description}
                  </p>
                  <div className="mt-3 text-xs text-gray-300 font-mono">
                    Contact : {comp.contactPerson} ({comp.contactRole})
                  </div>
                </div>

                <button
                  onClick={() => {
                    createDirectConversation({
                      id: comp.id,
                      name: comp.contactPerson,
                      title: `${comp.contactRole} · ${comp.name}`,
                      avatar: comp.logoUrl,
                      org: comp.name,
                      role: 'COMPANY',
                    });
                    onNavigate('messages');
                  }}
                  className="w-full py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center"
                >
                  Contacter Partenariat
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* EMPTY STATE */}
      {totalResultsCount === 0 && (
        <div className="p-12 rounded-2xl bg-[#090E1B] border border-white/10 text-center space-y-4 shadow-xl">
          <span className="text-4xl">🔍</span>
          <h3 className="text-lg font-bold text-white">
            {t('common.noResults', 'Aucun résultat ne correspond à vos critères')}
          </h3>
          <p className="text-xs text-gray-400 max-w-md mx-auto">
            {t('search.noMatches', 'Aucun profil ou entité ne correspond à votre recherche actuelle.')}
          </p>
          <button
            onClick={() => {
              handleQueryChange('');
              setSelectedCountry('ALL');
              setActiveCategory('ALL');
            }}
            className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
          >
            {t('search.clearFilters', 'Réinitialiser la recherche')}
          </button>
        </div>
      )}
    </div>
  );
};
