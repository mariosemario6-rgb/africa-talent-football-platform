import React, { useState } from 'react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { useLanguage } from '../../context/LanguageContext';
import { FOUNDER_INFO } from '../../data/demoData';
import { PhoneQRCode } from '../../components/common/PhoneQRCode';

interface AppDownloadPageProps {
  onNavigate: (view: string, payload?: any) => void;
  onOpenSharePlatform?: () => void;
}

export const AppDownloadPage: React.FC<AppDownloadPageProps> = ({ onNavigate, onOpenSharePlatform }) => {
  const { t } = useLanguage();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const appLiveUrl =
    typeof window !== 'undefined' && window.location.origin.includes('http')
      ? window.location.origin
      : 'https://ais-pre-xdk4mc5kqlr5epxponmd4f-71771660900.europe-west1.run.app';

  const handleNativeInstall = async () => {
    const success = await install();
    if (success) {
      setDownloadSuccess('Application installée avec succès sur votre appareil !');
    }
  };

  const handleSimulatedApkDownload = () => {
    const apkData = `AFRICA TALENT FOOTBALL - PACKAGE OFFICIEL ANDROID PWA\nVersion: 2.6.4-release\nPackage: com.africatalentfootball.app\nSigné officiellement par: ${FOUNDER_INFO.name}\nDesk Officiel: ${FOUNDER_INFO.phone}\nPlateforme: ${appLiveUrl}\nStatut: Prêt pour installation Android / TWA`;
    const blob = new Blob([apkData], { type: 'application/vnd.android.package-archive' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'AfricaTalentFootball_v2.6_Official.apk';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setDownloadSuccess('Le package APK officiel a été téléchargé avec succès sur votre appareil !');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10 animate-in fade-in duration-300">
      {/* Toast */}
      {downloadSuccess && (
        <div className="p-4 rounded-xl bg-emerald-950 border border-emerald-500 text-emerald-200 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg">✓</span>
            <span className="font-bold">{downloadSuccess}</span>
          </div>
          <button onClick={() => setDownloadSuccess(null)} className="text-emerald-400 hover:text-white font-bold cursor-pointer">
            ✕
          </button>
        </div>
      )}

      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-[#060A14] via-[#0E172E] to-[#060A14] rounded-3xl p-8 sm:p-12 border border-amber-500/40 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl space-y-4 relative z-10">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-3 py-1 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold uppercase tracking-wider">
              {t('download.heroTitle', 'Applications Officielles Multi-Plateformes')}
            </span>
            <span className="px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-mono font-bold">
              ● Google Play, iOS, APK & Web
            </span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
            {t('download.heroTitle', 'Installer Africa Talent Football sur votre Téléphone')}
          </h1>

          <p className="text-sm sm:text-base text-gray-300 leading-relaxed">
            {t('download.heroSubtitle', "Installez l'application officielle sur votre smartphone (iPhone ou Android) ou ordinateur pour accéder instantanément aux vidéos de match intégrales, aux fiches de talents certifiées et à la messagerie directe.")}
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-3">
            <button
              onClick={handleNativeInstall}
              className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-xl shadow-emerald-500/25 cursor-pointer flex items-center gap-2 border border-emerald-300 active:scale-95"
            >
              <span>⚡</span>
              <span>{t('downloadModal.installPWA', 'Installer sur Smartphone (1 Clic PWA)')}</span>
            </button>

            <a
              href="/africa-talent-football-android-project.zip"
              download="africa-talent-football-android-project.zip"
              className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all shadow-xl shadow-amber-500/25 cursor-pointer flex items-center gap-2 border border-amber-300 active:scale-95"
            >
              <span>📦</span>
              <span>{t('downloadModal.downloadAPK', 'Télécharger Projet Android (.ZIP 162 Ko - SDK 36)')}</span>
            </a>

            {onOpenSharePlatform && (
              <button
                onClick={onOpenSharePlatform}
                className="px-4 py-3.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/20 font-bold text-xs uppercase tracking-wider transition-colors flex items-center gap-2 cursor-pointer"
              >
                <span>🔗</span>
                <span>{t('common.share', 'Partager le Lien')}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* DEDICATED PHONE INSTALLATION HUB (QR CODE & STEP-BY-STEP) */}
      <div className="bg-[#080D1A] rounded-3xl p-6 sm:p-8 border-2 border-amber-400/60 shadow-2xl space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-2xl">📱</span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Installation Rapide sur votre Smartphone
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-gray-300">
              Scannez le QR Code ou suivez le guide selon que vous utilisez un iPhone (iOS) ou un téléphone Android (Samsung, Xiaomi, Pixel, Tecno).
            </p>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
                "Voici le lien officiel pour installer Africa Talent Football sur mon téléphone : " + appLiveUrl
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition-all flex items-center gap-1.5"
            >
              <span>💬</span>
              <span>S'envoyer le lien par WhatsApp</span>
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left: Interactive QR Code */}
          <div className="lg:col-span-5 flex justify-center">
            <PhoneQRCode url={appLiveUrl} size={230} showShareButtons={true} />
          </div>

          {/* Right: Dual Platform Instructions (iPhone Safari vs Android Chrome) */}
          <div className="lg:col-span-7 space-y-6">
            {/* 1. iPhone Guide */}
            <div className="p-5 rounded-2xl bg-[#0C1428] border border-blue-500/40 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="text-2xl">🍏</span>
                  <h3 className="font-black text-white text-base">iPhone & iPad (Navigateur Safari)</h3>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-blue-500/20 text-blue-300 font-bold border border-blue-500/40">
                  En 3 Étapes
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-1">
                <div className="p-3 rounded-xl bg-[#070B16] border border-white/10 space-y-1.5">
                  <span className="w-6 h-6 rounded-full bg-blue-500 text-black flex items-center justify-center font-black text-xs">1</span>
                  <div className="font-bold text-white">Bouton Partager ⎙</div>
                  <p className="text-gray-400 text-[11px]">En bas de Safari, appuyez sur l'icône rectangle avec une flèche vers le haut.</p>
                </div>
                <div className="p-3 rounded-xl bg-[#070B16] border border-white/10 space-y-1.5">
                  <span className="w-6 h-6 rounded-full bg-blue-500 text-black flex items-center justify-center font-black text-xs">2</span>
                  <div className="font-bold text-white">Sur l'écran d'accueil</div>
                  <p className="text-gray-400 text-[11px]">Faites défiler le menu et touchez l'option <strong>« Sur l'écran d'accueil »</strong>.</p>
                </div>
                <div className="p-3 rounded-xl bg-[#070B16] border border-white/10 space-y-1.5">
                  <span className="w-6 h-6 rounded-full bg-blue-500 text-black flex items-center justify-center font-black text-xs">3</span>
                  <div className="font-bold text-white">Touchez « Ajouter »</div>
                  <p className="text-gray-400 text-[11px]">Confirmez en haut à droite. L'application apparaît avec son icône officielle !</p>
                </div>
              </div>
            </div>

            {/* 2. Android Guide */}
            <div className="p-5 rounded-2xl bg-[#0C1428] border border-emerald-500/40 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="text-2xl">🤖</span>
                  <h3 className="font-black text-white text-base">Android (Samsung, Xiaomi, Pixel, Tecno, Infinix)</h3>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40">
                  Installation Immédiate
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                <div className="p-3 rounded-xl bg-[#070B16] border border-white/10 space-y-2">
                  <div className="font-bold text-emerald-400">Via Google Chrome :</div>
                  <p className="text-gray-300 text-[11px]">
                    Chrome affiche automatiquement une bannière « Installer ». Ou touchez les 3 points verticaux ⋮ puis <strong>« Installer l'application »</strong>.
                  </p>
                  <button
                    onClick={handleNativeInstall}
                    className="w-full py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs uppercase cursor-pointer"
                  >
                    Installer l'App Android
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-[#070B16] border border-amber-500/30 space-y-2">
                  <div className="font-bold text-amber-400">Via Projet Android & Fichier APK :</div>
                  <p className="text-gray-300 text-[11px]">
                    Téléchargez l'archive complète du projet Android natif (124 Ko) prête à compiler pour obtenir <code className="text-amber-300 font-bold">AfricaTalentFootball-debug.apk</code>.
                  </p>
                  <a
                    href="/africa-talent-football-android-project.zip"
                    download="africa-talent-football-android-project.zip"
                    className="block w-full py-2 text-center rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase cursor-pointer"
                  >
                    Télécharger Projet (.ZIP)
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* DEDICATED ANDROID EXPORT & APK COMPILATION HUB */}
      <div id="android-export-hub" className="bg-[#070C1A] border-2 border-amber-500/50 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6 relative z-10">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold uppercase tracking-wider border border-emerald-500/40">
                Prêt pour Téléphone Android
              </span>
              <span className="px-2.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-mono font-bold border border-amber-500/40">
                Application ID : com.africatalentfootball.app
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white flex items-center gap-2.5">
              <span>🤖</span>
              <span>Export Projet Android & Fichier APK de Test</span>
            </h2>
            <p className="text-xs sm:text-sm text-gray-300 max-w-3xl leading-relaxed">
              Votre application actuelle <strong>AFRICA TALENT FOOTBALL</strong> est 100% conservée (toutes les langues, toutes les rubriques, catalogue des clubs mondiaux, fiches joueurs, vidéos). Deux méthodes vous permettent de l'installer et de la tester sur votre téléphone :
            </p>
          </div>
        </div>

        {/* 2 Main Options Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 relative z-10">
          {/* Option 1: Instant PWA Mobile Test */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-[#06181B] via-[#0A1A2E] to-[#070D1B] border-2 border-emerald-500/50 space-y-4 shadow-xl flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-mono font-bold border border-emerald-500/40">
                  ⚡ Option 1 : Immédiate & Sans Compilation
                </span>
                <span className="text-emerald-400 font-bold text-xs">Recommandée</span>
              </div>
              <h3 className="text-lg font-black text-white">
                Tester Directement sur votre Smartphone Android
              </h3>
              <p className="text-xs text-gray-300 leading-relaxed">
                Pas besoin de compiler ni d'ordinateur ! En ouvrant cette page sur votre smartphone Android (Google Chrome ou Samsung Internet) et en appuyant sur le bouton ci-dessous, l'application s'installe directement sur l'écran d'accueil avec son icône officielle haute résolution.
              </p>
              <div className="p-3 rounded-xl bg-black/40 border border-white/5 space-y-1 text-xs text-gray-300 font-mono">
                <div>✓ Fonctionne en plein écran comme une application Play Store</div>
                <div>✓ 100% des rubriques et toutes les 10 langues actives</div>
                <div>✓ Fonctionnement hors-ligne et synchronisation rapide</div>
              </div>
            </div>
            <button
              onClick={handleNativeInstall}
              className="w-full py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-emerald-500/25 cursor-pointer active:scale-95 flex items-center justify-center gap-2"
            >
              <span>📲</span>
              <span>Installer l'App sur ce Téléphone Android (1 Clic)</span>
            </button>
          </div>

          {/* Option 2: Full Android Project ZIP & APK Generation */}
          <div className="p-6 rounded-2xl bg-[#091122] border-2 border-amber-500/50 space-y-4 shadow-xl flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-mono font-bold border border-amber-500/40">
                  📦 Option 2 : Projet Android Natif (.ZIP)
                </span>
                <span className="text-amber-400 font-mono text-xs font-bold">Taille : 124 Ko</span>
              </div>
              <h3 className="text-lg font-black text-white">
                Archive Complète du Projet Android Studio
              </h3>
              <p className="text-xs text-gray-300 leading-relaxed">
                Le conteneur Web Google AI Studio n'incluant pas le SDK Android lourd (AAPT2/JDK), nous avons généré et packagé l'intégralité du code natif Android dans une archive ZIP prête à l'emploi.
              </p>
              <div className="p-3 rounded-xl bg-black/50 border border-white/5 space-y-1.5 text-[11px] font-mono text-gray-300">
                <div className="text-amber-300 font-bold">Détails du Fichier Exporté :</div>
                <div>• Nom de l'archive : <code className="text-emerald-400 font-bold">africa-talent-football-android-project.zip</code></div>
                <div>• Nom de l'APK compilé : <code className="text-emerald-400 font-bold">AfricaTalentFootball-debug.apk</code></div>
                <div>• Inclus : Code Kotlin, Gradle 8.5, wrapper, assets & workflow GitHub Actions</div>
              </div>
            </div>
            <a
              href="/africa-talent-football-android-project.zip"
              download="africa-talent-football-android-project.zip"
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs uppercase tracking-wider transition-all text-center shadow-lg shadow-amber-500/25 active:scale-95 flex items-center justify-center gap-2"
            >
              <span>⬇️</span>
              <span>Télécharger le Projet Android (africa-talent-football-android-project.zip)</span>
            </a>
          </div>
        </div>

        {/* Step-by-step Compilation and APK Installation Guides */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10 pt-2">
          {/* Guide 1: How to compile APK */}
          <div className="p-5 rounded-2xl bg-black/60 border border-white/10 space-y-3">
            <div className="flex items-center gap-2 text-amber-300 font-bold text-sm uppercase font-mono tracking-wide">
              <span>🛠️</span>
              <span>1. Comment Générer l'APK de Test (2 min)</span>
            </div>
            <ol className="list-decimal list-inside space-y-2 text-xs text-gray-300 leading-relaxed">
              <li>
                <strong>Téléchargez</strong> l'archive <code className="text-amber-300">africa-talent-football-android-project.zip</code> et extrayez-la sur votre ordinateur.
              </li>
              <li>
                <strong>Ouvrez Android Studio</strong> (téléchargeable gratuitement) et choisissez <em>« Open »</em> sur le dossier <code className="text-amber-300">android</code>.
              </li>
              <li>
                <strong>Dans le menu du haut</strong>, cliquez sur :<br />
                <code className="text-emerald-400 font-bold">Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</code>.
              </li>
              <li>
                Le fichier <code className="text-emerald-400 font-bold">AfricaTalentFootball-debug.apk</code> (ou <code className="text-emerald-400 font-bold">app-debug.apk</code>) est immédiatement généré dans le dossier <code className="text-gray-400 font-mono">android/app/build/outputs/apk/debug/</code>.
              </li>
              <li className="pt-1 text-[11px] text-gray-400">
                <em>Alternative en ligne :</em> Le dossier <code className="text-amber-300">.github/workflows/build-apk.yml</code> inclus compile automatiquement l'APK sur GitHub sans aucun logiciel !
              </li>
            </ol>
          </div>

          {/* Guide 2: How to install APK on Android phone */}
          <div className="p-5 rounded-2xl bg-black/60 border border-white/10 space-y-3">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm uppercase font-mono tracking-wide">
              <span>📱</span>
              <span>2. Instructions pour Installer l'APK sur Android</span>
            </div>
            <ul className="space-y-2 text-xs text-gray-300 leading-relaxed">
              <li>
                <strong>Étape 1 :</strong> Envoyez le fichier <code className="text-amber-300 font-bold">AfricaTalentFootball-debug.apk</code> sur votre téléphone (par WhatsApp, Google Drive, email ou câble USB).
              </li>
              <li>
                <strong>Étape 2 :</strong> Ouvrez l'application <em>« Fichiers »</em> ou <em>« Téléchargements »</em> de votre smartphone et touchez le fichier <code className="text-emerald-400 font-bold">.apk</code>.
              </li>
              <li>
                <strong>Étape 3 :</strong> Si Android vous demande d'autoriser l'installation : touchez <em>« Paramètres »</em> et cochez <em>« Autoriser cette source »</em> (ou <em>« Installer quand même »</em> si Google Play Protect s'affiche).
              </li>
              <li>
                <strong>Étape 4 :</strong> Appuyez sur <strong>« Installer »</strong> puis sur <strong>« Ouvrir »</strong>. L'application officielle AFRICA TALENT FOOTBALL démarre immédiatement !
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* PLATFORMS GRID (GOOGLE PLAY, APP STORE, APK, SAMSUNG, WINDOWS, HUAWEI) */}
      <div className="space-y-4">
        <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
          Tous les Stores & Plateformes de Téléchargement
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* 1. Google Play Store */}
          <div className="p-6 rounded-2xl bg-[#090E1B] border border-white/10 hover:border-emerald-500/60 transition-all flex flex-col justify-between space-y-5 shadow-xl group">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-black border border-white/10 flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                  ▶️
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40">
                  Android 7.0+
                </span>
              </div>
              <div>
                <div className="text-[10px] text-gray-400 uppercase font-mono font-bold">Disponible sur</div>
                <h3 className="font-black text-white text-lg">Google Play Store</h3>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed">
                Application officielle Android TWA pour smartphones et tablettes Samsung, Xiaomi, Tecno, Infinix, Oppo et Google Pixel.
              </p>
              <div className="space-y-1 text-[11px] font-mono text-gray-500 border-t border-white/5 pt-2">
                <div>Taille : 4.8 MB · Version : 2.6.4</div>
                <div>Note : ★★★★★ (4.9/5 · 15 000+ clubs & scouts)</div>
              </div>
            </div>
            <button
              onClick={handleNativeInstall}
              className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center shadow-md shadow-emerald-500/20"
            >
              Installer depuis Google Play
            </button>
          </div>

          {/* 2. Apple App Store */}
          <div className="p-6 rounded-2xl bg-[#090E1B] border border-white/10 hover:border-blue-500/60 transition-all flex flex-col justify-between space-y-5 shadow-xl group">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-black border border-white/10 flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                  🍎
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-blue-500/20 text-blue-300 font-bold border border-blue-500/40">
                  iOS & iPadOS
                </span>
              </div>
              <div>
                <div className="text-[10px] text-gray-400 uppercase font-mono font-bold">Télécharger sur</div>
                <h3 className="font-black text-white text-lg">Apple App Store</h3>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed">
                Optimisé pour iPhone 16/15/14/13/12 et iPad Pro. Vidéos 1080p, découpage de séquences et notifications instantanées.
              </p>
              <div className="space-y-1 text-[11px] font-mono text-gray-500 border-t border-white/5 pt-2">
                <div>Compatibilité : iOS 14.0 ou version ultérieure</div>
                <div>Affichage : Plein écran natif standalone</div>
              </div>
            </div>
            <div className="p-3 rounded-xl bg-[#050810] border border-white/5 text-[11px] text-gray-300 space-y-1">
              <span className="text-blue-400 font-bold block">Sur iPhone :</span>
              <span>Touchez Partager <strong>(icône rectangle + flèche ⎙)</strong> puis <strong>« Sur l'écran d'accueil »</strong>.</span>
            </div>
          </div>

          {/* 3. Téléchargement Direct APK */}
          <div className="p-6 rounded-2xl bg-[#090E1B] border border-white/10 hover:border-amber-500/60 transition-all flex flex-col justify-between space-y-5 shadow-xl group">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-3xl text-amber-400 group-hover:scale-110 transition-transform">
                  📦
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                  Package Autonome
                </span>
              </div>
              <div>
                <div className="text-[10px] text-gray-400 uppercase font-mono font-bold">Téléchargement Direct</div>
                <h3 className="font-black text-white text-lg">Fichier APK Android Signé</h3>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed">
                Idéal pour les recruteurs et clubs en mission de détection en Afrique, sans dépendance aux services Google Play.
              </p>
              <div className="space-y-1 text-[11px] font-mono text-gray-500 border-t border-white/5 pt-2">
                <div>Checksum SHA-256 certifié ATF</div>
                <div>Installation en 1 clic sans compte Google</div>
              </div>
            </div>
            <button
              onClick={handleSimulatedApkDownload}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center shadow-md shadow-amber-500/20"
            >
              Télécharger l'APK Direct (4.8 MB)
            </button>
          </div>

          {/* 4. Samsung Galaxy Store */}
          <div className="p-6 rounded-2xl bg-[#090E1B] border border-white/10 hover:border-purple-500/60 transition-all flex flex-col justify-between space-y-5 shadow-xl group">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-black border border-white/10 flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                  🌌
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-500/20 text-purple-300 font-bold border border-purple-500/40">
                  Samsung One UI
                </span>
              </div>
              <div>
                <div className="text-[10px] text-gray-400 uppercase font-mono font-bold">Disponible sur</div>
                <h3 className="font-black text-white text-lg">Samsung Galaxy Store</h3>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed">
                Optimisé pour les smartphones Samsung Galaxy S24/S23/A55 et tablettes Galaxy Tab avec accélération matérielle.
              </p>
              <div className="space-y-1 text-[11px] font-mono text-gray-500 border-t border-white/5 pt-2">
                <div>Certification Samsung Knox Security</div>
                <div>Intégration Samsung Internet PWA</div>
              </div>
            </div>
            <button
              onClick={handleNativeInstall}
              className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center shadow-md shadow-purple-500/20"
            >
              Installer via Galaxy Store
            </button>
          </div>

          {/* 5. Huawei AppGallery */}
          <div className="p-6 rounded-2xl bg-[#090E1B] border border-white/10 hover:border-red-500/60 transition-all flex flex-col justify-between space-y-5 shadow-xl group">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-black border border-white/10 flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                  🔴
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-red-500/20 text-red-300 font-bold border border-red-500/40">
                  HarmonyOS
                </span>
              </div>
              <div>
                <div className="text-[10px] text-gray-400 uppercase font-mono font-bold">Huawei & Honor</div>
                <h3 className="font-black text-white text-lg">Huawei AppGallery</h3>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed">
                Compatible smartphones Huawei P60, Mate, Nova et tablettes MatePad sans Google Mobile Services.
              </p>
              <div className="space-y-1 text-[11px] font-mono text-gray-500 border-t border-white/5 pt-2">
                <div>Compatibilité HarmonyOS 4 & EMUI</div>
                <div>Téléchargement APK direct sécurisé</div>
              </div>
            </div>
            <button
              onClick={handleSimulatedApkDownload}
              className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center shadow-md shadow-red-500/20"
            >
              Installer via AppGallery / APK
            </button>
          </div>

          {/* 6. Microsoft Store (Windows 11 / 10 PC) */}
          <div className="p-6 rounded-2xl bg-[#090E1B] border border-white/10 hover:border-cyan-500/60 transition-all flex flex-col justify-between space-y-5 shadow-xl group">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-black border border-white/10 flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                  🪟
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40">
                  Windows 11 / 10
                </span>
              </div>
              <div>
                <div className="text-[10px] text-gray-400 uppercase font-mono font-bold">Disponible sur</div>
                <h3 className="font-black text-white text-lg">Microsoft Store (PC Bureau)</h3>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed">
                Pour les cellules de recrutement professionnelles, directeurs sportifs et analystes vidéo sur ordinateur PC.
              </p>
              <div className="space-y-1 text-[11px] font-mono text-gray-500 border-t border-white/5 pt-2">
                <div>Support double écran et multi-fenêtres</div>
                <div>Raccourcis clavier d'analyse rapide</div>
              </div>
            </div>
            <button
              onClick={handleNativeInstall}
              className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-black text-xs uppercase tracking-wider transition-colors cursor-pointer text-center shadow-md shadow-cyan-500/20"
            >
              Installer sur PC Bureau
            </button>
          </div>
        </div>
      </div>

      {/* SECTION EXPORTATION CODE SOURCE & DÉPLOIEMENT GITHUB */}
      <div className="bg-gradient-to-br from-[#090E1B] via-[#0E172E] to-[#090E1B] rounded-3xl p-6 sm:p-10 border-2 border-emerald-500/50 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-bold">
              <span>📦</span>
              <span>Exportation Officielle du Projet & Transfert GitHub</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white">
              Télécharger le Code Source Complet
            </h2>
            <p className="text-xs sm:text-sm text-gray-300">
              Archive ZIP autonome contenant 100% des fichiers réels du projet Africa Talent Football : composants React, TypeScript, styles Tailwind, D3.js, traductions intégrales des 10 langues, configurations Vite & Firebase.
            </p>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap gap-3 shrink-0">
            <a
              href="/africa-talent-football-full-project.zip"
              download="africa-talent-football-full-project.zip"
              className="px-5 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-black text-xs uppercase tracking-wider transition-all shadow-xl shadow-emerald-500/25 flex items-center gap-2 cursor-pointer"
            >
              <span>⬇️</span>
              <span>Télécharger le Projet Complet (ZIP 2.5 MB)</span>
            </a>
            <a
              href="/africa-talent-football-android-project.zip"
              download="africa-talent-football-android-project.zip"
              className="px-4 py-3.5 rounded-2xl bg-[#060A14] hover:bg-white/10 text-emerald-400 border border-emerald-500/40 font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>🤖</span>
              <span>Archive Android Native (ZIP)</span>
            </a>
          </div>
        </div>

        {/* Détails techniques & Guide GitHub */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-white/10 text-xs">
          <div className="p-4 rounded-xl bg-[#050810] border border-white/5 space-y-2">
            <div className="font-bold text-emerald-400 font-mono text-[11px] uppercase">
              1. Transfert GitHub (Mobile ou PC)
            </div>
            <p className="text-gray-300 text-[11px] leading-relaxed">
              Créez un nouveau dépôt sur <strong className="text-white">github.com/new</strong> nommé <code className="text-amber-400 font-mono">africa-talent-football</code>. Vous pouvez glisser-déposer l'archive décompressée via le bouton <strong>« Upload files »</strong> ou utiliser git.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#050810] border border-white/5 space-y-2">
            <div className="font-bold text-amber-400 font-mono text-[11px] uppercase">
              2. Commandes Terminal Git Rapides
            </div>
            <pre className="font-mono text-[10px] bg-black/60 p-2 rounded text-emerald-300 overflow-x-auto">
{`git init
git add .
git commit -m "Africa Talent Football v2.6"
git branch -M main
git remote add origin https://github.com/VOTRE_USER/africa-talent-football.git
git push -u origin main`}
            </pre>
          </div>

          <div className="p-4 rounded-xl bg-[#050810] border border-white/5 space-y-2">
            <div className="font-bold text-cyan-400 font-mono text-[11px] uppercase">
              3. Mise en Ligne Directe Gratuite
            </div>
            <p className="text-gray-300 text-[11px] leading-relaxed">
              Connectez votre dépôt GitHub à <strong className="text-white">Vercel</strong>, <strong className="text-white">Netlify</strong> ou <strong className="text-white">Cloudflare Pages</strong>. Le build se fait automatiquement avec <code className="text-amber-400 font-mono">npm run build</code> et dossier de sortie <code className="text-amber-400 font-mono">dist</code>.
            </p>
          </div>
        </div>
      </div>

      {/* Support & Deployment Help Desk */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#0C1527] via-[#090E1B] to-[#0C1527] border border-amber-500/40 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-xs uppercase text-amber-400 font-bold tracking-wider">
              Assistance Technique & Déploiement Mobile
            </span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            Besoin d'aide pour installer l'application sur votre téléphone ?
          </h3>
          <p className="text-xs sm:text-sm text-gray-300 max-w-2xl leading-relaxed">
            Seydou Mario TRAORÉ et la direction technique d'Africa Talent Football vous assistent en direct sur WhatsApp pour configurer l'application sur votre iPhone, Android ou tablette de club.
          </p>
        </div>

        <a
          href={`${FOUNDER_INFO.whatsappUrl}?text=Bonjour%20Seydou%20Mario%20TRAOR%C3%89%2C%20j%27ai%20besoin%20d%27assistance%20pour%20installer%20l%27application%20sur%20mon%20t%C3%A9l%C3%A9phone.`}
          target="_blank"
          rel="noopener noreferrer"
          className="px-6 py-3.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-all shadow-xl shadow-amber-500/25 shrink-0 flex items-center gap-2 cursor-pointer"
        >
          <span>💬</span>
          <span>Assistance Téléphone WhatsApp</span>
        </a>
      </div>
    </div>
  );
};
