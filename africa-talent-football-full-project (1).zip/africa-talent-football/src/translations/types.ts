export type Language = 'fr' | 'en' | 'es' | 'pt' | 'it' | 'de' | 'ar' | 'zh' | 'ru' | 'tr';

export interface LanguageMeta {
  code: Language;
  name: string;
  nativeName: string;
  flag: string;
  dir: 'ltr' | 'rtl';
}

export type TranslationsRecord = Record<string, Record<Language, string>>;
