import { Language, LanguageMeta, TranslationsRecord } from './types';
import { commonTranslations } from './common';
import { homeTranslations } from './home';
import { playersTranslations } from './players';
import { authTranslations } from './auth';
import { networkTranslations } from './network';
import { pricingTranslations } from './pricing';
import { dashboardsTranslations } from './dashboards';
import { founderTranslations } from './founder';
import { downloadTranslations } from './download';
import { searchTranslations } from './search';
import { drawerTranslations } from './drawer';
import { valuationTranslations } from './valuation';
import { featuresTranslations } from './features';

export * from './types';

export const WORLD_LANGUAGES: LanguageMeta[] = [
  { code: 'fr', name: 'Français', nativeName: 'Français', flag: '🇫🇷', dir: 'ltr' },
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧', dir: 'ltr' },
  { code: 'es', name: 'Español', nativeName: 'Español', flag: '🇪🇸', dir: 'ltr' },
  { code: 'pt', name: 'Português', nativeName: 'Português', flag: '🇵🇹', dir: 'ltr' },
  { code: 'it', name: 'Italiano', nativeName: 'Italiano', flag: '🇮🇹', dir: 'ltr' },
  { code: 'de', name: 'Deutsch', nativeName: 'Deutsch', flag: '🇩🇪', dir: 'ltr' },
  { code: 'ar', name: 'العربية', nativeName: 'العربية', flag: '🇸🇦', dir: 'rtl' },
  { code: 'zh', name: '中文', nativeName: '中文', flag: '🇨🇳', dir: 'ltr' },
  { code: 'ru', name: 'Русский', nativeName: 'Русский', flag: '🇷🇺', dir: 'ltr' },
  { code: 'tr', name: 'Türkçe', nativeName: 'Türkçe', flag: '🇹🇷', dir: 'ltr' },
];

export const allTranslations: TranslationsRecord = {
  ...commonTranslations,
  ...homeTranslations,
  ...playersTranslations,
  ...authTranslations,
  ...networkTranslations,
  ...pricingTranslations,
  ...dashboardsTranslations,
  ...founderTranslations,
  ...downloadTranslations,
  ...searchTranslations,
  ...drawerTranslations,
  ...valuationTranslations,
  ...featuresTranslations,
};
