import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

if ('serviceWorker' in navigator && import.meta.env.PROD) {
  try {
    registerSW({ immediate: true });
  } catch (error) {
    console.warn('PWA registration skipped:', error);
  }
}

createRoot(document.getElementById('root')!).render(<App />);
