import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  FootballClub,
  FootballProfessional,
  FootballCompany,
  Conversation,
  ChatMessage,
  FeedPost
} from '../types/database';
import {
  GLOBAL_CLUBS,
  GLOBAL_PROFESSIONALS,
  GLOBAL_COMPANIES,
  INITIAL_CONVERSATIONS,
  INITIAL_MESSAGES,
  INITIAL_FEED_POSTS
} from '../data/networkData';
import { FOUNDER_INFO } from '../data/demoData';

interface NetworkContextType {
  clubs: FootballClub[];
  professionals: FootballProfessional[];
  companies: FootballCompany[];
  feedPosts: FeedPost[];
  conversations: Conversation[];
  messages: Record<string, ChatMessage[]>;
  activeConversationId: string;
  setActiveConversationId: (id: string) => void;
  sendMessage: (conversationId: string, text: string, attachment?: any) => void;
  createDirectConversation: (recipient: { id: string; name: string; title: string; avatar: string; org: string; role: string }) => string;
  addFeedPost: (content: string, tags?: string[], playerAttachment?: any, authorOverride?: Partial<FeedPost>) => void;
  deleteFeedPost: (postId: string) => void;
  likePost: (postId: string) => void;
  addComment: (postId: string, commentText: string, commenter?: { name: string; title: string }) => void;
  toggleConnection: (proId: string) => void;
  globalSearch: string;
  setGlobalSearch: (q: string) => void;
  isQuickChatOpen: boolean;
  setIsQuickChatOpen: (open: boolean) => void;
  totalUnreadCount: number;
}

const STORAGE_FEED_KEY = 'atf_feed_posts_v3';

const NetworkContext = createContext<NetworkContextType | undefined>(undefined);

export const NetworkProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [clubs] = useState<FootballClub[]>(GLOBAL_CLUBS);
  const [professionals, setProfessionals] = useState<FootballProfessional[]>(GLOBAL_PROFESSIONALS);
  const [companies] = useState<FootballCompany[]>(GLOBAL_COMPANIES);
  
  // Initialize feed posts from localStorage or default
  const [feedPosts, setFeedPosts] = useState<FeedPost[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_FEED_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return INITIAL_FEED_POSTS;
  });

  const [conversations, setConversations] = useState<Conversation[]>(INITIAL_CONVERSATIONS);
  const [messages, setMessages] = useState<Record<string, ChatMessage[]>>(INITIAL_MESSAGES);
  const [activeConversationId, setActiveConversationId] = useState<string>('conv-01');
  const [globalSearch, setGlobalSearch] = useState<string>('');
  const [isQuickChatOpen, setIsQuickChatOpen] = useState<boolean>(false);

  // Sync feed posts to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_FEED_KEY, JSON.stringify(feedPosts));
    } catch {}
  }, [feedPosts]);

  const totalUnreadCount = useMemo(() => {
    return conversations.reduce((sum, c) => sum + c.unreadCount, 0);
  }, [conversations]);

  const sendMessage = (conversationId: string, text: string, attachment?: any) => {
    if (!text.trim() && !attachment) return;

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      conversationId,
      senderId: 'user-scout-01',
      senderName: FOUNDER_INFO.name,
      senderAvatar: '/src/assets/images/founder_mario_suit_1792079172729.jpg',
      senderRole: 'Scout Agent & Directeur ATF',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isMine: true,
      attachment
    };

    setMessages((prev) => ({
      ...prev,
      [conversationId]: [...(prev[conversationId] || []), newMsg]
    }));

    setConversations((prev) =>
      prev.map((c) =>
        c.id === conversationId
          ? {
              ...c,
              lastMessage: text || (attachment ? `Fiche jointe : ${attachment.title}` : ''),
              lastMessageTime: 'À l’instant',
              unreadCount: 0
            }
          : c
      )
    );

    // Simulate realistic intelligent B2B response from club sporting director / scout after 1.8 seconds
    setTimeout(() => {
      const activeConv = conversations.find(c => c.id === conversationId);
      if (activeConv) {
        const replyMsg: ChatMessage = {
          id: `reply-${Date.now()}`,
          conversationId,
          senderId: activeConv.participantId,
          senderName: activeConv.participantName,
          senderAvatar: activeConv.participantAvatar,
          senderRole: activeConv.participantRole,
          text: `Bien reçu Seydou. Notre cellule technique étudie attentivement ces éléments. Pouvons-nous prévoir un point WhatsApp officiel au ${FOUNDER_INFO.phone} aujourd'hui ?`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isMine: false
        };

        setMessages((prev) => ({
          ...prev,
          [conversationId]: [...(prev[conversationId] || []), replyMsg]
        }));

        setConversations((prev) =>
          prev.map((c) =>
            c.id === conversationId
              ? {
                  ...c,
                  lastMessage: replyMsg.text,
                  lastMessageTime: 'À l’instant'
                }
              : c
          )
        );
      }
    }, 1800);
  };

  const createDirectConversation = (recipient: {
    id: string;
    name: string;
    title: string;
    avatar: string;
    org: string;
    role: string;
  }): string => {
    const existing = conversations.find((c) => c.participantId === recipient.id);
    if (existing) {
      setActiveConversationId(existing.id);
      setIsQuickChatOpen(true);
      return existing.id;
    }

    const newConvId = `conv-${Date.now()}`;
    const newConv: Conversation = {
      id: newConvId,
      participantId: recipient.id,
      participantName: recipient.name,
      participantTitle: recipient.title,
      participantAvatar: recipient.avatar,
      participantOrg: recipient.org,
      participantRole: recipient.role,
      lastMessage: 'Conversation directe initiée sur Africa Talent Football',
      lastMessageTime: 'À l’instant',
      unreadCount: 0,
      online: true
    };

    setConversations((prev) => [newConv, ...prev]);
    setMessages((prev) => ({
      ...prev,
      [newConvId]: [
        {
          id: `msg-welcome-${Date.now()}`,
          conversationId: newConvId,
          senderId: 'user-scout-01',
          senderName: FOUNDER_INFO.name,
          senderAvatar: '/src/assets/images/founder_mario_suit_1792079172729.jpg',
          senderRole: 'Scout Agent & Directeur ATF',
          text: `Bonjour ${recipient.name}, je vous contacte depuis le desk de direction d’Africa Talent Football.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isMine: true
        }
      ]
    }));

    setActiveConversationId(newConvId);
    setIsQuickChatOpen(true);
    return newConvId;
  };

  const addFeedPost = (
    content: string,
    tags: string[] = ['#AfricaTalentFootball', '#ScoutingPro'],
    playerAttachment?: any,
    authorOverride?: Partial<FeedPost>
  ) => {
    const newPost: FeedPost = {
      id: `post-${Date.now()}`,
      authorId: authorOverride?.authorId,
      authorName: authorOverride?.authorName || FOUNDER_INFO.name,
      authorTitle: authorOverride?.authorTitle || FOUNDER_INFO.officialTitle,
      authorAvatar: authorOverride?.authorAvatar || '/src/assets/images/founder_mario_suit_1792079172729.jpg',
      authorOrg: authorOverride?.authorOrg || 'Africa Talent Football Platform',
      authorRole: authorOverride?.authorRole || 'SCOUT_AGENT',
      isVerified: authorOverride?.isVerified !== undefined ? authorOverride.isVerified : true,
      isPremiumAuthor: Boolean(authorOverride?.isPremiumAuthor),
      category: authorOverride?.category || 'GENERAL',
      mediaUrl: authorOverride?.mediaUrl,
      timeAgo: 'À l’instant',
      content,
      tags,
      likesCount: 1,
      commentsCount: 0,
      sharesCount: 0,
      isLiked: true,
      playerAttachment,
      comments: []
    };

    setFeedPosts((prev) => [newPost, ...prev]);
  };

  const deleteFeedPost = (postId: string) => {
    setFeedPosts((prev) => prev.filter((p) => p.id !== postId));
  };

  const likePost = (postId: string) => {
    setFeedPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const isLiked = !p.isLiked;
          return {
            ...p,
            isLiked,
            likesCount: isLiked ? p.likesCount + 1 : p.likesCount - 1
          };
        }
        return p;
      })
    );
  };

  const addComment = (
    postId: string,
    commentText: string,
    commenter?: { name: string; title: string }
  ) => {
    if (!commentText.trim()) return;

    setFeedPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          return {
            ...p,
            commentsCount: p.commentsCount + 1,
            comments: [
              ...p.comments,
              {
                id: `c-${Date.now()}`,
                author: commenter?.name || FOUNDER_INFO.name,
                authorTitle: commenter?.title || 'Membre Réseau ATF',
                text: commentText,
                time: 'À l’instant'
              }
            ]
          };
        }
        return p;
      })
    );
  };

  const toggleConnection = (proId: string) => {
    setProfessionals((prev) =>
      prev.map((pro) => {
        if (pro.id === proId) {
          const nextStatus =
            pro.connectionStatus === 'CONNECT'
              ? 'PENDING'
              : pro.connectionStatus === 'PENDING'
              ? 'CONNECTED'
              : 'CONNECT';
          return { ...pro, connectionStatus: nextStatus };
        }
        return pro;
      })
    );
  };

  const contextValue = useMemo<NetworkContextType>(() => ({
    clubs,
    professionals,
    companies,
    feedPosts,
    conversations,
    messages,
    activeConversationId,
    setActiveConversationId,
    sendMessage,
    createDirectConversation,
    addFeedPost,
    deleteFeedPost,
    likePost,
    addComment,
    toggleConnection,
    globalSearch,
    setGlobalSearch,
    isQuickChatOpen,
    setIsQuickChatOpen,
    totalUnreadCount
  }), [
    clubs,
    professionals,
    companies,
    feedPosts,
    conversations,
    messages,
    activeConversationId,
    globalSearch,
    isQuickChatOpen,
    totalUnreadCount
  ]);

  return (
    <NetworkContext.Provider value={contextValue}>
      {children}
    </NetworkContext.Provider>
  );
};

export const useNetwork = (): NetworkContextType => {
  const context = useContext(NetworkContext);
  if (!context) {
    throw new Error('useNetwork must be used within a NetworkProvider');
  }
  return context;
};
