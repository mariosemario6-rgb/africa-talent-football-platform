import React, { createContext, useContext, useState, ReactNode } from 'react';
import {
  SubscriptionTier,
  BillingInterval,
  CurrencyCode,
  PaymentMethodType,
  UserSubscription
} from '../types/database';
import { useAuth } from './AuthContext';

export interface PricingPlan {
  id: SubscriptionTier;
  title: string;
  targetAudience: string;
  badge?: string;
  monthlyEur: number;
  annualEur: number; // 20% discount applied
  features: string[];
  deliverables: {
    videoUploadLimit: string;
    scoutingAudit: string;
    directDeskAccess: string;
    directoryPlacement: string;
  };
  highlight?: boolean;
}

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'PLAYER_PRO',
    title: 'Talent Pro Passport',
    targetAudience: 'Pour jeunes joueurs & académies en recherche de visibilité pro',
    badge: 'LE PLUS POPULAIRE TALENTS',
    monthlyEur: 19,
    annualEur: 180,
    features: [
      'Badge Officiel « Audité Seydou Mario TRAORÉ »',
      'Upload vidéo de match complet 90 min (Format Eyeball HD)',
      'Positionnement prioritaire en tête de l’annuaire talents',
      'Calcul algorithmique de cote marchande officiel',
      'Alertes directes lors des appels d’offre de clubs européens',
      'Conformité stricte FIFA Art. 19 avec mandat tuteur'
    ],
    deliverables: {
      videoUploadLimit: 'Vidéos illimitées (1080p)',
      scoutingAudit: 'Audit technique complet sous 48h',
      directDeskAccess: 'Support prioritaire WhatsApp',
      directoryPlacement: 'Top 10% de visibilité recruteurs'
    }
  },
  {
    id: 'SCOUT_PRO',
    title: 'Scout Pro Intelligence',
    targetAudience: 'Pour scouts indépendants, agents licenciés & intermédiaires',
    badge: 'POUR SCOUTS & RECRUTEURS',
    monthlyEur: 79,
    annualEur: 750,
    highlight: true,
    features: [
      'Accès illimité à la banque vidéo Eyeball & séquences brutes',
      'Données GPS & métriques athlétiques complètes (Catapult)',
      'Export PDF instantané de fiches techniques avec cotes marchandes',
      'Messagerie directe illimitée avec les clubs et présidents',
      'Création et gestion de shortlists de scouting privées',
      'Accès aux coordonnées vérifiées des tuteurs légaux'
    ],
    deliverables: {
      videoUploadLimit: 'Téléchargement séquences HD illimité',
      scoutingAudit: 'Accès aux notes brutes Mario TRAORÉ',
      directDeskAccess: 'Canal prioritaire desk 7j/7',
      directoryPlacement: 'Profil scout certifié et vérifié'
    }
  },
  {
    id: 'CLUB_ELITE',
    title: 'Club Elite Access',
    targetAudience: 'Pour clubs professionnels européens, africains & mondiaux',
    badge: 'CLUBS DE 1ÈRE & 2ÈME DIVISION',
    monthlyEur: 249,
    annualEur: 2400,
    features: [
      'Publication d’appels d’offres officiels de recrutement sur le fil B2B',
      'Réservation prioritaire de places VIP aux Showcases (Abidjan/Dakar)',
      'Ligne directe exclusive avec Seydou Mario TRAORÉ (Scout Agent)',
      'Envoi sous 24h de matches complets avec fiches médicales',
      'Recherche avancée multicritères (profil morphologique & VMA)',
      'Mise en relation directe avec les académies formatrices certifiées'
    ],
    deliverables: {
      videoUploadLimit: 'Accès total multi-utilisateurs club',
      scoutingAudit: 'Rapports personnalisés sur-mesure',
      directDeskAccess: 'Ligne directe personnelle fondateur',
      directoryPlacement: 'Badge Club Professionnel Vérifié'
    }
  },
  {
    id: 'ENTERPRISE',
    title: 'Corporate & Brand Partner',
    targetAudience: 'Pour équipementiers, sponsors, marques de data & legal',
    monthlyEur: 499,
    annualEur: 4800,
    features: [
      'Espace entreprise officiel avec catalogue de services & partenariats',
      'Publications sponsorisées sur le fil réseau LinkedIn B2B',
      'Stand officiel & branding lors des tournois internationaux ATF',
      'Accès privilégié aux jeunes athlètes pour contrats de sponsoring',
      'Génération de leads qualifiés auprès des 100+ clubs affiliés'
    ],
    deliverables: {
      videoUploadLimit: 'Intégration technologique plateforme',
      scoutingAudit: 'Co-branding rapports d’audits',
      directDeskAccess: 'Account manager dédié',
      directoryPlacement: 'Top Sponsor Officiel'
    }
  }
];

export const CURRENCY_RATES: Record<CurrencyCode, { rate: number; symbol: string; label: string }> = {
  EUR: { rate: 1.0, symbol: '€', label: 'EUR (€) - Europe & International' },
  USD: { rate: 1.08, symbol: '$', label: 'USD ($) - Americas & Global' },
  GBP: { rate: 0.85, symbol: '£', label: 'GBP (£) - United Kingdom' },
  XOF: { rate: 655.957, symbol: 'FCFA', label: 'XOF (FCFA) - Afrique de l’Ouest & Centrale' }
};

interface PaymentContextType {
  currency: CurrencyCode;
  setCurrency: (code: CurrencyCode) => void;
  formatPrice: (amountEur: number, interval?: BillingInterval) => string;
  isCheckoutOpen: boolean;
  selectedTier: SubscriptionTier | null;
  openCheckout: (tier: SubscriptionTier) => void;
  closeCheckout: () => void;
  processPayment: (params: {
    tier: SubscriptionTier;
    interval: BillingInterval;
    provider: PaymentMethodType;
    details: string;
  }) => Promise<boolean>;
  activeSubscription: UserSubscription | null;
  cancelSubscription: () => void;
}

const PaymentContext = createContext<PaymentContextType | undefined>(undefined);

export const PaymentProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { currentUser, updateUser } = useAuth();

  const [currency, setCurrency] = useState<CurrencyCode>('EUR');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [selectedTier, setSelectedTier] = useState<SubscriptionTier | null>(null);

  // Active subscription from user profile or fallback
  const [activeSubscription, setActiveSubscription] = useState<UserSubscription | null>(
    currentUser?.subscription || null
  );

  const formatPrice = (amountEur: number, interval: BillingInterval = 'MONTHLY'): string => {
    const rateInfo = CURRENCY_RATES[currency] || CURRENCY_RATES.EUR;
    const converted = amountEur * rateInfo.rate;

    if (currency === 'XOF') {
      const rounded = Math.round(converted / 500) * 500;
      return `${rounded.toLocaleString('fr-FR')} ${rateInfo.symbol}${interval === 'ANNUAL' ? ' / an' : ' / mois'}`;
    }

    if (currency === 'GBP') {
      return `${rateInfo.symbol}${Math.round(converted)}${interval === 'ANNUAL' ? ' / yr' : ' / mo'}`;
    }

    if (currency === 'USD') {
      return `${rateInfo.symbol}${Math.round(converted)}${interval === 'ANNUAL' ? ' / yr' : ' / mo'}`;
    }

    return `${Math.round(converted)} ${rateInfo.symbol}${interval === 'ANNUAL' ? ' / an' : ' / mois'}`;
  };

  const openCheckout = (tier: SubscriptionTier) => {
    setSelectedTier(tier);
    setIsCheckoutOpen(true);
  };

  const closeCheckout = () => {
    setIsCheckoutOpen(false);
    setSelectedTier(null);
  };

  const processPayment = async (params: {
    tier: SubscriptionTier;
    interval: BillingInterval;
    provider: PaymentMethodType;
    details: string;
  }): Promise<boolean> => {
    // Simulate real gateway processing latency with security check
    await new Promise((resolve) => setTimeout(resolve, 1400));

    const plan = PRICING_PLANS.find((p) => p.id === params.tier) || PRICING_PLANS[0];
    const amountPaid = params.interval === 'ANNUAL' ? plan.annualEur : plan.monthlyEur;

    const expirationDate = new Date();
    if (params.interval === 'ANNUAL') {
      expirationDate.setFullYear(expirationDate.getFullYear() + 1);
    } else {
      expirationDate.setMonth(expirationDate.getMonth() + 1);
    }

    const newSub: UserSubscription = {
      tier: params.tier,
      interval: params.interval,
      status: 'ACTIVE',
      startDate: new Date().toISOString().split('T')[0],
      expiresAt: expirationDate.toISOString().split('T')[0],
      pricePaid: amountPaid,
      currency,
      paymentMethod: {
        type: params.provider,
        details: params.details
      },
      invoiceId: `ATF-INV-${Date.now().toString().slice(-6)}`
    };

    setActiveSubscription(newSub);
    if (currentUser) {
      updateUser({ subscription: newSub, verified: true });
    }

    return true;
  };

  const cancelSubscription = () => {
    if (!activeSubscription) return;
    const updated: UserSubscription = {
      ...activeSubscription,
      status: 'CANCELLED'
    };
    setActiveSubscription(updated);
    if (currentUser) {
      updateUser({ subscription: updated });
    }
  };

  return (
    <PaymentContext.Provider
      value={{
        currency,
        setCurrency,
        formatPrice,
        isCheckoutOpen,
        selectedTier,
        openCheckout,
        closeCheckout,
        processPayment,
        activeSubscription,
        cancelSubscription
      }}
    >
      {children}
    </PaymentContext.Provider>
  );
};

export const usePayment = (): PaymentContextType => {
  const context = useContext(PaymentContext);
  if (!context) {
    throw new Error('usePayment must be used within a PaymentProvider');
  }
  return context;
};
