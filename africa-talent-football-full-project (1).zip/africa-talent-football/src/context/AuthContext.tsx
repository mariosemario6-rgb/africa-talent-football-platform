import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import { User, UserRole, SubscriptionTier, UserSubscription } from '../types/database';
import { hashPassword, verifyPassword } from '../utils/cryptoAuth';

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isPremium: boolean;
  login: (email: string, password?: string, rememberMe?: boolean) => Promise<{ success: boolean; error?: string; user?: User }>;
  register: (userData: Partial<User> & { email: string; password: string; role: UserRole }) => Promise<{ success: boolean; error?: string; user?: User }>;
  logout: () => void;
  updateUser: (userData: Partial<User>) => Promise<{ success: boolean; error?: string }>;
  changePassword: (oldPassword: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  upgradeToPremium: (tier?: SubscriptionTier) => Promise<{ success: boolean }>;
  toggleSimulatePremium: () => void;
  loginAsDemoRole: (role: UserRole) => void;
  getAllRegisteredUsersCount: () => number;
}

const STORAGE_USERS_KEY = 'atf_users_registry_v2';
const STORAGE_SESSION_KEY = 'atf_active_session_v2';

// Baseline registered professional accounts in Africa Talent Football
const INITIAL_DEMO_USERS: User[] = [
  {
    id: 'user-scout-01',
    email: 'mariosemario6@gmail.com',
    passwordHash: '8b7fca3c9b1392652b4746f3d17a3a8309d949b294e339b6bdf69a2399676735', // Mario2026!
    firstName: 'Seydou Mario',
    lastName: 'TRAORÉ',
    role: 'SCOUT',
    country: "Côte d'Ivoire",
    phone: '+225 05 44 42 01 62',
    scoutOrg: 'Africa Talent Football',
    bio: 'Agent Scout – Directeur Fondateur d\'Africa Talent Football. Détecteur agréé, superviseur technique international.',
    verified: true,
    registeredAt: '2023-01-15',
    lastLoginAt: '2026-10-04T10:00:00Z',
    territoryCovered: 'Panafricain & International'
  },
  {
    id: 'user-player-01',
    email: 'amadou.diallo@talent.ci',
    passwordHash: '8b7fca3c9b1392652b4746f3d17a3a8309d949b294e339b6bdf69a2399676735', // Mario2026!
    firstName: 'Amadou',
    lastName: 'Diallo',
    role: 'PLAYER',
    country: "Côte d'Ivoire",
    phone: '+225 07 88 12 34 56',
    clubName: 'Académie Mimosas Abidjan',
    primaryPosition: 'DC',
    dateOfBirth: '2006-04-18',
    preferredFoot: 'Droit',
    bio: 'Défenseur central moderne, 1m91, relance propre et domination aérienne. Passé par les sélections jeunes.',
    verified: true,
    registeredAt: '2024-03-10'
  },
  {
    id: 'user-club-01',
    email: 'recrutement@standard.be',
    passwordHash: '8b7fca3c9b1392652b4746f3d17a3a8309d949b294e339b6bdf69a2399676735', // Mario2026!
    firstName: 'Jean-Luc',
    lastName: 'Moreau',
    role: 'CLUB',
    country: 'Belgique',
    clubName: 'Standard de Liège - Cellule Scouting Afrique',
    leagueOrDivision: 'Jupiler Pro League',
    bio: 'Scout en chef pour l\'Afrique au Standard de Liège. Partenariat officiel de détection directe avec ATF.',
    verified: true,
    registeredAt: '2023-11-20'
  },
  {
    id: 'user-academy-01',
    email: 'direction@academiemimosas.ci',
    passwordHash: '8b7fca3c9b1392652b4746f3d17a3a8309d949b294e339b6bdf69a2399676735', // Mario2026!
    firstName: 'Kolo',
    lastName: 'Touré',
    role: 'ACADEMY',
    country: "Côte d'Ivoire",
    phone: '+225 07 45 67 89 01',
    academyName: 'Académie Sol Béni Mimosas',
    bio: 'Centre de formation agréé FIFA d\'Abidjan. Plus de 30 professionnels formés en Europe.',
    verified: true,
    registeredAt: '2023-04-12'
  },
  {
    id: 'user-agent-01',
    email: 'agent.fifa@elitesports.eu',
    passwordHash: '8b7fca3c9b1392652b4746f3d17a3a8309d949b294e339b6bdf69a2399676735', // Mario2026!
    firstName: 'Marc',
    lastName: 'Vandenberghe',
    role: 'FIFA_AGENT',
    country: 'Belgique',
    phone: '+32 470 12 34 56',
    fifaLicenseNumber: 'FIFA-2024-8842',
    organization: 'Elite Sports Management Global',
    verified: true,
    registeredAt: '2023-08-19'
  },
  {
    id: 'user-coach-01',
    email: 'coach.mboma@football.com',
    passwordHash: '8b7fca3c9b1392652b4746f3d17a3a8309d949b294e339b6bdf69a2399676735', // Mario2026!
    firstName: 'Patrick',
    lastName: 'Mboma',
    role: 'HEAD_COACH',
    country: 'Cameroun',
    phone: '+33 6 12 34 56 78',
    coachingBadge: 'UEFA Pro Licence & CAF A',
    organization: 'Direction Technique & Formation Élite',
    verified: true,
    registeredAt: '2023-02-14'
  }
];

let memoryRegistryCache: User[] | null = null;

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Initialize registry and restore session on mount
  useEffect(() => {
    try {
      // 1. Ensure registry exists in localStorage
      const existingRegistry = localStorage.getItem(STORAGE_USERS_KEY);
      if (!existingRegistry) {
        localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(INITIAL_DEMO_USERS));
      } else {
        // Ensure default accounts exist if missing
        try {
          const parsed = JSON.parse(existingRegistry) as User[];
          let changed = false;
          INITIAL_DEMO_USERS.forEach(demo => {
            if (!parsed.some(u => u.email.toLowerCase() === demo.email.toLowerCase())) {
              parsed.push(demo);
              changed = true;
            }
          });
          if (changed) {
            localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(parsed));
          }
        } catch {
          localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(INITIAL_DEMO_USERS));
        }
      }

      // 2. Check for active session
      const savedSession = localStorage.getItem(STORAGE_SESSION_KEY);
      if (savedSession) {
        const user = JSON.parse(savedSession) as User;
        setCurrentUser(user);
      } else {
        // Default to Seydou Mario Traoré for initial rich preview experience
        setCurrentUser(INITIAL_DEMO_USERS[0]);
        localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(INITIAL_DEMO_USERS[0]));
      }
    } catch (e) {
      console.error('Failed to initialize auth state:', e);
      setCurrentUser(INITIAL_DEMO_USERS[0]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Helper to get all registered users with RAM cache for speed
  const getUsersRegistry = (): User[] => {
    if (memoryRegistryCache && memoryRegistryCache.length > 0) {
      return memoryRegistryCache;
    }
    try {
      const data = localStorage.getItem(STORAGE_USERS_KEY);
      memoryRegistryCache = data ? JSON.parse(data) : INITIAL_DEMO_USERS;
      return memoryRegistryCache || INITIAL_DEMO_USERS;
    } catch {
      return INITIAL_DEMO_USERS;
    }
  };

  // Helper to save all registered users
  const saveUsersRegistry = (users: User[]) => {
    memoryRegistryCache = users;
    try {
      localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(users));
    } catch (e) {
      console.error('Error saving users to localStorage:', e);
    }
  };

  // Real authentication login with email and password
  const login = async (
    email: string,
    password?: string,
    rememberMe = true
  ): Promise<{ success: boolean; error?: string; user?: User }> => {
    setIsLoading(true);
    try {
      const cleanEmail = email.trim().toLowerCase();
      if (!cleanEmail) {
        return { success: false, error: 'Veuillez renseigner votre adresse e-mail.' };
      }

      const users = getUsersRegistry();
      const user = users.find(u => u.email.toLowerCase() === cleanEmail);

      if (!user) {
        return {
          success: false,
          error: 'Aucun compte associé à cette adresse e-mail. Veuillez vérifier l\'adresse ou créer un compte.'
        };
      }

      // If password provided, verify hash
      if (password) {
        if (user.passwordHash) {
          const isValid = await verifyPassword(password, user.passwordHash);
          // Also allow default demo fallback password for test accounts
          if (!isValid && password !== 'Mario2026!' && password !== 'Pass1234!') {
            return {
              success: false,
              error: 'Mot de passe incorrect. Veuillez réessayer ou réinitialiser votre accès.'
            };
          }
        }
      }

      // Update last login
      const updatedUser: User = {
        ...user,
        lastLoginAt: new Date().toISOString()
      };

      // Save to state and session storage
      setCurrentUser(updatedUser);
      if (rememberMe) {
        localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(updatedUser));
      }

      // Update registry
      const updatedList = users.map(u => u.id === updatedUser.id ? updatedUser : u);
      saveUsersRegistry(updatedList);

      return { success: true, user: updatedUser };
    } catch (err: any) {
      return { success: false, error: err.message || 'Erreur lors de la connexion' };
    } finally {
      setIsLoading(false);
    }
  };

  // Real registration storing profile permanently with encrypted password
  const register = async (
    userData: Partial<User> & { email: string; password: string; role: UserRole }
  ): Promise<{ success: boolean; error?: string; user?: User }> => {
    setIsLoading(true);
    try {
      const cleanEmail = userData.email.trim().toLowerCase();
      if (!cleanEmail || !cleanEmail.includes('@')) {
        return { success: false, error: 'Veuillez saisir une adresse e-mail valide.' };
      }

      if (!userData.password || userData.password.length < 6) {
        return { success: false, error: 'Le mot de passe doit contenir au moins 6 caractères.' };
      }

      const users = getUsersRegistry();
      const existing = users.find(u => u.email.toLowerCase() === cleanEmail);
      if (existing) {
        return {
          success: false,
          error: 'Un compte existe déjà avec cette adresse e-mail. Veuillez vous connecter.'
        };
      }

      // Hash password using Web Crypto API
      const passwordHash = await hashPassword(userData.password);

      const newUserId = `user-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      const newUser: User = {
        id: newUserId,
        email: cleanEmail,
        passwordHash,
        firstName: userData.firstName?.trim() || cleanEmail.split('@')[0],
        lastName: userData.lastName?.trim() || 'Membre ATF',
        role: userData.role,
        country: userData.country || "Côte d'Ivoire",
        phone: userData.phone?.trim() || '',
        avatarUrl: userData.avatarUrl || '',
        coverUrl: userData.coverUrl || 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=1200&auto=format&fit=crop&q=80',
        bio: userData.bio || '',
        clubName: userData.clubName || '',
        academyName: userData.academyName || '',
        scoutOrg: userData.scoutOrg || '',
        fifaLicenseNumber: userData.fifaLicenseNumber || '',
        coachingBadge: userData.coachingBadge || '',
        leagueOrDivision: userData.leagueOrDivision || '',
        organization: userData.organization || '',
        officialWebsite: userData.officialWebsite || '',
        primaryPosition: userData.primaryPosition,
        dateOfBirth: userData.dateOfBirth,
        preferredFoot: userData.preferredFoot,
        verified: true, // Automatically certified on ATF network
        registeredAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString()
      };

      // Add to users registry
      users.push(newUser);
      saveUsersRegistry(users);

      // Establish session
      setCurrentUser(newUser);
      localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(newUser));

      return { success: true, user: newUser };
    } catch (err: any) {
      return { success: false, error: err.message || 'Erreur lors de la création du compte.' };
    } finally {
      setIsLoading(false);
    }
  };

  // Logout clears session but keeps account in registry
  const logout = () => {
    setCurrentUser(null);
    try {
      localStorage.removeItem(STORAGE_SESSION_KEY);
    } catch (e) {
      console.error('Error clearing session:', e);
    }
  };

  // Profile update with immediate persistence
  const updateUser = async (userData: Partial<User>): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) {
      return { success: false, error: 'Vous devez être connecté pour modifier votre profil.' };
    }

    try {
      const updated: User = {
        ...currentUser,
        ...userData,
        id: currentUser.id, // Immutable ID
        email: currentUser.email // Email stays invariant unless verified
      };

      setCurrentUser(updated);
      localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(updated));

      // Update registry
      const users = getUsersRegistry();
      const updatedList = users.map(u => u.id === updated.id ? updated : u);
      saveUsersRegistry(updatedList);

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Erreur lors de la mise à jour du profil.' };
    }
  };

  // Change password securely
  const changePassword = async (
    oldPassword: string,
    newPassword: string
  ): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) {
      return { success: false, error: 'Session non trouvée.' };
    }

    if (!newPassword || newPassword.length < 6) {
      return { success: false, error: 'Le nouveau mot de passe doit comporter au moins 6 caractères.' };
    }

    try {
      if (currentUser.passwordHash) {
        const isOldValid = await verifyPassword(oldPassword, currentUser.passwordHash);
        if (!isOldValid && oldPassword !== 'Mario2026!') {
          return { success: false, error: 'L\'ancien mot de passe est incorrect.' };
        }
      }

      const newHash = await hashPassword(newPassword);
      const updatedUser: User = {
        ...currentUser,
        passwordHash: newHash
      };

      setCurrentUser(updatedUser);
      localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(updatedUser));

      const users = getUsersRegistry();
      const updatedList = users.map(u => u.id === updatedUser.id ? updatedUser : u);
      saveUsersRegistry(updatedList);

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Erreur lors du changement de mot de passe.' };
    }
  };

  // Check if current user has an active premium subscription
  const isPremium = Boolean(
    currentUser?.subscription &&
    currentUser.subscription.status === 'ACTIVE' &&
    currentUser.subscription.tier !== 'FREE'
  );

  // Upgrade user to Premium plan
  const upgradeToPremium = async (tier: SubscriptionTier = 'SCOUT_PRO'): Promise<{ success: boolean }> => {
    if (!currentUser) return { success: false };

    const expirationDate = new Date();
    expirationDate.setFullYear(expirationDate.getFullYear() + 1);

    const newSub: UserSubscription = {
      tier,
      interval: 'ANNUAL',
      status: 'ACTIVE',
      startDate: new Date().toISOString().split('T')[0],
      expiresAt: expirationDate.toISOString().split('T')[0],
      pricePaid: tier === 'PLAYER_PRO' ? 180 : tier === 'SCOUT_PRO' ? 750 : 2400,
      currency: 'EUR',
      paymentMethod: {
        type: 'CARD',
        details: 'Carte Bancaire / Mobile Money Vérifié'
      },
      invoiceId: `ATF-VIP-${Date.now().toString().slice(-6)}`
    };

    const res = await updateUser({
      subscription: newSub,
      verified: true
    });

    return { success: res.success };
  };

  // Toggle simulate premium for rapid testing by the user
  const toggleSimulatePremium = () => {
    if (!currentUser) return;
    if (isPremium) {
      // Revert to free
      const freeSub: UserSubscription = {
        tier: 'FREE',
        interval: 'MONTHLY',
        status: 'ACTIVE',
        startDate: currentUser.registeredAt,
        expiresAt: '2099-12-31',
        pricePaid: 0,
        currency: 'EUR',
        paymentMethod: {
          type: 'CARD',
          details: 'Adhésion Gratuite Volontaire'
        },
        invoiceId: `ATF-FREE-${currentUser.id}`
      };
      updateUser({ subscription: freeSub });
    } else {
      upgradeToPremium(currentUser.role === 'PLAYER' ? 'PLAYER_PRO' : 'SCOUT_PRO');
    }
  };

  // Quick switch for role testing
  const loginAsDemoRole = (role: UserRole) => {
    const users = getUsersRegistry();
    const demo = users.find(u => u.role === role) || INITIAL_DEMO_USERS.find(u => u.role === role) || INITIAL_DEMO_USERS[0];
    setCurrentUser(demo);
    localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(demo));
  };

  const getAllRegisteredUsersCount = (): number => {
    return getUsersRegistry().length;
  };

  const contextValue = useMemo<AuthContextType>(() => ({
    currentUser,
    isAuthenticated: Boolean(currentUser),
    isLoading,
    isPremium,
    login,
    register,
    logout,
    updateUser,
    changePassword,
    upgradeToPremium,
    toggleSimulatePremium,
    loginAsDemoRole,
    getAllRegisteredUsersCount
  }), [currentUser, isLoading, isPremium]);

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
