import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import { RegisteredPlayer } from '../types/database';
import { INITIAL_REGISTERED_PLAYERS, estimateMarketValue, formatMarketValue, ASSETS } from '../data/demoData';

interface PlayerContextType {
  players: RegisteredPlayer[];
  registerNewPlayer: (data: Partial<RegisteredPlayer>) => RegisteredPlayer;
  deletePlayer: (id: string) => void;
  resetDefaultPlayers: () => void;
  activeVideo: { player: RegisteredPlayer; url: string; title: string } | null;
  openVideoModal: (player: RegisteredPlayer) => void;
  closeVideoModal: () => void;
  totalMarketValue: number;

  // Favorites & Shortlist
  favorites: string[];
  toggleFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;
  isFavoritesModalOpen: boolean;
  setIsFavoritesModalOpen: (open: boolean) => void;

  // Talent Comparison
  comparisonIds: string[];
  toggleComparison: (id: string) => void;
  clearComparison: () => void;
  isInComparison: (id: string) => boolean;
  isComparisonModalOpen: boolean;
  setIsComparisonModalOpen: (open: boolean) => void;
}

const STORAGE_KEY = 'atf_registered_players_v2';
const FAVORITES_STORAGE_KEY = 'atf_player_favorites_v1';

const PlayerContext = createContext<PlayerContextType | undefined>(undefined);

export const PlayerProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [players, setPlayers] = useState<RegisteredPlayer[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed: RegisteredPlayer[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Merge demo upgrades (biometrics, transferHistory, aiCertification)
          return parsed.map((p) => {
            const initial = INITIAL_REGISTERED_PLAYERS.find((init) => init.id === p.id);
            if (initial) {
              return {
                ...initial,
                ...p,
                biometrics: p.biometrics || initial.biometrics,
                transferHistory: p.transferHistory || initial.transferHistory,
                aiCertification: p.aiCertification || initial.aiCertification
              };
            }
            return p;
          });
        }
      }
    } catch {
      // Fallback
    }
    return INITIAL_REGISTERED_PLAYERS;
  });

  const [activeVideo, setActiveVideo] = useState<{ player: RegisteredPlayer; url: string; title: string } | null>(null);

  // Favorites state
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(FAVORITES_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return ['atf-ply-001', 'atf-ply-002'];
  });
  const [isFavoritesModalOpen, setIsFavoritesModalOpen] = useState(false);

  // Comparison state
  const [comparisonIds, setComparisonIds] = useState<string[]>(['atf-ply-001', 'atf-ply-002']);
  const [isComparisonModalOpen, setIsComparisonModalOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(players));
    } catch (e) {
      console.warn('Could not persist players to localStorage', e);
    }
  }, [players]);

  useEffect(() => {
    try {
      localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favorites));
    } catch (e) {
      console.warn('Could not persist favorites to localStorage', e);
    }
  }, [favorites]);

  const toggleFavorite = (id: string) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const isFavorite = (id: string) => favorites.includes(id);

  const toggleComparison = (id: string) => {
    setComparisonIds((prev) => {
      if (prev.includes(id)) {
        return prev.filter((item) => item !== id);
      }
      if (prev.length >= 3) {
        // Replace oldest or keep max 3
        return [...prev.slice(1), id];
      }
      return [...prev, id];
    });
  };

  const clearComparison = () => {
    setComparisonIds([]);
  };

  const isInComparison = (id: string) => comparisonIds.includes(id);

  const openVideoModal = (player: RegisteredPlayer) => {
    setActiveVideo({
      player,
      url: player.videoUrl || 'https://www.youtube.com',
      title: player.videoTitle || `${player.firstName} ${player.lastName} - Vidéo de Scouting Officielle`
    });
  };

  const closeVideoModal = () => {
    setActiveVideo(null);
  };

  const registerNewPlayer = (data: Partial<RegisteredPlayer>): RegisteredPlayer => {
    const calculatedAge = data.calculatedAge || (data.dateOfBirth ? Math.max(16, 2026 - parseInt(data.dateOfBirth.split('-')[0])) : 18);
    const isMinor = calculatedAge < 18;

    const stats = {
      matches: data.stats?.matches ?? 15,
      minutes: data.stats?.minutes ?? 1250,
      goals: data.stats?.goals ?? (data.primaryPosition === 'BU' ? 9 : 3),
      assists: data.stats?.assists ?? (data.primaryPosition === 'MC' ? 7 : 2),
      cleanSheets: data.stats?.cleanSheets ?? (data.primaryPosition === 'GB' ? 6 : 0),
      passAccuracyPct: data.stats?.passAccuracyPct ?? 82,
      topSpeedKmh: data.stats?.topSpeedKmh ?? 32.5,
      duelsWonPct: data.stats?.duelsWonPct ?? 65,
      yellowCards: data.stats?.yellowCards ?? 1
    };

    const estimatedValue = data.marketValueEur || estimateMarketValue(calculatedAge, data.primaryPosition || 'BU', stats);

    // Pick avatar based on position or default
    let defaultAvatar = ASSETS.playerStriker;
    if (data.primaryPosition === 'MC' || data.primaryPosition === 'MOC' || data.primaryPosition === 'MDF') {
      defaultAvatar = ASSETS.playerMidfielder;
    } else if (data.primaryPosition === 'DC' || data.primaryPosition === 'DL' || data.primaryPosition === 'GB') {
      defaultAvatar = ASSETS.playerDefender;
    }

    const newPlayer: RegisteredPlayer = {
      id: `atf-ply-${Date.now()}`,
      firstName: data.firstName || 'Talent',
      lastName: data.lastName || 'Africain',
      dateOfBirth: data.dateOfBirth || '2008-01-01',
      calculatedAge,
      isMinor,
      nationality: data.nationality || "Côte d'Ivoire",
      countryFlag: data.countryFlag || '🇨🇮',
      primaryPosition: data.primaryPosition || 'BU',
      secondaryPosition: data.secondaryPosition || '',
      preferredFoot: data.preferredFoot || 'Droit',
      heightCm: data.heightCm || 180,
      weightKg: data.weightKg || 74,
      currentClub: data.currentClub || 'Académie Indépendante',
      academy: data.academy || 'Centre de Formation Recommandé',
      avatarUrl: data.avatarUrl || defaultAvatar,
      videoUrl: data.videoUrl || 'https://www.youtube.com',
      videoTitle: data.videoTitle || `${data.firstName || 'Joueur'} ${data.lastName || ''} - Séquences Clés & Buts`,
      marketValueEur: estimatedValue,
      marketValueDisplay: formatMarketValue(estimatedValue),
      marketValueTrend: 'UP',
      contractStatus: data.contractStatus || 'Sous convention académie',
      stats,
      physicalRadar: data.physicalRadar || {
        pace: Math.min(95, Math.round(stats.topSpeedKmh * 2.6)),
        shooting: data.primaryPosition === 'BU' ? 86 : 72,
        passing: stats.passAccuracyPct,
        dribbling: 82,
        defending: data.primaryPosition === 'DC' ? 90 : 50,
        physicality: 80
      },
      guardianContact: isMinor
        ? data.guardianContact || {
            name: 'Mandataire Légal Agréé',
            phone: '+225 05 44 42 01 62',
            relationship: 'Représentant Légal'
          }
        : undefined,
      scoutingReports: [
        {
          id: `rep-${Date.now()}`,
          scoutName: 'Seydou Mario TRAORÉ',
          scoutTitle: 'Scout Agent, Director, Founder of Africa Talent Football',
          date: new Date().toISOString().split('T')[0],
          overallRating: 88,
          potentialRating: 93,
          summary: `Profil athlétique audité et validé sur la plateforme Africa Talent Football. Données morphologiques, vidéo et statistiques attestées par Seydou Mario TRAORÉ.`,
          strengths: ['Capacité athlétique', 'Qualité technique dans le jeu direct', 'Discipline tactique'],
          areasOfDevelopment: ['Adaptation au rythme européen de haute intensité']
        }
      ],
      certifiedBy: 'Seydou Mario TRAORÉ, Scout Agent & Fondateur',
      registeredAt: new Date().toISOString().split('T')[0],
      status: 'DISPONIBLE',
      bio: data.bio || `Joueur enregistré et certifié sur la plateforme Africa Talent Football sous la direction de Seydou Mario TRAORÉ.`
    };

    setPlayers((prev) => [newPlayer, ...prev]);
    return newPlayer;
  };

  const deletePlayer = (id: string) => {
    setPlayers((prev) => prev.filter((p) => p.id !== id));
  };

  const resetDefaultPlayers = () => {
    setPlayers(INITIAL_REGISTERED_PLAYERS);
  };

  const totalMarketValue = useMemo(() => {
    return players.reduce((sum, p) => sum + p.marketValueEur, 0);
  }, [players]);

  const contextValue = useMemo<PlayerContextType>(() => ({
    players,
    registerNewPlayer,
    deletePlayer,
    resetDefaultPlayers,
    activeVideo,
    openVideoModal,
    closeVideoModal,
    totalMarketValue,
    favorites,
    toggleFavorite,
    isFavorite,
    isFavoritesModalOpen,
    setIsFavoritesModalOpen,
    comparisonIds,
    toggleComparison,
    clearComparison,
    isInComparison,
    isComparisonModalOpen,
    setIsComparisonModalOpen
  }), [
    players,
    activeVideo,
    totalMarketValue,
    favorites,
    isFavoritesModalOpen,
    comparisonIds,
    isComparisonModalOpen
  ]);

  return (
    <PlayerContext.Provider value={contextValue}>
      {children}
    </PlayerContext.Provider>
  );
};

export const usePlayers = (): PlayerContextType => {
  const context = useContext(PlayerContext);
  if (!context) {
    throw new Error('usePlayers must be used within a PlayerProvider');
  }
  return context;
};

export const usePlayer = usePlayers;
