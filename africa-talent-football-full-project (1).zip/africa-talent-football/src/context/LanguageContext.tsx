import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  Language,
  LanguageMeta,
  WORLD_LANGUAGES,
  allTranslations,
} from '../translations';

export * from '../translations';

export interface LanguageContextType {
  language: Language;
  currentLanguageMeta: LanguageMeta;
  setLanguage: (lang: Language) => void;
  t: (key: string, fallback?: string) => string;
  languages: LanguageMeta[];
  isRTL: boolean;
  dir: 'ltr' | 'rtl';

  // Football domain localization helpers
  tPosition: (pos: string) => string;
  tFoot: (foot: string) => string;
  tContract: (status: string) => string;
  tPlayerStatus: (status: string) => string;
  tRole: (role: string) => string;
  tTier: (tier: string) => string;

  // Formatting helpers
  formatDate: (date: string | Date | number, options?: Intl.DateTimeFormatOptions) => string;
  formatCurrency: (amount: number, currency?: string) => string;
  formatNumber: (num: number) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const detectInitialLanguage = (): Language => {
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('atf_language') as Language;
    if (saved && WORLD_LANGUAGES.some((l) => l.code === saved)) {
      return saved;
    }
    const navLangs = navigator.languages || [navigator.language || (navigator as any).userLanguage || ''];
    for (const raw of navLangs) {
      if (!raw) continue;
      const lower = raw.toLowerCase().trim();
      if (lower.startsWith('fr')) return 'fr';
      if (lower.startsWith('en')) return 'en';
      if (lower.startsWith('es')) return 'es';
      if (lower.startsWith('pt')) return 'pt';
      if (lower.startsWith('it')) return 'it';
      if (lower.startsWith('de')) return 'de';
      if (lower.startsWith('ar')) return 'ar';
      if (lower.startsWith('zh')) return 'zh';
      if (lower.startsWith('ru')) return 'ru';
      if (lower.startsWith('tr')) return 'tr';
    }
  }
  return 'fr';
};

// Domain mappings for positions, feet, contracts, statuses, roles, tiers
const POSITION_MAP: Record<string, Record<Language, string>> = {
  BU: {
    fr: 'Attaquant de pointe (BU)',
    en: 'Center Forward / Striker (CF)',
    es: 'Delantero Centro (DC)',
    pt: 'Centroavante (CA)',
    it: 'Punta Centrale (PC)',
    de: 'Mittelstürmer (MS)',
    ar: 'رأس حربة (م)',
    zh: '中锋 (CF)',
    ru: 'Центральный нападающий (ЦН)',
    tr: 'Santrfor (SF)',
  },
  AG: {
    fr: 'Ailier Gauche (AG)',
    en: 'Left Winger (LW)',
    es: 'Extremo Izquierdo (EI)',
    pt: 'Ponta Esquerda (PE)',
    it: 'Ala Sinistra (AS)',
    de: 'Linksaußen (LA)',
    ar: 'جناح أيسر (جا)',
    zh: '左边锋 (LW)',
    ru: 'Левый вингер (ЛВ)',
    tr: 'Sol Kanat (SK)',
  },
  AD: {
    fr: 'Ailier Droit (AD)',
    en: 'Right Winger (RW)',
    es: 'Extremo Derecho (ED)',
    pt: 'Ponta Direita (PD)',
    it: 'Ala Destra (AD)',
    de: 'Rechtsaußen (RA)',
    ar: 'جناح أيمن (جيم)',
    zh: '右边锋 (RW)',
    ru: 'Правый вингер (ПВ)',
    tr: 'Sağ Kanat (SK)',
  },
  MOC: {
    fr: 'Milieu Offensif (MOC)',
    en: 'Attacking Midfielder (CAM)',
    es: 'Mediocentro Ofensivo (MCO)',
    pt: 'Meia Ofensivo (MCO)',
    it: 'Trequartista (TRQ)',
    de: 'Offensives Mittelfeld (OM)',
    ar: 'وسط هجومي (وص هـ)',
    zh: '前腰 (CAM)',
    ru: 'Атакующий полузащитник (АПЗ)',
    tr: 'Ofansif Orta Saha (OOS)',
  },
  MC: {
    fr: 'Milieu Central (MC)',
    en: 'Central Midfielder (CM)',
    es: 'Mediocentro (MC)',
    pt: 'Meio-Campista (MC)',
    it: 'Centrocampista Centrale (CC)',
    de: 'Zentrales Mittelfeld (ZM)',
    ar: 'وسط ميدان (وص)',
    zh: '中前卫 (CM)',
    ru: 'Центральный полузащитник (ЦП)',
    tr: 'Merkez Orta Saha (MOS)',
  },
  MDF: {
    fr: 'Milieu Défensif (MDF)',
    en: 'Defensive Midfielder (CDM)',
    es: 'Pivote Defensivo (MCD)',
    pt: 'Volante Defensivo (VOL)',
    it: 'Mediano Difensivo (MED)',
    de: 'Defensives Mittelfeld (DM)',
    ar: 'وسط دفاعي (وص د)',
    zh: '后腰 (CDM)',
    ru: 'Опорный полузащитник (ОПЗ)',
    tr: 'Ön Libero (ÖL)',
  },
  DC: {
    fr: 'Défenseur Central (DC)',
    en: 'Center Back (CB)',
    es: 'Defensa Central (DFC)',
    pt: 'Zagueiro Central (ZAG)',
    it: 'Difensore Centrale (DC)',
    de: 'Innenverteidiger (IV)',
    ar: 'قلب دفاع (قد)',
    zh: '中后卫 (CB)',
    ru: 'Центральный защитник (ЦЗ)',
    tr: 'Stoper (STP)',
  },
  DL: {
    fr: 'Défenseur Latéral (DL)',
    en: 'Full Back (FB)',
    es: 'Lateral (LAT)',
    pt: 'Lateral (LAT)',
    it: 'Terzino (TD/TS)',
    de: 'Außenverteidiger (AV)',
    ar: 'ظهير (ظ)',
    zh: '边后卫 (FB)',
    ru: 'Крайний защитник (КЗ)',
    tr: 'Bek (BEK)',
  },
  GB: {
    fr: 'Gardien de But (GB)',
    en: 'Goalkeeper (GK)',
    es: 'Portero (POR)',
    pt: 'Goleiro (GOL)',
    it: 'Portiere (POR)',
    de: 'Torwart (TW)',
    ar: 'حارس مرمى (حم)',
    zh: '门将 (GK)',
    ru: 'Вратарь (ВР)',
    tr: 'Kaleci (KL)',
  },
};

const FOOT_MAP: Record<string, Record<Language, string>> = {
  Droit: {
    fr: 'Droitier',
    en: 'Right Footed',
    es: 'Diestro',
    pt: 'Destro',
    it: 'Destro',
    de: 'Rechtsfuß',
    ar: 'يمني',
    zh: '右脚',
    ru: 'Правша',
    tr: 'Sağ Ayak',
  },
  Gauche: {
    fr: 'Gaucher',
    en: 'Left Footed',
    es: 'Zurdo',
    pt: 'Canhoto',
    it: 'Mancino',
    de: 'Linksfuß',
    ar: 'أعسر',
    zh: '左脚',
    ru: 'Левша',
    tr: 'Sol Ayak',
  },
  Ambidextre: {
    fr: 'Ambidextre (Deux Pieds)',
    en: 'Both Feet / Ambidextrous',
    es: 'Ambidextro',
    pt: 'Ambidestro',
    it: 'Ambidestro',
    de: 'Beidfüßig',
    ar: 'كلتا القدمين',
    zh: '双脚均衡',
    ru: 'Обе ноги',
    tr: 'Çift Ayak',
  },
};

const CONTRACT_MAP: Record<string, Record<Language, string>> = {
  'Sous convention académie': {
    fr: 'Sous convention académie',
    en: 'Under Academy Contract',
    es: 'Bajo convenio de academia',
    pt: 'Sob contrato de formação de academia',
    it: 'Sotto convenzione di accademia',
    de: 'Unter Akademie-Vereinbarung',
    ar: 'تحت اتفاقية الأكاديمية',
    zh: '青训学院协议期',
    ru: 'На соглашении с академией',
    tr: 'Akademi sözleşmesi altında',
  },
  'Libre de tout contrat': {
    fr: 'Libre de tout contrat',
    en: 'Free Agent',
    es: 'Agente libre',
    pt: 'Livre no mercado',
    it: 'Svincolato / Libero da contratto',
    de: 'Vertragslos / Freier Spieler',
    ar: 'حر من أي عقد',
    zh: '自由球员',
    ru: 'Свободный агент',
    tr: 'Serbest Oyuncu',
  },
  'Contrat aspirant': {
    fr: 'Contrat aspirant professionnel',
    en: 'Aspirant Pro Contract',
    es: 'Contrato aspirante profesional',
    pt: 'Contrato aspirante profissional',
    it: 'Contratto aspirante professionista',
    de: 'Nachwuchs-Profivertrag',
    ar: 'عقد احترافي تمهيدي',
    zh: '预备职业合同',
    ru: 'Контракт стажера',
    tr: 'Aday Profesyonel Sözleşme',
  },
};

const STATUS_MAP: Record<string, Record<Language, string>> = {
  DISPONIBLE: {
    fr: 'Disponible pour recrutement',
    en: 'Available for signing',
    es: 'Disponible para fichaje',
    pt: 'Disponível para contratação',
    it: 'Disponibile per trasferimento',
    de: 'Verfügbar für Transfer',
    ar: 'متاح للتعاقد',
    zh: '可供签约',
    ru: 'Доступен для трансфера',
    tr: 'Transfer için Müsait',
  },
  EN_ESSAI: {
    fr: 'Actuellement en essai club',
    en: 'Currently on trial',
    es: 'Actualmente a prueba',
    pt: 'Atualmente em período de testes',
    it: 'Attualmente in prova',
    de: 'Aktuell im Probetraining',
    ar: 'حالياً في فترة اختبار',
    zh: '试训中',
    ru: 'На просмотре в клубе',
    tr: 'Deneme Sürecinde',
  },
  SOUS_OPTION: {
    fr: 'Sous option prioritaire',
    en: 'Under priority option',
    es: 'Bajo opción prioritaria',
    pt: 'Sob opção prioritária',
    it: 'Sotto opzione prioritaria',
    de: 'Unter Vorvertragsoption',
    ar: 'تحت خيار أولوية',
    zh: '优先特权期',
    ru: 'Под приоритетной опцией',
    tr: 'Öncelikli Opsiyonda',
  },
};

const ROLE_MAP: Record<string, Record<Language, string>> = {
  PLAYER: {
    fr: 'Joueur & Talent',
    en: 'Player & Talent',
    es: 'Jugador y Talento',
    pt: 'Jogador e Talento',
    it: 'Giocatore e Talento',
    de: 'Spieler & Talent',
    ar: 'لاعب وموهبة',
    zh: '球员与天才',
    ru: 'Игрок и талант',
    tr: 'Oyuncu ve Yetenek',
  },
  SCOUT: {
    fr: 'Scout / Recruteur',
    en: 'Scout / Recruiter',
    es: 'Ojeador / Scout',
    pt: 'Olheiro / Scout',
    it: 'Talent Scout',
    de: 'Scout / Talentsucher',
    ar: 'كشاف مواهب',
    zh: '球探 / 招募官',
    ru: 'Скаут / Рекрутер',
    tr: 'Yetenek Avcısı / Scout',
  },
  CLUB: {
    fr: 'Club Professionnel',
    en: 'Professional Club',
    es: 'Club Profesional',
    pt: 'Clube Profissional',
    it: 'Club Professionistico',
    de: 'Profiverein',
    ar: 'نادي محترف',
    zh: '职业俱乐部',
    ru: 'Профессиональный клуб',
    tr: 'Profesyonel Kulüp',
  },
  ACADEMY: {
    fr: 'Académie de Football',
    en: 'Football Academy',
    es: 'Academia de Fútbol',
    pt: 'Academia de Futebol',
    it: 'Accademia di Calcio',
    de: 'Fußballakademie',
    ar: 'أكاديمية كرة قدم',
    zh: '足球学院',
    ru: 'Футбольная академия',
    tr: 'Futbol Akademisi',
  },
  FIFA_AGENT: {
    fr: 'Agent Licencié FIFA',
    en: 'FIFA Licensed Agent',
    es: 'Agente con Licencia FIFA',
    pt: 'Agente Licenciado FIFA',
    it: 'Agente Licenziato FIFA',
    de: 'FIFA-lizenzierter Agent',
    ar: 'وكيل معتمد من الفيفا',
    zh: 'FIFA持牌经纪人',
    ru: 'Лицензированный агент ФИФА',
    tr: 'FIFA Lisanslı Menajer',
  },
  HEAD_COACH: {
    fr: 'Entraîneur Principal',
    en: 'Head Coach',
    es: 'Director Técnico / Entrenador',
    pt: 'Treinador Principal',
    it: 'Allenatore Principale',
    de: 'Cheftrainer',
    ar: 'مدير فني / مدرب أول',
    zh: '主教练',
    ru: 'Главный тренер',
    tr: 'Teknik Direktör',
  },
  SPORTING_DIRECTOR: {
    fr: 'Directeur Sportif',
    en: 'Sporting Director',
    es: 'Director Deportivo',
    pt: 'Diretor Esportivo',
    it: 'Direttore Sportivo',
    de: 'Sportdirektor',
    ar: 'مدير رياضي',
    zh: '体育总监',
    ru: 'Спортивный директор',
    tr: 'Sportif Direktör',
  },
  PRESIDENT: {
    fr: 'Président de Club / Dirigeant',
    en: 'Club President / Executive',
    es: 'Presidente de Club / Dirigente',
    pt: 'Presidente do Clube / Dirigente',
    it: 'Presidente di Club / Dirigente',
    de: 'Vereinspräsident / Vorstand',
    ar: 'رئيس نادي / مسؤول تنفيذي',
    zh: '俱乐部主席 / 高管',
    ru: 'Президент клуба / Руководитель',
    tr: 'Kulüp Başkanı / Yönetici',
  },
  RECRUITMENT_MANAGER: {
    fr: 'Responsable Recrutement',
    en: 'Head of Recruitment',
    es: 'Jefe de Reclutamiento',
    pt: 'Chefe de Recrutamento',
    it: 'Responsabile Scouting e Mercato',
    de: 'Leiter Scouting & Rekrutierung',
    ar: 'مسؤول التعاقدات والاكتشاف',
    zh: '招募主管',
    ru: 'Руководитель скаутской службы',
    tr: 'Transfer ve İzcilik Sorumlusu',
  },
  ADMIN: {
    fr: 'Administrateur Plateforme',
    en: 'Platform Administrator',
    es: 'Administrador de Plataforma',
    pt: 'Administrador da Plataforma',
    it: 'Amministratore della Piattaforma',
    de: 'Plattform-Administrator',
    ar: 'مدير المنصة',
    zh: '平台管理员',
    ru: 'Администратор платформы',
    tr: 'Platform Yöneticisi',
  },
};

const TIER_MAP: Record<string, Record<Language, string>> = {
  FREE: {
    fr: 'Découverte Gratuite',
    en: 'Free Discovery',
    es: 'Descubrimiento Gratuito',
    pt: 'Descoberta Gratuita',
    it: 'Scoperta Gratuita',
    de: 'Kostenlose Testversion',
    ar: 'استكشاف مجاني',
    zh: '免费体验版',
    ru: 'Бесплатный ознакомительный',
    tr: 'Ücretsiz Keşif',
  },
  PLAYER_PRO: {
    fr: 'Athlète Pro Certifié',
    en: 'Player Pro Certified',
    es: 'Atleta Pro Certificado',
    pt: 'Atleta Pro Certificado',
    it: 'Atleta Pro Certificato',
    de: 'Spieler Pro Zertifiziert',
    ar: 'لاعب محترف معتمد',
    zh: '认证职业球员版',
    ru: 'Профессиональный игрок',
    tr: 'Onaylı Profesyonel Sporcu',
  },
  SCOUT_PRO: {
    fr: 'Scout Pro & Recruteur',
    en: 'Scout Pro & Recruiter',
    es: 'Scout Pro y Reclutador',
    pt: 'Scout Pro e Olheiro',
    it: 'Scout Pro e Recruiter',
    de: 'Scout Pro & Talentsucher',
    ar: 'كشاف محترف ومعتمد',
    zh: '专业球探与招募版',
    ru: 'Профессиональный скаут',
    tr: 'Profesyonel Yetenek Avcısı',
  },
  CLUB_ELITE: {
    fr: 'Club Élite & Académie',
    en: 'Club Elite & Academy',
    es: 'Club Élite y Academia',
    pt: 'Clube Elite e Academia',
    it: 'Club Elite e Accademia',
    de: 'Verein Elite & Akademie',
    ar: 'أندية النخبة والأكاديميات',
    zh: '俱乐部精英与青训版',
    ru: 'Элитный клуб и академия',
    tr: 'Elit Kulüp ve Akademi',
  },
  ENTERPRISE: {
    fr: 'Fédération & Institution',
    en: 'Enterprise & Federation',
    es: 'Federación e Institucional',
    pt: 'Federação e Institucional',
    it: 'Federazione e Istituzionale',
    de: 'Verband & Institutionell',
    ar: 'الاتحادات والمؤسسات الكبرى',
    zh: '足协与机构定制版',
    ru: 'Федерации и институциональный',
    tr: 'Federasyon ve Kurumsal',
  },
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(detectInitialLanguage);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('atf_language', lang);
      const meta = WORLD_LANGUAGES.find((l) => l.code === lang);
      if (meta) {
        document.documentElement.setAttribute('lang', lang);
        document.documentElement.setAttribute('dir', meta.dir);
      }
    }
  };

  useEffect(() => {
    const meta = WORLD_LANGUAGES.find((l) => l.code === language);
    if (meta && typeof document !== 'undefined') {
      document.documentElement.setAttribute('lang', language);
      document.documentElement.setAttribute('dir', meta.dir);
    }
  }, [language]);

  // Enhanced t function that NEVER falls back silently to French for non-French selections
  const t = (key: string, fallback?: string): string => {
    const item = allTranslations[key];
    if (item && item[language] && item[language].trim()) {
      return item[language];
    }
    // If French is the chosen language, return French
    if (language === 'fr' && item && item['fr'] && item['fr'].trim()) {
      return item['fr'];
    }
    // For non-French, fall back to English first (international sports standard)
    if (item && item['en'] && item['en'].trim()) {
      return item['en'];
    }
    // Then provided fallback
    if (fallback && fallback.trim()) {
      return fallback;
    }
    // Lastly French if nothing else exists
    if (item && item['fr'] && item['fr'].trim()) {
      return item['fr'];
    }
    return fallback || key;
  };

  // Domain helpers
  const tPosition = (pos: string): string => {
    const clean = (pos || '').trim().toUpperCase();
    if (POSITION_MAP[clean] && POSITION_MAP[clean][language]) {
      return POSITION_MAP[clean][language];
    }
    return pos || '';
  };

  const tFoot = (foot: string): string => {
    const clean = (foot || '').trim();
    if (FOOT_MAP[clean] && FOOT_MAP[clean][language]) {
      return FOOT_MAP[clean][language];
    }
    return foot || '';
  };

  const tContract = (status: string): string => {
    const clean = (status || '').trim();
    if (CONTRACT_MAP[clean] && CONTRACT_MAP[clean][language]) {
      return CONTRACT_MAP[clean][language];
    }
    return status || '';
  };

  const tPlayerStatus = (status: string): string => {
    const clean = (status || '').trim().toUpperCase();
    if (STATUS_MAP[clean] && STATUS_MAP[clean][language]) {
      return STATUS_MAP[clean][language];
    }
    return status || '';
  };

  const tRole = (role: string): string => {
    const clean = (role || '').trim().toUpperCase();
    if (ROLE_MAP[clean] && ROLE_MAP[clean][language]) {
      return ROLE_MAP[clean][language];
    }
    return role || '';
  };

  const tTier = (tier: string): string => {
    const clean = (tier || '').trim().toUpperCase();
    if (TIER_MAP[clean] && TIER_MAP[clean][language]) {
      return TIER_MAP[clean][language];
    }
    return tier || '';
  };

  // Localized Formatters
  const formatDate = (date: string | Date | number, options?: Intl.DateTimeFormatOptions): string => {
    try {
      const d = typeof date === 'string' || typeof date === 'number' ? new Date(date) : date;
      const locale = language === 'ar' ? 'ar-EG' : language === 'zh' ? 'zh-CN' : language;
      return new Intl.DateTimeFormat(locale, options || { day: 'numeric', month: 'short', year: 'numeric' }).format(d);
    } catch {
      return String(date);
    }
  };

  const formatCurrency = (amount: number, currency = 'EUR'): string => {
    try {
      const locale = language === 'ar' ? 'ar-EG' : language === 'zh' ? 'zh-CN' : language;
      return new Intl.NumberFormat(locale, {
        style: 'currency',
        currency,
        maximumFractionDigits: 0,
      }).format(amount);
    } catch {
      return `${amount.toLocaleString()} €`;
    }
  };

  const formatNumber = (num: number): string => {
    try {
      const locale = language === 'ar' ? 'ar-EG' : language === 'zh' ? 'zh-CN' : language;
      return new Intl.NumberFormat(locale).format(num);
    } catch {
      return num.toLocaleString();
    }
  };

  const currentLanguageMeta =
    WORLD_LANGUAGES.find((l) => l.code === language) || WORLD_LANGUAGES[0];
  const isRTL = language === 'ar';
  const dir = isRTL ? 'rtl' : 'ltr';

  const contextValue = useMemo<LanguageContextType>(
    () => ({
      language,
      currentLanguageMeta,
      setLanguage,
      t,
      languages: WORLD_LANGUAGES,
      isRTL,
      dir,
      tPosition,
      tFoot,
      tContract,
      tPlayerStatus,
      tRole,
      tTier,
      formatDate,
      formatCurrency,
      formatNumber,
    }),
    [language, currentLanguageMeta, isRTL, dir]
  );

  return (
    <LanguageContext.Provider value={contextValue}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
