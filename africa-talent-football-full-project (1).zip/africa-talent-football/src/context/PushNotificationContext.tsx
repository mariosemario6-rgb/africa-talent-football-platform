import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { MercatoAlert, PushNotificationSettings } from '../types/database';
import { INITIAL_MERCATO_ALERTS } from '../data/mercatoData';

export interface PushNotificationHistoryItem {
  id: string;
  title: string;
  body: string;
  timestamp: string;
  type: 'MERCATO' | 'TRIAL' | 'SCOUTING' | 'CLUB' | 'PLAYER';
  read: boolean;
  linkPayload?: any;
}

export interface CustomMercatoAlertCriteria {
  id: string;
  title: string;
  confederation?: string;
  country?: string;
  league?: string;
  position?: string;
  minAmountEur?: number;
  maxAmountEur?: number;
  createdAt: string;
}

interface PushNotificationContextType {
  permission: NotificationPermission;
  settings: PushNotificationSettings;
  updateSettings: (newSettings: Partial<PushNotificationSettings>) => void;
  requestPermission: () => Promise<boolean>;
  triggerTestPush: (customTitle?: string, customBody?: string) => void;
  mercatoAlerts: MercatoAlert[];
  unreadAlertsCount: number;
  markAllAlertsAsRead: () => void;
  addMercatoAlert: (alert: MercatoAlert) => void;
  simulateIncomingMercatoAlert: () => void;
  subscribedClubIds: string[];
  toggleClubAlertSubscription: (clubId: string, clubName: string) => boolean;
  isSubscribedToClub: (clubId: string) => boolean;
  customAlerts: CustomMercatoAlertCriteria[];
  addCustomAlert: (criteria: Omit<CustomMercatoAlertCriteria, 'id' | 'createdAt'>) => void;
  removeCustomAlert: (id: string) => void;
  notificationHistory: PushNotificationHistoryItem[];
  markNotificationAsRead: (id: string) => void;
  clearNotificationHistory: () => void;
  isMercatoModalOpen: boolean;
  setIsMercatoModalOpen: (open: boolean) => void;
  isPushSettingsModalOpen: boolean;
  setIsPushSettingsModalOpen: (open: boolean) => void;
  activePushToast: { title: string; body: string; type?: string } | null;
  dismissPushToast: () => void;
}

const SETTINGS_STORAGE_KEY = 'atf_push_settings_v2';
const ALERTS_READ_KEY = 'atf_mercato_alerts_read_v1';
const SUBSCRIBED_CLUBS_KEY = 'atf_subscribed_clubs_v2';
const CUSTOM_ALERTS_KEY = 'atf_custom_mercato_alerts_v1';
const NOTIFICATION_HISTORY_KEY = 'atf_push_history_v1';

const DEFAULT_SETTINGS: PushNotificationSettings = {
  enabled: true,
  soundEnabled: true,
  vibrationEnabled: true,
  mercatoAlerts: true,
  newPlayersDetected: true,
  clubMessages: true,
  scoutingShowcases: true,
};

const PushNotificationContext = createContext<PushNotificationContextType | undefined>(undefined);

// Web Audio API dual-tone chime
const playNotificationChime = () => {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    
    // Note 1: 587.33 Hz (D5)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, ctx.currentTime);
    gain1.gain.setValueAtTime(0.12, ctx.currentTime);
    gain1.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(ctx.currentTime);
    osc1.stop(ctx.currentTime + 0.35);

    // Note 2: 880.00 Hz (A5)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(880.00, ctx.currentTime + 0.08);
    gain2.gain.setValueAtTime(0.18, ctx.currentTime + 0.08);
    gain2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.55);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(ctx.currentTime + 0.08);
    osc2.stop(ctx.currentTime + 0.55);
  } catch (e) {
    // Audio context may require user gesture on some browsers
  }
};

const INITIAL_HISTORY: PushNotificationHistoryItem[] = [
  {
    id: 'push-hist-01',
    title: '🚨 Offre d’Essai KRC Genk (Belgique)',
    body: 'Convocation officielle pour un buteur U20. Prise en charge intégrale au Cegeka Arena.',
    timestamp: 'Il y a 25 min',
    type: 'TRIAL',
    read: false,
  },
  {
    id: 'push-hist-02',
    title: '🎯 Recherche Urgente : RC Lens (France)',
    body: 'Recherche active d’un ailier percutant pied gauche U19 pour l’équipe réserve pro.',
    timestamp: 'Il y a 1 heure',
    type: 'MERCATO',
    read: false,
  },
  {
    id: 'push-hist-03',
    title: '✍️ Accord de Transfert Standard de Liège',
    body: 'Finalisation du protocole d’intégration pour un défenseur central issu d’Abidjan.',
    timestamp: 'Il y a 3 heures',
    type: 'MERCATO',
    read: true,
  },
  {
    id: 'push-hist-04',
    title: '🔍 Demande de Rapport GPS : Brighton FC',
    body: 'Sollicitation formelle de métriques pour un milieu axial box-to-box par le desk anglais.',
    timestamp: 'Hier à 18h40',
    type: 'SCOUTING',
    read: true,
  }
];

export const PushNotificationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [permission, setPermission] = useState<NotificationPermission>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'default';
  });

  const [settings, setSettings] = useState<PushNotificationSettings>(() => {
    try {
      const saved = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    } catch {
      // Fallback
    }
    return DEFAULT_SETTINGS;
  });

  const [mercatoAlerts, setMercatoAlerts] = useState<MercatoAlert[]>(INITIAL_MERCATO_ALERTS);
  const [unreadAlertsCount, setUnreadAlertsCount] = useState<number>(() => {
    try {
      const read = localStorage.getItem(ALERTS_READ_KEY);
      if (read === 'true') return 0;
    } catch {}
    return INITIAL_MERCATO_ALERTS.length;
  });

  // Subscribed clubs for push notifications
  const [subscribedClubIds, setSubscribedClubIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(SUBSCRIBED_CLUBS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return ['club-uefa-02', 'club-caf-01', 'club-uefa-01']; // default subscribed to Genk, ASEC, Lens
  });

  // Custom user alert criteria
  const [customAlerts, setCustomAlerts] = useState<CustomMercatoAlertCriteria[]>(() => {
    try {
      const saved = localStorage.getItem(CUSTOM_ALERTS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'ca-01',
        title: 'Buteurs U19 & U20 (UEFA & CAF)',
        position: 'BU',
        confederation: 'UEFA',
        createdAt: '2026-03-15',
      },
      {
        id: 'ca-02',
        title: 'Clubs Belges (Jupiler Pro League)',
        country: 'Belgique',
        createdAt: '2026-03-20',
      },
    ];
  });

  // Notification history
  const [notificationHistory, setNotificationHistory] = useState<PushNotificationHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem(NOTIFICATION_HISTORY_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_HISTORY;
  });

  const [isMercatoModalOpen, setIsMercatoModalOpen] = useState(false);
  const [isPushSettingsModalOpen, setIsPushSettingsModalOpen] = useState(false);
  const [activePushToast, setActivePushToast] = useState<{ title: string; body: string; type?: string } | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    } catch {}
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem(SUBSCRIBED_CLUBS_KEY, JSON.stringify(subscribedClubIds));
    } catch {}
  }, [subscribedClubIds]);

  useEffect(() => {
    try {
      localStorage.setItem(CUSTOM_ALERTS_KEY, JSON.stringify(customAlerts));
    } catch {}
  }, [customAlerts]);

  useEffect(() => {
    try {
      localStorage.setItem(NOTIFICATION_HISTORY_KEY, JSON.stringify(notificationHistory));
    } catch {}
  }, [notificationHistory]);

  const updateSettings = (newSettings: Partial<PushNotificationSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const requestPermission = async (): Promise<boolean> => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setPermission('granted');
      updateSettings({ enabled: true });
      return true;
    }

    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      if (result === 'granted') {
        updateSettings({ enabled: true });
        triggerTestPush(
          '🔔 Notifications Push Activées !',
          'Vous recevrez désormais en direct les alertes Mercato, invitations d’essais et messages des directeurs sportifs.'
        );
        return true;
      }
      return false;
    } catch {
      // In iframe or sandboxed environment
      setPermission('granted');
      updateSettings({ enabled: true });
      return true;
    }
  };

  const triggerTestPush = (customTitle?: string, customBody?: string) => {
    const title = customTitle || '🚨 ALERTE MERCATO : KRC Genk';
    const body = customBody || 'Offre d’essai officielle pour un buteur U20. Prise en charge intégrale. Consulter le dossier au desk Mario Traoré.';

    // 1. Play chime if sound enabled
    if (settings.soundEnabled) {
      playNotificationChime();
    }

    // 2. Vibrate device if vibration enabled
    if (settings.vibrationEnabled && typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate([100, 50, 150]);
      } catch {}
    }

    // 3. Android Native Bridge integration
    if (typeof window !== 'undefined' && (window as any).AndroidPushBridge?.showNotification) {
      try {
        (window as any).AndroidPushBridge.showNotification(title, body, 'MERCATO');
      } catch {}
    }

    // 4. Web Notification API (when granted)
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body,
          icon: '/pwa-192x192.png',
          badge: '/icon.svg',
          tag: 'atf-mercato-alert',
          silent: !settings.soundEnabled,
        } as any);
      } catch {
        // Notification constructor could fail in some iframe environments
      }
    }

    // 5. In-App Interactive Push Banner
    setActivePushToast({
      title,
      body,
      type: 'mercato',
    });

    // 6. Record in notification history
    const historyItem: PushNotificationHistoryItem = {
      id: `push-${Date.now()}`,
      title,
      body,
      timestamp: 'À l’instant',
      type: 'MERCATO',
      read: false,
    };
    setNotificationHistory((prev) => [historyItem, ...prev.slice(0, 24)]);

    // Auto-dismiss after 6 seconds
    setTimeout(() => {
      setActivePushToast((curr) => (curr?.title === title ? null : curr));
    }, 6000);
  };

  const addMercatoAlert = (alert: MercatoAlert) => {
    setMercatoAlerts((prev) => [alert, ...prev]);
    setUnreadAlertsCount((prev) => prev + 1);
    try {
      localStorage.setItem(ALERTS_READ_KEY, 'false');
    } catch {}
    triggerTestPush(
      `🚨 ALERTE MERCATO : ${alert.clubName}`,
      `${alert.title} - ${alert.positionTarget || 'Profil recherché'} (${alert.clubCountry})`
    );
  };

  const simulateIncomingMercatoAlert = () => {
    const simulationPool = [
      {
        type: 'TRIAL_OFFER' as const,
        title: 'Convocation Immédiate pour Essai 10 Jours (Pro B)',
        clubName: 'Sporting CP (Académie Cristiano Ronaldo)',
        clubCountry: 'Portugal',
        clubCountryFlag: '🇵🇹',
        confederation: 'UEFA' as const,
        positionTarget: 'Milieu Créatif (MOC / MC) U18',
        amountDisplay: 'Bourse d’Excellence Académie',
        summary: 'La direction sportive de l’académie du Sporting CP convoque un joueur africain pour une mise à l’essai supervisée.',
        details: 'Tests physiques Wyscout, opposition amicale et bilan médical pris en charge.',
        urgent: true,
      },
      {
        type: 'URGENT_NEED' as const,
        title: 'Recherche Prioritaire : Buteur Axial Puissant +1m86',
        clubName: 'Al Ahly SC',
        clubCountry: 'Égypte',
        clubCountryFlag: '🇪🇬',
        confederation: 'CAF' as const,
        positionTarget: 'Avant-centre (BU) U21',
        amountDisplay: 'Budget Transfert 1.4M€',
        summary: 'Recherche active pour la phase finale de la Ligue des Champions CAF. Profil physique dominant.',
        details: 'Supervision technique urgente demandée au desk de Seydou Mario Traoré.',
        urgent: true,
      },
      {
        type: 'OFFICIAL_TRANSFER' as const,
        title: 'Validation de Transfert & Convention de Formation',
        clubName: 'Club Bruges KV',
        clubCountry: 'Belgique',
        clubCountryFlag: '🇧🇪',
        confederation: 'UEFA' as const,
        positionTarget: 'Piston Droit (DL / AD) U19',
        amountDisplay: '600 000 € + 25% Plus-value',
        summary: 'Accord conclu entre le club belge et l’académie d’Abidjan pour l’intégration à l’équipe Club NXT.',
        details: 'Dossier passeport sportif et visa complétés sous l’égide d’Africa Talent Football.',
        urgent: false,
      },
      {
        type: 'SCOUTING_INQUIRY' as const,
        title: 'Demande d’Audit GPS & Données Biométriques',
        clubName: 'Brighton & Hove Albion',
        clubCountry: 'Angleterre',
        clubCountryFlag: '🇬🇧',
        confederation: 'UEFA' as const,
        positionTarget: 'Sentinelle (MDF) U20',
        amountDisplay: 'Cote estimée 2.8M€',
        summary: 'La cellule data de Brighton sollicite les métriques physiques et vidéos 90 min intégrales.',
        details: 'Analyse VMA, nombre de sprints au-dessus de 25 km/h et pourcentage de passes progressives.',
        urgent: false,
      },
    ];

    const pick = simulationPool[Math.floor(Math.random() * simulationPool.length)];
    const newAlert: MercatoAlert = {
      id: `mercato-live-${Date.now()}`,
      ...pick,
      timestamp: 'À l’instant',
      verifiedByDesk: true,
    };

    addMercatoAlert(newAlert);
  };

  const toggleClubAlertSubscription = (clubId: string, clubName: string): boolean => {
    let newState = false;
    setSubscribedClubIds((prev) => {
      if (prev.includes(clubId)) {
        newState = false;
        return prev.filter((id) => id !== clubId);
      } else {
        newState = true;
        return [...prev, clubId];
      }
    });

    if (settings.soundEnabled) {
      playNotificationChime();
    }

    const toastTitle = newState
      ? `🔔 Abonné aux Alertes de ${clubName}`
      : `🔕 Désabonné des Alertes de ${clubName}`;
    const toastBody = newState
      ? `Vous recevrez en direct chaque besoin mercato, convocation d’essai et annonce officielle de ${clubName}.`
      : `Vous ne recevrez plus les notifications push spécifiques à ${clubName}.`;

    setActivePushToast({
      title: toastTitle,
      body: toastBody,
      type: 'mercato',
    });

    setTimeout(() => {
      setActivePushToast((curr) => (curr?.title === toastTitle ? null : curr));
    }, 4500);

    return newState;
  };

  const isSubscribedToClub = (clubId: string): boolean => {
    return subscribedClubIds.includes(clubId);
  };

  const addCustomAlert = (criteria: Omit<CustomMercatoAlertCriteria, 'id' | 'createdAt'>) => {
    const newItem: CustomMercatoAlertCriteria = {
      id: `ca-${Date.now()}`,
      ...criteria,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setCustomAlerts((prev) => [newItem, ...prev]);

    if (settings.soundEnabled) {
      playNotificationChime();
    }

    setActivePushToast({
      title: '🎯 Alerte Personnalisée Enregistrée !',
      body: `Critère : "${newItem.title}". Vous serez notifié dès qu'une opportunité correspondante est publiée.`,
      type: 'mercato',
    });
    setTimeout(() => {
      setActivePushToast(null);
    }, 4500);
  };

  const removeCustomAlert = (id: string) => {
    setCustomAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  const markNotificationAsRead = (id: string) => {
    setNotificationHistory((prev) =>
      prev.map((item) => (item.id === id ? { ...item, read: true } : item))
    );
  };

  const clearNotificationHistory = () => {
    setNotificationHistory([]);
  };

  const markAllAlertsAsRead = () => {
    setUnreadAlertsCount(0);
    try {
      localStorage.setItem(ALERTS_READ_KEY, 'true');
    } catch {}
    setNotificationHistory((prev) => prev.map((item) => ({ ...item, read: true })));
  };

  const dismissPushToast = () => {
    setActivePushToast(null);
  };

  return (
    <PushNotificationContext.Provider
      value={{
        permission,
        settings,
        updateSettings,
        requestPermission,
        triggerTestPush,
        mercatoAlerts,
        unreadAlertsCount,
        markAllAlertsAsRead,
        addMercatoAlert,
        simulateIncomingMercatoAlert,
        subscribedClubIds,
        toggleClubAlertSubscription,
        isSubscribedToClub,
        customAlerts,
        addCustomAlert,
        removeCustomAlert,
        notificationHistory,
        markNotificationAsRead,
        clearNotificationHistory,
        isMercatoModalOpen,
        setIsMercatoModalOpen,
        isPushSettingsModalOpen,
        setIsPushSettingsModalOpen,
        activePushToast,
        dismissPushToast,
      }}
    >
      {children}
    </PushNotificationContext.Provider>
  );
};

export const usePushNotifications = (): PushNotificationContextType => {
  const context = useContext(PushNotificationContext);
  if (!context) {
    throw new Error('usePushNotifications must be used within a PushNotificationProvider');
  }
  return context;
};

