import React, { useState, useMemo, Suspense } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { PlayerProvider, usePlayers } from './context/PlayerContext';
import { NetworkProvider, useNetwork } from './context/NetworkContext';
import { PaymentProvider, usePayment } from './context/PaymentContext';
import { PushNotificationProvider } from './context/PushNotificationContext';
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { VideoShowcaseModal } from './components/common/VideoShowcaseModal';
import { QuickChatDrawer } from './components/common/QuickChatDrawer';
import { CheckoutModal } from './components/common/CheckoutModal';
import { MobileInstallBanner } from './components/common/MobileInstallBanner';
import { OfflineIndicator } from './components/common/OfflineIndicator';
import { AndroidBottomBar } from './components/common/AndroidBottomBar';
import { ComparisonFloatingBar } from './components/talent/ComparisonFloatingBar';
import { PushNotificationBanner } from './components/common/PushNotificationBanner';
import { PageSkeleton } from './components/common/PageSkeleton';
import { Home } from './pages/Home';
import { PlayerBiometricsAndTransfers } from './components/talent/PlayerBiometricsAndTransfers';
import { DEMO_OPPORTUNITIES, FOUNDER_INFO, formatMarketValue } from './data/demoData';
import { RegisteredPlayer } from './types/database';
import { matchesQuery } from './utils/searchEngine';
import { getOptimizedImageUrl, lazyImageProps } from './utils/imageOptimizer';
import { DashboardRoleKey } from './pages/Dashboards/ProfessionalDashboards';

// Code-split route pages for high speed on African mobile 3G/4G networks
const Register = React.lazy(() => import('./pages/Auth/Register').then(m => ({ default: m.Register })));
const Founder = React.lazy(() => import('./pages/Founder').then(m => ({ default: m.Founder })));
const FeedPage = React.lazy(() => import('./pages/Network/FeedPage').then(m => ({ default: m.FeedPage })));
const DirectoryPage = React.lazy(() => import('./pages/Network/DirectoryPage').then(m => ({ default: m.DirectoryPage })));
const SearchPage = React.lazy(() => import('./pages/Search/SearchPage').then(m => ({ default: m.SearchPage })));
const MessagesPage = React.lazy(() => import('./pages/Network/MessagesPage').then(m => ({ default: m.MessagesPage })));
const PricingPage = React.lazy(() => import('./pages/Pricing/PricingPage').then(m => ({ default: m.PricingPage })));
const AppDownloadPage = React.lazy(() => import('./pages/Download/AppDownloadPage').then(m => ({ default: m.AppDownloadPage })));
const MatchCalendarPage = React.lazy(() => import('./pages/Matches/MatchCalendarPage').then(m => ({ default: m.MatchCalendarPage })));
const LoginPage = React.lazy(() => import('./pages/Auth/LoginPage').then(m => ({ default: m.LoginPage })));
const ProfilePage = React.lazy(() => import('./pages/Auth/ProfilePage').then(m => ({ default: m.ProfilePage })));
const ProfessionalDashboards = React.lazy(() => import('./pages/Dashboards/ProfessionalDashboards').then(m => ({ default: m.ProfessionalDashboards })));

// Code-split heavy modals and charts on demand
const GlobalSearchModal = React.lazy(() => import('./components/common/GlobalSearchModal').then(m => ({ default: m.GlobalSearchModal })));
const SharePlatformModal = React.lazy(() => import('./components/common/SharePlatformModal').then(m => ({ default: m.SharePlatformModal })));
const AppDownloadModal = React.lazy(() => import('./components/common/AppDownloadModal').then(m => ({ default: m.AppDownloadModal })));
const OfficialDomainModal = React.lazy(() => import('./components/common/OfficialDomainModal').then(m => ({ default: m.OfficialDomainModal })));
const PlayerPDFExportModal = React.lazy(() => import('./components/common/PlayerPDFExportModal').then(m => ({ default: m.PlayerPDFExportModal })));
const TalentComparisonModal = React.lazy(() => import('./components/talent/TalentComparisonModal').then(m => ({ default: m.TalentComparisonModal })));
const FavoritesModal = React.lazy(() => import('./components/talent/FavoritesModal').then(m => ({ default: m.FavoritesModal })));
const MercatoAlertsModal = React.lazy(() => import('./components/mercato/MercatoAlertsModal').then(m => ({ default: m.MercatoAlertsModal })));
const PushNotificationModal = React.lazy(() => import('./components/common/PushNotificationModal').then(m => ({ default: m.PushNotificationModal })));
const D3PlayerStatsChart = React.lazy(() => import('./components/stats/D3PlayerStatsChart').then(m => ({ default: m.D3PlayerStatsChart })));
const MarketValuationCalculatorModal = React.lazy(() => import('./components/stats/MarketValuationCalculatorModal').then(m => ({ default: m.MarketValuationCalculatorModal })));

const MainContent: React.FC = () => {
  const [currentView, setCurrentView] = useState<string>('home');
  const [dashboardRole, setDashboardRole] = useState<DashboardRoleKey>('CLUB_PRO');
  const [selectedPlayer, setSelectedPlayer] = useState<RegisteredPlayer | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [positionFilter, setPositionFilter] = useState<string>('ALL');
  const [footFilter, setFootFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'VALUE_DESC' | 'GOALS_DESC' | 'SPEED_DESC' | 'AGE_ASC'>('VALUE_DESC');
  const [viewFormat, setViewFormat] = useState<'CARDS' | 'TABLE'>('CARDS');

  // Shortlist state
  const [shortlist, setShortlist] = useState<string[]>(['atf-ply-001', 'atf-ply-002']);

  // Universal Search, Share Platform, Domain Status & Download modals
  const [isSearchModalOpen, setIsSearchModalOpen] = useState<boolean>(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState<boolean>(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState<boolean>(false);
  const [isDomainModalOpen, setIsDomainModalOpen] = useState<boolean>(false);
  const [pdfPlayer, setPdfPlayer] = useState<RegisteredPlayer | null>(null);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState<boolean>(false);
  const [isMenuDrawerOpen, setIsMenuDrawerOpen] = useState<boolean>(false);
  const [isValuationModalOpen, setIsValuationModalOpen] = useState<boolean>(false);
  const [valuationPlayerId, setValuationPlayerId] = useState<string | undefined>(undefined);

  const { currentUser, loginAsDemoRole, logout } = useAuth();
  const { language, t } = useLanguage();
  const {
    players,
    openVideoModal,
    totalMarketValue,
    favorites,
    toggleFavorite,
    isFavorite,
    isFavoritesModalOpen,
    setIsFavoritesModalOpen,
    comparisonIds,
    toggleComparison,
    clearComparison,
    isInComparison,
    isComparisonModalOpen,
    setIsComparisonModalOpen,
  } = usePlayers();
  const { activeSubscription, openCheckout } = usePayment();

  // Android Back Button & Browser History Handling
  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      if (!window.history.state) {
        window.history.replaceState({ view: 'home' }, '');
      }

      const handlePopState = (e: PopStateEvent) => {
        // Prioritize closing open overlays / modals first
        if (isMenuDrawerOpen) {
          setIsMenuDrawerOpen(false);
          return;
        }
        if (isComparisonModalOpen) {
          setIsComparisonModalOpen(false);
          return;
        }
        if (isFavoritesModalOpen) {
          setIsFavoritesModalOpen(false);
          return;
        }
        if (isSearchModalOpen) {
          setIsSearchModalOpen(false);
          return;
        }
        if (isShareModalOpen) {
          setIsShareModalOpen(false);
          return;
        }
        if (isDownloadModalOpen) {
          setIsDownloadModalOpen(false);
          return;
        }
        if (isDomainModalOpen) {
          setIsDomainModalOpen(false);
          return;
        }
        if (isPdfModalOpen) {
          setIsPdfModalOpen(false);
          return;
        }
        if (selectedPlayer) {
          setSelectedPlayer(null);
          setCurrentView('players');
          return;
        }

        // Navigate views
        if (e.state && e.state.view) {
          setCurrentView(e.state.view);
          if (e.state.payload) setSelectedPlayer(e.state.payload);
        } else if (currentView !== 'home') {
          setCurrentView('home');
        }
      };

      window.addEventListener('popstate', handlePopState);
      return () => window.removeEventListener('popstate', handlePopState);
    }
  }, [
    isMenuDrawerOpen,
    isComparisonModalOpen,
    isFavoritesModalOpen,
    isSearchModalOpen,
    isShareModalOpen,
    isDownloadModalOpen,
    isDomainModalOpen,
    isPdfModalOpen,
    selectedPlayer,
    currentView,
  ]);

  // Global keyboard shortcut for search (Cmd+K / Ctrl+K or /)
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchModalOpen((prev) => !prev);
      } else if (
        e.key === '/' &&
        !['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)
      ) {
        e.preventDefault();
        setIsSearchModalOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleNavigate = (view: string, payload?: any) => {
    if (view === 'player-detail' && payload) {
      setSelectedPlayer(payload);
    }
    if (view === 'dashboard' && payload?.role) {
      setDashboardRole(payload.role);
    }
    if (typeof window !== 'undefined' && (view !== currentView || payload)) {
      window.history.pushState({ view, payload }, '');
    }
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const toggleShortlist = (id: string) => {
    setShortlist(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  // Filter and sort players
  const filteredAndSortedPlayers = useMemo(() => {
    return players
      .filter((p) => {
        const searchBlob = `${p.firstName} ${p.lastName} ${p.academy} ${p.currentClub || ''} ${p.nationality} ${p.primaryPosition} ${p.secondaryPosition || ''} ${p.preferredFoot} ${p.bio}`;
        const matchesSearch = matchesQuery(searchBlob, searchQuery);

        const matchesPosition =
          positionFilter === 'ALL' ||
          (positionFilter === 'ATT' && ['BU', 'AG', 'AD'].includes(p.primaryPosition)) ||
          (positionFilter === 'MID' && ['MC', 'MOC', 'MDF'].includes(p.primaryPosition)) ||
          (positionFilter === 'DEF' && ['DC', 'DL'].includes(p.primaryPosition)) ||
          (positionFilter === 'GK' && p.primaryPosition === 'GB');

        const matchesFoot = footFilter === 'ALL' || p.preferredFoot === footFilter;

        return matchesSearch && matchesPosition && matchesFoot;
      })
      .sort((a, b) => {
        if (sortBy === 'VALUE_DESC') return b.marketValueEur - a.marketValueEur;
        if (sortBy === 'GOALS_DESC') return b.stats.goals - a.stats.goals;
        if (sortBy === 'SPEED_DESC') return b.stats.topSpeedKmh - a.stats.topSpeedKmh;
        if (sortBy === 'AGE_ASC') return a.calculatedAge - b.calculatedAge;
        return 0;
      });
  }, [players, searchQuery, positionFilter, footFilter, sortBy]);

  return (
    <div className="min-h-screen bg-[#040711] flex flex-col font-sans antialiased text-gray-100 selection:bg-amber-500 selection:text-black">
      <OfflineIndicator />
      <Navbar
        onNavigate={handleNavigate}
        activeView={currentView}
        onOpenSearch={() => setIsSearchModalOpen(true)}
        onOpenSharePlatform={() => setIsShareModalOpen(true)}
        onOpenDownloadApp={() => setIsDownloadModalOpen(true)}
        onOpenDomainModal={() => setIsDomainModalOpen(true)}
        onOpenFavorites={() => setIsFavoritesModalOpen(true)}
        onOpenComparison={() => setIsComparisonModalOpen(true)}
        isMenuDrawerOpen={isMenuDrawerOpen}
        setIsMenuDrawerOpen={setIsMenuDrawerOpen}
      />
      <VideoShowcaseModal />
      <QuickChatDrawer />
      <CheckoutModal />
      {isSearchModalOpen && (
        <Suspense fallback={null}>
          <GlobalSearchModal
            isOpen={isSearchModalOpen}
            onClose={() => setIsSearchModalOpen(false)}
            onNavigate={handleNavigate}
          />
        </Suspense>
      )}
      {isShareModalOpen && (
        <Suspense fallback={null}>
          <SharePlatformModal
            isOpen={isShareModalOpen}
            onClose={() => setIsShareModalOpen(false)}
          />
        </Suspense>
      )}
      {isDownloadModalOpen && (
        <Suspense fallback={null}>
          <AppDownloadModal
            isOpen={isDownloadModalOpen}
            onClose={() => setIsDownloadModalOpen(false)}
          />
        </Suspense>
      )}
      {isDomainModalOpen && (
        <Suspense fallback={null}>
          <OfficialDomainModal
            isOpen={isDomainModalOpen}
            onClose={() => setIsDomainModalOpen(false)}
            onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
          />
        </Suspense>
      )}
      {isPdfModalOpen && (
        <Suspense fallback={null}>
          <PlayerPDFExportModal
            player={pdfPlayer}
            isOpen={isPdfModalOpen}
            onClose={() => setIsPdfModalOpen(false)}
          />
        </Suspense>
      )}
      {isComparisonModalOpen && (
        <Suspense fallback={null}>
          <TalentComparisonModal
            isOpen={isComparisonModalOpen}
            onClose={() => setIsComparisonModalOpen(false)}
            onOpenVideo={openVideoModal}
          />
        </Suspense>
      )}
      {isFavoritesModalOpen && (
        <Suspense fallback={null}>
          <FavoritesModal
            isOpen={isFavoritesModalOpen}
            onClose={() => setIsFavoritesModalOpen(false)}
            onNavigate={handleNavigate}
            onExportPdf={(player) => {
              setPdfPlayer(player);
              setIsPdfModalOpen(true);
            }}
          />
        </Suspense>
      )}
      <PushNotificationBanner />
      <Suspense fallback={null}>
        <MercatoAlertsModal />
        <PushNotificationModal />
      </Suspense>
      <MobileInstallBanner
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
      />

      <main className="flex-grow pb-24 lg:pb-0">
        <Suspense fallback={<PageSkeleton />}>
        {/* VUE ACCUEIL */}
        {currentView === 'home' && (
          <Home
            onNavigate={handleNavigate}
            onOpenSearch={() => setIsSearchModalOpen(true)}
            onOpenSharePlatform={() => setIsShareModalOpen(true)}
            onExportPdf={(player) => {
              setPdfPlayer(player);
              setIsPdfModalOpen(true);
            }}
          />
        )}

        {/* VUE TÉLÉCHARGEMENT MULTI-PLATEFORMES (PLAY STORE, IOS, APK, WINDOWS) */}
        {currentView === 'download' && (
          <AppDownloadPage
            onNavigate={handleNavigate}
            onOpenSharePlatform={() => setIsShareModalOpen(true)}
          />
        )}

        {/* VUE MOTEUR DE RECHERCHE DÉDIÉ */}
        {currentView === 'search' && (
          <SearchPage
            onNavigate={handleNavigate}
            onExportPdf={(player) => {
              setPdfPlayer(player);
              setIsPdfModalOpen(true);
            }}
          />
        )}

        {/* VUE FIL RÉSEAU LINKEDIN */}
        {currentView === 'feed' && <FeedPage onNavigate={handleNavigate} />}

        {/* VUE ANNUAIRE MONDIAL & RECHERCHE (CLUBS, DIRIGEANTS, ENTREPRISES) */}
        {currentView === 'directory' && <DirectoryPage onNavigate={handleNavigate} />}

        {/* VUE CALENDRIER DES MATCHS, SCORES & FLUX D'ACTUALITÉS MONDIALES */}
        {(currentView === 'matches' || currentView === 'calendar' || currentView === 'news') && (
          <MatchCalendarPage onNavigate={handleNavigate} />
        )}

        {/* VUE MESSAGERIE B2B */}
        {currentView === 'messages' && <MessagesPage onNavigate={handleNavigate} />}

        {/* VUE MONÉTISATION & TARIFS INTERNATIONAUX */}
        {currentView === 'pricing' && <PricingPage onNavigate={handleNavigate} />}

        {/* VUE ENREGISTREMENT */}
        {currentView === 'register' && <Register onNavigate={handleNavigate} />}

        {/* VUE CONNEXION ESPACE MEMBRE */}
        {currentView === 'login' && <LoginPage onNavigate={handleNavigate} />}

        {/* VUE PROFIL MEMBRE & ÉDITION */}
        {currentView === 'profile' && <ProfilePage onNavigate={handleNavigate} />}

        {/* VUE FONDATEUR (SEYDOU MARIO TRAORÉ) */}
        {currentView === 'founder' && <Founder />}

        {/* VUE CATALOGUE TALENTS, STATS & VIDÉOS (EYEBALL STYLE) */}
        {currentView === 'players' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div>
                <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
                  {t('catalog.headerBadge', 'Vidéothèque & Scouting Eyeball')}
                </span>
                <h1 className="text-3xl font-black text-white mt-1">
                  {t('catalog.headerTitle', 'Talents, Vidéos de Match & Valeurs Marchandes')}
                </h1>
                <p className="text-xs text-gray-400 mt-1">
                  {t('catalog.headerSubtitle', 'Supervision technique directe et certification par')} <strong>{FOUNDER_INFO.name}</strong>, {FOUNDER_INFO.officialTitle}.
                </p>
              </div>

              {/* Action buttons & Market Ticker */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="text-xs bg-[#090E1B] px-3.5 py-2 rounded-lg border border-white/10 font-mono">
                  <span className="text-gray-400">{t('stats.market_value', 'Cote totale')} : </span>
                  <span className="text-emerald-400 font-bold">{formatMarketValue(totalMarketValue)}</span>
                  <span className="text-gray-500"> ({players.length} {t('stats.players', 'profils')})</span>
                </div>
                <button
                  onClick={() => handleNavigate('pricing')}
                  className="px-3.5 py-2 rounded bg-gradient-to-r from-amber-500 to-amber-600 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-md"
                >
                  ★ {t('nav.pricing', 'Passer Premium')}
                </button>
                <button
                  onClick={() => handleNavigate('register')}
                  className="px-4 py-2 rounded bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  + {t('hero.cta_register', 'Enregistrer Joueur')}
                </button>
              </div>
            </div>

            {/* FILTER TOOLBAR */}
            <div className="p-4 rounded-xl bg-[#090E1B] border border-white/10 space-y-3 shadow-xl">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {/* Search */}
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={t('dir.searchPlaceholder', 'Nom, club, académie...')}
                    className="w-full px-3 py-2 pl-8 rounded bg-[#050810] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                  />
                  <span className="absolute left-2.5 top-2.5 text-gray-500 text-xs">🔍</span>
                </div>

                {/* Position tabs */}
                <div className="flex items-center gap-1 bg-[#050810] p-1 rounded border border-white/10 overflow-x-auto">
                  {[
                    { id: 'ALL', label: t('catalog.all', 'Tous') },
                    { id: 'ATT', label: t('catalog.forwards', 'Attaque') },
                    { id: 'MID', label: t('catalog.midfielders', 'Milieu') },
                    { id: 'DEF', label: t('catalog.defenders', 'Défense') },
                    { id: 'GK', label: t('catalog.goalkeepers', 'Gardien') },
                  ].map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setPositionFilter(tab.id)}
                      className={`px-2.5 py-1 text-xs font-bold rounded transition-colors whitespace-nowrap cursor-pointer ${
                        positionFilter === tab.id
                          ? 'bg-amber-500 text-black font-black'
                          : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>

                {/* Sort selector */}
                <div>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="w-full px-3 py-2 rounded bg-[#050810] border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                  >
                    <option value="VALUE_DESC">{t('sort.valueDesc', 'Trier: Valeur Marchande (Décroissante)')}</option>
                    <option value="GOALS_DESC">{t('sort.goalsDesc', 'Trier: Nombre de Buts')}</option>
                    <option value="SPEED_DESC">{t('sort.speedDesc', 'Trier: Vitesse Max (km/h)')}</option>
                    <option value="AGE_ASC">{t('sort.ageAsc', 'Trier: Âge (Plus jeune d\'abord)')}</option>
                  </select>
                </div>

                {/* View toggle */}
                <div className="flex items-center justify-end gap-2">
                  <button
                    onClick={() => setIsSearchModalOpen(true)}
                    className="px-3 py-1 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold transition-colors text-xs flex items-center gap-1 cursor-pointer"
                    title={t('nav.search', 'Moteur de Recherche Global')}
                  >
                    <span>🔍 {t('nav.search', 'Recherche Globale')}</span>
                  </button>

                  <div className="flex items-center bg-[#050810] border border-white/10 rounded p-1 text-xs">
                    <button
                      onClick={() => setViewFormat('CARDS')}
                      className={`px-3 py-1 rounded font-bold transition-colors ${
                        viewFormat === 'CARDS' ? 'bg-white/20 text-white' : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      {t('home.viewCards', 'Cartes')}
                    </button>
                    <button
                      onClick={() => setViewFormat('TABLE')}
                      className={`px-3 py-1 rounded font-bold transition-colors ${
                        viewFormat === 'TABLE' ? 'bg-white/20 text-white' : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      {t('home.viewTable', 'Tableau (Wyscout)')}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* TALENT GRID (CARDS FORMAT) */}
            {viewFormat === 'CARDS' && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredAndSortedPlayers.map(p => {
                  const isShortlisted = shortlist.includes(p.id);
                  return (
                    <div
                      key={p.id}
                      className="p-5 rounded-xl bg-[#090E1B] border border-white/10 hover:border-amber-500/50 transition-all space-y-4 flex flex-col justify-between shadow-xl group"
                    >
                      <div>
                        {/* Image header with Video button */}
                        <div className="h-60 rounded-lg bg-black overflow-hidden relative">
                          <img
                            src={getOptimizedImageUrl(p.avatarUrl, 'card')}
                            alt={`${p.firstName} ${p.lastName}`}
                            className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                            {...lazyImageProps}
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-[#090E1B] via-transparent to-transparent" />

                          {/* Position */}
                          <div className="absolute top-2.5 left-2.5 bg-black/85 border border-amber-500/60 px-2.5 py-0.5 rounded text-xs font-black text-amber-400 font-mono">
                            {p.primaryPosition}
                          </div>

                          {/* AI Certification badge on card photo */}
                          {p.aiCertification?.isCertified && (
                            <div className="absolute top-10 left-2.5 bg-emerald-950/90 border border-emerald-500/70 text-emerald-300 px-2 py-0.5 rounded text-[10px] font-bold font-mono flex items-center gap-1 shadow-md">
                              <span>🤖</span>
                              <span>Certifié IA</span>
                            </div>
                          )}

                          {/* Market Value */}
                          <div className="absolute top-2.5 right-2.5 bg-black/85 border border-emerald-500/60 px-2.5 py-0.5 rounded text-xs font-black text-emerald-400 font-mono">
                            {p.marketValueDisplay}
                          </div>

                          {/* Video trigger button */}
                          <button
                            onClick={() => openVideoModal(p)}
                            className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-amber-500 hover:bg-amber-400 text-black flex items-center justify-center font-black text-sm shadow-xl transition-transform hover:scale-110 active:scale-95 cursor-pointer"
                            title={t('home.watchVideo', 'Regarder la vidéo de match')}
                          >
                            ▶
                          </button>

                          {/* Shortlist star */}
                          <button
                            onClick={() => toggleShortlist(p.id)}
                            className={`absolute bottom-2.5 right-2.5 p-1.5 rounded bg-black/80 text-xs transition-colors cursor-pointer ${
                              isShortlisted ? 'text-amber-400' : 'text-gray-400 hover:text-white'
                            }`}
                            title={isShortlisted ? t('player.inShortlist', 'Dans ma sélection') : t('player.addToShortlist', 'Ajouter à la sélection')}
                          >
                            ★
                          </button>

                          {p.isMinor && (
                            <div className="absolute bottom-2.5 left-2.5 bg-red-950/90 text-red-200 border border-red-700/60 px-2 py-0.5 rounded text-[10px] font-bold">
                              {t('player.minorFifa', 'Mineur (Directive FIFA)')}
                            </div>
                          )}
                        </div>

                        {/* Info & Metrics */}
                        <div className="space-y-3 pt-3">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-black text-white text-base group-hover:text-amber-400 transition-colors">
                                {p.firstName} {p.lastName}
                              </h3>
                              <p className="text-xs text-gray-400 font-mono">
                                {p.countryFlag} {p.nationality} · {p.calculatedAge} {t('player.yearsOld', 'ans')} · {p.heightCm} cm · {p.preferredFoot}
                              </p>
                            </div>
                          </div>

                          <div className="text-xs text-gray-300 truncate font-semibold">
                            {p.currentClub} ({p.academy})
                          </div>

                          {/* Stats Grid */}
                          <div className="grid grid-cols-4 gap-1 text-center text-xs bg-[#050810] p-2 rounded-lg border border-white/5">
                            <div>
                              <div className="text-white font-mono font-bold">{p.stats.matches}</div>
                              <div className="text-[9px] text-gray-500 uppercase">{t('stats.matches', 'Matchs')}</div>
                            </div>
                            <div>
                              <div className="text-white font-mono font-bold">{p.stats.minutes}'</div>
                              <div className="text-[9px] text-gray-500 uppercase">{t('stats.minutes', 'Min')}</div>
                            </div>
                            <div>
                              <div className="text-amber-400 font-mono font-bold">
                                {p.primaryPosition === 'GB' ? (p.stats.cleanSheets ?? 0) : p.stats.goals}
                              </div>
                              <div className="text-[9px] text-gray-500 uppercase">
                                {p.primaryPosition === 'GB' ? 'CS' : t('stats.goals', 'Buts')}
                              </div>
                            </div>
                            <div>
                              <div className="text-emerald-400 font-mono font-bold">
                                {p.stats.topSpeedKmh}
                              </div>
                              <div className="text-[9px] text-gray-500 uppercase">km/h</div>
                            </div>
                          </div>

                          {p.scoutingReports.length > 0 && (
                            <p className="text-[11px] text-gray-300 italic line-clamp-2 border-l-2 border-amber-500/50 pl-2">
                              "{p.scoutingReports[0].summary}"
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="grid grid-cols-2 gap-2 pt-2">
                        <button
                          onClick={() => openVideoModal(p)}
                          className="py-2.5 rounded bg-[#0E1527] hover:bg-white/10 border border-amber-500/40 text-amber-300 hover:text-white font-black text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <span>▶ {t('home.watchVideo', 'Vidéo')}</span>
                        </button>
                        <button
                          onClick={() => handleNavigate('player-detail', p)}
                          className="py-2.5 rounded bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
                        >
                          {t('player.profile', 'Fiche Technique')}
                        </button>
                      </div>

                      <button
                        onClick={() => {
                          setPdfPlayer(p);
                          setIsPdfModalOpen(true);
                        }}
                        className="w-full mt-2 py-1.5 rounded-lg bg-white/5 hover:bg-amber-500/15 border border-white/10 hover:border-amber-400/40 text-gray-300 hover:text-amber-300 font-bold text-[11px] uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      >
                        <span>📄</span>
                        <span>{t('home.exportPdf', 'Exporter en PDF')}</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            )}

            {/* TALENT TABLE (WYSCOUT FORMAT) */}
            {viewFormat === 'TABLE' && (
              <div className="bg-[#090E1B] rounded-xl border border-white/10 overflow-x-auto shadow-2xl">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#050810] border-b border-white/10 text-gray-400 font-mono uppercase text-[10px]">
                    <tr>
                      <th className="py-3 px-4">{t('home.tablePlayer', 'Joueur')} / {t('home.tablePos', 'Poste')}</th>
                      <th className="py-3 px-4">{t('home.tableAge', 'Âge')}</th>
                      <th className="py-3 px-4">{t('home.tableClub', 'Club / Académie')}</th>
                      <th className="py-3 px-4 text-center">{t('stats.matches', 'Matchs')}</th>
                      <th className="py-3 px-4 text-center">{t('stats.goals', 'Buts')} / CS</th>
                      <th className="py-3 px-4 text-center">{t('stats.assists', 'Passes')}</th>
                      <th className="py-3 px-4 text-center">{t('stats.passAccuracy', 'Précision')}</th>
                      <th className="py-3 px-4 text-center">{t('home.tableSpeed', 'Vitesse Max')}</th>
                      <th className="py-3 px-4 text-right">{t('home.tableValue', 'Valeur Marchande')}</th>
                      <th className="py-3 px-4 text-center">{t('home.tableActions', 'Actions')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {filteredAndSortedPlayers.map((player) => (
                      <tr key={player.id} className="hover:bg-white/5 transition-colors">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={player.avatarUrl}
                              alt={player.firstName}
                              className="w-8 h-8 rounded object-cover"
                            />
                            <div>
                              <div className="font-bold text-white">
                                {player.firstName} {player.lastName}
                              </div>
                              <span className="text-[10px] text-amber-400 font-mono font-bold">
                                {player.primaryPosition} · {player.countryFlag}
                              </span>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4 font-mono text-gray-300">{player.calculatedAge} {t('player.yearsOld', 'ans')}</td>
                        <td className="py-3 px-4 text-gray-300">{player.currentClub}</td>
                        <td className="py-3 px-4 text-center font-mono tabular-nums text-white">
                          {player.stats.matches}
                        </td>
                        <td className="py-3 px-4 text-center font-mono tabular-nums text-amber-400 font-bold">
                          {player.primaryPosition === 'GB' ? (player.stats.cleanSheets ?? 0) : player.stats.goals}
                        </td>
                        <td className="py-3 px-4 text-center font-mono tabular-nums text-white">
                          {player.stats.assists}
                        </td>
                        <td className="py-3 px-4 text-center font-mono tabular-nums text-gray-300">
                          {player.stats.passAccuracyPct}%
                        </td>
                        <td className="py-3 px-4 text-center font-mono tabular-nums text-emerald-400 font-bold">
                          {player.stats.topSpeedKmh} km/h
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-black text-emerald-400 text-sm">
                          {player.marketValueDisplay}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => openVideoModal(player)}
                              className="px-2 py-1 rounded bg-[#0E1527] hover:bg-amber-500 hover:text-black text-amber-300 font-bold text-[10px] uppercase transition-colors"
                            >
                              ▶ {t('home.watchVideo', 'Vidéo')}
                            </button>
                            <button
                              onClick={() => handleNavigate('player-detail', player)}
                              className="px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-white font-bold text-[10px] uppercase transition-colors"
                            >
                              {t('home.fullProfile', 'Fiche')}
                            </button>
                            <button
                              onClick={() => {
                                setPdfPlayer(player);
                                setIsPdfModalOpen(true);
                              }}
                              className="px-2 py-1 rounded bg-amber-500/20 hover:bg-amber-500 hover:text-black text-amber-300 font-bold text-[10px] uppercase transition-colors"
                              title={t('home.exportPdf', 'Exporter en PDF')}
                            >
                              📄 PDF
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* VUE DÉTAIL JOUEUR */}
        {currentView === 'player-detail' && selectedPlayer && (
          <div className="max-w-5xl mx-auto px-4 py-12 space-y-8">
            <button
              onClick={() => handleNavigate('players')}
              className="text-xs font-bold text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>←</span>
              <span>{t('player.backToList', 'Retour à la base de talents')}</span>
            </button>

            <div className="bg-[#090E1B] rounded-2xl p-6 sm:p-8 border border-amber-500/40 shadow-2xl grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Left Column: Visual, Market Tag & Video launcher */}
              <div className="space-y-4">
                <div className="relative rounded-xl overflow-hidden border border-white/10 bg-black">
                  <img
                    src={selectedPlayer.avatarUrl}
                    alt={selectedPlayer.firstName}
                    className="w-full h-80 object-cover object-top"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 left-3 bg-black/85 border border-amber-500 px-3 py-1 rounded text-xs font-black text-amber-400 font-mono">
                    {selectedPlayer.primaryPosition}
                  </div>
                  <div className="absolute top-3 right-3 bg-black/85 border border-emerald-500 px-3 py-1 rounded text-xs font-black text-emerald-400 font-mono">
                    {selectedPlayer.marketValueDisplay}
                  </div>

                  <button
                    onClick={() => openVideoModal(selectedPlayer)}
                    className="absolute inset-0 m-auto w-14 h-14 rounded-full bg-amber-500 hover:bg-amber-400 text-black flex items-center justify-center font-black text-lg shadow-2xl transition-transform hover:scale-110 active:scale-95 cursor-pointer"
                    title={t('home.watchVideo', 'Lire la vidéo')}
                  >
                    ▶
                  </button>
                </div>

                <button
                  onClick={() => openVideoModal(selectedPlayer)}
                  className="w-full py-3 rounded-lg bg-[#0E1527] hover:bg-amber-500 hover:text-black border border-amber-500/60 text-amber-300 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <span>▶ {t('player.watchEyeballVideo', 'Visionner la Vidéo Eyeball')}</span>
                </button>

                <button
                  onClick={() => {
                    setPdfPlayer(selectedPlayer);
                    setIsPdfModalOpen(true);
                  }}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg shadow-amber-500/25 active:scale-95 cursor-pointer border border-amber-200"
                >
                  <span>📄</span>
                  <span>{t('player.exportCertifiedPdf', 'Exporter en PDF (Rapport Certifié)')}</span>
                </button>

                <div className="p-4 rounded-xl bg-[#050810] border border-white/10 text-xs space-y-2.5 font-sans">
                  <div className="flex justify-between">
                    <span className="text-gray-400">{t('player.position', 'Poste')} :</span>
                    <span className="font-bold text-white">{selectedPlayer.primaryPosition}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">{t('player.preferredFoot', 'Pied fort')} :</span>
                    <span className="font-bold text-white">{selectedPlayer.preferredFoot}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">{t('player.heightWeight', 'Taille / Poids')} :</span>
                    <span className="font-bold text-white font-mono tabular-nums">{selectedPlayer.heightCm} cm / {selectedPlayer.weightKg} kg</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">{t('player.age', 'Âge')} :</span>
                    <span className="font-bold text-white">{selectedPlayer.calculatedAge} {t('player.yearsOld', 'ans')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">{t('player.academy', 'Académie')} :</span>
                    <span className="font-bold text-amber-400">{selectedPlayer.academy}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">{t('player.contractStatus', 'Statut')} :</span>
                    <span className="font-bold text-emerald-400">{selectedPlayer.contractStatus}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => toggleFavorite(selectedPlayer.id)}
                    className={`py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer border flex items-center justify-center gap-1.5 shadow-sm active:scale-95 ${
                      isFavorite(selectedPlayer.id)
                        ? 'bg-amber-500 text-black border-amber-400 shadow-amber-500/20'
                        : 'bg-[#050810] text-amber-300 border-amber-500/40 hover:bg-amber-500/20'
                    }`}
                  >
                    <span>★</span>
                    <span>{isFavorite(selectedPlayer.id) ? 'En Favoris' : '+ Favori'}</span>
                  </button>

                  <button
                    onClick={() => toggleComparison(selectedPlayer.id)}
                    className={`py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer border flex items-center justify-center gap-1.5 shadow-sm active:scale-95 ${
                      isInComparison(selectedPlayer.id)
                        ? 'bg-purple-600 text-white border-purple-400 shadow-purple-500/20'
                        : 'bg-[#050810] text-purple-300 border-purple-500/40 hover:bg-purple-600/20'
                    }`}
                  >
                    <span>⇄</span>
                    <span>{isInComparison(selectedPlayer.id) ? 'En Face-à-Face' : 'Comparer'}</span>
                  </button>
                </div>
              </div>

              {/* Right Column: In-depth Statistics & Scout Report */}
              <div className="md:col-span-2 space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-amber-400 uppercase tracking-widest">
                        {t('player.officialFile', 'Fiche Officielle Africa Talent Football')}
                      </span>
                      <span className="text-gray-500">·</span>
                      <span className="text-xs text-emerald-400 font-mono font-bold">
                        {t('stats.market_value', 'Cote')}: {selectedPlayer.marketValueDisplay}
                      </span>
                    </div>
                    <h1 className="text-3xl font-black text-white mt-1">
                      {selectedPlayer.firstName} {selectedPlayer.lastName}
                    </h1>
                    <p className="text-xs text-gray-400 mt-1">
                      {t('scout.supervisor', 'Supervision & Cotation Technique')} : <strong className="text-white">{FOUNDER_INFO.name}</strong> ({FOUNDER_INFO.officialTitle})
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      setPdfPlayer(selectedPlayer);
                      setIsPdfModalOpen(true);
                    }}
                    className="px-4 py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 hover:border-amber-300 text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer shadow-sm self-start sm:self-auto shrink-0"
                  >
                    <span>📄</span>
                    <span>{t('home.exportPdf', 'Exporter en PDF')}</span>
                  </button>
                </div>

                {/* STATISTIQUES SAISON */}
                <div>
                  <h3 className="text-xs font-mono font-bold uppercase text-white mb-2 tracking-wider">
                    {t('stats.competitiveSeason', 'Statistiques de Saison Compétitive')}
                  </h3>
                  <div className="grid grid-cols-4 gap-2 text-center text-xs">
                    <div className="p-3 rounded-lg bg-[#050810] border border-white/10">
                      <div className="text-lg font-black text-white font-mono tabular-nums">{selectedPlayer.stats.matches}</div>
                      <div className="text-gray-400 text-[10px]">{t('stats.matches', 'Matchs')}</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[#050810] border border-white/10">
                      <div className="text-lg font-black text-white font-mono tabular-nums">{selectedPlayer.stats.minutes}'</div>
                      <div className="text-gray-400 text-[10px]">{t('stats.minutes', 'Minutes')}</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[#050810] border border-white/10">
                      <div className="text-lg font-black text-amber-400 font-mono tabular-nums">
                        {selectedPlayer.primaryPosition === 'GB' ? (selectedPlayer.stats.cleanSheets ?? 0) : selectedPlayer.stats.goals}
                      </div>
                      <div className="text-gray-400 text-[10px]">
                        {selectedPlayer.primaryPosition === 'GB' ? t('stats.cleanSheets', 'Invincibilités') : t('stats.goals', 'Buts')}
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-[#050810] border border-white/10">
                      <div className="text-lg font-black text-emerald-400 font-mono tabular-nums">
                        {selectedPlayer.stats.topSpeedKmh} km/h
                      </div>
                      <div className="text-gray-400 text-[10px]">{t('home.tableSpeed', 'Vitesse Max')}</div>
                    </div>
                  </div>
                </div>

                {/* RADAR ATHLÉTIQUE */}
                <div>
                  <h3 className="text-xs font-mono font-bold uppercase text-white mb-2 tracking-wider">
                    {t('radar.athleticAttributes', 'Évaluation Aptitudes & Données Physiques')}
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {Object.entries(selectedPlayer.physicalRadar).map(([key, val]) => (
                      <div key={key} className="p-2.5 rounded-lg bg-[#050810] border border-white/10 space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-gray-400 uppercase text-[10px]">{key}</span>
                          <span className="text-white font-mono font-bold">{val}/100</span>
                        </div>
                        <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-amber-400 h-full rounded-full"
                            style={{ width: `${val}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* STATISTIQUES & RADAR D3.JS INTERACTIF (CHARGEMENT À LA DEMANDE) */}
                <Suspense fallback={<div className="h-48 rounded-xl bg-black/40 border border-white/5 animate-pulse flex items-center justify-center text-xs text-gray-500 font-mono">Chargement du radar interactif...</div>}>
                  <D3PlayerStatsChart player={selectedPlayer} />
                </Suspense>

                {/* ANALYSE BIOMÉTRIQUE, HISTORIQUE DES TRANSFERTS & BADGE DE CERTIFICATION IA */}
                <PlayerBiometricsAndTransfers player={selectedPlayer} />

                {/* RAPPORT DE SCOUTING CERTIFIÉ PAR SEYDOU MARIO TRAORÉ */}
                {selectedPlayer.scoutingReports.length > 0 && (
                  <div className="p-5 rounded-xl bg-[#050810] border border-amber-500/40 space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                      <h4 className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
                        {t('scout.auditReport', 'Rapport d\'Audit Technique Certifié')}
                      </h4>
                      <span className="text-xs text-gray-300 font-mono">
                        {t('scout.supervisor', 'Scout Superviseur')} : {selectedPlayer.scoutingReports[0].scoutName}
                      </span>
                    </div>

                    <p className="text-xs text-gray-200 italic leading-relaxed">
                      "{selectedPlayer.scoutingReports[0].summary}"
                    </p>

                    <div className="space-y-1 pt-1">
                      <span className="text-[10px] uppercase font-bold text-gray-400 block font-mono">{t('scout.strengths', 'Points Forts Remarqués')} :</span>
                      <div className="flex gap-2 flex-wrap">
                        {selectedPlayer.scoutingReports[0].strengths.map((s, idx) => (
                          <span
                            key={idx}
                            className="text-[10px] bg-amber-500/10 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded font-semibold"
                          >
                            ✓ {s}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* FIFA MINOR OR DIRECT CONTACT */}
                {selectedPlayer.isMinor ? (
                  <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-600/50 text-amber-200 text-xs space-y-2">
                    <p className="font-bold flex items-center gap-1.5">
                      <span>⚠️</span>
                      <span>{t('player.fifaProtection', 'Protection Joueur Mineur (Directive FIFA Article 19)')} :</span>
                    </p>
                    <p className="text-[11px] text-gray-300 leading-relaxed">
                      Les coordonnées de l'athlète sont masquées. Toute démarche officielle est centralisée auprès du tuteur agréé et du desk de supervision :
                    </p>
                    <p className="font-semibold text-white pt-1">
                      {selectedPlayer.guardianContact?.name} — {selectedPlayer.guardianContact?.phone}
                    </p>
                    <div className="pt-2">
                      <a
                        href={`${FOUNDER_INFO.whatsappUrl}?text=Demande%20officielle%20encadree%20concernant%20le%20joueur%20mineur%20${encodeURIComponent(selectedPlayer.firstName + ' ' + selectedPlayer.lastName)}%20sur%20Africa%20Talent%20Football.`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-block px-5 py-2.5 rounded bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors"
                      >
                        {t('player.contactAgency', 'Contacter le Desk Seydou Mario TRAORÉ')}
                      </a>
                    </div>
                  </div>
                ) : (
                  <div className="pt-2 flex flex-col sm:flex-row gap-3">
                    <a
                      href={`${FOUNDER_INFO.whatsappUrl}?text=Demande%20scouting%20dossier%20complet%20pour%20le%20joueur%20${encodeURIComponent(selectedPlayer.firstName + ' ' + selectedPlayer.lastName)}%20(Valeur%3A%20${encodeURIComponent(selectedPlayer.marketValueDisplay)})%20sur%20Africa%20Talent%20Football.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-6 py-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider text-center transition-colors shadow-lg shadow-amber-500/20"
                    >
                      {t('player.contactAgency', 'Demande d\'Information & Match Complet (WhatsApp Direct)')}
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* VUE DÉTECTIONS (OPPORTUNITÉS) */}
        {currentView === 'opportunities' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
            <div>
              <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
                {t('home.upcomingShowcases', 'Calendrier Showcases')}
              </span>
              <h1 className="text-3xl font-black text-white mt-1">
                {t('opp.title', 'Détections & Tournois d\'Essai')}
              </h1>
              <p className="text-xs text-gray-400 mt-1">
                {t('opp.subtitle', 'Organisés et supervisés sous l\'égide de Seydou Mario TRAORÉ.')}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {DEMO_OPPORTUNITIES.map((opp) => (
                <div
                  key={opp.id}
                  className="bg-[#090E1B] rounded-xl border border-white/10 p-6 flex flex-col justify-between space-y-5 hover:border-amber-500/50 transition-colors shadow-xl"
                >
                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                        {opp.category}
                      </span>
                      <span className="text-[10px] font-black px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                        {opp.status.replace('_', ' ')}
                      </span>
                    </div>

                    <div>
                      <h3 className="font-black text-white text-base">{opp.title}</h3>
                      <p className="text-xs text-gray-400 mt-1">{opp.organizer}</p>
                    </div>

                    <p className="text-xs text-gray-300 leading-relaxed">{opp.description}</p>

                    <div className="space-y-1.5 pt-2 border-t border-white/10">
                      <span className="text-[10px] uppercase font-bold text-gray-400 block font-mono">
                        Critères d'admission :
                      </span>
                      {opp.criteria.map((crit, idx) => (
                        <div key={idx} className="text-xs text-gray-300 flex items-start gap-1.5">
                          <span className="text-amber-400">✓</span>
                          <span>{crit}</span>
                        </div>
                      ))}
                    </div>

                    <div className="text-[11px] text-gray-400 space-y-1 pt-2 border-t border-white/10">
                      <div className="flex justify-between">
                        <span className="text-gray-500">{t('home.location', 'Lieu')} :</span>
                        <span className="text-white font-medium">{opp.location}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">{t('home.dates', 'Dates')} :</span>
                        <span className="text-white font-medium">{opp.date}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Date limite :</span>
                        <span className="text-amber-400 font-bold font-mono">{opp.deadline}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2">
                    <a
                      href={`${FOUNDER_INFO.whatsappUrl}?text=Candidature%20pour%20l'%C3%A9v%C3%A9nement%20${encodeURIComponent(opp.title)}%20sur%20Africa%20Talent%20Football.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block text-center w-full py-2.5 rounded bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider transition-colors shadow-lg shadow-amber-500/20"
                    >
                      {t('opp.apply', 'Postuler via le Desk WhatsApp')}
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VUE MULTI-TABLEAUX DE BORD PROFESSIONNELS (CLUBS, JOUEURS, ACADÉMIES, STAFF, AGENTS) */}
        {currentView === 'dashboard' && (
          <div className="space-y-8">
            <ProfessionalDashboards
              initialRole={dashboardRole}
              onNavigate={handleNavigate}
              onOpenSharePlatform={() => setIsShareModalOpen(true)}
              onExportPdf={(player) => {
                setPdfPlayer(player);
                setIsPdfModalOpen(true);
              }}
            />

            {/* SUBSCRIPTION & BILLING CARD FOR LOGGED IN USERS */}
            {currentUser && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12 space-y-8">
                <div className="p-6 rounded-2xl bg-[#090E1B] border border-white/10 space-y-4 shadow-xl">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h3 className="text-base font-black text-white uppercase font-mono">
                        {t('pricing.billingStatus', 'Statut de Souscription & Facturation Mondiale')} ({currentUser.firstName} {currentUser.lastName})
                      </h3>
                      <p className="text-xs text-gray-400">
                        {t('common.connectedAccount', 'Compte connecté')} : <strong className="text-amber-400">{currentUser.email}</strong> · {t('common.activeRole', 'Rôle actif')} : <strong className="text-white">{currentUser.role}</strong>
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleNavigate('pricing')}
                        className="px-4 py-2 rounded bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase"
                      >
                        {t('pricing.viewAllPlans', 'Voir tous les plans')}
                      </button>
                      <button
                        onClick={() => {
                          logout();
                          handleNavigate('home');
                        }}
                        className="px-3 py-2 rounded bg-red-950/60 hover:bg-red-900 border border-red-700/50 text-red-200 text-xs font-bold"
                      >
                        {t('nav.logout', 'Déconnexion')}
                      </button>
                    </div>
                  </div>

                  {activeSubscription && activeSubscription.status === 'ACTIVE' ? (
                    <div className="p-4 rounded-xl bg-[#050810] border border-emerald-500/40 grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs font-mono">
                      <div>
                        <span className="text-gray-500 block text-[10px]">{t('pricing.activePlan', 'Formule Active')} :</span>
                        <span className="font-bold text-emerald-400 text-sm">{activeSubscription.tier}</span>
                      </div>
                      <div>
                        <span className="text-gray-500 block text-[10px]">{t('pricing.billing', 'Facturation')} :</span>
                        <span className="font-bold text-white">{activeSubscription.interval === 'ANNUAL' ? 'Annuelle (-20%)' : 'Mensuelle'}</span>
                      </div>
                      <div>
                        <span className="text-gray-500 block text-[10px]">{t('pricing.paymentMethod', 'Mode de Paiement')} :</span>
                        <span className="font-bold text-white">{activeSubscription.paymentMethod.details}</span>
                      </div>
                      <div>
                        <span className="text-gray-500 block text-[10px]">{t('pricing.renewal', 'Renouvellement')} :</span>
                        <span className="font-bold text-amber-400">{activeSubscription.expiresAt}</span>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 rounded-xl bg-[#050810] border border-white/10 text-xs flex flex-col sm:flex-row items-center justify-between gap-3">
                      <div className="space-y-0.5">
                        <span className="font-bold text-white">{t('pricing.trialNotice', 'Compte en version d\'essai standard')}</span>
                        <p className="text-gray-400 text-[11px]">{t('pricing.trialDesc', 'Débloquez les vidéos complètes 90 min, les rapports GPS et le contact direct avec les présidents.')}</p>
                      </div>
                      <button
                        onClick={() => openCheckout('SCOUT_PRO')}
                        className="px-4 py-2 rounded bg-amber-500 hover:bg-amber-400 text-black font-black text-xs uppercase tracking-wider cursor-pointer"
                      >
                        {t('pricing.activateScoutPro', 'Activer Scout Pro')}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
        </Suspense>
      </main>

      <Footer onNavigate={handleNavigate} />
      <AndroidBottomBar
        activeView={currentView}
        onNavigate={handleNavigate}
        onOpenMenu={() => setIsMenuDrawerOpen(true)}
      />
      <ComparisonFloatingBar />
    </div>
  );
};

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <PaymentProvider>
          <PlayerProvider>
            <PushNotificationProvider>
              <NetworkProvider>
                <MainContent />
              </NetworkProvider>
            </PushNotificationProvider>
          </PlayerProvider>
        </PaymentProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}
