import os
import zipfile

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
OUTPUT_ZIP_PUBLIC = os.path.join(PROJECT_ROOT, 'public', 'africa-talent-football-full-project.zip')
OUTPUT_ZIP_ROOT = os.path.join(PROJECT_ROOT, 'africa-talent-football-full-project.zip')

EXCLUDE_DIRS = {
    'node_modules',
    'dist',
    '.git',
    '.gradle',
    'build',
    '.tempmediaStorage',
    '.aistudio',
    '.cache',
    'output-apk'
}

EXCLUDE_FILES = {
    'africa-talent-football-full-project.zip',
    'package-lock.json',
    '.DS_Store',
    'local.properties'
}

EXCLUDE_EXTENSIONS = {
    '.zip',
    '.apk',
    '.aab',
    '.keystore',
    '.jks',
    '.log'
}

def should_exclude(rel_path):
    parts = rel_path.replace('\\', '/').split('/')
    for part in parts:
        if part in EXCLUDE_DIRS:
            return True
    
    filename = os.path.basename(rel_path)
    if filename in EXCLUDE_FILES:
        return True
    
    _, ext = os.path.splitext(filename)
    if ext.lower() in EXCLUDE_EXTENSIONS:
        return True
        
    return False

def make_archive(output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    file_count = 0
    total_size = 0

    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(PROJECT_ROOT):
            # Prune excluded directories in-place
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            
            for file in files:
                abs_path = os.path.join(root, file)
                rel_path = os.path.relpath(abs_path, PROJECT_ROOT)
                
                if should_exclude(rel_path):
                    continue
                
                # Archive name inside zip
                arcname = os.path.join('africa-talent-football', rel_path)
                zipf.write(abs_path, arcname)
                file_count += 1
                total_size += os.path.getsize(abs_path)

    zip_size = os.path.getsize(output_path)
    print(f"Archive créée avec succès : {output_path}")
    print(f"Fichiers inclus : {file_count}")
    print(f"Poids total décompressé : {total_size / (1024*1024):.2f} MB")
    print(f"Poids de l'archive ZIP : {zip_size / (1024*1024):.2f} MB")
    return file_count, zip_size

if __name__ == '__main__':
    print("Exportation complète du nouveau projet Africa Talent Football...")
    count, size = make_archive(OUTPUT_ZIP_PUBLIC)
    # Also copy to root for direct local export convenience
    import shutil
    shutil.copy2(OUTPUT_ZIP_PUBLIC, OUTPUT_ZIP_ROOT)
    print("Archive également copiée à la racine : africa-talent-football-full-project.zip")
