import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

// Minimal CRC32 implementation
function makeCrcTable() {
  const cTable = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = ((c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1));
    }
    cTable[n] = c;
  }
  return cTable;
}
const crcTable = makeCrcTable();

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function createChunk(type, data) {
  const typeBuf = Buffer.from(type, 'ascii');
  const lenBuf = Buffer.alloc(4);
  lenBuf.writeUInt32BE(data.length, 0);

  const crcPayload = Buffer.concat([typeBuf, data]);
  const crc = crc32(crcPayload);
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc, 0);

  return Buffer.concat([lenBuf, typeBuf, data, crcBuf]);
}

function generateIcon(width, height, isMaskable = false) {
  const rowSize = 1 + width * 4;
  const rawData = Buffer.alloc(height * rowSize);

  const cx = width / 2;
  const cy = height / 2;
  const radius = width * (isMaskable ? 0.38 : 0.44);
  const innerRadius = radius * 0.45;

  let offset = 0;
  for (let y = 0; y < height; y++) {
    rawData[offset++] = 0; // Filter: None

    for (let x = 0; x < width; x++) {
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Deep dark athletic background #040711
      let r = 4;
      let g = 7;
      let b = 17;
      let a = 255;

      // Subtle gradient towards center
      const centerDistNorm = dist / (width * 0.7);
      if (centerDistNorm < 1) {
        r = Math.min(255, Math.floor(4 + (1 - centerDistNorm) * 12));
        g = Math.min(255, Math.floor(7 + (1 - centerDistNorm) * 20));
        b = Math.min(255, Math.floor(17 + (1 - centerDistNorm) * 35));
      }

      // Shield / Outer Ring (Gold #F59E0B)
      const ringWidth = Math.max(2, Math.floor(width * 0.025));
      if (dist <= radius && dist >= radius - ringWidth) {
        // Gold gradient #F59E0B
        r = 245;
        g = 158;
        b = 11;
      } else if (dist < radius - ringWidth) {
        // Inside shield: dark athletic blue #080F1E
        r = 8;
        g = 15;
        b = 30;

        // Inner crest ring #34D399 (emerald green accent)
        const innerBorder = Math.max(1, Math.floor(width * 0.012));
        if (dist <= innerRadius + innerBorder && dist >= innerRadius) {
          r = 52;
          g = 211;
          b = 153;
        } else if (dist < innerRadius) {
          // Center core: Soccer ball gold center
          r = 14;
          g = 26;
          b = 48;
          // Core center dot
          if (dist < innerRadius * 0.4) {
            r = 245;
            g = 158;
            b = 11;
          }
        }
      }

      rawData[offset++] = r;
      rawData[offset++] = g;
      rawData[offset++] = b;
      rawData[offset++] = a;
    }
  }

  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace

  const ihdrChunk = createChunk('IHDR', ihdr);
  const compressed = zlib.deflateSync(rawData);
  const idatChunk = createChunk('IDAT', compressed);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([sig, ihdrChunk, idatChunk, iendChunk]);
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// 1. 192x192 PNG
const png192 = generateIcon(192, 192, false);
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), png192);

// 2. 512x512 PNG
const png512 = generateIcon(512, 512, false);
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), png512);

// 3. 512x512 maskable PNG (with safe-zone margin)
const pngMaskable = generateIcon(512, 512, true);
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), pngMaskable);

// 4. Apple Touch Icon 180x180 PNG
const pngApple = generateIcon(180, 180, false);
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), pngApple);

// 5. Favicon 48x48 PNG (named favicon.ico or used directly)
const pngFavicon = generateIcon(48, 48, false);
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), pngFavicon);

console.log('✅ PWA PNG icons generated successfully in /public');
