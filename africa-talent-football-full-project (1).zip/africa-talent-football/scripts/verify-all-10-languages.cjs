const fs = require('fs');
const path = require('path');

const LANGS = ['fr', 'en', 'es', 'pt', 'it', 'de', 'ar', 'zh', 'ru', 'tr'];

console.log('=== TEST OFFICIEL ET VALIDATION DES 10 LANGUES AFRICA TALENT FOOTBALL ===\n');

const translationsDir = path.join(__dirname, '../src/translations');
const files = fs.readdirSync(translationsDir).filter(f => f.endsWith('.ts') && f !== 'types.ts' && f !== 'index.ts');

let totalKeys = 0;
let missingLangsCount = 0;
let emptyValuesCount = 0;
let detailedReport = {};

for (const lang of LANGS) {
  detailedReport[lang] = { total: 0, missing: 0, empty: 0 };
}

for (const file of files) {
  const content = fs.readFileSync(path.join(translationsDir, file), 'utf8');
  // Match key: { ... }
  const regex = /['"]([a-zA-Z0-9_.-]+)['"]\s*:\s*\{([^}]+)\}/gs;
  let match;
  while ((match = regex.exec(content)) !== null) {
    totalKeys++;
    const key = match[1];
    const body = match[2];

    for (const lang of LANGS) {
      detailedReport[lang].total++;
      // Support fr:, 'fr':, "fr":
      const langRegex = new RegExp(`(?:['"]?${lang}['"]?)\\s*:\\s*(['"\`])([\\s\\S]*?)\\1`, 'm');
      const langMatch = body.match(langRegex);

      if (!langMatch) {
        missingLangsCount++;
        detailedReport[lang].missing++;
        console.warn(`[MISSING] ${file} -> Key "${key}" missing language [${lang.toUpperCase()}]`);
      } else {
        const val = langMatch[2].trim();
        if (val === '') {
          emptyValuesCount++;
          detailedReport[lang].empty++;
          console.warn(`[EMPTY] ${file} -> Key "${key}" empty in [${lang.toUpperCase()}]`);
        }
      }
    }
  }
}

console.log(`\nNombre total de clés analysées : ${totalKeys}`);
console.log(`Langues testées : ${LANGS.join(', ')}\n`);

console.log('--- RÉSULTATS PAR LANGUE ---');
for (const lang of LANGS) {
  const rep = detailedReport[lang];
  const coveragePct = (((rep.total - rep.missing - rep.empty) / (rep.total || 1)) * 100).toFixed(1);
  console.log(`Langue [${lang.toUpperCase()}] : ${coveragePct}% de couverture (Manquantes: ${rep.missing}, Vides: ${rep.empty}, Total: ${rep.total})`);
}

console.log(`\nBilan Global :`);
console.log(`- Total entrées manquantes : ${missingLangsCount}`);
console.log(`- Total valeurs vides : ${emptyValuesCount}`);

if (missingLangsCount === 0 && emptyValuesCount === 0) {
  console.log('\n>>> SUCCÈS TOTAL : 100% DES 10 LANGUES SONT OPÉRATIONNELLES SANS AUCUNE CLÉ MANQUANTE !');
} else {
  console.log('\n>>> ATTENTION : Des clés manquantes doivent être complétées.');
}
