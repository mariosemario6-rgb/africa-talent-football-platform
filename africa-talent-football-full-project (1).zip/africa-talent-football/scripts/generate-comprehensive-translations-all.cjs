const fs = require('fs');
const path = require('path');

function appendOrUpdateTranslations(filename, varName, newEntries) {
  const filePath = path.join(__dirname, '../src/translations', filename);
  let content = fs.readFileSync(filePath, 'utf8');

  // For each key in newEntries
  for (const [key, langs] of Object.entries(newEntries)) {
    // If key already exists in content, we replace its block
    const keyRegex = new RegExp(`['"]${key}['"]\\s*:\\s*\\{[^}]+\\}`, 'g');
    let block = `  '${key}': {\n`;
    for (const [l, v] of Object.entries(langs)) {
      const esc = String(v).replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\n/g, '\\n');
      block += `    ${l}: '${esc}',\n`;
    }
    block += `  }`;

    if (keyRegex.test(content)) {
      content = content.replace(keyRegex, block);
    } else {
      // Insert before closing bracket of object
      const lastIndex = content.lastIndexOf('};');
      if (lastIndex !== -1) {
        content = content.slice(0, lastIndex) + block + ',\n' + content.slice(lastIndex);
      }
    }
  }

  fs.writeFileSync(filePath, content, 'utf8');
  console.log(`Updated ${filename} with ${Object.keys(newEntries).length} keys.`);
}

// 1. SEARCH TRANSLATIONS
const searchData = {
  'search.indexSystem': {
    fr: 'Système d\'Indexation Mondiale',
    en: 'Worldwide Indexing System',
    es: 'Sistema de Indexación Mundial',
    pt: 'Sistema de Indexação Mundial',
    it: 'Sistema di Indicizzazione Mondiale',
    de: 'Weltweites Indexierungssystem',
    ar: 'نظام الفهرسة العالمية',
    zh: '全球索引检索系统',
    ru: 'Глобальная система индексации',
    tr: 'Küresel İndeksleme Sistemi'
  },
  'search.officialTitle': {
    fr: 'Moteur de Recherche Officiel Africa Talent Football',
    en: 'Official Africa Talent Football Search Engine',
    es: 'Motor de Búsqueda Oficial Africa Talent Football',
    pt: 'Motor de Busca Oficial Africa Talent Football',
    it: 'Motore di Ricerca Ufficiale Africa Talent Football',
    de: 'Offizielle Africa Talent Football Suchmaschine',
    ar: 'محرك البحث الرسمي لأفريكا تالنت فوتبول',
    zh: 'Africa Talent Football官方搜索引擎',
    ru: 'Официальная поисковая система Africa Talent Football',
    tr: 'Resmi Africa Talent Football Arama Motoru'
  },
  'search.subtitle': {
    fr: 'Recherchez instantanément parmi l\'ensemble des clubs mondiaux, présidents, directeurs sportifs, entraîneurs, talents africains et entreprises partenaires.',
    en: 'Instantly search across worldwide clubs, presidents, sporting directors, head coaches, African talents, and partner enterprises.',
    es: 'Busque al instante entre clubes mundiales, presidentes, directores deportivos, entrenadores, talentos africanos y empresas colaboradoras.',
    pt: 'Pesquise instantaneamente entre clubes mundiais, presidentes, diretores desportivos, treinadores, talentos africanos e empresas parceiras.',
    it: 'Cerca istantaneamente tra club mondiali, presidenti, direttori sportivi, allenatori, talenti africani e aziende partner.',
    de: 'Durchsuchen Sie sofort weltweite Vereine, Präsidenten, Sportdirektoren, Trainer, afrikanische Talente und Partnerunternehmen.',
    ar: 'ابحث فوراً بين الأندية العالمية، الرؤساء، المديرين الرياضيين، المدربين، المواهب الإفريقية والشركات الشريكة.',
    zh: '即时检索全球俱乐部、主席、体育总监、主教练、非洲优秀球员和合作伙伴企业。',
    ru: 'Мгновенный поиск по мировым клубам, президентам, спортивным директорам, тренерам, африканским талантам и партнерам.',
    tr: 'Dünya çapındaki kulüpler, başkanlar, sportif direktörler, teknik direktörler, Afrikalı yetenekler ve iş ortakları arasında anında arama yapın.'
  },
  'search.placeholder': {
    fr: 'Rechercher un club, président, directeur sportif, entraîneur, joueur ou marque...',
    en: 'Search a club, president, sporting director, coach, player, or brand...',
    es: 'Buscar un club, presidente, director deportivo, entrenador, jugador o marca...',
    pt: 'Pesquisar clube, presidente, diretor desportivo, treinador, jogador ou marca...',
    it: 'Cerca un club, presidente, direttore sportivo, allenatore, giocatore o marchio...',
    de: 'Suchen Sie nach Verein, Präsident, Sportdirektor, Trainer, Spieler oder Marke...',
    ar: 'ابحث عن نادٍ، رئيس، مدير رياضي، مدرب، لاعب أو علامة تجارية...',
    zh: '搜索俱乐部、主席、体育总监、教练、球员或合作品牌...',
    ru: 'Поиск клуба, президента, спортдиректора, тренера, игрока или бренда...',
    tr: 'Kulüp, başkan, sportif direktör, teknik direktör, oyuncu veya marka arayın...'
  },
  'search.catAll': {
    fr: 'Tous les résultats',
    en: 'All Results',
    es: 'Todos los resultados',
    pt: 'Todos os resultados',
    it: 'Tutti i risultati',
    de: 'Alle Ergebnisse',
    ar: 'جميع النتائج',
    zh: '全部搜索结果',
    ru: 'Все результаты',
    tr: 'Tüm Sonuçlar'
  },
  'search.catClubs': {
    fr: 'Clubs Professionnels',
    en: 'Professional Clubs',
    es: 'Clubes Profesionales',
    pt: 'Clubes Profissionais',
    it: 'Club Professionistici',
    de: 'Profivereine',
    ar: 'الأندية المحترفة',
    zh: '职业俱乐部',
    ru: 'Профессиональные клубы',
    tr: 'Profesyonel Kulüpler'
  },
  'search.catPresidents': {
    fr: 'Présidents & Dirigeants',
    en: 'Presidents & Executives',
    es: 'Presidentes y Dirigentes',
    pt: 'Presidentes e Dirigentes',
    it: 'Presidenti e Dirigenti',
    de: 'Präsidenten & Vorstände',
    ar: 'الرؤساء والمسؤولون',
    zh: '主席与高级管理层',
    ru: 'Президенты и руководство',
    tr: 'Başkanlar ve Yöneticiler'
  },
  'search.catDirectors': {
    fr: 'Directeurs Sportifs & Scouts',
    en: 'Sporting Directors & Scouts',
    es: 'Directores Deportivos y Ojeadores',
    pt: 'Diretores Desportivos e Olheiros',
    it: 'Direttori Sportivi e Scout',
    de: 'Sportdirektoren & Scouts',
    ar: 'المديرون الرياضيون والكشافة',
    zh: '体育总监与球探',
    ru: 'Спортивные директора и скауты',
    tr: 'Sportif Direktörler ve Gözlemciler'
  },
  'search.catCoaches': {
    fr: 'Entraîneurs & Staff',
    en: 'Head Coaches & Staff',
    es: 'Entrenadores y Cuerpo Técnico',
    pt: 'Treinadores e Comissão Técnica',
    it: 'Allenatori e Staff Tecnico',
    de: 'Cheftrainer & Trainerstab',
    ar: 'المدربون والأطقم الفنية',
    zh: '主教练与教练组',
    ru: 'Главные тренеры и штаб',
    tr: 'Teknik Direktörler ve Ekip'
  },
  'search.catPlayers': {
    fr: 'Joueurs & Talents Africains',
    en: 'African Players & Talents',
    es: 'Jugadores y Talentos Africanos',
    pt: 'Jogadores e Talentos Africanos',
    it: 'Giocatori e Talenti Africani',
    de: 'Afrikanische Spieler & Talente',
    ar: 'اللاعبون والمواهب الإفريقية',
    zh: '非洲球员与青年才俊',
    ru: 'Африканские игроки и таланты',
    tr: 'Afrikalı Oyuncular ve Yetenekler'
  },
  'search.catCompanies': {
    fr: 'Entreprises & Partenaires',
    en: 'Enterprises & Partners',
    es: 'Empresas y Colaboradores',
    pt: 'Empresas e Parceiros',
    it: 'Aziende e Partner',
    de: 'Unternehmen & Partner',
    ar: 'الشركات والشركاء',
    zh: '企业与合作伙伴',
    ru: 'Компании и партнеры',
    tr: 'Şirketler ve İş Ortakları'
  },
  'search.filterCountry': {
    fr: 'Filtrer par Pays / Nationalité',
    en: 'Filter by Country / Nationality',
    es: 'Filtrar por País / Nacionalidad',
    pt: 'Filtrar por País / Nacionalidade',
    it: 'Filtra per Paese / Nazionalità',
    de: 'Nach Land / Nationalität filtern',
    ar: 'تصفية حسب الدولة / الجنسية',
    zh: '按国家 / 国籍筛选',
    ru: 'Фильтр по стране / гражданству',
    tr: 'Ülke / Uyruğa Göre Filtrele'
  },
  'search.noMatches': {
    fr: 'Aucun profil ou entité ne correspond à votre recherche actuelle.',
    en: 'No profile or entity matches your current search criteria.',
    es: 'Ningún perfil o entidad coincide con su búsqueda actual.',
    pt: 'Nenhum perfil ou entidade corresponde à sua pesquisa atual.',
    it: 'Nessun profilo o entità corrisponde alla tua ricerca attuale.',
    de: 'Kein Profil oder Verein entspricht Ihren aktuellen Suchkriterien.',
    ar: 'لا توجد ملفات تعريف أو جهات تطابق معايير بحثك الحالية.',
    zh: '没有找到符合当前检索条件的文件或机构。',
    ru: 'По вашему запросу профилей или организаций не найдено.',
    tr: 'Arama kriterlerinize uyan profil veya kuruluş bulunamadı.'
  },
  'search.clearFilters': {
    fr: 'Réinitialiser la recherche',
    en: 'Reset Search Filters',
    es: 'Restablecer búsqueda',
    pt: 'Limpar filtros de pesquisa',
    it: 'Reimposta filtri di ricerca',
    de: 'Suche zurücksetzen',
    ar: 'إعادة ضبط البحث',
    zh: '重置搜索筛选',
    ru: 'Сбросить фильтры поиска',
    tr: 'Aramayı Sıfırla'
  }
};

appendOrUpdateTranslations('search.ts', 'searchTranslations', searchData);

// 2. AUTH & PROFILE TRANSLATIONS
const authData = {
  'auth.loginTitle': {
    fr: 'Connexion Espace Membre',
    en: 'Member Portal Login',
    es: 'Acceso Área de Miembros',
    pt: 'Acesso à Área de Membros',
    it: 'Accesso Area Membri',
    de: 'Mitgliederbereich Anmeldung',
    ar: 'تسجيل دخول بوابة الأعضاء',
    zh: '会员专区登录',
    ru: 'Вход в личный кабинет',
    tr: 'Üye Portalı Girişi'
  },
  'auth.loginSubtitle': {
    fr: 'Accédez à votre espace professionnel certifié Africa Talent Football.',
    en: 'Access your certified professional workspace on Africa Talent Football.',
    es: 'Acceda a su espacio profesional certificado en Africa Talent Football.',
    pt: 'Acesse seu espaço profissional certificado no Africa Talent Football.',
    it: 'Accedi al tuo spazio professionale certificato su Africa Talent Football.',
    de: 'Greifen Sie auf Ihren zertifizierten Profi-Bereich bei Africa Talent Football zu.',
    ar: 'ادخل إلى مساحتك المهنية المعتمدة على أفريكا تالنت فوتبول.',
    zh: '登录您的Africa Talent Football官方认证专业空间。',
    ru: 'Войдите в свое сертифицированное рабочее пространство Africa Talent Football.',
    tr: 'Africa Talent Football onaylı profesyonel çalışma alanınıza erişin.'
  },
  'auth.quickDemoTitle': {
    fr: 'Connexion Rapide Démo & Rôles Professionnels',
    en: 'Fast Demo Access & Professional Roles',
    es: 'Acceso Rápido Demo y Roles Profesionales',
    pt: 'Acesso Rápido de Demonstração e Perfis Profissionais',
    it: 'Accesso Rapido Demo e Ruoli Professionali',
    de: 'Schnellzugriff Demo & Profi-Rollen',
    ar: 'دخول تجريبي سريع واختيار الأدوار المهنية',
    zh: '快速体验通道与职业角色演示',
    ru: 'Быстрый демо-доступ и выбор роли',
    tr: 'Hızlı Demo Girişi ve Profesyonel Roller'
  },
  'auth.rememberMe': {
    fr: 'Se souvenir de moi sur cet appareil',
    en: 'Remember me on this device',
    es: 'Recordarme en este dispositivo',
    pt: 'Lembrar-me neste dispositivo',
    it: 'Ricordami su questo dispositivo',
    de: 'Auf diesem Gerät angemeldet bleiben',
    ar: 'تذكرني على هذا الجهاز',
    zh: '在此设备上记住我',
    ru: 'Запомнить меня на этом устройстве',
    tr: 'Beni bu cihazda hatırla'
  },
  'auth.forgotPassword': {
    fr: 'Mot de passe oublié ?',
    en: 'Forgot Password?',
    es: '¿Ha olvidado su contraseña?',
    pt: 'Esqueceu a senha?',
    it: 'Password dimenticata?',
    de: 'Passwort vergessen?',
    ar: 'نسيت كلمة المرور؟',
    zh: '忘记密码？',
    ru: 'Забыли пароль?',
    tr: 'Şifrenizi mi unuttunuz?'
  },
  'auth.noAccount': {
    fr: 'Pas encore membre ?',
    en: 'Not registered yet?',
    es: '¿Aún no tiene cuenta?',
    pt: 'Ainda não é membro?',
    it: 'Non sei ancora registrato?',
    de: 'Noch kein Mitglied?',
    ar: 'لست عضواً بعد؟',
    zh: '还不是平台会员？',
    ru: 'Еще нет аккаунта?',
    tr: 'Henüz üye değil misiniz?'
  },
  'auth.createAccount': {
    fr: 'Créer un compte professionnel',
    en: 'Create a professional account',
    es: 'Crear cuenta profesional',
    pt: 'Criar conta profissional',
    it: 'Crea account professionale',
    de: 'Profi-Konto erstellen',
    ar: 'إنشاء حساب مهني جديد',
    zh: '创建专业会员账户',
    ru: 'Создать профессиональный аккаунт',
    tr: 'Profesyonel hesap oluşturun'
  },
  'auth.profileSettings': {
    fr: 'Paramètres du Profil & Sécurité',
    en: 'Profile & Security Settings',
    es: 'Configuración del Perfil y Seguridad',
    pt: 'Configurações de Perfil e Segurança',
    it: 'Impostazioni Profilo e Sicurezza',
    de: 'Profil- & Sicherheitseinstellungen',
    ar: 'إعدادات الملف الشخصي والأمان',
    zh: '个人资料与安全设置',
    ru: 'Настройки профиля и безопасность',
    tr: 'Profil ve Güvenlik Ayarları'
  },
  'auth.changePassword': {
    fr: 'Modifier le Mot de Passe',
    en: 'Change Password',
    es: 'Modificar Contraseña',
    pt: 'Alterar Senha',
    it: 'Modifica Password',
    de: 'Passwort ändern',
    ar: 'تغيير كلمة المرور',
    zh: '修改登录密码',
    ru: 'Сменить пароль',
    tr: 'Şifreyi Değiştir'
  },
  'auth.oldPassword': {
    fr: 'Ancien Mot de Passe',
    en: 'Current Password',
    es: 'Contraseña Actual',
    pt: 'Senha Atual',
    it: 'Password Attuale',
    de: 'Aktuelles Passwort',
    ar: 'كلمة المرور الحالية',
    zh: '当前密码',
    ru: 'Текущий пароль',
    tr: 'Mevcut Şifre'
  },
  'auth.newPassword': {
    fr: 'Nouveau Mot de Passe',
    en: 'New Password',
    es: 'Nueva Contraseña',
    pt: 'Nova Senha',
    it: 'Nuova Password',
    de: 'Neues Passwort',
    ar: 'كلمة المرور الجديدة',
    zh: '新密码',
    ru: 'Новый пароль',
    tr: 'Yeni Şifre'
  },
  'auth.confirmPassword': {
    fr: 'Confirmer le Nouveau Mot de Passe',
    en: 'Confirm New Password',
    es: 'Confirmar Nueva Contraseña',
    pt: 'Confirmar Nova Senha',
    it: 'Conferma Nuova Password',
    de: 'Neues Passwort bestätigen',
    ar: 'تأكيد كلمة المرور الجديدة',
    zh: '确认新密码',
    ru: 'Подтвердите новый пароль',
    tr: 'Yeni Şifreyi Onaylayın'
  },
  'auth.logout': {
    fr: 'Déconnexion Sécurisée',
    en: 'Secure Logout',
    es: 'Cerrar Sesión Segura',
    pt: 'Terminar Sessão Segura',
    it: 'Disconnessione Sicura',
    de: 'Sichere Abmeldung',
    ar: 'تسجيل خروج آمن',
    zh: '安全退出登录',
    ru: 'Безопасный выход',
    tr: 'Güvenli Çıkış'
  },
  'auth.saveSuccess': {
    fr: 'Profil mis à jour avec succès.',
    en: 'Profile updated successfully.',
    es: 'Perfil actualizado con éxito.',
    pt: 'Perfil atualizado com sucesso.',
    it: 'Profilo aggiornato con successo.',
    de: 'Profil erfolgreich aktualisiert.',
    ar: 'تم تحديث الملف الشخصي بنجاح.',
    zh: '个人资料已成功保存更新。',
    ru: 'Профиль успешно обновлен.',
    tr: 'Profil başarıyla güncellendi.'
  }
};

appendOrUpdateTranslations('auth.ts', 'authTranslations', authData);

// 3. DASHBOARDS TRANSLATIONS
const dashboardsData = {
  'dashboard.proHub': {
    fr: 'Tableau de Bord Professionnel',
    en: 'Professional Dashboard',
    es: 'Panel Profesional',
    pt: 'Painel Profissional',
    it: 'Dashboard Professionale',
    de: 'Profi-Dashboard',
    ar: 'لوحة التحكم الاحترافية',
    zh: '专业工作台',
    ru: 'Профессиональная панель управления',
    tr: 'Profesyonel Kontrol Paneli'
  },
  'dashboard.selectRole': {
    fr: 'Changer de Vue Professionnelle',
    en: 'Switch Professional View',
    es: 'Cambiar Vista Profesional',
    pt: 'Mudar Visão Profissional',
    it: 'Cambia Vista Professionale',
    de: 'Profi-Ansicht wechseln',
    ar: 'تبديل العرض المهني',
    zh: '切换职业视图',
    ru: 'Сменить вид панели',
    tr: 'Profesyonel Görünümü Değiştir'
  },
  'dashboard.kpiMarketValue': {
    fr: 'Cote Marchande Globale Sous Gestion',
    en: 'Total Market Value Under Monitoring',
    es: 'Valor de Mercado Total Bajo Gestión',
    pt: 'Valor de Mercado Total Sob Gestão',
    it: 'Valore di Mercato Totale Monitorato',
    de: 'Gesamter betreuter Marktwert',
    ar: 'القيمة السوقية الإجمالية الخاضعة للمتابعة',
    zh: '监控中的总球员身价估值',
    ru: 'Общая трансферная стоимость под наблюдением',
    tr: 'İzlenen Toplam Piyasa Değeri'
  },
  'dashboard.kpiTalentsCount': {
    fr: 'Talents Actifs Indexés',
    en: 'Active Indexed Talents',
    es: 'Talentos Activos Indexados',
    pt: 'Talentos Ativos Indexados',
    it: 'Talenti Attivi Indicizzati',
    de: 'Aktive erfasste Talente',
    ar: 'المواهب النشطة المفهرسة',
    zh: '已认证并建档的现役球员',
    ru: 'Активные сертифицированные игроки',
    tr: 'Aktif İndekslenmiş Yetenekler'
  },
  'dashboard.kpiOpportunities': {
    fr: 'Détections & Essais Ouverts',
    en: 'Open Trials & Detection Calls',
    es: 'Pruebas y Detecciones Abiertas',
    pt: 'Peneiras e Testes Abertos',
    it: 'Provini e Selezioni Aperte',
    de: 'Offene Probetrainings & Sichtungen',
    ar: 'تجارب الأداء والفرص المفتوحة',
    zh: '开放中的试训与选拔考核',
    ru: 'Открытые просмотры и отборы',
    tr: 'Açık Denemeler ve Seçmeler'
  },
  'dashboard.kpiReports': {
    fr: 'Rapports Techniques Certifiés',
    en: 'Certified Technical Reports',
    es: 'Informes Técnicos Certificados',
    pt: 'Relatórios Técnicos Certificados',
    it: 'Report Tecnici Certificati',
    de: 'Zertifizierte Scouting-Berichte',
    ar: 'التقارير الفنية المعتمدة',
    zh: '官方认证球探报告',
    ru: 'Сертифицированные скаутские отчеты',
    tr: 'Onaylı Teknik Raporlar'
  },
  'dashboard.tabOverview': {
    fr: 'Vue d\'Ensemble',
    en: 'Overview',
    es: 'Resumen General',
    pt: 'Visão Geral',
    it: 'Panoramica',
    de: 'Übersicht',
    ar: 'نظرة عامة',
    zh: '总览面板',
    ru: 'Обзор',
    tr: 'Genel Bakış'
  },
  'dashboard.tabRoster': {
    fr: 'Effectif & Talents',
    en: 'Squad & Talents',
    es: 'Plantilla y Talentos',
    pt: 'Elenco e Talentos',
    it: 'Rosa e Talenti',
    de: 'Kader & Talente',
    ar: 'التشكيلة والمواهب',
    zh: '球员阵容与天才库',
    ru: 'Состав и таланты',
    tr: 'Kadro ve Yetenekler'
  },
  'dashboard.tabScouting': {
    fr: 'Shortlist de Recrutement',
    en: 'Scouting Shortlist',
    es: 'Lista de Seguimiento',
    pt: 'Lista de Observação',
    it: 'Lista Obiettivi Scouting',
    de: 'Scouting-Beobachtungsliste',
    ar: 'قائمة المتابعة والاستقطاب',
    zh: '重点考察名单',
    ru: 'Шорт-лист скаутинга',
    tr: 'İzleme Listesi'
  },
  'dashboard.tabFinances': {
    fr: 'Finances & Estimations',
    en: 'Finances & Valuations',
    es: 'Finanzas y Valoraciones',
    pt: 'Finanças e Avaliações',
    it: 'Finanze e Valutazioni',
    de: 'Finanzen & Bewertungen',
    ar: 'المالية والتقييمات',
    zh: '财务与估值模型',
    ru: 'Финансы и оценки',
    tr: 'Finans ve Değerlemeler'
  }
};

appendOrUpdateTranslations('dashboards.ts', 'dashboardsTranslations', dashboardsData);

// 4. NETWORK & MESSAGING TRANSLATIONS
const networkData = {
  'network.feedTitle': {
    fr: 'Fil d\'Actualités B2B & Mercato Africain',
    en: 'B2B Newsfeed & African Transfer Market',
    es: 'Muro Profesional B2B y Mercado Africano',
    pt: 'Feed Profissional B2B e Mercado Africano',
    it: 'Feed Notizie B2B e Calciomercato Africano',
    de: 'B2B-Newsfeed & Afrikanischer Transfermarkt',
    ar: 'شريط أخبار B2B وسوق الانتقالات الإفريقي',
    zh: 'B2B专业动态与非洲转会市场',
    ru: 'Лента новостей B2B и африканский трансферный рынок',
    tr: 'B2B Haber Akışı ve Afrika Transfer Pazarı'
  },
  'network.composePlaceholder': {
    fr: 'Partagez une opportunité, une analyse technique ou un joueur à observer...',
    en: 'Share an opportunity, technical analysis, or player to watch...',
    es: 'Comparta una oportunidad, análisis técnico o jugador a observar...',
    pt: 'Compartilhe uma oportunidade, análise técnica ou jogador para observar...',
    it: 'Condividi un\'opportunità, un\'analisi tecnica o un giocatore da osservare...',
    de: 'Teilen Sie ein Angebot, eine Taktikanalyse oder ein Beobachtungstalent...',
    ar: 'شارك فرصة، تحليلاً فنياً أو لاعباً للمراقبة...',
    zh: '分享引援需求、战术分析或值得考察的潜力球员...',
    ru: 'Поделитесь возможностью, тактическим анализом или перспективным игроком...',
    tr: 'Bir fırsat, teknik analiz veya takip edilecek bir oyuncu paylaşın...'
  },
  'network.publish': {
    fr: 'Publier dans le Réseau',
    en: 'Publish to Network',
    es: 'Publicar en la Red',
    pt: 'Publicar na Rede',
    it: 'Pubblica nella Rete',
    de: 'Im Netzwerk veröffentlichen',
    ar: 'نشر في الشبكة',
    zh: '发布到专业网络',
    ru: 'Опубликовать в сети',
    tr: 'Ağda Paylaş'
  },
  'network.messagesTitle': {
    fr: 'Messagerie & Échanges Professionnels',
    en: 'Messaging & Professional Inquiries',
    es: 'Mensajería y Contactos Profesionales',
    pt: 'Mensagens e Contatos Profissionais',
    it: 'Messaggi e Trattative Professionali',
    de: 'Nachrichten & Professionelle Anfragen',
    ar: 'المراسلات والمحادثات المهنية',
    zh: '私信洽谈与官方沟通',
    ru: 'Сообщения и деловые переговоры',
    tr: 'Mesajlaşma ve Profesyonel Görüşmeler'
  },
  'network.searchConversations': {
    fr: 'Rechercher une conversation ou un contact...',
    en: 'Search conversations or contacts...',
    es: 'Buscar conversación o contacto...',
    pt: 'Pesquisar conversas ou contatos...',
    it: 'Cerca conversazione o contatto...',
    de: 'Unterhaltungen oder Kontakte durchsuchen...',
    ar: 'ابحث عن محادثة أو جهة اتصال...',
    zh: '搜索会话或联系人...',
    ru: 'Поиск диалогов или контактов...',
    tr: 'Görüşme veya kişi arayın...'
  },
  'network.noConversations': {
    fr: 'Aucune conversation active pour le moment.',
    en: 'No active conversations yet.',
    es: 'No hay conversaciones activas por el momento.',
    pt: 'Nenhuma conversa ativa no momento.',
    it: 'Nessuna conversazione attiva al momento.',
    de: 'Noch keine aktiven Unterhaltungen.',
    ar: 'لا توجد محادثات نشطة حالياً.',
    zh: '暂无进行中的即时会话。',
    ru: 'Пока нет активных диалогов.',
    tr: 'Henüz aktif bir görüşme bulunmuyor.'
  }
};

appendOrUpdateTranslations('network.ts', 'networkTranslations', networkData);

// 5. DOWNLOAD PAGE TRANSLATIONS
const downloadData = {
  'download.heroTitle': {
    fr: 'Installez l\'Application Officielle Africa Talent Football',
    en: 'Install the Official Africa Talent Football App',
    es: 'Instale la Aplicación Oficial Africa Talent Football',
    pt: 'Instale o Aplicativo Oficial Africa Talent Football',
    it: 'Installa l\'Applicazione Ufficiale Africa Talent Football',
    de: 'Installieren Sie die offizielle Africa Talent Football App',
    ar: 'تثبيت التطبيق الرسمي لأفريكا تالنت فوتبول',
    zh: '安装Africa Talent Football官方应用程序',
    ru: 'Установите официальное приложение Africa Talent Football',
    tr: 'Resmi Africa Talent Football Uygulamasını Yükleyin'
  },
  'download.heroSubtitle': {
    fr: 'Disponible instantanément sur Android, iPhone, tablette et ordinateur de bureau sans passer par un store tiers.',
    en: 'Available instantly on Android, iPhone, tablet, and desktop without third-party store friction.',
    es: 'Disponible instantáneamente en Android, iPhone, tableta y ordenador sin intermediarios.',
    pt: 'Disponível instantaneamente no Android, iPhone, tablet e computador sem intermediários.',
    it: 'Disponibile istantaneamente su Android, iPhone, tablet e computer senza intermediari.',
    de: 'Sofort verfügbar auf Android, iPhone, Tablet und Desktop ohne Umwege.',
    ar: 'متاح فوراً على أندرويد، آيفون، الأجهزة اللوحية وأجهزة الكمبيوتر دون عناء المتاجر الخارجية.',
    zh: '即时安装于Android、iPhone、平板电脑和桌面电脑，畅享极速体验。',
    ru: 'Мгновенно доступно на Android, iPhone, планшетах и компьютерах без сторонних магазинов.',
    tr: 'Üçüncü taraf mağaza engelleri olmadan Android, iPhone, tablet ve masaüstünde anında kullanılabilir.'
  },
  'download.androidTitle': {
    fr: 'Installation sur Smartphone Android',
    en: 'Installation on Android Smartphone',
    es: 'Instalación en Smartphone Android',
    pt: 'Instalação no Smartphone Android',
    it: 'Installazione su Smartphone Android',
    de: 'Installation auf Android-Smartphone',
    ar: 'التثبيت على هواتف أندرويد',
    zh: 'Android智能手机安装指南',
    ru: 'Установка на смартфон Android',
    tr: 'Android Akıllı Telefona Kurulum'
  },
  'download.iosTitle': {
    fr: 'Installation sur Apple iPhone & iPad (iOS)',
    en: 'Installation on Apple iPhone & iPad (iOS)',
    es: 'Instalación en Apple iPhone e iPad (iOS)',
    pt: 'Instalação no Apple iPhone e iPad (iOS)',
    it: 'Installazione su Apple iPhone e iPad (iOS)',
    de: 'Installation auf Apple iPhone & iPad (iOS)',
    ar: 'التثبيت على أجهزة آبل آيفون وآيباد (iOS)',
    zh: 'Apple iPhone与iPad (iOS) 安装步骤',
    ru: 'Установка на Apple iPhone и iPad (iOS)',
    tr: 'Apple iPhone ve iPad (iOS) Üzerine Kurulum'
  },
  'download.iosStep1': {
    fr: 'Ouvrez ce site dans le navigateur Safari sur votre iPhone.',
    en: 'Open this website in the Safari browser on your iPhone.',
    es: 'Abra este sitio web en el navegador Safari de su iPhone.',
    pt: 'Abra este site no navegador Safari no seu iPhone.',
    it: 'Apri questo sito web nel browser Safari del tuo iPhone.',
    de: 'Öffnen Sie diese Website im Safari-Browser auf Ihrem iPhone.',
    ar: 'افتح هذا الموقع في متصفح سفاري على جهاز آيفون الخاص بك.',
    zh: '在iPhone上的Safari浏览器中打开此网站。',
    ru: 'Откройте этот сайт в браузере Safari на вашем iPhone.',
    tr: 'Bu web sitesini iPhone\'unuzdaki Safari tarayıcısında açın.'
  },
  'download.iosStep2': {
    fr: 'Appuyez sur le bouton de Partage (icône carré avec flèche vers le haut en bas de l\'écran).',
    en: 'Tap the Share button (square icon with an upward arrow at the bottom).',
    es: 'Toque el botón Compartir (icono cuadrado con flecha hacia arriba en la parte inferior).',
    pt: 'Toque no botão Compartilhar (ícone quadrado com seta para cima na parte inferior).',
    it: 'Tocca il pulsante Condividi (icona quadrata con freccia verso l\'alto in basso).',
    de: 'Tippen Sie auf die Teilen-Schaltfläche (Viereck mit Pfeil nach oben).',
    ar: 'اضغط على زر المشاركة (المربع ذو السهم لأعلى في أسفل الشاشة).',
    zh: '点击屏幕底部的“分享”按钮（带有向上箭头的方形图标）。',
    ru: 'Нажмите кнопку «Поделиться» (значок квадрата со стрелкой вверх внизу экрана).',
    tr: 'Ekranın altındaki Paylaş düğmesine (yukarı oklu kare simge) dokunun.'
  },
  'download.iosStep3': {
    fr: 'Faites défiler vers le bas et sélectionnez "Sur l\'écran d\'accueil".',
    en: 'Scroll down and select "Add to Home Screen".',
    es: 'Desplácese hacia abajo y seleccione "Añadir a la pantalla de inicio".',
    pt: 'Role para baixo e selecione "Adicionar à Tela de Início".',
    it: 'Scorri verso il basso e seleziona "Aggiungi alla schermata Home".',
    de: 'Scrollen Sie nach unten und wählen Sie "Zum Home-Bildschirm".',
    ar: 'مرر لأسفل واختر "إضافة إلى الشاشة الرئيسية".',
    zh: '向下滚动并选择“添加到主屏幕”。',
    ru: 'Прокрутите вниз и выберите «На экран «Домой»».',
    tr: 'Aşağı kaydırın ve "Ana Ekrana Ekle"yi seçin.'
  }
};

appendOrUpdateTranslations('download.ts', 'downloadTranslations', downloadData);

console.log('All comprehensive translation sets updated successfully!');
