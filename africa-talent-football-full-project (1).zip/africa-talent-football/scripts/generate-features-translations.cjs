const fs = require('fs');
const path = require('path');

// Helper to write a ts translation file
function writeTranslationFile(filename, varName, data) {
  const targetPath = path.join(__dirname, '../src/translations', filename);
  let out = `import { TranslationsRecord } from './types';\n\nexport const ${varName}: TranslationsRecord = {\n`;
  for (const [key, langs] of Object.entries(data)) {
    out += `  '${key}': {\n`;
    for (const [lang, val] of Object.entries(langs)) {
      // Escape single quotes
      const escaped = String(val).replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\n/g, '\\n');
      out += `    ${lang}: '${escaped}',\n`;
    }
    out += `  },\n`;
  }
  out += `};\n`;
  fs.writeFileSync(targetPath, out, 'utf8');
  console.log(`Generated ${filename} with ${Object.keys(data).length} keys.`);
}

// 1. FEATURES TRANSLATIONS (Modals, tactical, biometrics, fixtures, download modal, etc.)
const featuresData = {
  // Modal titles & actions
  'modal.close': {
    fr: 'Fermer la fenêtre',
    en: 'Close window',
    es: 'Cerrar ventana',
    pt: 'Fechar janela',
    it: 'Chiudi finestra',
    de: 'Fenster schließen',
    ar: 'إغلاق النافذة',
    zh: '关闭窗口',
    ru: 'Закрыть окно',
    tr: 'Pencereyi kapat'
  },
  'modal.saveChanges': {
    fr: 'Enregistrer les modifications',
    en: 'Save changes',
    es: 'Guardar cambios',
    pt: 'Salvar alterações',
    it: 'Salva modifiche',
    de: 'Änderungen speichern',
    ar: 'حفظ التعديلات',
    zh: '保存更改',
    ru: 'Сохранить изменения',
    tr: 'Değişiklikleri kaydet'
  },
  'modal.cancel': {
    fr: 'Annuler',
    en: 'Cancel',
    es: 'Cancelar',
    pt: 'Cancelar',
    it: 'Annulla',
    de: 'Abbrechen',
    ar: 'إلغاء',
    zh: '取消',
    ru: 'Отмена',
    tr: 'İptal'
  },

  // App Download Modal & Banner
  'downloadModal.title': {
    fr: 'Télécharger l\'Application Mobile ATF',
    en: 'Download ATF Mobile Application',
    es: 'Descargar la Aplicación Móvil ATF',
    pt: 'Baixar o Aplicativo Móvel ATF',
    it: 'Scarica l\'Applicazione Mobile ATF',
    de: 'ATF Mobile App herunterladen',
    ar: 'تحميل تطبيق الهاتف المحمول ATF',
    zh: '下载ATF移动应用程序',
    ru: 'Скачать мобильное приложение ATF',
    tr: 'ATF Mobil Uygulamasını İndirin'
  },
  'downloadModal.subtitle': {
    fr: 'Installez Africa Talent Football sur votre smartphone pour un accès instantané aux vidéos, fiches joueurs et alertes mercato.',
    en: 'Install Africa Talent Football on your smartphone for instant access to videos, player profiles and transfer alerts.',
    es: 'Instale Africa Talent Football en su smartphone para acceder instantáneamente a vídeos, fichas de jugadores y alertas de fichajes.',
    pt: 'Instale o Africa Talent Football no seu smartphone para acesso instantâneo a vídeos, perfis de jogadores e alertas de mercado.',
    it: 'Installa Africa Talent Football sul tuo smartphone per accedere istantaneamente a video, schede giocatori e avvisi di mercato.',
    de: 'Installieren Sie Africa Talent Football auf Ihrem Smartphone für sofortigen Zugriff auf Videos, Spielerprofile und Transferwarnungen.',
    ar: 'قم بتثبيت أفريكا تالنت فوتبول على هاتفك للوصول الفوري إلى مقاطع الفيديو وملفات اللاعبين وتنبيهات الميركاتو.',
    zh: '在您的智能手机上安装Africa Talent Football，即时访问比赛集锦、球员资料和转会动态。',
    ru: 'Установите Africa Talent Football на свой смартфон для быстрого доступа к видео, анкетам игроков и трансферным новостям.',
    tr: 'Videolara, oyuncu profillerine ve transfer uyarılarına anında erişmek için Africa Talent Football\'u akıllı telefonunuza yükleyin.'
  },
  'downloadModal.installPWA': {
    fr: 'Installer l\'Application Directe (PWA)',
    en: 'Install Direct App (PWA)',
    es: 'Instalar Aplicación Directa (PWA)',
    pt: 'Instalar Aplicativo Direto (PWA)',
    it: 'Installa App Diretta (PWA)',
    de: 'Direkt-App installieren (PWA)',
    ar: 'تثبيت التطبيق المباشر (PWA)',
    zh: '安装原生网页应用 (PWA)',
    ru: 'Установить приложение (PWA)',
    tr: 'Doğrudan Uygulamayı Yükle (PWA)'
  },
  'downloadModal.downloadAPK': {
    fr: 'Télécharger le Fichier APK Android',
    en: 'Download Android APK Package',
    es: 'Descargar Archivo APK Android',
    pt: 'Baixar Pacote APK Android',
    it: 'Scarica Pacchetto APK Android',
    de: 'Android APK-Paket herunterladen',
    ar: 'تحميل حزمة APK لنظام أندرويد',
    zh: '下载Android APK安装包',
    ru: 'Скачать APK-файл Android',
    tr: 'Android APK Paketini İndir'
  },
  'downloadModal.qrCode': {
    fr: 'Scannez le QR Code avec votre téléphone',
    en: 'Scan the QR Code with your phone camera',
    es: 'Escanee el código QR con su teléfono',
    pt: 'Escaneie o código QR com a câmera do seu celular',
    it: 'Scansiona il codice QR con la fotocamera del telefono',
    de: 'Scannen Sie den QR-Code mit Ihrem Smartphone',
    ar: 'امسح رمز الاستجابة السريعة بكاميرا هاتفك',
    zh: '使用手机扫描二维码直接打开',
    ru: 'Отсканируйте QR-код камерой вашего смартфона',
    tr: 'QR Kodunu telefonunuzun kamerasıyla tarayın'
  },

  // Checkout & Subscription Modal
  'checkout.title': {
    fr: 'Finaliser votre Abonnement Professionnel',
    en: 'Complete Your Professional Subscription',
    es: 'Finalizar su Suscripción Profesional',
    pt: 'Finalizar sua Assinatura Profissional',
    it: 'Completa il tuo Abbonamento Professionale',
    de: 'Schließen Sie Ihr Profi-Abonnement ab',
    ar: 'إتمام اشتراكك المهني',
    zh: '完成您的专业版订阅',
    ru: 'Оформить профессиональную подписку',
    tr: 'Profesyonel Aboneliğinizi Tamamlayın'
  },
  'checkout.selectPayment': {
    fr: 'Choisissez votre mode de règlement sécurisé',
    en: 'Select your secure payment method',
    es: 'Seleccione su método de pago seguro',
    pt: 'Escolha seu método de pagamento seguro',
    it: 'Seleziona il metodo di pagamento sicuro',
    de: 'Wählen Sie Ihre sichere Zahlungsmethode',
    ar: 'اختر طريقة الدفع الآمنة',
    zh: '选择您的安全支付方式',
    ru: 'Выберите безопасный способ оплаты',
    tr: 'Güvenli ödeme yönteminizi seçin'
  },
  'checkout.card': {
    fr: 'Carte Bancaire Internationale (Visa / Mastercard)',
    en: 'International Credit Card (Visa / Mastercard)',
    es: 'Tarjeta Bancaria Internacional (Visa / Mastercard)',
    pt: 'Cartão de Crédito Internacional (Visa / Mastercard)',
    it: 'Carta di Credito Internazionale (Visa / Mastercard)',
    de: 'Internationale Kreditkarte (Visa / Mastercard)',
    ar: 'بطاقة ائتمان دولية (فيزا / ماستركارد)',
    zh: '国际信用卡 (Visa / Mastercard)',
    ru: 'Международная банковская карта (Visa / Mastercard)',
    tr: 'Uluslararası Kredi Kartı (Visa / Mastercard)'
  },
  'checkout.mobileMoney': {
    fr: 'Mobile Money Afrique (Orange Money, MTN, Moov, Wave)',
    en: 'Africa Mobile Money (Orange Money, MTN, Moov, Wave)',
    es: 'Mobile Money África (Orange Money, MTN, Moov, Wave)',
    pt: 'Mobile Money África (Orange Money, MTN, Moov, Wave)',
    it: 'Mobile Money Africa (Orange Money, MTN, Moov, Wave)',
    de: 'Afrika Mobile Money (Orange Money, MTN, Moov, Wave)',
    ar: 'الدفع عبر الهاتف المحمول في إفريقيا (أورنج، إم تي إن، موف، ويف)',
    zh: '非洲移动支付 (Orange Money, MTN, Moov, Wave)',
    ru: 'Мобильные платежи Африки (Orange Money, MTN, Moov, Wave)',
    tr: 'Afrika Mobil Para (Orange Money, MTN, Moov, Wave)'
  },
  'checkout.instantActivation': {
    fr: 'Activation immédiate de vos accès professionnels après confirmation.',
    en: 'Immediate activation of your professional access upon confirmation.',
    es: 'Activación inmediata de su acceso profesional tras la confirmación.',
    pt: 'Ativação imediata do seu acesso profissional após confirmação.',
    it: 'Attivazione immediata dell\'accesso professionale dopo la conferma.',
    de: 'Sofortige Aktivierung Ihres Profi-Zugangs nach Bestätigung.',
    ar: 'تفعيل فوري لحسابك المهني فور التأكيد.',
    zh: '确认支付后立即开通专业权限。',
    ru: 'Мгновенная активация профессионального доступа после подтверждения.',
    tr: 'Onaylandıktan sonra profesyonel erişiminiz anında etkinleştirilir.'
  },
  'checkout.payNow': {
    fr: 'Confirmer et Régler',
    en: 'Confirm & Pay Now',
    es: 'Confirmar y Pagar',
    pt: 'Confirmar e Pagar',
    it: 'Conferma e Paga',
    de: 'Bestätigen und Bezahlen',
    ar: 'تأكيد ودفع الآن',
    zh: '确认并立即支付',
    ru: 'Подтвердить и оплатить',
    tr: 'Onayla ve Şimdi Öde'
  },

  // Direct Platform Contact Modal
  'contactModal.title': {
    fr: 'Contacter la Direction Technique & Desk Fondateur',
    en: 'Contact Technical Direction & Founder Desk',
    es: 'Contactar a la Dirección Técnica y Despacho del Fundador',
    pt: 'Contatar a Direção Técnica e Gabinete do Fundador',
    it: 'Contatta la Direzione Tecnica e l\'Ufficio del Fondatore',
    de: 'Kontaktieren Sie die Technische Leitung & Gründer-Büro',
    ar: 'الاتصال بالإدارة الفنية ومكتب المؤسس',
    zh: '联系技术总监兼创始人办公室',
    ru: 'Связаться с техническим руководством и офисом основателя',
    tr: 'Teknik Yönetim ve Kurucu Masası ile İletişime Geçin'
  },
  'contactModal.supervisor': {
    fr: 'Superviseur Général : TRAORÉ SEYDOU (Directeur Fondateur – Agent Scout)',
    en: 'General Supervisor: TRAORÉ SEYDOU (Founder & Managing Director – Scout Agent)',
    es: 'Supervisor General: TRAORÉ SEYDOU (Director Fundador – Agente Scout)',
    pt: 'Supervisor Geral: TRAORÉ SEYDOU (Diretor Fundador – Agente Scout)',
    it: 'Supervisore Generale: TRAORÉ SEYDOU (Direttore Fondatore – Agente Scout)',
    de: 'Hauptsupervisor: TRAORÉ SEYDOU (Gründer & Geschäftsführer – Scout-Agent)',
    ar: 'المشرف العام: تراوري سيدو (المدير المؤسس – وكيل كشاف)',
    zh: '总负责人：TRAORÉ SEYDOU（创始人兼董事 – 球探经纪人）',
    ru: 'Главный координатор: ТРАОРЕ СЕЙДУ (Директор-основатель – Скаут-агент)',
    tr: 'Genel Koordinatör: TRAORÉ SEYDOU (Kurucu Direktör – Yetenek Avcısı Menajer)'
  },
  'contactModal.yourName': {
    fr: 'Votre Nom Complet',
    en: 'Your Full Name',
    es: 'Su Nombre Completo',
    pt: 'Seu Nome Completo',
    it: 'Il Tuo Nome Completo',
    de: 'Ihr vollständiger Name',
    ar: 'اسمك الكامل',
    zh: '您的全名',
    ru: 'Ваше полное имя',
    tr: 'Tam Adınız'
  },
  'contactModal.yourOrg': {
    fr: 'Club, Académie ou Organisation',
    en: 'Club, Academy or Organization',
    es: 'Club, Academia u Organización',
    pt: 'Clube, Academia ou Organização',
    it: 'Club, Accademia o Organizzazione',
    de: 'Verein, Akademie oder Organisation',
    ar: 'النادي، الأكاديمية أو المؤسسة',
    zh: '俱乐部、青训学院或组织机构',
    ru: 'Клуб, академия или организация',
    tr: 'Kulüp, Akademi veya Kuruluş'
  },
  'contactModal.yourRole': {
    fr: 'Votre Fonction Professionnelle',
    en: 'Your Professional Role',
    es: 'Su Cargo Profesional',
    pt: 'Sua Função Profissional',
    it: 'Il Tuo Ruolo Professionale',
    de: 'Ihre berufliche Funktion',
    ar: 'صفتك المهنية',
    zh: '您的职业职位',
    ru: 'Ваша профессиональная должность',
    tr: 'Mesleki Göreviniz'
  },
  'contactModal.message': {
    fr: 'Détails de votre demande ou cible de recrutement',
    en: 'Details of your request or recruitment target',
    es: 'Detalles de su solicitud o perfil de fichaje buscado',
    pt: 'Detalhes da sua solicitação ou alvo de recrutamento',
    it: 'Dettagli della tua richiesta o obiettivo di mercato',
    de: 'Details Ihrer Anfrage oder Ihres Transferziels',
    ar: 'تفاصيل طلبك أو اللاعب المستهدف للاستقطاب',
    zh: '您的需求详情或引援目标',
    ru: 'Подробности вашего запроса или трансферная цель',
    tr: 'Talebinizin detayları veya transfer hedefi'
  },
  'contactModal.sendWhatsApp': {
    fr: 'Transmettre par WhatsApp Direct Officiel',
    en: 'Send via Official Direct WhatsApp',
    es: 'Enviar por WhatsApp Directo Oficial',
    pt: 'Enviar por WhatsApp Direto Oficial',
    it: 'Invia tramite WhatsApp Diretto Ufficiale',
    de: 'Über offizielles Direkt-WhatsApp senden',
    ar: 'إرسال عبر الواتساب المباشر الرسمي',
    zh: '通过官方WhatsApp直接发送',
    ru: 'Отправить через официальный прямой WhatsApp',
    tr: 'Resmi Doğrudan WhatsApp ile Gönder'
  },

  // Player PDF Export Modal
  'pdfExport.title': {
    fr: 'Exportation du CV Sportif Officiel (PDF Certifié)',
    en: 'Official Sports CV Export (Certified PDF)',
    es: 'Exportación del CV Deportivo Oficial (PDF Certificado)',
    pt: 'Exportação do CV Desportivo Oficial (PDF Certificado)',
    it: 'Esportazione del CV Sportivo Ufficiale (PDF Certificato)',
    de: 'Offizieller Sportler-Lebenslauf Export (Zertifiziertes PDF)',
    ar: 'تصدير السيرة الذاتية الرياضية الرسمية (PDF معتمد)',
    zh: '导出官方体育简历 (认证PDF)',
    ru: 'Экспорт официального спортивного резюме (Сертифицированный PDF)',
    tr: 'Resmi Sporcu Özgeçmişi Dışa Aktarma (Onaylı PDF)'
  },
  'pdfExport.description': {
    fr: 'Générez un dossier athlétique complet et partageable contenant les statistiques vérifiées, le radar physique, les tests biométriques et les liens de séquences vidéo.',
    en: 'Generate a complete, shareable athletic dossier containing verified statistics, physical radar, biometric tests, and video match links.',
    es: 'Genere un expediente atlético completo y compartible con estadísticas verificadas, radar físico, pruebas biométricas y enlaces de vídeos.',
    pt: 'Gere um dossiê atlético completo e compartilhável contendo estatísticas verificadas, radar físico, testes biométricos e links de vídeos.',
    it: 'Genera un dossier atletico completo e condivisibile contenente statistiche verificate, radar fisico, test biometrici e link ai video.',
    de: 'Erstellen Sie ein vollständiges Sportlerdossier mit geprüften Statistiken, Leistungsradar, Biometriewerten und Videolinks.',
    ar: 'أنشئ ملفاً رياضياً شاملاً وقابلاً للمشاركة يتضمن إحصائيات معتمدة ومؤشرات بدنية واختبارات حيوية وروابط مباريات كاملة.',
    zh: '生成完整的专业档案，包含认证数据、体能雷达图、生物指标和比赛视频链接。',
    ru: 'Сформируйте полное спортивное досье с проверенной статистикой, радаром физических качеств, биометрией и видеоссылками.',
    tr: 'Doğrulanmış istatistikler, fiziksel radar, biyometrik testler ve video bağlantılarını içeren eksiksiz ve paylaşılabilir bir dosya oluşturun.'
  },
  'pdfExport.downloadBtn': {
    fr: 'Télécharger le Dossier PDF',
    en: 'Download PDF Dossier',
    es: 'Descargar Expediente en PDF',
    pt: 'Baixar Dossiê em PDF',
    it: 'Scarica Dossier in PDF',
    de: 'PDF-Dossier herunterladen',
    ar: 'تحميل الملف بصيغة PDF',
    zh: '下载PDF档案',
    ru: 'Скачать досье в PDF',
    tr: 'PDF Dosyasını İndir'
  },
  'pdfExport.printBtn': {
    fr: 'Imprimer la Fiche Technique',
    en: 'Print Technical Sheet',
    es: 'Imprimir Ficha Técnica',
    pt: 'Imprimir Ficha Técnica',
    it: 'Stampa Scheda Tecnica',
    de: 'Technisches Datenblatt drucken',
    ar: 'طباعة البطاقة الفنية',
    zh: '打印技术资料表',
    ru: 'Распечатать технический лист',
    tr: 'Teknik Bilgi Formunu Yazdır'
  },

  // Tactical Pitch Board
  'tactical.title': {
    fr: 'Tableau Tactique & Dispositifs d\'Équipe',
    en: 'Tactical Board & Team Formations',
    es: 'Pizarra Táctica y Alineaciones',
    pt: 'Quadro Tático e Esquemas de Equipe',
    it: 'Lavagna Tattica e Moduli di Gioco',
    de: 'Taktiktafel & Team-Formationen',
    ar: 'اللوحة التكتيكية والتشكيلات',
    zh: '战术板与阵型配置',
    ru: 'Тактическая доска и расстановки',
    tr: 'Taktik Tahtası ve Takım Dizilişleri'
  },
  'tactical.formation': {
    fr: 'Schéma Tactique',
    en: 'Formation',
    es: 'Esquema Táctico',
    pt: 'Esquema Tático',
    it: 'Modulo Tattico',
    de: 'Taktische Aufstellung',
    ar: 'الخطة التكتيكية',
    zh: '阵型选择',
    ru: 'Тактическая схема',
    tr: 'Taktik Diziliş'
  },
  'tactical.dragDropNotice': {
    fr: 'Glissez et déposez les joueurs sur le terrain pour analyser les complémentarités athlétiques et techniques.',
    en: 'Drag and drop players on the pitch to analyze athletic and technical complementarities.',
    es: 'Arrastre y suelte jugadores en el campo para analizar compatibilidades tácticas.',
    pt: 'Arraste e solte os jogadores no campo para analisar a complementaridade técnica e atlética.',
    it: 'Trascina i giocatori sul campo per analizzare la compatibilità tattica e tecnica.',
    de: 'Ziehen Sie Spieler auf das Spielfeld, um Synergien und Taktik zu analysieren.',
    ar: 'اسحب اللاعبين وأفلتهم على أرضية الملعب لتحليل التناغم التكتيكي والبدني.',
    zh: '在球场上拖拽球员以分析战术互补性和技术配合。',
    ru: 'Перетаскивайте игроков по полю для анализа тактического взаимодействия.',
    tr: 'Teknik ve fiziksel uyumu analiz etmek için oyuncuları sahaya sürükleyip bırakın.'
  },

  // Biometrics & Transfers
  'biometrics.title': {
    fr: 'Données Biométriques & Historique des Transferts',
    en: 'Biometric Metrics & Transfer History',
    es: 'Métricas Biométricas e Historial de Fichajes',
    pt: 'Métricas Biométricas e Histórico de Transferências',
    it: 'Metriche Biometriche e Cronologia Trasferimenti',
    de: 'Biometrische Daten & Transferhistorie',
    ar: 'المقاييس الحيوية وسجل الانتقالات',
    zh: '生物学指标与转会履历',
    ru: 'Биометрические показатели и история трансферов',
    tr: 'Biyometrik Ölçümler ve Transfer Geçmişi'
  },
  'biometrics.vo2max': {
    fr: 'Capacité Aérobie (VO2 Max)',
    en: 'Aerobic Capacity (VO2 Max)',
    es: 'Capacidad Aeróbica (VO2 Máx)',
    pt: 'Capacidade Aeróbica (VO2 Máx)',
    it: 'Capacità Aerobica (VO2 Max)',
    de: 'Aerobe Kapazität (VO2 Max)',
    ar: 'السعة الهوائية (VO2 Max)',
    zh: '最大摄氧量 (VO2 Max)',
    ru: 'Аэробная выносливость (VO2 Max)',
    tr: 'Aerobik Kapasite (VO2 Max)'
  },
  'biometrics.topSpeed': {
    fr: 'Vitesse de Pointe Mesurée',
    en: 'Measured Top Speed',
    es: 'Velocidad Máxima Medida',
    pt: 'Velocidade Máxima Medida',
    it: 'Velocità di Punta Misurata',
    de: 'Gemessene Spitzengeschwindigkeit',
    ar: 'السرعة القصوى المسجلة',
    zh: '实测最高冲刺速度',
    ru: 'Максимальная зафиксированная скорость',
    tr: 'Ölçülen Maksimum Hız'
  },
  'biometrics.verticalJump': {
    fr: 'Détente Verticale (Sargent Test)',
    en: 'Vertical Jump (Sargent Test)',
    es: 'Salto Vertical (Test de Sargent)',
    pt: 'Salto Vertical (Teste de Sargent)',
    it: 'Salto Verticale (Test di Sargent)',
    de: 'Sprungkraft (Sargent-Test)',
    ar: 'الارتقاء العمودي (اختبار سارجنت)',
    zh: '垂直弹跳力 (Sargent测试)',
    ru: 'Высота вертикального прыжка',
    tr: 'Dikey Sıçrama (Sargent Testi)'
  },
  'biometrics.heartRecovery': {
    fr: 'Récupération Cardiaque (1 min)',
    en: 'Heart Rate Recovery (1 min)',
    es: 'Recuperación Cardíaca (1 min)',
    pt: 'Recuperação Cardíaca (1 min)',
    it: 'Recupero Cardiaco (1 min)',
    de: 'Herzerholung (1 Min.)',
    ar: 'معدل تعافي نبضات القلب (دقيقة واحدة)',
    zh: '心率恢复速率 (1分钟)',
    ru: 'Восстановление пульса (1 мин)',
    tr: 'Kalp Atış Hızı Toparlanması (1 dk)'
  },
  'biometrics.transfers': {
    fr: 'Parcours Sportif & Conventions',
    en: 'Career Journey & Agreements',
    es: 'Trayectoria Deportiva y Convenios',
    pt: 'Trajetória Desportiva e Acordos',
    it: 'Percorso Sportivo e Accordi',
    de: 'Karriereverlauf & Vereinbarungen',
    ar: 'المسار الرياضي والاتفاقيات',
    zh: '球员生涯履历与签约协议',
    ru: 'Спортивная карьера и соглашения',
    tr: 'Kariyer Yolculuğu ve Anlaşmalar'
  },

  // Real-time Partner Hub
  'partnerHub.title': {
    fr: 'Hub Partenaires & Intelligence Réseau B2B',
    en: 'Partner Hub & B2B Network Intelligence',
    es: 'Centro de Socios e Inteligencia B2B',
    pt: 'Hub de Parceiros e Inteligência de Rede B2B',
    it: 'Hub Partner e Intelligence di Rete B2B',
    de: 'Partner-Hub & B2B-Netzwerk-Intelligence',
    ar: 'مركز الشركاء ومعلومات شبكة B2B',
    zh: '合作伙伴中心与B2B网络动态',
    ru: 'Центр партнеров и аналитика сети B2B',
    tr: 'İş Ortağı Merkezi ve B2B Ağ Bilgileri'
  },
  'partnerHub.liveFeed': {
    fr: 'Flux en Direct des Confédérations',
    en: 'Live Confederations Feed',
    es: 'Flujo en Vivo de Confederaciones',
    pt: 'Feed em Tempo Real das Confederações',
    it: 'Feed in Diretta dalle Confederazioni',
    de: 'Live-Feed der Konföderationen',
    ar: 'بث مباشر من الاتحادات القارية',
    zh: '大洲足联实时动态流',
    ru: 'Прямой поток новостей конфедераций',
    tr: 'Canlı Konfederasyon Akışı'
  },

  // Share Platform Modal
  'shareModal.title': {
    fr: 'Partager Africa Talent Football',
    en: 'Share Africa Talent Football',
    es: 'Compartir Africa Talent Football',
    pt: 'Compartilhar Africa Talent Football',
    it: 'Condividi Africa Talent Football',
    de: 'Africa Talent Football teilen',
    ar: 'مشاركة منصة أفريكا تالنت فوتبول',
    zh: '分享Africa Talent Football平台',
    ru: 'Поделиться Africa Talent Football',
    tr: 'Africa Talent Football\'u Paylaşın'
  },
  'shareModal.copyLink': {
    fr: 'Copier le Lien Officiel',
    en: 'Copy Official Link',
    es: 'Copiar Enlace Oficial',
    pt: 'Copiar Link Oficial',
    it: 'Copia Link Ufficiale',
    de: 'Offiziellen Link kopieren',
    ar: 'نسخ الرابط الرسمي',
    zh: '复制官方链接',
    ru: 'Скопировать официальную ссылку',
    tr: 'Resmi Bağlantıyı Kopyala'
  },
  'shareModal.linkCopied': {
    fr: 'Lien copié dans le presse-papier !',
    en: 'Link copied to clipboard!',
    es: '¡Enlace copiado al portapapeles!',
    pt: 'Link copiado para a área de transferência!',
    it: 'Link copiato negli appunti!',
    de: 'Link in die Zwischenablage kopiert!',
    ar: 'تم نسخ الرابط إلى الحافظة بنجاح!',
    zh: '链接已成功复制到剪贴板！',
    ru: 'Ссылка скопирована в буфер обмена!',
    tr: 'Bağlantı panoya kopyalandı!'
  },

  // Post Share Modal
  'postShare.title': {
    fr: 'Partager cette Publication Professionnelle',
    en: 'Share this Professional Post',
    es: 'Compartir esta Publicación Profesional',
    pt: 'Compartilhar esta Publicação Profissional',
    it: 'Condividi questo Post Professionale',
    de: 'Diesen Profi-Beitrag teilen',
    ar: 'مشاركة هذا المنشور المهني',
    zh: '分享此专业动态',
    ru: 'Поделиться этой публикацией',
    tr: 'Bu Profesyonel Gönderiyi Paylaş'
  },

  // Official Domain Modal
  'officialDomain.title': {
    fr: 'Adresse & Domaine Officiel de l\'Application',
    en: 'Application Official Domain & Address',
    es: 'Dominio y Dirección Oficial de la Aplicación',
    pt: 'Domínio e Endereço Oficial do Aplicativo',
    it: 'Dominio e Indirizzo Ufficiale dell\'Applicazione',
    de: 'Offizielle Domain & Anwendungsadresse',
    ar: 'النطاق والعنوان الرسمي للتطبيق',
    zh: '应用程序官方域名与访问地址',
    ru: 'Официальный домен и адрес приложения',
    tr: 'Uygulamanın Resmi Alan Adı ve Adresi'
  },
  'officialDomain.desc': {
    fr: 'La plateforme Africa Talent Football est actuellement accessible via son URL certifiée sécurisée avec chiffrement TLS et conformité PWA.',
    en: 'The Africa Talent Football platform is currently accessible via its certified secure URL with TLS encryption and PWA compliance.',
    es: 'La plataforma Africa Talent Football es accesible mediante su URL certificada segura con cifrado TLS y compatibilidad PWA.',
    pt: 'A plataforma Africa Talent Football está acessível através de seu URL certificado seguro com criptografia TLS e compatibilidade PWA.',
    it: 'La piattaforma Africa Talent Football è accessibile tramite il suo URL certificato sicuro con crittografia TLS e conformità PWA.',
    de: 'Die Plattform Africa Talent Football ist über ihre zertifizierte, sichere URL mit TLS-Verschlüsselung und PWA-Konformität erreichbar.',
    ar: 'يمكن الوصول إلى منصة أفريكا تالنت فوتبول عبر عنوانها المعتمد والآمن بتشفير TLS وتوافق PWA.',
    zh: 'Africa Talent Football平台当前通过具备TLS高强度加密和PWA标准的官方安全网址进行访问。',
    ru: 'Платформа Africa Talent Football доступна по официальному безопасному адресу с TLS-шифрованием и поддержкой PWA.',
    tr: 'Africa Talent Football platformuna, TLS şifrelemesi ve PWA uyumluluğu ile onaylanmış güvenli adresi üzerinden erişilebilir.'
  },

  // Quick Chat Drawer
  'chat.title': {
    fr: 'Messagerie Directe B2B',
    en: 'Direct B2B Messaging',
    es: 'Mensajería Directa B2B',
    pt: 'Mensagens Diretas B2B',
    it: 'Messaggistica Diretta B2B',
    de: 'Direkte B2B-Nachrichten',
    ar: 'المراسلة المباشرة B2B',
    zh: 'B2B即时洽谈',
    ru: 'Прямые сообщения B2B',
    tr: 'Doğrudan B2B Mesajlaşma'
  },
  'chat.placeholder': {
    fr: 'Écrivez votre message professionnel...',
    en: 'Write your professional message...',
    es: 'Escriba su mensaje profesional...',
    pt: 'Escreva sua mensagem profissional...',
    it: 'Scrivi il tuo messaggio professionale...',
    de: 'Schreiben Sie Ihre berufliche Nachricht...',
    ar: 'اكتب رسالتك المهنية هنا...',
    zh: '输入您的专业交流信息...',
    ru: 'Напишите профессиональное сообщение...',
    tr: 'Profesyonel mesajınızı yazın...'
  },
  'chat.send': {
    fr: 'Envoyer',
    en: 'Send',
    es: 'Enviar',
    pt: 'Enviar',
    it: 'Invia',
    de: 'Senden',
    ar: 'إرسال',
    zh: '发送',
    ru: 'Отправить',
    tr: 'Gönder'
  },
  'chat.attachPlayer': {
    fr: 'Joindre la fiche d\'un joueur',
    en: 'Attach player profile',
    es: 'Adjuntar ficha de jugador',
    pt: 'Anexar perfil de jogador',
    it: 'Allega scheda giocatore',
    de: 'Spielerprofil anhängen',
    ar: 'إرفاق ملف لاعب',
    zh: '附带球员资料卡',
    ru: 'Прикрепить профиль игрока',
    tr: 'Oyuncu profili ekle'
  },

  // Video Showcase Modal
  'video.showcaseTitle': {
    fr: 'Visionnage Vidéo Certifiée & Actions de Match',
    en: 'Certified Video Showcase & Match Highlights',
    es: 'Visualización de Vídeo Certificado y Jugadas',
    pt: 'Visualização de Vídeo Certificado e Lances',
    it: 'Visione Video Certificato e Azioni Salienti',
    de: 'Zertifizierte Video-Highlights & Spielszenen',
    ar: 'عرض الفيديو المعتمد ولقطات المباراة',
    zh: '认证比赛录像与精彩集锦',
    ru: 'Просмотр сертифицированного видео и моментов матча',
    tr: 'Onaylı Video İzleme ve Maç Özetleri'
  },
  'video.certifiedBadge': {
    fr: 'Audit Vidéo Certifié ATF · 90 Minutes Intégrales',
    en: 'ATF Certified Video Audit · Full 90 Minutes Available',
    es: 'Auditoría de Vídeo Certificada ATF · 90 Minutos Completos',
    pt: 'Auditoria de Vídeo Certificada ATF · 90 Minutos Integrais',
    it: 'Audit Video Certificato ATF · 90 Minuti Completi',
    de: 'ATF Zertifiziertes Video · Volle 90 Minuten',
    ar: 'تدقيق فيديو معتمد من ATF · 90 دقيقة كاملة',
    zh: 'ATF认证视频审核 · 提供完整90分钟比赛录像',
    ru: 'Сертифицированный видеоаудит ATF · Полные 90 минут',
    tr: 'ATF Onaylı Video Denetimi · Tam 90 Dakika'
  },

  // Push Notifications Banner & Modal
  'push.bannerTitle': {
    fr: 'Recevez les Alertes Recrutement en Direct',
    en: 'Receive Live Recruitment & Transfer Alerts',
    es: 'Reciba Alertas de Fichajes en Vivo',
    pt: 'Receba Alertas de Recrutamento em Tempo Real',
    it: 'Ricevi Avvisi di Calciomercato in Tempo Reale',
    de: 'Erhalten Sie Live-Transferbenachrichtigungen',
    ar: 'احصل على تنبيهات الاستقطاب والميركاتو المباشرة',
    zh: '接收即时球员招募与转会通知',
    ru: 'Получайте уведомления о трансферах в реальном времени',
    tr: 'Canlı Transfer ve İzcilik Uyarıları Alın'
  },
  'push.bannerDesc': {
    fr: 'Soyez averti dès qu\'un nouveau talent certifié ou une opportunité d\'essai professionnel est publiée sur la plateforme.',
    en: 'Get notified as soon as a new certified talent or professional trial opportunity is published on the platform.',
    es: 'Reciba notificaciones cuando se publique un nuevo talento certificado o una oportunidad de prueba profesional.',
    pt: 'Seja notificado assim que um novo talento certificado ou oportunidade de teste for publicado na plataforma.',
    it: 'Ricevi una notifica non appena un nuovo talento certificato o un provino professionale viene pubblicato sulla piattaforma.',
    de: 'Lassen Sie sich benachrichtigen, sobald ein neues zertifiziertes Talent oder ein Probetraining verfügbar ist.',
    ar: 'كن أول من يعلم عند نشر موهبة معتمدة جديدة أو فرصة تجارب أداء احترافية على المنصة.',
    zh: '当平台上发布新认证球员或职业试训机会时，第一时间收到提醒。',
    ru: 'Получайте оповещения при публикации новых проверенных талантов или приглашений на просмотры.',
    tr: 'Platformda yeni onaylı bir yetenek veya deneme fırsatı yayınlandığında anında bildirim alın.'
  },
  'push.enableBtn': {
    fr: 'Activer les Notifications',
    en: 'Enable Notifications',
    es: 'Activar Notificaciones',
    pt: 'Ativar Notificações',
    it: 'Attiva Notifiche',
    de: 'Benachrichtigungen aktivieren',
    ar: 'تفعيل الإشعارات',
    zh: '开启通知',
    ru: 'Включить уведомления',
    tr: 'Bildirimleri Aç'
  },
  'push.laterBtn': {
    fr: 'Plus tard',
    en: 'Maybe later',
    es: 'Más tarde',
    pt: 'Mais tarde',
    it: 'Più tardi',
    de: 'Später',
    ar: 'لاحقاً',
    zh: '稍后再说',
    ru: 'Позже',
    tr: 'Daha sonra'
  },

  // Propose Player Modal
  'proposePlayer.title': {
    fr: 'Proposer un Talent à la Direction Technique',
    en: 'Submit a Talent to Technical Direction',
    es: 'Proponer un Talento a la Dirección Técnica',
    pt: 'Propor um Talento à Direção Técnica',
    it: 'Proponi un Talento alla Direzione Tecnica',
    de: 'Ein Talent an die Technische Leitung melden',
    ar: 'تقديم موهبة إلى الإدارة الفنية',
    zh: '向技术总监推荐新球员',
    ru: 'Предложить талант техническому руководству',
    tr: 'Teknik Yönetime Bir Yetenek Önerin'
  },
  'proposePlayer.subtitle': {
    fr: 'Votre recommandation sera directement examinée par l\'équipe de détection sous la supervision de Mario Seydou Traoré.',
    en: 'Your recommendation will be directly reviewed by the scouting team supervised by Mario Seydou Traore.',
    es: 'Su recomendación será evaluada directamente por el equipo de scouting bajo la supervisión de Mario Seydou Traore.',
    pt: 'Sua recomendação será diretamente avaliada pela equipe de observação sob a supervisão de Mario Seydou Traore.',
    it: 'La tua raccomandazione sarà esaminata dal team di osservatori sotto la supervisione di Mario Seydou Traore.',
    de: 'Ihre Empfehlung wird vom Scouting-Team unter der Leitung von Mario Seydou Traore geprüft.',
    ar: 'سيتم فحص ترشيحك مباشرة من قبل فريق الكشافة تحت إشراف ماريو سيدو تراوري.',
    zh: '您的推荐将由Mario Seydou Traore监督下的专业球探团队直接审核。',
    ru: 'Ваша рекомендация будет рассмотрена скаутской службой под руководством Марио Сейду Траоре.',
    tr: 'Öneriniz, Mario Seydou Traore gözetimindeki yetenek avcısı ekip tarafından doğrudan incelenecektir.'
  },

  // Founder Photo Update
  'founder.photoModalTitle': {
    fr: 'Photo Officielle du Fondateur (Seydou Mario Traoré)',
    en: 'Official Founder Portrait (Seydou Mario Traore)',
    es: 'Foto Oficial del Fundador (Seydou Mario Traore)',
    pt: 'Foto Oficial do Fundador (Seydou Mario Traore)',
    it: 'Foto Ufficiale del Fondatore (Seydou Mario Traore)',
    de: 'Offizielles Gründerfoto (Seydou Mario Traore)',
    ar: 'الصورة الرسمية للمؤسس (سيدو ماريو تراوري)',
    zh: '创始人官方肖像照 (Seydou Mario Traore)',
    ru: 'Официальное фото основателя (Сейду Марио Траоре)',
    tr: 'Resmi Kurucu Fotoğrafı (Seydou Mario Traore)'
  },
  'founder.changePhoto': {
    fr: 'Mettre à jour la photo officielle',
    en: 'Update official portrait',
    es: 'Actualizar foto oficial',
    pt: 'Atualizar foto oficial',
    it: 'Aggiorna foto ufficiale',
    de: 'Offizielles Foto aktualisieren',
    ar: 'تحديث الصورة الرسمية',
    zh: '更新官方肖像照',
    ru: 'Обновить официальное фото',
    tr: 'Resmi fotoğrafı güncelle'
  },
  'founder.uploadFromDevice': {
    fr: 'Importer depuis votre appareil',
    en: 'Upload from your device',
    es: 'Subir desde su dispositivo',
    pt: 'Carregar do seu dispositivo',
    it: 'Carica dal tuo dispositivo',
    de: 'Von Ihrem Gerät hochladen',
    ar: 'تحميل من جهازك',
    zh: '从您的设备中上传',
    ru: 'Загрузить с устройства',
    tr: 'Cihazınızdan yükleyin'
  },
  'founder.photoUploadedSuccess': {
    fr: 'Photo officielle du fondateur mise à jour avec succès !',
    en: 'Official founder portrait updated successfully!',
    es: '¡Foto oficial del fundador actualizada con éxito!',
    pt: 'Foto oficial do fundador atualizada com sucesso!',
    it: 'Foto ufficiale del fondatore aggiornata con successo!',
    de: 'Offizielles Gründerfoto erfolgreich aktualisiert!',
    ar: 'تم تحديث الصورة الرسمية للمؤسس بنجاح!',
    zh: '创始人官方肖像已成功更新！',
    ru: 'Официальное фото основателя успешно обновлено!',
    tr: 'Resmi kurucu fotoğrafı başarıyla güncellendi!'
  }
};

writeTranslationFile('features.ts', 'featuresTranslations', featuresData);
