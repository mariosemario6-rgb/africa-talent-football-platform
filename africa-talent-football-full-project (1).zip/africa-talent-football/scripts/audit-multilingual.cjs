const fs = require('fs');
const path = require('path');

// Read files in src/translations
const translationFiles = [
  'common.ts', 'home.ts', 'players.ts', 'auth.ts', 'network.ts',
  'pricing.ts', 'dashboards.ts', 'founder.ts', 'download.ts',
  'search.ts', 'drawer.ts', 'valuation.ts'
];

const LANGUAGES = ['fr', 'en', 'es', 'pt', 'it', 'de', 'ar', 'zh', 'ru', 'tr'];

console.log('=== AUDIT DES TRADUCTIONS ET CLÉS AFRICA TALENT FOOTBALL ===\n');

// 1. Check all exported objects from translations
let allKeys = {};
for (const file of translationFiles) {
  const filePath = path.join(__dirname, '../src/translations', file);
  if (!fs.existsSync(filePath)) {
    console.error(`File missing: ${file}`);
    continue;
  }
  const content = fs.readFileSync(filePath, 'utf8');
  // Simple extraction of key blocks: 'key': { fr: '...', ... } or "key": { ... }
  // Let's count how many keys are defined
  const keyMatches = content.match(/['"]([a-zA-Z0-9_.-]+)['"]\s*:\s*\{/g);
  console.log(`Fichier ${file}: ~${keyMatches ? keyMatches.length : 0} clés détectées.`);
}

// 2. Scan src/ for calls to t('...')
const srcDir = path.join(__dirname, '../src');
function walk(dir, fileList = []) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      if (file !== 'node_modules' && file !== 'dist') walk(fullPath, fileList);
    } else if (file.endsWith('.tsx') || file.endsWith('.ts')) {
      fileList.push(fullPath);
    }
  }
  return fileList;
}

const allSrcFiles = walk(srcDir);
console.log(`\nTotal fichiers source TypeScript analysés: ${allSrcFiles.length}`);

const tCalls = new Set();
const componentsWithoutUseLanguage = [];
const componentsWithHardcodedFrench = [];

const frenchPatterns = [
  /Rechercher\b/i,
  /Connexion\b/i,
  /Déconnexion\b/i,
  /Inscription\b/i,
  /Joueurs?\b/i,
  /Recrutement\b/i,
  /Détection\b/i,
  /Télécharger\b/i,
  /Enregistrer\b/i,
  /Annuler\b/i,
  /Confirmer\b/i,
  /Fermer\b/i,
  /Suivant\b/i,
  /Précédent\b/i,
  /Voir plus\b/i,
  /Consulter\b/i,
  /Partager\b/i,
  /Modifier\b/i,
  /Supprimer\b/i,
  /Chargement\b/i,
  /Envoyer\b/i
];

for (const f of allSrcFiles) {
  if (f.includes('/translations/')) continue;
  const content = fs.readFileSync(f, 'utf8');
  const relativePath = path.relative(srcDir, f);

  // Check t('key')
  const matches = content.matchAll(/\bt\(\s*['"]([^'"]+)['"]/g);
  for (const m of matches) {
    tCalls.add(m[1]);
  }

  // Check if component uses useLanguage
  if (f.endsWith('.tsx')) {
    if (!content.includes('useLanguage') && !content.includes('LanguageContext') && !f.includes('main.tsx')) {
      // Check if it has text in JSX
      if (content.includes('<') && content.includes('>')) {
        componentsWithoutUseLanguage.push(relativePath);
      }
    }
  }
}

console.log(`\nTotal clés uniques appelées via t('...'): ${tCalls.size}`);
console.log(`Composants JSX sans useLanguage: ${componentsWithoutUseLanguage.length}`);
componentsWithoutUseLanguage.slice(0, 15).forEach(c => console.log(`  - ${c}`));
